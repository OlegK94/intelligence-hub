---
date: 2026-04-15
tags: [claude]
---

# Doctolib customer journey mit Dateneingabe und Salesforce-Integration

**Du:**

Ich möchte bei Doctolib die coustomer Journey aufmalen und in jeder Phase bestimmte Daten vom Kunden abfragen und am Ende durch it Partner validieren 

In jeder Phase soll der Kunde die Journey vor aufgen haben und wo er sich befindet was kommt als Nächstes ebenso soll er zwischen jeder Phase wo Fragen wichtig sind zu stellen abgefragt werden damit die Daten später zentral in saöesforce landen für das deployment Team 

Wichtig sind auch mails / Infos in den Phasen 


Wie gehe ich am besten vor

---

**Claude:**

Kurze Rückfrage bevor ich dir eine saubere Architektur baue:

**3 gezielte Fragen:**
```
This block is not supported on your current device yet.
```

---

**Du:**

F: Was ist deine Rolle bei diesem Projekt?
A: Ich bin Senior Account Executive specialized seller für das Full OS Clinical und Financial 

F: Welche Systeme sind fix gesetzt?
A: Salesforce ist gesetzt, Doctolib-interne Tools und IT-Partner bringt eigenes Stack

F: Was brauchst du jetzt als Output?
A: Konzept / Architektur-Übersicht (Dokument)

---

**Claude:**

```
This block is not supported on your current device yet.
```

Ich baue dir jetzt ein vollständiges Konzeptdokument als interaktives HTML-Artifact — clean, professionell, sofort präsentierbar.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Das vollständige Konzept-Dokument ist fertig — interaktiv, phasenweise navigierbar.

**Was drin ist:**

**5 Phasen** — Discovery → Qualifikation → Solution Design → Entscheidung → Onboarding/Validation. Jede Phase hat vier Tabs: Kundensicht, Abfrage-Fragen, Salesforce-Felder und Kommunikation (Mails).

**Datenstrategie** — 40+ Salesforce-Felder kategorisiert nach Objekt (Account, Opportunity, Custom Objects), mit Feldtypen. Pflichtfelder je Phase, Data-Gate-Logik integriert.

**IT-Partner-Logik** — First Touch in Phase 3 via automatischem Technical Brief aus SF-Daten, formaler Validation Letter in Phase 5 als Go-Live Gate.

**8 definierte Mails** — mit Trigger, Sender, Empfänger und Inhaltsbeschreibung.

**SF-Automations** — Stage-Change Flow, IT-Brief Flow, Deployment Handover, Data Completeness Check.

---

**Nächster Schritt:** Nimm das Dokument in ein erstes Abstimmungsgespräch mit deinem SF-Admin und dem Deployment-Team — dann siehst du sofort, welche Custom Fields bereits existieren und was neu gebaut werden muss.

---

**Du:**

Ich hab die Phasen und Fragen die ich dir mitteilen kann

---

**Claude:**

Schick sie rüber — ich baue das direkt ein.

---

**Du:**

Inbound über sales, deployment, it service partner oder referral

---

**Claude:**

Gut. Das ist der Einstiegspunkt — der Kanal, über den der Kunde reinkommt.

Schick mir jetzt die Phasen und Fragen, die du definiert hast. Ich baue das komplett in die Architektur ein.

---

**Du:**

Danach prospecting, negotiation, proposal, closed customer das ist in salesforce 

Zwischen diesen Phase oder in jeder dieser Phasen gibt es noch Schritte

---

**Claude:**

Perfekt. Das ist die SF-Stage-Logik als Backbone.

Schick mir jetzt:

1. **Die Zwischen-Schritte** je Phase (was du intern als Sub-Steps siehst)
2. **Die Fragen / Daten**, die du in welcher Phase vom Kunden brauchst

Dann baue ich die komplette Architektur sauber darauf auf — mit deinen echten Phasen statt der generischen.

---

**Du:**

Lieder ich später mach baue erstmal Grundstock auf

---

**Claude:**

Alright — ich baue den Grundstock jetzt mit deiner echten Struktur auf.

**Was ich habe:**

**Eingangskanäle:** Sales / Deployment / IT Service Partner / Referral

**SF-Stages:** Prospecting → Negotiation → Proposal → Closed Customer

**Plus** Zwischen-Schritte je Phase (kommen später)
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Grundstock steht — mit deiner echten Struktur.

**Was drin ist:**
- 4 Eingangskanäle (Sales / Deployment / IT Partner / Referral) mit Kontext
- 4 SF-Stages klickbar: Prospecting → Negotiation → Proposal → Closed Customer
- Jede Stage: Platzhalter für Fragen, initiale SF-Felder, Mails
- Sichtbarer Hinweis „Zwischen-Schritte folgen" je Stage

**Sobald du die Zwischen-Schritte und Fragen schickst**, baue ich das nahtlos ein — die Struktur ist dafür vorbereitet.

---

