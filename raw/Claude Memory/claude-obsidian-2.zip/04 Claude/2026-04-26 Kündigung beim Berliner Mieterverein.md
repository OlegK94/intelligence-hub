---
date: 2026-04-26
tags: [claude]
---

# Kündigung beim Berliner Mieterverein

**Du:**

formuliere eine Kündigung an den Berliner Mieterverein


Knden nummer 12533367
 __[bmv@berliner-mieterverein.de](mailto:bmv@berliner-mieterverein.de)__

---

**Claude:**

```
This block is not supported on your current device yet.
```

Zwei Varianten — je nach Absicht:

**Ordentliche Kündigung** → zum nächstmöglichen Termin (typisch: Jahresende, Frist 3 Monate). Standardfall.

**Außerordentliche Kündigung** → fristlos, z.B. wenn du ARAG bereits als vollwertigen Ersatz hast und keinen Mehrwert mehr siehst.

Denk daran, deinen **Nachnamen** noch einzutragen. Empfehle zusätzlich per **Einschreiben** zu senden — bei Mitgliedschaftskündigungen immer sauberer als nur per E-Mail.

---

