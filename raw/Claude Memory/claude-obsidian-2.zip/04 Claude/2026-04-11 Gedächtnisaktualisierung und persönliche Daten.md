---
date: 2026-04-11
tags: [claude]
---

# Gedächtnisaktualisierung und persönliche Daten

**Du:**

Ich habe mein Gedächtnis aktualisiert. Was hast du über mich gelernt?

---

**Claude:**

```
This block is not supported on your current device yet.
```

Hier ist eine kompakte Zusammenfassung dessen, was ich über dich weiß — sowohl aus meinen eigenen Gesprächsnotizen als auch aus deinen manuellen Memory Edits:

---

**Zur Person**
Du heißt Oleg, wohnst in Berlin (geb. 30. Januar 1994), lebst mit deiner Freundin zusammen und hast einen Weimaraner. Du trainierst regelmäßig (Kraftsport, Laufen, weighted Calisthenics) und trackst alles mit der Apple Watch Ultra.

**Beruf & Finanzen**
Gehaltsstruktur mit Fixanteil + Provision, Firmenwagen (Golf 7, 1%-Regel). Du hast eine Holding-Struktur aufgebaut (ok-holding.com / Capital UG / Wagglz GmbH) und nutzt Google Workspace Standard als produktives E-Mail-Hub.

**Laufende Projekte / Themen**
- **ARYS** – Lifestyle-Brand-Projekt (Brandbook, Website, Produktionspartner in Portugal/Türkei)
- **Bett & Matratze** – auf der Suche nach einem Hybrid-Modell mit Zonenaufbau H3/H4 + elektrischem Lattenrost
- **Mietrechtsstreit** – Schimmel, Bauschäden, Sicherheitsmängel; Mitglied Berliner Mieterverein, ARAG-Rechtsschutz
- **JGA für Hai** – 15.–17. Mai, ~8 Personen, Haus mit Pool & Sauna in Brandenburg oder Polen

**Tools & Ökosystem**
Ausschließlich Apple-Geräte, privacy-affin (Proton, Mullvad, Brave), aber pragmatisch. Setup: Google Workspace + 1Password + Proton VPN.

**Stil**
NYC Preppy-meets-Streetwear à la Aimé Leon Dore — Noah NY, Norse Projects, A.P.C., Ami Paris.

---

Gibt es etwas, das du korrigieren oder ergänzen möchtest?

---

**Du:**

Tools nut Apple Ökosystem und PRoton VPN + Authenticator + Proton Meet

 später wenn alles besser wird ziehe ich alles um

Mullvad und brave nutze ich nicht

Google workspace nut für meien Firma

1 Passowrd ist raus

Aime leon dore mag ich trage ich aber nicht den rest auch nicht

---

**Claude:**

Danke für die Korrekturen — ich aktualisiere das jetzt.
```
This block is not supported on your current device yet.
```

Das Memory-Edit-Feld hat ein Zeichenlimit, ich kann den Block nicht als Ganzes ersetzen. Ich speichere die Korrekturen stattdessen als separaten Eintrag:
```
This block is not supported on your current device yet.
```

Gespeichert. Kurz zusammengefasst was ich korrigiert habe:

- **Tools:** Apple-Ökosystem + Proton VPN, Authenticator & Meet — das ist dein aktueller Stack
- **Mullvad & Brave:** nicht genutzt
- **Google Workspace:** nur für die Firma, nicht privat
- **1Password:** raus, kein Passwort-Manager aktuell
- **Menswear:** ALD & Co. als stilistische Inspiration, nicht als Marken die du trägst
- **Langfristiger Plan:** alles sauber umziehen wenn die Zeit kommt

Was trägst du eigentlich aktuell so, wenn ich fragen darf? Oder hast du da noch nichts Festes?

---

**Du:**

Arys ist hier nur ein prototyp wird aber noch besser aufgebaut von der designerin

---

**Claude:**

Verstanden — ARYS ist im Aufbau, der bisherige Prototyp war nur ein erster Entwurf, und die Designerin übernimmt jetzt den professionellen Aufbau.
```
This block is not supported on your current device yet.
```

Gespeichert. Wenn die Designerin fertig ist und du Feedback, Texte oder Content für ARYS brauchst, bin ich dabei.

---

**Du:**

Password manager nutze ich auch von proton

---

**Claude:**

Danke — also Proton Pass, logisch.
```
This block is not supported on your current device yet.
```

Gespeichert. Dein aktueller Stack ist dann: Apple-Ökosystem + Proton VPN, Authenticator, Meet und Pass — alles unter einem Dach. Sauber.

---

