---
date: 2026-04-24
tags: [claude]
---

# Catch-all in Proton Mail aktivieren

**Du:**

Wie aktiviere ich catch all in proton hab DNS, und adressen sind eingestellt

---

**Claude:**

```
This block is not supported on your current device yet.
```

Direkt und knapp — da DNS und Adressen bereits eingestellt sind, brauchst du nur noch diesen einen Schritt:

---

## Catch-All in Proton Mail aktivieren

**Settings → All Settings → Organization → Domain names**

Im Dropdown-Menü **„Actions"** neben deiner Domain → **„Set catch-all"** auswählen → dann eine Zieladresse eingeben, die zu deiner Domain gehört (z.B. `oleg@ok-holding.com`).

Ab sofort landet alles, was an eine nicht explizit angelegte Adresse deiner Domain gesendet wird, in diesem Postfach.

---

**Tipp:** Empfehlenswert ist eine dedizierte Adresse wie `catchall@ok-holding.com` oder `accounts@ok-holding.com` — damit der Catch-All-Traffic nicht deinen Haupt-Inbox vollmüllt. Du hast `accounts@` bereits als Alias — das würde sich anbieten.

**Wichtig zu wissen:** Catch-All ermöglicht nur *Empfangen* an beliebige Adressen. Antworten oder Senden *von* einer beliebigen Wildcard-Adresse ist aktuell nicht möglich — nur von Adressen, die explizit angelegt wurden.

---

**Nächster Schritt:** Teste es sofort — schick eine Mail an eine Fantasie-Adresse deiner Domain (z.B. `test123@ok-holding.com`) und prüf ob sie im Catch-All-Postfach landet.

---

**Du:**

muss ich warten bis die DNS einträge durch sind da es nicht angezeigt wird

---

**Claude:**

Ja, sehr wahrscheinlich.

**Was passiert gerade:** Proton verifiziert die Domain erst, wenn die DNS-Einträge (MX, SPF, DKIM) korrekt propagiert sind. Solange die Verifikation nicht grün ist, wird die „Set catch-all"-Option im Actions-Menü nicht angezeigt.

**Wartezeit:** Typisch 15 Minuten bis 4 Stunden, je nach Registrar. Maximal 48h, aber das ist selten.

**Sofort-Check:**
Geh auf [dnschecker.org](https://dnschecker.org) → gib deine Domain ein → prüf ob die MX-Einträge weltweit schon sichtbar sind. Wenn ja, einmal in Proton Settings die Domain-Verifikation manuell neu anstoßen (dort gibt es einen „Verify"-Button).

Sobald der Status auf „Verified" / grün springt, erscheint Catch-All automatisch im Dropdown.

---

**Du:**

ich hab probleme beim portieren der yahoo mails für Hai von yahoo zu proton 

Er sagt das 

ungültige anmeldedaten sind

---

**Claude:**

Das ist ein bekanntes Yahoo-Problem. Yahoo blockiert normale Passwörter für IMAP-Zugriff — Proton Mail Easy Switch (oder jeder andere IMAP-Import) braucht ein **App-Passwort**, nicht das reguläre Yahoo-Passwort.

---

## Lösung: Yahoo App-Passwort erstellen

Hai muss das auf seinem Yahoo-Account machen:

1. [login.yahoo.com](https://login.yahoo.com) → einloggen
2. **Account Security** → (Suchfeld: „App password" oder direkt: [yahoo.com/account/security](https://yahoo.com/account/security))
3. **„Generate app password"** → Kategorie: „Mail" → Gerät: „Other" → beliebigen Namen eingeben (z.B. „Proton Import")
4. Das generierte **16-stellige Passwort** kopieren

Dann in Proton Easy Switch dieses App-Passwort statt dem normalen Passwort eingeben — fertig.

---

**Voraussetzung:** Yahoo-Account muss 2FA aktiviert haben, sonst erscheint die App-Passwort-Option nicht. Falls 2FA aus ist → erst 2FA aktivieren, dann App-Passwort generieren.

**Nächster Schritt:** Hai generiert das App-Passwort und ihr versucht den Import erneut.

---

**Du:**

wie nutze ich vertical tabs in brave

---

**Claude:**

**Einstellungen → Appearance → „Show vertical tabs"** — das wars.

Oder schneller: Rechtsklick auf die Tab-Leiste oben → **„Use vertical tabs"**.

Die Tabs wandern dann in eine ein-/ausklappbare Seitenleiste links. Mit dem Pfeil-Icon oben in der Leiste kannst du sie kollabieren wenn du mehr Platz brauchst.

---

**Du:**

ist ausgegraut geht nicht

---

**Claude:**

Dann ist wahrscheinlich eine Policy oder Flag aktiv die es blockiert. Schnell-Check:

**1. brave://flags** aufrufen → Suchfeld: `vertical` → schau ob `Vertical Tabs` auf **Disabled** steht → auf **Enabled** setzen → Relaunch.

**2. Falls immer noch ausgegraut:**
brave://policy aufrufen → prüf ob dort irgendwas zu Tabs oder UI auftaucht. Wenn ja, kommt die Sperre von einer externen Policy (z.B. Managed-Gerät).

Welches Betriebssystem — Mac oder Windows?

---

**Du:**

wo kannn die einstellung der policy sein

---

**Claude:**

Auf dem Mac:

**Terminal öffnen** → eingeben:
```
defaults read com.brave.Browser
```
Dort nach `VerticalTabsAllowed` oder ähnlichem suchen.

Oder direkt prüfen ob eine Managed Policy-Datei existiert:
```
ls /Library/Managed\ Preferences/com.brave.Browser.plist
```

Wenn die Datei existiert → wird Brave von einem MDM (z.B. Jamf, Mosyle) verwaltet und die Einstellung ist von außen gesperrt. Das wäre dann nur durch den Admin änderbar.

---

**Wahrscheinlichster Fall bei dir:** Du nutzt ein privates MacBook ohne MDM — dann liegt es eher an brave://flags. Hast du dort nachgeschaut? Was zeigt es bei `vertical`?

---

