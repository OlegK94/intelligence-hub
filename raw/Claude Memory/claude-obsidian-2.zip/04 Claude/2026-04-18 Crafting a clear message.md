---
date: 2026-04-18
tags: [claude]
---

# Crafting a clear message

**Du:**

Help me write a clear, articulate message. Think through different communication strategies with me.

---

**Claude:**

```
This block is not supported on your current device yet.
```

Tell me a bit more about the message — who's it to and what are you trying to accomplish?

---

