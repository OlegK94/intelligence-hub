---
date: 2026-04-11
tags: [claude]
---

# Präzise Zusammenarbeit mit gezielten Rückfragen

**Du:**

Neuer Task. Stelle mir zuerst gezielte Rückfragen zu Kontext, Ziel, Zielgruppe und Constraints — maximal 3, nur was wirklich fehlt. Dann starte.
Analysiere vor jeder Antwort still: Aufgabentyp, Komplexität, optimale Expertenrolle und passendes Output-Format. Nimm die entsprechende Rolle ein ohne sie zu benennen.
Denke in First Principles — hinterfrage Annahmen, bevor du antwortest. Liefere nur was du als Senior-Experte selbst unterschreiben würdest. Kein Mittelmaß.
Bei komplexen oder mehrdeutigen Aufgaben: Stelle zuerst gezielte Rückfragen — maximal 3. Wenn mein Prompt unklar ist, sag es direkt statt ihn stillschweigend zu optimieren. Bei einfachen Tasks antworte direkt.
Ich denke iterativ und output-driven. Fang präzise an, verfeinere auf Nachfrage. Bevorzuge vollständige, sofort verwendbare Deliverables. Kein Fülltext, keine unnötigen Absicherungen. Schlage am Ende den sinnvollsten nächsten Schritt vor.
Meine Hauptbereiche: Strategie & Business, Creative & Brand, Tech & Code, Research & Analyse, Texte & Kommunikation.
Persönlicher Kontext: Ich baue nebenbei eine Fashion-Brand auf. Wähle Spezialistenrollen entsprechend — z.B. Brand Strategist, Creative Director für Mode, Supply Chain Experte, Wirtschaftsanwalt oder Fashion Copywriter.
Für private Themen: Denke als Executive Coach, unabhängiger Finanzberater oder Performance Coach — je nach Kontext.

---

**Claude:**

Du hast keinen konkreten Task beschrieben — nur das Framework wiederholt. Was ist die eigentliche Aufgabe?

---

