---
date: 2026-04-06
tags: [claude]
---

# Meal prep kaufen oder selbst kochen

**Du:**

Prüfe bitte für mich ob es sich lohnt prep my meal zu kaufen vs selbst kochen

Ich baue Muskeln auf und gehe 5-6x trainieren

---

**Claude:**

```
This block is not supported on your current device yet.
```

Hier ist meine ehrliche Einschätzung für deinen Fall:

---

**Kosten: PrepMyMeal vs. selbst kochen**

Die Preise liegen bei **8,49 – 9,90 € pro Gericht** (einzelne Portion), also ca. 5,24 – 5,99 € pro Portion bei XL-Gerichten.

Zum Vergleich: Selbst gekochte High-Protein-Mahlzeiten (Hähnchen/Reis/Gemüse) kosten dich in Berlin realistisch **2,50 – 4 €** pro Portion bei vernünftiger Qualität.

Bei **2 Mahlzeiten/Tag × 30 Tage** bedeutet das:
- PrepMyMeal: ~**500 – 600 €/Monat**
- Selbst kochen: ~**150 – 240 €/Monat**

**Differenz: ca. 300 – 400 € mehr pro Monat**

---

**Für Muskelaufbau ist der Service gut geeignet**

Die Muskelaufbau-Gerichte enthalten mindestens 35 g Eiweiß pro Packung – das ist solide. Die präzisen Nährwertangaben machen das Kalorienzählen überflüssig und erleichtern die Einhaltung einer spezifischen Ernährungsweise.

---

**Wo der Haken liegt**

Der größte Kritikpunkt ist der Preis – es ist ein Premium-Service. Außerdem können die Portionen für sehr hungrige Menschen nach hartem Training etwas klein sein. Bei 5-6x Training pro Woche brauchst du wahrscheinlich mehr als eine Portion pro Mahlzeit.

Außerdem gibt es ein systematisches Problem mit dem Abo-Modell – Kündigung und Pausierung solltest du dir genau durchlesen.

---

**Mein Fazit für dich**

Es kommt auf eine Frage an: **Wie viel ist dir deine Zeit wert?**

Laut PrepMyMeal sparst du bis zu 22 Stunden Kochzeit pro Monat. Wenn du diese Zeit produktiv nutzt (für ARYS, Training, etc.) und 300-400 €/Monat gut verkraften kannst – kann es sich rechnen.

**Bessere Alternative für deinen Fall:** Klassisches Meal Prep selbst machen – einmal pro Woche 2-3 Stunden kochen, 5-6 Tage versorgt. Das gibt dir volle Kontrolle über Kalorien, Protein und Kosten, und ist für ernsthaften Muskelaufbau oft sogar besser, weil du die Mengen selbst anpassen kannst.

---

