---
date: 2026-04-08
tags: [claude]
---

# Fashion Brand mit maßgeschneidertem Fit

**Du:**

Ich überlege, eine Fashion Brand zu gründen. Die das Problem der Männer und Frauen löst, und zwar mit dem Fit und den Maßen der Kleidung. Ganz auf Basics. Schwarze, weiße T-Shirts, Unterhosen, Socken und Hosen. Wie kann ich das Problem am besten lösen? Ich deinen externen Schreiner Schreiner sag ich Schneider, dazuholen. Kann ich das in Techpacks schon so gut gestalten, dass ich 'n SM XXL verkaufe zum Beispiel. Hat den perfekten Fitfinder, den Problem ist halt oft bei Frauen und Männern, dass das in den Ärmeln nicht passt, dass die zu kurz, zu lang sind oder zu schmal. Zu weit. Zu generell sind, vorne am Bauch zu stark abstehen, Und ich möcht das Problem lösen, eine tolle Brand daraus kreieren mit 'nem Mehrwert. Und 'nem vernünftigen USP. Und vor allem aber auch dass man die Brand weiter ausbaut, wo man später wie Emily Leodor ein Café Label Stores und Ähnliches anbietet. Upcycling und Reparatur Sprich, man kann beispielsweise in eigenen Stores 'n Schneiderservice anbieten, oder dass man dort gewisse Maße noch mal anpasst, so ähnlich wie zum Beispiel. Was würdest Du mir konkret empfehlen? Welche Lösung gibt es schon aufm Markt? Was können wir da machen?

---

**Claude:**

```
This block is not supported on your current device yet.
```

Sehr gute Idee — und du hast das Problem wirklich präzise erkannt. Lass mich das strukturiert aufdröseln.

---

## Das Problem (dein USP-Kern)

Standardgrößen (S–XXL) basieren auf **Durchschnittskörpern**, die es kaum gibt. Ergebnis:
- Ärmel zu lang/kurz
- Schulternaht sitzt falsch
- Bauch bauscht sich auf
- Unterwäsche schneidet ein oder fällt herunter
- Hosen passen in der Taille aber nicht im Schritt — oder umgekehrt

Das ist ein **universelles, gelöstes-aber-nicht-wirklich-gelöstes Problem** — ideal für eine Brand mit starkem USP.

---

## Was es schon gibt

**Im Premiumbereich:**
- **Proper Cloth / Ministry of Supply** — made-to-measure, aber teuer und nicht lifestyle-orientiert
- **Uniqlo** — exzellente Passform durch viele Sub-Sizes, aber kein Branding, kein Lifestyle
- **Buck Mason** — Fit-First-Basics, aber nur USA und kein Customization

**Im Technologie-Bereich:**
- **True Fit / Fit Analytics** — B2B-Tools für andere Brands, kein eigenes Produkt
- **Levi's Lot No. 1** — Custom-Jeans via 3D-Scan, aber sehr niche

**Niemand** kombiniert bisher: **Premium Lifestyle Brand + Fit-System + In-Store-Schneider + Community Ecosystem** — da ist deine Lücke.

---

## Meine konkrete Empfehlung: Das 3-Ebenen-Modell

### Ebene 1 — Produkt: Smarter Size-Split

Statt S/M/L/XL arbeitest du mit **Compound Sizes**:

```
Größe = Körperbau + Länge
Beispiel: M-tall / M-slim / M-regular
```

Das bedeutet:
- **3–4 Schnittmuster pro Garment**, nicht nur eines
- In Techpacks definierst du für jeden Fit separate Gradierungsregeln (grading rules)
- Ärmel, Schulter und Body werden **unabhängig** gegradet

Das ist technisch machbar mit einem erfahrenen Schneider und sauber dokumentierten Techpacks. Dein Schneider wird dein wichtigster früher Partner.

### Ebene 2 — Digital: Fit Finder

Kein Quiz ("wie passt du normalerweise?") — sondern **körperbasiert**:

- Nutzer gibt 3–4 Maße ein: Brustumfang, Ärmellänge, Schulterbreite, Taillenumfang
- Der Finder matched auf deinen nächsten Schnitt
- Optional: Foto-Scan via Handy (spätere Phase, Technologie vorhanden z.B. via **3DLOOK API**)

### Ebene 3 — Store: Schneider-Service

Genau wie du sagst — **in-store tailoring** als Markenversprechen:

- Kauf online → passt nicht perfekt → bringe es in den Store → kostenlose oder günstige Anpassung
- Das ist ein **Retention-Tool**, kein Kostenfaktor
- Macht aus Käufern Fans

---

## Techpack-Logik für deinen Schneider

Ja, du kannst das sehr präzise in Techpacks lösen. Für jedes Garment brauchst du:

1. **Base size** (z.B. M-regular) mit allen Maßen in cm
2. **Grading table** — wie sich jede Naht pro Size ändert
3. **Fit annotation** — wo der Garment sitzen soll (z.B. "shoulder seam sits on natural shoulder point, not forward")
4. **Construction notes** — Nahtzugaben, Stretch-Werte bei Jersey

Für einen guten portugiesischen Hersteller wie **ASBX oder Labwear** ist das Standard — die können dir auch helfen, den First Fit zu samplen und zu justieren.

---

## Ecosystem-Roadmap (dein ALD-Modell)

| Phase | Was |
|---|---|
| **Jahr 1** | Perfekten Fit für 2–3 Basics entwickeln (T-Shirt, Hose, Unterwäsche) |
| **Jahr 2** | Fit Finder online + Pop-up mit Schneider-Service |
| **Jahr 3** | Erster eigener Store mit Café-Element + Repair-Service |
| **Jahr 4+** | Label, Kollaborationen, Community Events |

---

## Mein ehrlicher Rat

Fang mit **einem einzigen Garment** an — z.B. das weiße T-Shirt in 3 Fits (slim / regular / relaxed), jeweils in Short/Regular/Long. Das sind 9 SKUs, aber du hast damit das stärkste Proof-of-Concept.

Willst du, dass ich dir einen **Techpack-Template-Aufbau** skizziere, einen **Fit-Finder-Prototypen** als Artifact baue, oder das **Brand-Konzept** für dieses Fit-First-Modell ausarbeite?

---

**Du:**

Wie wäre der sinnvollste und schlankste Weg einen perfekten MVP rauszubringen, hab jetzt eine Designerin die das Konzept Farben und Co aufbaut. Und komplett die Brand aufbaut und ich hätte auch eine Produktdesigner Runde ihr Produkte auch machen könnte. Und dann müssten wir quasi nur noch 'n Hersteller finden beziehungsweise auch Schneider, Je nach Ich würd das Ganze so minimal halten vom Investment, hab nicht so viel Geld. Daher möcht ich das so schlank wie möglich aufbauen.

---

**Claude:**

Sehr smart, dass du es schlank halten willst. Hier ist der direkteste Weg:

---

## Die ehrliche MVP-Wahrheit

Du brauchst für einen echten Fit-MVP **nicht** S-XXL in allen Varianten. Du brauchst **einen Schnitt, perfekt sitzend, eine Farbe**.

---

## Der schlankste Weg — Schritt für Schritt

### Schritt 1 — Einen Schneider vor Ort finden (Berlin)

Noch vor dem Hersteller. Ein lokaler Schneider/Patternmaker hilft dir:
- Den **Musterschnitt** zu entwickeln (Sloper)
- 2–3 Fit-Prototypen zu nähen und anzupassen
- Das Ergebnis in ein sauberes **Techpack** zu übersetzen

Kosten: 500–1.500€ für Schnittentwicklung + Samples. Das ist dein wertvollstes Investment.

### Schritt 2 — Ein einziges Produkt, drei Fits

Nur **ein T-Shirt**. Schwarz oder weiß, nicht beides.

Drei Schnitte: **Slim / Regular / Relaxed** — das löst bereits 80% des Fit-Problems ohne explodierende SKUs.

Keine Längen-Varianten in Phase 1. Zu komplex, zu teuer.

### Schritt 3 — Kleinserie in Portugal

ASBX, Labwear oder ähnliche — die machen **Mindestmengen ab 30–50 Stück pro Style**. Das heißt:

- 3 Fits × 5 Größen × 10 Stück = **150 T-Shirts als erster Run**
- Kosten pro Stück bei guter Qualität: ca. 15–25€
- **Gesamtinvestment Produktion: 2.500–4.000€**

### Schritt 4 — Kein eigener Store, kein Lager

Verkauf nur **online, direkt, made-to-order oder limitiert**. Kein Lagerrisiko.

Ein einfacher Shopify-Store reicht. Deine Designerin baut das Visual, du brauchst keine Agentur.

### Schritt 5 — Fit Finder minimal

Kein Tech-Tool zu Beginn. Stattdessen:
- Eine **einfache Maßtabelle** mit 3 Körpermaßen
- Ein klarer Guide: "Wenn dein Brustumfang X und deine Schulterlänge Y ist, nimm Slim"

Das ist skalierbar und kostet nichts.

---

## Budget-Übersicht MVP

| Posten | Kosten |
|---|---|
| Schneider / Patternmaker Berlin | 500–1.500€ |
| Samples (3–5 Stück zum Testen) | 300–600€ |
| Erster Produktionslauf (150 Stück) | 2.500–4.000€ |
| Shopify + Domain | 50€/Monat |
| Fotografie | 500–1.000€ |
| **Gesamt** | **~4.000–7.000€** |

Designerin und Produktdesigner hast du bereits — das spart dir locker 5.000–10.000€.

---

## Was du NICHT brauchst in Phase 1

- Unterwäsche und Socken → kommen in Phase 2
- Hosen → zu komplex für MVP
- In-Store Schneider → Phase 3
- Café, Label, Events → Vision ja, Investment nein

---

## Nächster konkreter Schritt

**Einen Patternmaker/Schneider in Berlin finden** — am besten jemand mit Erfahrung in Menswear-Basics und der Techpack-Sprache spricht.

Soll ich dir eine Liste von relevanten Adressen/Kontakten in Berlin recherchieren, oder direkt einen **Briefing-Template** für deine Designerin und den Produktdesigner ausarbeiten, damit alle vom gleichen Stand starten?

---

**Du:**

Wie kann ich es aufbauen das es nicht zu teuer wird aber auch skalierbar ist und kompetetiv gegen Marken wie Uniqlo Snocks etc

---

**Claude:**

Gute Frage — das ist eigentlich der härteste Teil. Denn Uniqlo und Snocks gewinnen über **Volumen und Infrastruktur**, die du nicht hast. Du kannst nicht günstiger sein. Du musst **anders** gewinnen.

---

## Dein eigentlicher Wettbewerbsvorteil

Uniqlo löst Fit durch viele Größen, aber **ohne Persönlichkeit**.
Snocks gewinnt über Preis und DTC-Marketing, aber **Fit ist generisch**.

Du gewinnst über: **Fit + Brand + Community**. Das ist die einzige realistische Lücke.

---

## Das Skalierbarkeits-Problem ehrlich betrachtet

Das Kernproblem bei Fit-Varianten:

- Mehr Fits = mehr SKUs = mehr Kapital gebunden
- Mehr Kapital = mehr Risiko bei kleinem Budget

Die Lösung ist **nicht weniger Qualität**, sondern **weniger Produkte mit höherem Preis**.

---

## Das Modell das funktioniert

### Preisstrategie

| | Snocks | Uniqlo | Du |
|---|---|---|---|
| T-Shirt | 8–12€ | 15–20€ | 45–65€ |
| Positionierung | Preis | Volumen | Fit + Brand |

Du konkurrierst **nicht** im Preiskampf. Du bist premium — aber **begründet premium**. Der Fit ist die Begründung.

### Margins die dich am Leben halten

- Herstellungskosten: ~20–25€
- Verkaufspreis: 55–65€
- Marge: ~60–65% → gesund für DTC

Das funktioniert aber **nur** wenn deine Brand stark genug ist, dass jemand 60€ für ein T-Shirt ausgibt. Deshalb ist die Arbeit deiner Designerin gerade das Wichtigste.

---

## Skalierbarkeit ohne großes Kapital

### Modell 1 — Pre-Order (empfohlen für Phase 1)

- Du zeigst das Produkt, nimmst Bestellungen an
- Produzierst erst wenn genug Orders da sind
- **Kein Lagerrisiko, kein totes Kapital**
- Nachteil: Lieferzeit 4–6 Wochen — musst du kommunizieren

### Modell 2 — Capsule Drops

- Statt durchgehendem Sortiment: **limitierte Drops**
- 100–200 Stück, ausverkauft, nächster Drop
- Schafft Dringlichkeit, hält Lager klein
- ALD macht das genauso

### Modell 3 — Community vor Produkt

- Erst Audience aufbauen (Instagram, Newsletter)
- Dann verkaufen an Menschen die bereits warten
- Kostet Zeit, nicht Geld

---

## Wie du gegen Uniqlo skalierst — langfristig

Der einzige Weg ist **Vertikalisierung**, genau wie du es dir vorstellst:

```
T-Shirt → Hose → Unterwäsche
    ↓
Eigener Store mit Schneider
    ↓
Café + Community
    ↓
Label / Kollaborationen
```

Jede Stufe **finanziert die nächste**. Niemals alles gleichzeitig.

---

## Konkret: Was macht dich skalierbar ohne Kapital

1. **Shopify** von Anfang an — sauber, skalierbar, kein Custom-Dev
2. **Portugal-Hersteller** der mit dir wächst — Mindestmengen verhandeln, Beziehung aufbauen
3. **Kein Wholesale** in Phase 1 — zu schlechte Margen
4. **Ein Kernartikel** der perfektioniert wird bevor du erweiterst
5. **Content ist dein Marketing** — kein Paid Ads Budget nötig wenn Designerin stark ist

---

## Die eine Frage die alles entscheidet

Wer ist dein erster Kunde genau?

- Mann, 28–38, Berlin/München/Wien
- Gibt 60€ für ein T-Shirt aus wenn der Fit stimmt
- Folgt Brands wie ALD, Norse Projects, Our Legacy

Wenn du diese Person kennst und erreichst, ist alles andere lösbar. Soll ich dir helfen das **Kundenprofil** und die **Go-to-Market Strategie** für den Launch auszuarbeiten?

---

**Du:**

Es soll qualitativ aufjedenfall hochwertig sein das die Sachen lange halten und nicht kaputt gehen oder verwaschen 

Wenn das besteht dann können Menschen auch mehr Geld ausgeben

---

**Claude:**

Genau richtig gedacht — das ist eigentlich die solideste Brand-Logik überhaupt.

**"Kauf einmal, trag es 5 Jahre"** schlägt Fast Fashion nicht im Preis, aber im Wert.

---

## Was Qualität bei Basics wirklich bedeutet

### Stoff — das Wichtigste überhaupt

Für T-Shirts:
- **180–220g/m² Baumwolle** minimum — alles drunter wird dünn nach 10 Wäschen
- **Combed & Ring-spun Cotton** — glatter, haltbarer, weicher
- **GOTS-zertifiziert** wenn möglich — nachhaltiger Anbau, keine Chemikalien die ausblassen
- **Keine OE-Baumwolle** (Open End) — billiger, aber reißt schneller

Für Schwarz das nie verblasst:
- **Reactive Dyeing** statt Pigment Dyeing — sitzt tiefer in der Faser
- **Fixiermittel** im Färbeprozess — hält Farbe bei vielen Wäschen
- Das musst du explizit im Techpack spezifizieren

### Nähte — wo billige Sachen zuerst kaputtgehen

- **Doppelnaht** an Ärmeln und Saum minimum
- **Flachnaht (flatlock)** an Schulter und Seitennähten — kein Scheuern, kein Auftrennen
- **Kettelstich** am Halsausschnitt — dehnt sich mit, reißt nicht

### Waschbeständigkeit — konkret testbar

Vor Produktion lässt du **Wash Tests** machen:
- 20× Maschinenwäsche bei 40°
- Farbmessung vorher/nachher
- Schrumpfung messen

Das ist Standard bei guten portugiesischen Herstellern — einfach anfragen.

---

## Was das kommunikativ bedeutet

Du verkaufst nicht ein T-Shirt. Du verkaufst **Cost-per-Wear**:

> *"Unser T-Shirt kostet 60€. Nach 200 Wäschen sieht es noch gleich aus. Das sind 0,30€ pro Trag."*

Das ist ein Argument das sitzt — besonders gegen Leute die bei H&M 3 T-Shirts für 30€ kaufen und nach einem Jahr wieder neu kaufen.

---

## Qualitätsstrategie für jedes Produkt

| Produkt | Worauf achten |
|---|---|
| T-Shirt | Gramm, Dyeing-Methode, Doppelnaht |
| Hose | Fadengewicht, Bundverarbeitung, Knopflöcher |
| Unterwäsche | Elastikband-Qualität, Nahtführung, Stretch-Recovery |
| Socken | Nadelzahl (je höher desto feiner), Fersenverstärkung |

---

## Mein konkreter Rat

Bevor du mit dem Hersteller sprichst — **definiere mit deiner Designerin und dem Produktdesigner ein Qualitäts-Dokument**. Quasi ein internes Versprechen:

- Mindest-Gramm pro Produkt
- Erlaubte Materialien (und verbotene)
- Wash-Test Anforderungen
- Nahtstandards

Das wird Teil deines Techpacks und **unterscheidet dich vom ersten Tag an** von Brands die einfach was bestellen.

---

Willst du dass ich dir dieses **Qualitäts-Dokument als Template** ausarbeite — direkt nutzbar für deine Designerin und den Hersteller?

---

**Du:**

Ja bevor du das machst gibt es noch Punkte die wir beachten sollten

---

**Claude:**

Ja, sag mir alles — was liegt dir noch auf dem Herzen?

---

**Du:**

Prüfe was wir noch nicht bedacht haben

---

**Claude:**

Gute Idee, lass mich das systematisch durchgehen — was haben wir noch nicht angesprochen:

---

## Was wir noch nicht bedacht haben

### 1. Retouren-Strategie
Fit-Brand bedeutet automatisch **höheres Retouren-Risiko** — besonders online. Wenn jemand 3 Fits bestellt um zu schauen welcher passt, hast du ein Problem. Du brauchst:
- Klare Maßtabelle die Retouren **verhindert**
- Eine Retourenquote die du dir leisten kannst
- Eventuell: kostenpflichtige Retouren ab dem 2. Mal

### 2. Größen-Infrastruktur für Frauen vs. Männer
Du hast beides erwähnt — aber Frauen-Sizing ist **deutlich komplexer**. Brust, Hüfte, Taille variieren viel stärker. Eventuell zuerst nur **Menswear**, Womenswear als Phase 2.

### 3. Rechtliches
- **Markenanmeldung** deines Brandnamens (EUIPO, ca. 850€)
- **AGB, Widerrufsrecht, Impressum** — Pflicht in Deutschland/EU
- **Textilkennzeichnungspflicht** — jedes Garment braucht Materialetikett

### 4. Etiketten & Branding am Produkt
- Innenetikett, Wovenlabel, Hangtag
- Das kostet extra und braucht **Vorlaufzeit beim Hersteller**
- Muss mit deiner Designerin parallel entwickelt werden

### 5. Logistik & Fulfillment
- Wo lagerst du die Ware?
- Packst du selbst oder nutzt du ein **Fulfillment-Center**?
- Versandkosten und -zeiten kommunizieren

### 6. Waschanleitungen & Pflegehinweise
Pflicht auf jedem Kleidungsstück — und bei Qualitäts-Brand auch ein **Kommunikationsmittel**

### 7. Fotografiekonzept
Nicht nur Lookbook — du brauchst **Fit-Fotos** die zeigen wie die verschiedenen Schnitte am Körper sitzen. Verschiedene Körpertypen fotografieren.

### 8. Pricing-Psychologie
Hast du schon überlegt ob du **Bundle-Preise** machst? Z.B. 2 T-Shirts für 99€ statt 65€ einzeln — erhöht Average Order Value.

---

## Was davon ist für dich gerade am dringendsten?

Oder soll ich einfach das **Qualitätsdokument** jetzt aufbauen und diese Punkte dort wo relevant einarbeiten?

---

**Du:**

Retoure wird immer bezahlt beim zurücksenden vom Kunden 

Maßgeschneiderte Sachen garnixht retournieren 

Shirts in Maßen die gleiche Größen wie s m l cö haben können retourniert werden

---

**Claude:**

Sehr klar und sinnvoll. Das ist eine faire aber schützende Policy.

Kurz zusammengefasst wie ich das verstehe:

---

**Deine Retourenpolitik:**

- **Standard-Größen (S–XXL)** → Rücksendung möglich, aber **Porto zahlt der Kunde**
- **Maßgefertigte Produkte** → **Kein Rückgaberecht**, da individuell produziert — rechtlich in der EU auch so zulässig wenn klar kommuniziert vor dem Kauf
- **Begründung** die du kommunizierst: Fairness, Nachhaltigkeit, bewusster Konsum

---

Das ist auch **brandstrategisch stark** — es zwingt den Kunden dazu den Fit Finder ernstzunehmen bevor er bestellt. Das reduziert Retouren automatisch.

---

Gibt es noch weitere Punkte die du klären willst, bevor ich das Qualitätsdokument aufbaue? Oder soll ich jetzt starten?

---

