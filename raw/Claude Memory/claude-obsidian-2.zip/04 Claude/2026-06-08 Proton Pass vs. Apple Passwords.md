---
date: 2026-06-08
tags: [claude]
---

# Proton Pass vs. Apple Passwords

**Du:**

Was ist besser Proton Passwörter oder Apple

---

**Claude:**

The user is asking about Proton Passwords vs Apple (Keychain/Passwords app) for password management. Let me analyze this properly given what I know about Oleg - he's already in the Proton ecosystem (Proton Mail, Proton Pass, Proton VPN, Brave browser). So this is likely a validation question or he's reconsidering.

Let me give a sharp, opinionated analysis.

Key dimensions to evaluate:
1. Security architecture
2. Cross-platform / ecosystem lock-in
3. Privacy model
4. Features
5. Integration with his existing setup
Proton Pass uses end-to-end encryption for everything including metadata like email addresses and URLs, it's open source and audited, and works across all major platforms plus browser extensions—plus it integrates with his existing Proton setup and includes Hide-my-email aliases. Apple's Keychain is secure but doesn't offer the same level of E2E encryption since Apple holds the keys, though they do use hardware security modules and secure enclaves.

Given that Oleg already uses Proton Pass, has Brave set up, and is privacy-focused in Berlin with a full Proton ecosystem, Proton Pass is clearly the better fit for his needs.Für dein Profil: **Proton Pass, klar.**

**Warum Apple Passwords verliert**

Apple Keychain ist exzellent — innerhalb des Apple-Ökosystems. Sobald du einen Brave Browser nutzt, ein Android-Gerät anfasst oder irgendwann Linux brauchst, bist du angeschmissen. Die Windows-App ist ein Nachzügler, keine echte Lösung. Das ist kein Passwort-Manager, das ist ein Apple-Bindungsmittel.

Das eigentliche Problem: Apple verschlüsselt Inhalte E2E, aber die Metadaten (welche URL, wann, wie oft) sind deutlich schlechter geschützt als bei Proton. Für Privacy-sensitive Workflows ist das relevant.

**Warum Proton Pass gewinnt**

Drei Argumente, die wirklich zählen:

Erstens: Metadaten-Verschlüsselung. Proton verschlüsselt nicht nur Passwort und Benutzername, sondern auch URL, Notizen und E-Mail-Adressen. Apple nicht vollständig. Das ist der Kernunterschied im Threat Model.

Zweitens: Die integrierten E-Mail-Aliase (SimpleLogin-Technologie). Du generierst beim Registrieren direkt eine Wegwerf-Adresse — das reduziert deine echte E-Mail-Exponierung massiv. Apple hat seit iOS 18 "Hide My Email", aber nur für Apple-Dienste und nur wenn du iCloud+ zahlst.

Drittens: Ecosystemunabhängigkeit. Du bist bereits in Proton (Mail, VPN, Drive). Ein einziges Passwort für den Tresor, ein Anbieter mit konsistenter Sicherheitsphilosophie. Brave-Extension läuft sauber.

**Was Proton Pass noch nicht kann**

Passkey-Unterstützung ist noch nicht auf Apples Niveau — Apple hat hier echten Vorsprung. Wenn du Passkeys aktiv nutzt, ist das kurzfristig ein Reibungspunkt. Proton holt auf, ist aber noch nicht gleichwertig.

**Verdict**

Du nutzt Proton Pass bereits. Richtige Entscheidung, kein Grund zum Wechseln. Apple Passwords wäre nur besser, wenn du plant, ausschließlich im Apple-Universum zu leben und Privacy gegenüber Komfort priorisierst — das ist nicht dein Profil.

Nächster Schritt: Prüf, ob du bereits Proton Pass mit der Brave-Extension korrekt eingerichtet hast und ob SimpleLogin-Aliase aktiv für neue Registrierungen genutzt werden. Das ist der meiste Hebel, den du noch nicht voll ausschöpfst, wenn du es wie die meisten Nutzer verwendest.

---

**Du:**

Ich nutze alles von Apple

---

**Claude:**

Oleg is clarifying that he uses everything from Apple - so the Apple ecosystem lock-in argument I made is less relevant for him. Let me reassess with this new information.

If he's 100% Apple (iPhone, Mac, iPad, etc.) and uses everything from Apple, then Apple Passwords becomes much more competitive. Let me give an honest reassessment.

But wait - he also uses Brave browser, Proton Mail, Proton VPN, Proton Pass, Proton Drive. So "alles von Apple" might mean his devices are all Apple, but his software stack is mixed (Proton ecosystem + Apple devices).
Since he's using Brave as his main browser rather than Safari, Apple's native password integration doesn't help much - though Apple did recently release a Passwords extension for Chrome-based browsers. He's already committed to Proton Pass, which works across his entire setup, so switching to Apple Passwords would actually create friction rather than solve anything. The Brave browser compatibility actually works now with Apple's extension for Chrome-based browsers, which weakens that argument. But the real differentiator for him is the email alias generation through SimpleLogin—that's something Apple Passwords doesn't offer, and it's genuinely useful. So while Apple Passwords has become legitimately excellent for all-Apple users, Proton Pass still edges it out for his specific setup.Dann ändert sich die Antwort — aber nicht komplett.

**Was sich ändert**

Das Ecosystem-Lock-in-Argument fällt weg. Auf 100% Apple ist die Integration von Apple Passwords tatsächlich unschlagbar: Face ID, Passkeys, Family Sharing, kein zusätzlicher Abopreis, Handoff zwischen Geräten läuft reibungslos. Seit iOS 18 / macOS Sequoia ist das eine ernsthafte App, kein Anhängsel mehr.

**Was bleibt**

Du nutzt Brave, nicht Safari. Apple Passwords hat inzwischen eine Chrome-Extension — die funktioniert, aber sie ist nicht das, wofür Apple Passwords optimiert ist. Proton Pass läuft in Brave nativ und friktionslos.

Und der Killer-Vorteil von Proton Pass, den Apple nie replizieren wird: **E-Mail-Aliase direkt beim Speichern generieren.** Für jeden neuen Account eine echte Wegwerfadresse, die auf deine Proton-Mail weiterleitet. Apple hat "Hide My Email" nur für Apple-Dienste und nur mit iCloud+. Das ist nicht dasselbe.

**Revidiertes Urteil**

Wenn du Brave durch Safari ersetzen würdest und E-Mail-Aliase dir egal sind: Apple Passwords gewinnt auf deinem Setup.

So wie du arbeitest — Brave + Proton-Ökosystem + Privacy-Fokus — bleibt Proton Pass die bessere Wahl. Nicht weil Apple schlechter ist, sondern weil das Alias-Feature und die Brave-Integration echte Nutzungsvorteile liefern, die Apple dir nicht gibt.

**Nächster Schritt:** Entscheide einmal grundsätzlich, ob Brave oder Safari dein Hauptbrowser bleibt. Das ist die eigentliche Weggabelung — alles andere folgt daraus.

---

**Du:**

Ich nutze auch Safari

---

**Claude:**

Okay, so Oleg uses all Apple products AND Safari (not just Brave). Let me reassess again.

So his actual setup seems to be:
- All Apple devices
- Safari as browser (at least as main browser, or in addition to Brave)
- Proton ecosystem (Mail, VPN, Pass, Drive)

Wait, his memory says he uses Brave browser. But now he's saying he also uses Safari. So maybe he uses both, or Safari is his primary.

If he uses Safari on all Apple devices, Apple Passwords becomes much more compelling. The integration is seamless - autofill just works, no extension needed, Face ID everywhere, Passkeys are best in class.
Now I'm weighing the tradeoff: if he's fully committed to Apple and Safari, Apple Passwords offers superior daily UX and integration, though Proton Pass's email alias feature and metadata encryption are legitimate advantages. But he's already invested in Proton Pass, so switching has real friction—either option works well for his situation. I need to give him a straightforward recommendation without hedging—Apple Passwords is the better fit for his all-Apple setup unless he's actively leveraging Proton Pass's alias feature.Dann ist die ehrliche Antwort: **Apple Passwords gewinnt für deinen Alltag.**

100% Apple-Hardware, Safari als Browser — da ist Apple Passwords nicht nur "gut genug", sondern tatsächlich die bessere Wahl. Die Integration ist auf einem Level, das kein Drittanbieter erreicht: Face ID, Passkeys, automatisches Ausfüllen ohne Extension, Shared Password Groups, alles synchron über alle Geräte ohne Nachdenken.

**Der einzige echte Vorteil, den Proton Pass noch hat**

E-Mail-Aliase. Wenn du für jeden neuen Account eine separate Wegwerfadresse nutzt, die auf Proton Mail weiterleitet, ist das ein echter Sicherheitsgewinn. Den kann Apple nicht replizieren.

**Meine Position jetzt**

Wenn du die Alias-Funktion von Proton Pass aktiv nutzt: behalte beides — Apple Passwords als primären Manager, Proton Pass nur für Alias-Generierung bei neuen Registrierungen.

Wenn du die Aliase nicht aktiv nutzt: Wechsel vollständig zu Apple Passwords. Weniger Komplexität, bessere Integration, ein Tool weniger.

**Nächster Schritt:** Schau kurz nach, wie viele aktive Aliase du in Proton Pass tatsächlich hast. Wenn es unter 10 sind und du sie nicht systematisch nutzt, konsolidiere auf Apple Passwords — und vergiss Proton Pass als Passwort-Manager.

---

**Du:**

Das mit den email hat Apple doch auch 

Muss ich die passkeys alle neu aufsetzten wenn ich migriere

---

**Claude:**

Oleg is making two points:

1. Apple also has "Hide My Email" (which is true - it's part of iCloud+)
2. Asking about whether he needs to reset all passkeys when migrating from Proton Pass to Apple Passwords

Let me address both:

**On Hide My Email:**
Yes, Apple has Hide My Email as part of iCloud+. It generates random @icloud.com addresses that forward to your real email. It works in Safari and with Apple services. However, there are some differences vs SimpleLogin/Proton aliases:
- Apple's Hide My Email works broadly now, not just Apple services - you can create aliases for any site in Safari
- You get unlimited aliases with iCloud+, but they all forward to iCloud Mail specifically, not to whatever email you choose. That's a key difference from Proton Pass, where aliases can forward to Proton Mail or any other email address you prefer. If Proton Mail is his primary inbox, Apple's system might not fit his workflow as seamlessly.

**On Passkeys migration:**
This is the more important practical question. Passkeys are tied to the authenticator that created them and aren't directly transferable between password managers in a standard way.

Passkeys stored in iCloud Keychain sync across Apple devices, while passkeys in Proton Pass live in Proton's infrastructure. If he has passkeys in Proton Pass and wants to switch to Apple Passwords, he'd need to manually reset each one by deleting it from the service and creating a new passkey through Apple's authenticator—there's no bulk migration tool.

But here's the thing: he might not actually have passkeys stored in Proton Pass yet. Proton Pass supports passkeys, but it's a newer feature, so if he's primarily been using it for regular passwords, there's no passkey migration problem to solve. Regular passwords can be migrated straightforwardly.

For the practical answer: Hide My Email works differently between the two—Apple's version forwards to iCloud Mail rather than Proton Mail, which matters if Proton is his primary inbox. As for passkeys, if he doesn't have many stored in Proton Pass, manually re-enrolling them site by site isn't a huge burden, and his regular passwords can be imported directly.**Zu Hide My Email:** Stimmt, Apple kann das — aber die Aliase leiten an deine iCloud-Adresse weiter, nicht an Proton Mail. Wenn Proton Mail dein primäres Postfach ist, läuft der Vorteil ins Leere. Kleiner aber relevanter Unterschied.

**Zu den Passkeys:**

Kurze Antwort: Ja, die müssen neu aufgesetzt werden — aber das ist wahrscheinlich kein großes Problem.

Passkeys sind nicht portierbar. Sie sind kryptografisch an den Authenticator gebunden, der sie erstellt hat. Es gibt keinen Exportstandard. Du kannst nicht "Passkey aus Proton Pass → Apple Passwords" verschieben.

Was das in der Praxis bedeutet: Du gehst zu jedem Dienst, löschst den alten Passkey, erstellst einen neuen mit Apple als Authenticator. Kein automatischer Prozess.

**Aber:** Normale Passwörter lassen sich migrieren. Proton Pass hat einen CSV-Export, Apple Passwords einen Import. Das geht reibungslos.

Die echte Frage ist: Wie viele Passkeys hast du tatsächlich in Proton Pass gespeichert? Die meisten Nutzer haben noch relativ wenige — Passkeys sind noch nicht überall verbreitet. Wenn es unter 5 sind, ist der Aufwand minimal.

**Nächster Schritt:** Öffne Proton Pass, filtere nach Passkeys. Wenn es weniger als 10 sind, ist die Migration kein Argument gegen den Wechsel zu Apple Passwords.

---

**Du:**

Wie migriere ich Codes und Passwörter sauber zu Apple Passwörter

---

**Claude:**

Oleg wants to know how to migrate from Proton Pass to Apple Passwords cleanly. Let me give him a concrete, step-by-step guide.

Key steps:
1. Export from Proton Pass (CSV)
2. Import into Apple Passwords
3. Handle 2FA/TOTP codes separately
4. Handle passkeys separately

Let me think through this carefully:

**Proton Pass Export:**
- Proton Pass allows export as CSV or encrypted ZIP (PGP)
- Go to Settings → Export in Proton Pass
- Export as CSV for Apple compatibility

**Apple Passwords Import:**
- macOS Sequoia and iOS 18 added native import functionality
- On Mac, I open the Passwords app, go to File → Import Passwords, and select the CSV file
- Apple Passwords actually supports TOTP codes since iOS 17/macOS Sonoma, so if Proton Pass exports them in the right format, they'll import correctly

The tricky part is that Proton Pass and Apple Passwords use different CSV column structures, so I need to check what format each one expects and potentially reformat the export before importing. Apple Passwords can import otpauth:// URIs directly in the OTPAuth column, so the TOTP codes should transfer fine. The most straightforward approach for Oleg is exporting from Proton Pass as CSV, adjusting column headers if needed in a spreadsheet, then importing into the macOS Passwords app—making sure to securely delete the CSV file afterward and manually re-enroll any passkeys.**Schritt 1: Export aus Proton Pass**

Mac oder Browser → Proton Pass → Einstellungen → Daten exportieren → CSV wählen (nicht PGP). Du bekommst eine ZIP-Datei, darin eine CSV mit allen Logins.

**Schritt 2: CSV-Spalten anpassen**

Proton Pass und Apple Passwords sprechen nicht dieselbe Sprache. Du musst die Spaltenköpfe in Numbers oder Excel umbenennen:

| Proton Pass | → | Apple Passwords |
|---|---|---|
| name | → | Title |
| url | → | URL |
| username | → | Username |
| password | → | Password |
| note | → | Notes |
| totp | → | OTPAuth |

Spalten wie `type`, `createTime`, `modifyTime` einfach löschen.

**Schritt 3: Import in Apple Passwords**

Nur auf dem Mac möglich. Passwords App öffnen → oben im Menü `Datei → Passwörter importieren` → CSV auswählen → Duplikate prüfen und bestätigen.

**Schritt 4: 2FA-Codes prüfen**

Apple Passwords unterstützt TOTP seit iOS 17. Wenn deine `OTPAuth`-Spalte korrekte `otpauth://`-URIs enthält, werden die Codes automatisch mitimportiert. Nach dem Import jeden kritischen Account einmal testen — Code generieren und gegen den alten abgleichen.

**Schritt 5: Passkeys manuell neu einrollen**

Vor der Migration: In Proton Pass filtern welche Einträge Passkeys haben (nicht TOTP — Passkeys sind separate Einträge). Für jeden: beim jeweiligen Dienst einloggen, Passkey löschen, neuen mit Apple erstellen.

**Schritt 6: Aufräumen**

CSV-Datei nach dem Import sofort sicher löschen — Papierkorb leeren reicht nicht, `rm` im Terminal oder Finder → Sofort löschen. Dann Proton Pass erst deinstallieren wenn alles verifiziert ist.

---

**Realistische Zeitschätzung:** 30–45 Minuten, wenn du unter 200 Einträge hast und wenige Passkeys. Der Engpass ist Schritt 2, nicht der Import selbst.

Nächster Schritt: Exportiere jetzt die CSV und schau dir an wie viele `totp`-Einträge und Passkeys du tatsächlich hast — das bestimmt den Aufwand.

---

**Du:**

Es sind viele Passwörter nicht übertragen oder nicht richtig

---

**Claude:**

Oleg is having issues with the migration - many passwords didn't transfer correctly or at all. Let me think about the common failure points:

1. **Column header mismatch** - If the CSV headers weren't renamed correctly, Apple Passwords won't recognize the fields
2. **Encoding issues** - Special characters (German umlauts, etc.) can cause CSV parsing problems
3. **URL format** - Some URLs might not be in the right format
4. **Multiple URLs per entry** - Proton Pass might have multiple URLs per login, Apple only takes one
5. **Empty fields** - Some required fields might be empty
6. **CSV delimiter** - Comma vs semicolon issues, especially on German-language systems
7. **Quotes and escaping** - Passwords with commas or quotes can break the CSV structure
8. **Export format** - Proton Pass exports different item types (logins, notes, credit cards), but only login entries transfer to Apple
9. **Encoding variants** - UTF-8 vs UTF-8 BOM differences can cause parsing failures

The most likely culprits are German locale systems saving CSVs with semicolons instead of commas, special characters in passwords corrupting the structure, and non-login item types being included in the export. He should start by opening the CSV in a text editor to inspect the actual format and verify the data integrity. I should focus on the most practical debugging step: opening the CSV file in a text editor to see the actual structure and identify where the formatting broke down.Typische Ursachen, in Reihenfolge der Wahrscheinlichkeit:

**Wahrscheinlichste Ursache: Semikolon statt Komma**

Numbers auf deutschem System speichert CSV mit Semikolon als Trennzeichen. Apple Passwords erwartet Komma. Öffne die CSV in TextEdit — siehst du Semikolons zwischen den Feldern, ist das der Fehler.

Fix: In Numbers → Exportieren → CSV → funktioniert oft nicht. Besser: CSV in TextEdit öffnen, Cmd+A, alles kopieren, in einen neuen TextEdit-Text einfügen, Semikolons per Suchen/Ersetzen (Cmd+H) gegen Kommas tauschen, als `.csv` speichern.

**Zweithäufigste Ursache: Sonderzeichen sprengen die Struktur**

Passwörter die selbst Kommas, Anführungszeichen oder Zeilenumbrüche enthalten, zerstören das CSV-Format. Öffne die CSV in VS Code (kostenlos) — dort siehst du sofort wo Zeilen falsch umbrechen.

**Dritte Ursache: Falsche Item-Types**

Proton Pass exportiert alle Typen (logins, notes, credit cards, identities). Apple importiert nur Login-Einträge. Wenn du in der CSV eine `type`-Spalte noch drin hast: nur Zeilen mit `login` behalten, Rest löschen.

---

**Schnellster Weg jetzt:**

1. CSV in VS Code öffnen (vscode.dev im Browser geht auch ohne Installation)
2. Erste 5 Zeilen anschauen — Trennzeichen identifizieren, Spaltenköpfe prüfen
3. Screenshot oder die ersten 3 Zeilen hier reinkopieren

Dann kann ich dir exakt sagen was kaputt ist und wie du es in einem Schritt fixst.

---

**Du:**

Es gibt in Proton mehrere Felder die es so in Apple Passwörter nicht gibt 

Wie gehen wir damit um

---

**Claude:**

Oleg is asking about fields in Proton Pass that don't exist in Apple Passwords. Let me think about what those fields are:

Proton Pass has:
- **Vaults** (organized collections) - Apple has folders but different concept
- **Custom fields** - Proton Pass allows custom fields per entry (e.g., security questions, PIN codes, custom text fields)
- **Multiple URLs per entry** - Apple only supports one URL
- **Credit card details** - Apple Passwords doesn't store credit cards (that's Apple Wallet)
- **Notes/Secure Notes** - Apple Passwords has notes field but Proton has dedicated secure notes
- **Identity items** - Full identity profiles with name, address, and other personal details that Apple Passwords doesn't support
- **Email aliases** - A Proton-specific feature with no Apple equivalent

So the main incompatible fields when migrating from Proton to Apple are custom fields, multiple URLs, credit cards, identity profiles, email aliases, and the vault organization structure itself.

For the unmappable data, I'd need to make some practical compromises. Custom fields and extra URLs can go into the Notes section. Credit cards won't transfer since Apple Passwords doesn't handle them—I'd either keep those in Proton Pass or move them to Apple Wallet. Identity items have no real home in Apple Passwords, so I'd either leave them in Proton Pass, store them in the Notes app with password protection, or just accept not migrating them. Secure notes could become dummy password entries with the content in the Notes field. And the vault structure would require manual reorganization using Apple's folder and tag system.

The reality is that Apple Passwords is significantly more limited than Proton Pass.Konkret welche Felder tauchen auf? Vermutlich eine Kombination aus:

- **Custom Fields** (PIN, Sicherheitsfragen, beliebige Zusatzfelder)
- **Mehrere URLs pro Eintrag**
- **Kreditkarten**
- **Identity-Einträge** (Name, Adresse etc.)
- **Secure Notes**
- **Vaults** (Ordnerstruktur)

Umgang je Typ:

**Custom Fields + mehrere URLs** → Alles in das Notes-Feld des Apple-Eintrags kippen. Nicht elegant, aber vollständig und durchsuchbar.

**Kreditkarten** → Nicht migrieren. Apple Passwords hat kein CC-Feld. Entweder Apple Wallet, oder Proton Pass nur dafür behalten.

**Identity-Einträge** → Apple Passwords hat kein Äquivalent. Optionen: In die Notizen-App mit Face-ID-Sperre, oder einfach in Proton Pass lassen.

**Secure Notes** → Als Passwort-Eintrag mit Dummy-URL anlegen, Inhalt ins Notes-Feld. Workaround, funktioniert.

**Vaults** → Apple hat Ordner. Manuelle Zuordnung nach Import.

---

**Ehrliche Einschätzung**

Du merkst gerade selbst, dass Apple Passwords ein deutlich schlankeres Produkt ist. Kein CC, keine Identitäten, keine Custom Fields, keine Aliase. Für pure Login-Verwaltung reicht es — sobald du Proton Pass als strukturierten digitalen Safe nutzt, verlierst du bei der Migration real etwas.

Die Frage die du dir stellen solltest: Nutzt du diese erweiterten Felder aktiv, oder sind das hauptsächlich Altlasten die du eh aufräumen wolltest?

Wenn aktiv genutzt → Migration nicht empfehlenswert, Komplexität überwiegt den UX-Gewinn.
Wenn Altlasten → Aufräumen, dann migrieren.

---

