---
date: 2026-04-17
tags: [claude]
---

# Mietminderung bei Schimmel und Mängeln

**Du:**

Wieviel Miete kann ich bei Schimmel und anderen Dingen mindern wenn sich die Hausverwaltung seit ja je ein nicht kümmert und das Problem nicht behebt und jetzt auch nicht antwortet

---

**Claude:**

```
This block is not supported on your current device yet.
```

Hier die relevanten Richtwerte und dein konkretes Vorgehen — kompakt und direkt verwertbar.

---

## Mietminderung: Was dir zusteht

### Schimmel — Orientierungswerte aus der Rechtsprechung

Leichter Schimmel in einem Raum: **10–15 %** · Größerer Befall in mehreren Räumen: **20–50 %** · Gesundheitsgefährdend / faktisch unbewohnbar: **bis 100 %**

Wichtig: Nach BGH-Urteil VIII ZR 271/17 liegt die Beweislast beim Vermieter — er muss nachweisen, dass der Schimmel nicht baulich bedingt ist. Du musst nicht beweisen, dass du richtig gelüftet hast.

### Weitere typische Mängel (falls bei dir relevant)

Heizung unzureichend: **20–50 %** · Heizungsausfall im Winter: **bis 70 %** · Undichte Fenster/Zugluft: **5–15 %** je nach Jahreszeit

Basis ist immer die **Warmmiete** (Kaltmiete + NK). Beispiel: 1.000 € Warmmiete × 30 % = 300 € Minderung → du zahlst 700 €.

---

## Wichtig: Strategie bei ignorierender Hausverwaltung

Da die Verwaltung nicht antwortet, hast du bereits einen klaren Vorteil — aber du musst es richtig aufsetzen:

**1. Mängelanzeige per Einschreiben nachweisen**
Die Mietminderung ist erst ab Kenntnis des Vermieters zulässig. Voraussetzung ist eine ordnungsgemäße Mängelanzeige — rückwirkende oder unangekündigte Kürzungen sind unzulässig. Falls du das noch nicht schriftlich per Einschreiben getan hast: sofort nachholen.

**2. Minderung eher konservativ ansetzen**
Betroffene gehen häufig von einer höheren Quote aus, als Gerichte später zusprechen. Eine zu hohe Mietminderung kann im schlimmsten Fall eine fristlose Kündigung wegen Mietrückstand auslösen.

**3. Unter Vorbehalt zahlen als sicherere Alternative**
Du kannst die volle Miete weiter zahlen, aber **schriftlich unter Vorbehalt** — und später die Differenz zurückfordern. Das eliminiert das Kündigungsrisiko vollständig.

**4. ARAG aktivieren**
Du hast Rechtsschutz — das ist genau der Fall dafür. Beauftrage über ARAG einen Mietrechtler, der dir die genaue Quote bestätigt und ggf. die Hausverwaltung anschreibt. Ein Anwaltsschreiben wirkt oft sofort.

---

## Realistischer Rahmen für deinen Fall

Ohne alle Details zu kennen: Bei Schimmel + strukturellen Schäden + Sicherheitsmängeln **kumulierst** du mehrere Mängel. In Kombination sind **20–40 % Mietminderung** realistisch und gerichtsfest — sofern die Mängelanzeige dokumentiert ist.

---

**Nächster Schritt:** ARAG anrufen, Anwalt beauftragen, Mängelanzeige per Einschreiben (falls noch nicht done) — und parallel alle Mängel mit Fotos und Datum dokumentieren.

---

**Du:**

Formuliere ein Satz für untervorbehalt gesetzlich korrekt

---

**Claude:**

**„Ich zahle die Miete für [Monat/Jahr] in Höhe von [Betrag] € unter dem ausdrücklichen Vorbehalt der Rückforderung gemäß § 536 BGB."**

---

