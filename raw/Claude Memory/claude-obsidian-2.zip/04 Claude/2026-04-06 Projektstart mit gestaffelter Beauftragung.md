---
date: 2026-04-06
tags: [claude]
---

# Projektstart mit gestaffelter Beauftragung

**Du:**

Guten Morgen Nadine,
alles klar, kein Problem.
Ja richtig, ich würde grundsätzlich euch beide zusammen beauftragen aber nach ein paar Überlegungen und Gesprächen mit meiner Freundin habe ich entschieden erstmal mit dir anzufangen und Marta später einzubinden und losgelöst damit wir Schritt für SChritt beauftragen können. Ich würde auch gern mehr von Martas arbeiten da ich bisher nichts in richtung Fashion auf der Webpage erkennen konnte was ihre Expertise unterstreicht in diesem Bereich, das würde mich aufjedenfall mehr sicherheit geben.
Auftrag 1: Position 1+2 wären 4200€ + Position 3. 300€ =900,00 = 4500€ Gesamt Netto - 4998€ Brutto
Bezüglich der Zahlung habe ich verstanden, wenn wir jetzt im April starten würde ich gern ab Ende April zahlen.


Formuliere

---

**Claude:**

```
This block is not supported on your current device yet.
```

Hier sind zwei Varianten — je nachdem wie direkt oder diplomatisch du klingen möchtest:
```
This block is not supported on your current device yet.
```

Zwei Varianten — eine sachlich-strukturiert, eine etwas wärmer im Ton. Ich habe die Zahlen aus deiner Nachricht übernommen (300 € × 3 = 900 €) — falls Position 3 anders kalkuliert ist, kurz Bescheid geben.

---

