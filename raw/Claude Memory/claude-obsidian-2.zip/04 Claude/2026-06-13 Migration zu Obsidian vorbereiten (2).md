---
date: 2026-06-13
tags: [claude]
---

# Migration zu Obsidian vorbereiten

**Du:**

Kannst du mir alles vorbereitten zur migration zu obisidian aus diesem Projekt?

---

**Claude:**

The user wants to migrate everything from this Claude Project to Obsidian. They want me to prepare everything for that migration.

Let me think about what "this project" contains. Based on the userMemories, this is the "Research & Analyse" project (or possibly the general project). The user has 7 Claude projects total.

What they're asking: prepare a migration from this Claude Project to Obsidian. This likely means:
1. Extracting the userMemories/context into Obsidian-formatted notes
2. Possibly creating a vault structure
3. Creating MOCs (Maps of Content), templates, etc.
I should look at the recent conversations in this project to understand what content exists here, then structure it appropriately for Obsidian. The userMemories give me context about Oleg, but I need to see what specific work and conversations are happening within this project to properly migrate everything.Lass mich zuerst schauen, was in diesem Projekt alles liegt.
```
This block is not supported on your current device yet.
```

Now I have a comprehensive view of all conversations in this project. Let me analyze what's here and plan the Obsidian migration.

The project contains conversations spanning these domains:
1. **Claude/AI Setup** - Project structure, User Preferences (June 7, 2026)
2. **Performance & Health** - Huberman/Rhonda Patrick protocol, training, nutrition, supplements, Hyrox (June 6, 2026, April 19, 2026)
3. **Café Project** - Berlin café analysis, partnership with Hai (May 24, 2026)
4. **DoktorLib Automation** - Discovery pipeline, Tally → Make → Salesforce → Notion → Dust (May 8, 2026)
5. **Cyprus Relocation** - Tax analysis, budget, action items (April 19, 2026)
6. **Privacy/Tech Stack** - Proton ecosystem, Brave, DNS setup (May 10, 2026)
7. **Password Manager** - Proton Pass vs Apple Passwords migration (June 9, 2026)
8. **Insurance** - Allianz consolidation (April 25, 2026)
9. **Mattress Research** - TEMPUR purchase (May 14, 2026)
10. **Misc** - Houseplants, dog, running, washing clothes, and other personal notes

Now I'm planning the Obsidian migration structure. I need to organize the vault to match Oleg's domains, create individual notes for each topic with decisions and action items, set up Maps of Content to connect everything, and prepare the actual markdown files ready to import with proper frontmatter, tags, and internal links.

Creating vault structure... I'm prioritizing which files to create first—the vault index, the major projects like Café Berlin and Cyprus Relocation, the health and training protocols, and the tech setup notes. I'll generate these as markdown files with proper frontmatter, internal links, and structured content using a bash script.Guter Überblick. 20 Conversations, klar gruppierbares Material. Ich baue dir jetzt ein vollständiges Obsidian Vault-Paket — strukturiert, sofort importierbar.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Jetzt alles zippen und verpacken:
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

**Was drin ist — 16 Dateien, sofort importierbar:**

```
obsidian-vault/
├── 00-MOC/
│   ├── 🏠 Home.md              ← Startseite mit Prioritäten-Dashboard
│   ├── MOC Strategie & Business.md
│   ├── MOC Performance & Leben.md
│   └── MOC Tech & Setup.md
├── 01-Strategie-Business/
│   ├── Café Berlin — Partnership Hai.md   ← inkl. Agenda 14.06
│   ├── DoktorLib Automation Pipeline.md   ← Architektur + Phasen
│   ├── Cyprus Relocation.md               ← Gate-Items + Tax-Analyse
│   └── Allianz Insurance Consolidation.md
├── 02-Performance-Leben/
│   ├── Health Protocol — Master.md        ← Vollprotokoll
│   ├── Supplement Stack.md
│   ├── Hyrox — 10-Week Training.md
│   └── 3D Body Scan — Scaneca Mai 2026.md
├── 03-Tech-Setup/
│   ├── Privacy & Tech Stack.md
│   ├── Password Manager Migration.md
│   └── Claude Projects Setup.md
├── 04-Recherchen/
│   └── TEMPUR Matratzenkauf.md
└── 05-Inbox/
    └── 📥 Offene Actions.md               ← Alle offenen Tasks, priorisiert
```

**Import:** ZIP entpacken → Ordner als neues Vault in Obsidian öffnen (File → Open folder as vault). Alle `[[Links]]` funktionieren sofort, YAML Frontmatter für Tags/Filter ist gesetzt.

Nächster Schritt: Willst du die Café-Planning-Note für morgen noch tiefer ausarbeiten — konkrete Zahlen-Templates, Gesellschaftervertrag-Checkliste, oder Gesprächsführung mit Hai?

---

