---
date: 2026-05-24
tags: [claude]
---

# Café-Gründung mit bestehender UG und GmbH

**Du:**

Ich hab eine UG und GmbH die aktuell nichts tun 

Ich möchte sie nicht leerlaufen und Kosten verursachen daher überlege ich gastronomisch ein Café aufzumachen mit hauptsächlich Getränken und ggf später bisschen Kuchen und Kleinigkeit zu essen wir Baguette 

Mit Schankerlaubnis für abends 


Prüfe alle Vorraussetzungen Kosten etc für das gesamte Projekt 

Es soll kein grosses cafe zu Beginn sein

---

**Claude:**

```
This block is not supported on your current device yet.
```

Bevor ich eine vollständige Analyse liefere — drei kurze Rückfragen, die das Ergebnis erheblich schärfen:

**1. Standort?**
Berlin (welcher Bezirk) — oder planst du das Café in einer anderen Stadt? Das beeinflusst Mietpreise, Behörden, Konkurrenz und Zielgruppe massiv.

**2. Welche Gesellschaft soll operativ tätig werden?**
UG oder GmbH? Oder soll eine davon als Holdinggesellschaft fungieren und die andere den Betrieb aufnehmen? Das hat steuerliche und haftungsrechtliche Konsequenzen.

**3. Was ist dein verfügbares Startkapital?**
Grobe Hausnummer reicht — z.B. unter 30k€, 30–80k€, oder 80k€+. Das bestimmt, ob wir über Eigenfinanzierung, KfW-Kredit oder Investor-Struktur sprechen.

---

**Du:**

Berlin 

Friedrichshain Prenzlauer Berg 

GmbH operativ 

Kapital ist noch offen

---

**Claude:**

Gut. Ich baue dir eine vollständige Machbarkeitsanalyse — strukturiert, ehrlich, ohne Schönfärberei.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Ich habe jetzt genug Datenmaterial. Hier ist die vollständige Analyse.

---

# Café-Projekt Berlin — Vollanalyse

## 0. Strategische Vorbemerkung

Du hast zwei schlafende Gesellschaften und willst sie aktivieren — das ist ein legitimer Grund. Aber sei ehrlich mit dir: Gastronomie ist kein passives Investment. Die Insolvenzquote in den ersten drei Jahren liegt bei über 50 %. Friedrichshain/Prenzlauer Berg sind attraktiv, aber auch gesättigt und teuer. Das Konzept — klein, Getränke, abends Alkohol — ist tragfähig, wenn du es richtig aufsetzt. Diese Analyse zeigt dir, was wirklich auf dich zukommt.

---

## 1. Rechtliche Voraussetzungen

### 1.1 Gaststättenerlaubnis (Konzession)

Da du abends Alkohol ausschenken willst, ist eine **Gaststättenerlaubnis zwingend** — kein Weg dran vorbei.

Gastronomische Betriebe, in denen Alkohol ausgeschenkt werden soll, müssen ein Konzessionsverfahren durchlaufen, an dem mehrere Ämter beteiligt werden.

**Zuständig:** Ordnungsamt Berlin-Friedrichshain-Kreuzberg bzw. Pankow (je nach finalem Standort)

**Erforderliche Unterlagen:**
- Gewerbeanmeldung der GmbH
- Führungszeugnis des/der Geschäftsführer(in) — personenbezogen, nicht gesellschaftsbezogen
- IHK-Unterrichtungsnachweis (Gaststättenunterrichtung, ca. 4–8h Kurs)
- Grundriss der Räumlichkeiten (maßstabsgetreu)
- Miet-/Pachtvertrag
- Nachweis Infektionsschutzbelehrung (Gesundheitsamt)
- Ggf. Baugenehmigung bei Umbau

**Kosten:** In Berlin kostet eine unbefristete Lizenz zwischen 100 und 1.500 Euro.

**Zeitaufwand:** Für die Bearbeitung der Unterlagen müssen 1–3 Monate eingeplant werden. Realitätsnäher in Berlin: 2–4 Monate.

> **Wichtig:** Die Erlaubnis ist **personenbezogen** (Geschäftsführer), **raumbezogen** (konkrete Adresse) und **betriebsartbezogen**. Wechselt einer dieser drei Faktoren, neue Erlaubnis nötig.

### 1.2 GmbH als Betreiber

Grundsätzlich darf jede juristische Person (GmbH, UG, AG) ein Restaurant betreiben. Nötig ist lediglich eine Gaststättenerlaubnis.

Die GmbH als Betreiber ist sauber — Haftungstrennung, Privatvermögen geschützt. Die UG könnte als stille Holding-Ebene im Hintergrund bleiben (z.B. für IP, Brand, Darlehen an die GmbH). Das sollte ein Steuerberater strukturieren.

### 1.3 Weitere Behördengänge

| Stelle | Was | Wann |
|---|---|---|
| Ordnungsamt | Gewerbeanmeldung GmbH | Vor Eröffnung |
| Ordnungsamt | Gaststättenerlaubnis | 3–4 Monate vor Eröffnung |
| Gesundheitsamt | Infektionsschutzbelehrung | Vor Eröffnung |
| IHK Berlin | Gaststättenunterrichtung | Vor Antrag Erlaubnis |
| Finanzamt | USt-ID, ELSTER | Sofort nach Gewerbeanmeldung |
| Bauamt | Ggf. Baugenehmigung bei Umbau | Früh klären |
| GEMA | Anmeldung bei Musikbeschallung | Vor Eröffnung |
| Berufsgenossenschaft | BGN-Anmeldung | Nach erster Einstellung |

---

## 2. Standort & Mietkosten

### 2.1 Realistische Mietpreise

Für ein kleines Café (40–80 m²) in Friedrichshain/Prenzlauer Berg:

Aktuelle Inserate zeigen: Sonntagsstraße Friedrichshain 4.500€/157m², Prenzlauer Berg 3.000€/105m² und 2.940€/91m².

Für dein Format (40–60 m²) realistisch: **1.500–2.800 € Kaltmiete/Monat** in guter Lage. Nebenkosten +20–30%.

**Total Warmmiete: ca. 1.800–3.600 €/Monat**

### 2.2 Strategie: Übernahme statt Neueröffnung

Deutlich smarter als Neustart: Einen bestehenden Betrieb mit vorhandener Gaststättenerlaubnis, Einrichtung und Küche übernehmen.

Aktuell stehen Objekte in Friedrichshain und Prenzlauer Berg zur Übernahme, teilweise mit kompletter Einrichtung & Warenbestand ab 29.800 €.

Vorteile: Sofortige Konzession (Übertragungsverfahren schneller), keine Umbauzeit, günstigere Startkosten. Ablöse verhandeln.

---

## 3. Investitionskosten (Gesamtübersicht)

### Szenario A: Neueröffnung (kleines Café, 50m², Rohfläche)

| Posten | Kosten |
|---|---|
| Umbau / Renovierung | 10.000–25.000 € |
| Theke (Bau + Einbau) | 5.000–10.000 € |
| Siebträger-Kaffeemaschine (2 Gruppen) | 3.000–8.000 € |
| Kaffeemühle (Gastro) | 1.500–2.500 € |
| Kühlschränke, Spülmaschine | 3.000–6.000 € |
| Möbel (Tische, Stühle, Deko) | 4.000–10.000 € |
| Kassensystem (TSE-konform) | 1.500–3.500 € |
| Erstausstattung Geschirr/Gläser | 1.000–2.000 € |
| Kaution (2–3 Monatsmieten) | 4.000–9.000 € |
| Genehmigungen + IHK + Behörden | 800–2.500 € |
| Marketing / Eröffnung | 1.000–3.000 € |
| **Liquiditätsreserve (3 Monate laufend)** | **12.000–20.000 €** |
| **GESAMT** | **47.000–100.000 €** |

### Szenario B: Übernahme bestehender Betrieb

| Posten | Kosten |
|---|---|
| Ablöse inkl. Inventar | 15.000–50.000 € |
| Eigene Anpassungen/Renovierung | 2.000–10.000 € |
| Neue Kaffeemaschine (optional) | 3.000–8.000 € |
| Kaution | 3.000–6.000 € |
| Genehmigungen | 500–1.500 € |
| Liquiditätsreserve | 12.000–20.000 € |
| **GESAMT** | **35.000–95.000 €** |

> **Empfehlung:** Szenario B ist der realistischere Einstieg. Ziel: Unter 60.000 € Gesamtinvestition bei sauber verhandelter Ablöse.

---

## 4. Laufende Kosten (monatlich)

| Posten | Betrag |
|---|---|
| Miete warm | 1.800–3.600 € |
| Wareneinsatz (25–35% vom Umsatz) | variabel |
| 1 Teilzeitkraft (Minijob/Midijob) | 520–1.200 € |
| Steuerberater | 300–600 € |
| GmbH-Verwaltungskosten (IHK, etc.) | 80–150 € |
| GEMA | 80–200 € |
| Versicherungen (Betriebs-, Inventar-, Haftpflicht) | 200–400 € |
| Strom/Gas/Wasser | 300–600 € |
| Kassensystem/Software | 50–100 € |
| **Fixkosten gesamt** | **ca. 3.500–7.000 €/Monat** |

---

## 5. Umsatzsteuer — Wichtige Neuerung 2026

Die Bundesregierung hat die Umsatzsteuersenkung auf Speisen in der Gastronomie auf sieben Prozent zum 1. Januar 2026 dauerhaft beschlossen.

Das bedeutet für dein Café konkret:

- **Speisen (Kuchen, Baguette):** 7% MwSt ✅
- **Getränke (Kaffee, Softdrinks):** 19% MwSt — daran ändert sich nichts
- **Alkohol:** 19% MwSt

Das Kassensystem muss getrennte Steuersätze korrekt buchen.

---

## 6. Rentabilitäts-Check

Break-Even-Schätzung für ein kleines Café in Friedrichshain/PB:

- **Fixkosten/Monat:** ~5.000 € (konservativ)
- **Durchschnittlicher Bon:** 6–8 € (Getränkefokus)
- **Benötigte Transaktionen/Tag:** ~30–40 (bei 25 Öffnungstagen)
- **Benötigter Monatsumsatz:** ~18.000–20.000 € brutto (bei 30% Wareneinsatz)

Das ist machbar — aber nur wenn du täglich 25+ Gäste hast. In Friedrichshain/PB realistisch, wenn Lage stimmt.

---

## 7. Kritische Risiken

**Das musst du wirklich durchdenken:**

1. **Du hast keinen Gastronomie-Hintergrund** — du brauchst entweder einen erfahrenen Betriebsleiter oder du lernst das Handwerk vor dem Start
2. **Personalbindung:** Zuverlässige Teilzeitkräfte in Berlin zu finden ist schwer und zeitaufwendig
3. **Standortrisiko:** In Friedrichshain/PB ist jede zweite Ecke ein Café — Differenzierung ist entscheidend
4. **Zeitaufwand:** Ein Café "nebenbei" zu führen ist nur mit starken Strukturen möglich
5. **Liquiditätsrisiko:** Die ersten 6 Monate laufen fast immer unter Erwartung

---

## 8. Empfohlene Struktur (GmbH + UG)

```
OK Holding (UG) — Ebene 1
├── Darlehen an GmbH (zinsgünstig, steueroptimiert)
└── ggf. Markenrechte / IP

Café-GmbH — Ebene 2
├── Gaststättenerlaubnis
├── Mietvertrag
└── operativer Betrieb
```

Die UG bleibt passiv, kann aber Gewinne der GmbH via Dividende steuergünstig aufnehmen (Schachtelprivileg: 95% steuerfrei auf GmbH-Ebene). Das prüft ein Steuerberater im Detail.

---

## Nächster Schritt

**Bevor du irgendwas anmietest oder investierst:**

Geh auf Kleinanzeigen und ImmoScout24, filtere Café-Übernahmen in Friedrichshain und Prenzlauer Berg unter 60.000 € Ablöse, und hol dir 3–5 konkrete Objekte zur Besichtigung. Parallel: 1 Termin mit einem Gastro-erfahrenen Steuerberater zur GmbH-Struktur. Daraus bauen wir dann einen konkreten Businessplan und Finanzplan.

Soll ich den Businessplan / Finanzplan als Excel oder Dokument aufbauen?

---

**Du:**

Ich bin gelernter restaurantfachmann

Hab auch viele Freunde die ein Café Bar haben die mich unterstützen würden

---

**Claude:**

Das ändert die Risikolage erheblich — und positiv. Dann lass uns direkt schärfer werden.

---

## Update der Risikoanalyse

**Was sich ändert:**

Ausbildung als Restaurantfachmann bedeutet: Du kennst Betriebsabläufe, Wareneinsatz-Kalkulation, Personalführung und Gästepsychologie. Das ist der häufigste Grund warum Café-Gründer ohne Gastro-Background in Jahr 1 scheitern — den hast du nicht.

Freunde mit laufenden Café-Bars bedeutet: Lieferantenkontakte, Erfahrungswerte zu echten Kosten, ggf. günstiger Einkauf über deren Accounts, und ein Netzwerk für Personalengpässe.

**Dein reales Risikoprofil sinkt damit von "hoch" auf "mittel".**

---

## Was jetzt die entscheidenden Fragen sind

Da du operativ weißt was du tust, geht es jetzt um drei Dinge:

**1. Konzept-Schärfe** — Willst du ein klassisches Café das abends zur Bar wird? Oder von Anfang an eine klare Bar-Café-Hybrid-Identität? Das bestimmt Zielgruppe, Einrichtung, Preisstruktur und Marketing komplett.

**2. Deine Zeitkapazität** — Du arbeitest im Sales mit Remote-Flexibilität. Wie viele Stunden pro Woche kannst du realistisch ins Café investieren, besonders in der Startphase? Das entscheidet ob du einen Betriebsleiter brauchst oder nicht.

**3. Finanzierung** — Jetzt wo klar ist dass du es ernst meinst: Eigenkapital, KfW-Kredit, oder Kombination? Die Struktur über GmbH + UG eröffnet interessante Optionen.

Beantworte mir diese drei Punkte kurz — dann baue ich dir einen konkreten Businessplan und Finanzplan als vollständiges Dokument.

---

**Du:**

KfW Kredit mit Eigenkapital

---

**Claude:**

Gut. Noch zwei schnelle Präzisierungen bevor ich den Finanzplan baue:

**Eigenkapital:** Welche Größenordnung kannst du einbringen? KfW empfiehlt mindestens 20–30% der Gesamtinvestition aus Eigenmitteln — bei 60.000€ Gesamtbudget wären das ~15.000–20.000€. Liegst du in dieser Range, drüber oder drunter?

**Konzept-Richtung:** Café tagsüber + Bar abends — eher **entspannt/specialty coffee** (Third Wave, Prenzlauer Berg-Zielgruppe, junge Familien + Kreative) oder eher **urban/lebhaft** (Friedrichshain-Energie, Studenten + Szene, mehr Bar-Fokus)? Das beeinflusst Preiskalkulation und Umsatzstruktur im Finanzplan direkt.

---

**Du:**

Ja schaffe ich 

Genau diese Art von Konzept ist super

---

**Claude:**

Welches von beiden meinst du genau — specialty coffee/entspannt oder urban/Bar-fokus? Oder eine Kombination aus beiden?

Und: 15.000–20.000 € Eigenkapital, oder eher mehr?

---

**Du:**

Coffe bis 16-17 Uhr danach Fokus auf Bar und Drinks

---

**Claude:**

Perfekt. Klares Konzept, klare Trennung. Das ist operativ sauber umsetzbar.

Eigenkapital — konkrete Zahl? 15k, 20k, 30k? Damit kann ich den KfW-Kreditbedarf und die monatliche Tilgungsbelastung exakt durchrechnen.

---

**Du:**

20

---

**Claude:**

Gut. Ich habe alles was ich brauche. Ich baue jetzt den vollständigen Businessplan als Dokument.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

---

**Du:**

Warte noch mit dem Businessplan 

Prüfe bitte alle Schritte die ich jetzt machen müsste in Berlin und mach eine Checkliste dienlich ggf abhaken kann worauf ich achten sollte Vorteile Nachteile etc

Voll umfassend 

Wieviel Gewinn kommt realistisch raus wenn ich mich selbst zahlen müsste bei vollzeit und wenn ich jemanden einstelle

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Gut. Ich habe alle Zahlen. Jetzt baue ich die vollständige interaktive Checkliste als React-Artifact — abhakbar, mit Gewinnrechner.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Hier ist deine vollständige interaktive Checkliste + Gewinnrechner.

**Was drin ist:**

**Checkliste** — 5 Phasen, 38 Punkte, alle abhakbar. Kritische Pflichtpunkte rot markiert (!). Jeder Punkt aufklappbar mit konkreter Erklärung, Kosten und Empfehlung. Fortschrittsanzeige oben.

**Gewinnrechner** — zwei Szenarien direkt vergleichbar:

Mit deinen Zahlen (20k Eigenkapital, ~40k KfW-Kredit, Miete ~2.200€):

- **Szenario 1 — Du arbeitest selbst Vollzeit** (GF-Gehalt 3.500 €): Break-Even bei ca. 17.500–18.000 € Monatsumsatz — realistisch erreichbar ab Monat 4–6 in guter Lage
- **Szenario 2 — Du stellst jemanden ein**: Break-Even schon früher durch fehlendes GF-Gehalt, aber du verdienst nichts aus dem Betrieb — macht Sinn wenn Sales-Job weiterläuft

**Die ehrliche Zahl:** Mindestlohn steigt 2027 weiter auf 14,60 €/h — das ist bereits eingerechnet als Planungsrisiko. Speisen werden ab 2026 dauerhaft mit 7% besteuert, Getränke bleiben bei 19% — für deinen Getränkefokus ist das neutral.

**Nächster Schritt:** Schiebe im Rechner den Umsatz-Slider auf dein Bauchgefühl für Monat 1 — dann siehst du sofort ob du mit 20k Eigenkapital als Puffer durchkommst oder ob die Reserve zu knapp ist.

---

**Du:**

Ich würde das GEhalt gerne selbst einstellen im Rechner 


Prüfe ob wir für dieses Projekt noch was übersehen haben

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Gut. Ich habe die Lücken identifiziert. Jetzt aktualisiere ich das Artifact mit einstellbarem GF-Gehalt + allen übersehenen Punkten.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Aktualisiert. Was neu ist:

**Gewinnrechner — jetzt vollständig einstellbar:**
- GF-Gehalt frei schiebbar (0–8.000 €)
- Personal/Aushilfen separat einstellbar
- Zwei Szenarien: du selbst aktiv vs. nur Mitarbeiter
- Break-Even wird dynamisch neu berechnet

**Übersehene Punkte — jetzt ergänzt:**

Vier Sachen die wir vorher nicht hatten und die wirklich relevant sind:

Seit Januar 2023 gilt die Mehrwegpflicht in der Gastronomie — bei Nichteinhaltung kann das Bußgeld bis zu 10.000 Euro betragen. In Friedrichshain-Kreuzberg ist RECUP bereits in über 80 Cafés etabliert — du kannst einfach mitmachen, kein eigenes System aufbauen nötig.

Für das Aufstellen von Tischen und Stühlen vor dem Café auf öffentlichem Straßenraum ist in Berlin eine Sondernutzungserlaubnis notwendig — kein Automatismus, kein Anspruch drauf.

Jugendschutz bei Alkohol: Schulung aller Mitarbeiter muss dokumentiert sein — ein nachgewiesener Verstoß kann die Konzession direkt gefährden.

Mindestlohn steigt 2027 weiter auf 14,60 €/h — Personalkosten-Slider jetzt direkt einstellbar damit du das schon heute einplanen kannst.

**Nächster sinnvoller Schritt:** Schiebe im Rechner mal auf deinen realistischen Monat-3-Umsatz (nicht den Wunschfall) und justiere dein GF-Gehalt so, dass der Break-Even noch grün bleibt — das zeigt dir wie viel Puffer du aus dem 20k Eigenkapital brauchst.

---

**Du:**

Frage dazu was ist sinnvoller 

Mein Angestellten Job mit 110-150k pro Jahr oder ein eigenes Café welches ich weitere skalieren könnte

---

**Claude:**

Ehrliche Antwort — keine beschönigte.

---

## Die harte Wahrheit zuerst

Ein Café ist **kein Einkommensersatz für 110–150k**. Das ist rechnerisch fast unmöglich mit einem einzelnen kleinen Standort.

Selbst im guten Szenario:
- GF-Gehalt aus der GmbH: 3.500–5.000 € brutto/Monat = **42–60k/Jahr**
- Unternehmensgewinn nach Steuer: vielleicht weitere 1.000–2.000 €/Monat

**Decke eines einzelnen Cafés:** ~70–80k Gesamtentnahme im sehr guten Jahr. Eher 50–60k realistisch.

Du würdest also **mindestens 50–90k Jahreseinkommen opfern** — auf unbestimmte Zeit.

---

## Die eigentliche Frage ist eine andere

Du hast zwei schlafende Gesellschaften und willst sie aktivieren. Das ist der echte Ausgangspunkt. Die relevante Frage ist nicht "Job oder Café" sondern:

**Was ist dein tatsächliches Ziel?**

Drei völlig verschiedene Antworten führen zu völlig verschiedenen Strategien:

**A) Du willst Unternehmertum und Freiheit** — dann ist Gastronomie der härteste mögliche Einstieg. Gebunden an Standort, Öffnungszeiten, Personal, 6–7 Tage/Woche Verantwortung. Weniger Freiheit als jeder Angestelltenjob.

**B) Du willst Vermögensaufbau** — dann ist ein einzelnes Café ein schlechtes Instrument. Das Kapital in ETFs oder Immobilien arbeitet effizienter mit weniger Risiko.

**C) Du willst ein skalierbares Unternehmen aufbauen** — dann könnte Gastronomie ein Einstieg sein, aber nur wenn du von Anfang an mit Franchise- oder Multi-Location-Logik denkst. Nicht als Café-Betreiber sondern als Unternehmer der Systeme baut.

---

## Was wirklich skaliert in der Gastronomie

Einzelne Cafés skalieren nicht. Was skaliert:

- **Konzept + Marke** die replizierbar ist (Filialen, Franchise)
- **Catering/Events** als zweites Standbein
- **Eigenmarke** (Kaffee, Produkte) mit E-Commerce
- **Immobilie** — wenn du irgendwann Eigentümer statt Mieter bist

Aber das ist Jahr 3–5, nicht Jahr 1.

---

## Der einzige Weg bei dem beides Sinn ergibt

**Café als Nebenprojekt** — Remote-Job behalten, Café mit starkem Betriebsleiter aufbauen, selbst nur strategisch eingebunden. Das geht wenn du einen verlässlichen Menschen findest der operativ führt. Du hast das Gastro-Know-how um das zu beurteilen.

Dann verlierst du kein Einkommen, baust aber Unternehmenssubstanz auf — und entscheidest in 12–18 Monaten mit echten Zahlen ob du skalierst oder den Job aufgibst.

---

## Meine direkte Einschätzung

Mit 110–150k im Job, Remote-Flexibilität, Fashion Brand als weiterem Projekt und Emigrationsplänen nach Zypern: **Ein Café als Haupteinkommensquelle wäre ein strategischer Fehler.**

Ein Café als **aktivierte GmbH mit Betriebsleiter, das Cashflow generiert und dein unternehmerisches Fundament aufbaut** — das ergibt Sinn. Aber nur wenn du nicht operativ drinsteckst.

Die entscheidende Frage: **Hast du jemanden dem du den Betrieb anvertrauen würdest?** Aus deinem Freundesnetzwerk mit Café-Bar-Erfahrung?

---

**Du:**

Ok dann machen wir es nicht 
Eine Fashion brand habe ich auch noch nicht

Was würde am meisten Sinn machen für jetzt und kommende Jahre als Firma anzubieten?

---

**Claude:**

Bevor ich antworte — das ist eine der wichtigsten strategischen Fragen die du dir stellen kannst. Ich will sie richtig beantworten, nicht schnell.

Drei gezielte Fragen:

**1. Was machst du genau im Sales-Job?**
B2B, SaaS, Enterprise, Recruiting? Branche und Art des Verkaufens — das ist dein stärkstes Asset und bestimmt die naheliegendsten Optionen.

**2. Wo willst du in 3–5 Jahren stehen?**
Vollzeit-Unternehmer mit Team? Oder hohe Einnahmen bei maximaler Freiheit und minimalem Aufwand (Solopreneur/Consulting)? Oder Zypern + passives Einkommen?

**3. Was machst du außerhalb des Jobs mit Energie und Interesse?**
Nicht was du kannst — was dich wirklich interessiert. Fashion ist ein Hinweis. Gibt es noch andere Bereiche?

---

**Du:**

B2b saas Praxis Software an Ärzte 

3-5 Jahre will ich über 250k als Anlage haben 

Slim und effizient mit Freiheit auswandern evtl wenn wir viel Geld haben können wir auch bleiben 

Ich liebe Sport

---

**Claude:**

Perfekt. Jetzt habe ich genug.

Das ist kein kompliziertes Puzzle — die Antwort liegt direkt vor dir. Lass mich das strukturiert aufschlüsseln.

---

## Dein tatsächliches Asset-Portfolio

Du hast drei Dinge die die meisten Menschen nicht haben:

**1. B2B SaaS Sales an Ärzte** — du weißt wie Healthcare-Entscheider denken, kaufen und was sie brauchen. Das ist ein Nischenmarkt den kaum jemand versteht.

**2. Restaurantfachmann + Gastro-Netzwerk** — operatives Wissen, Menschenführung, Stressresistenz.

**3. Sport als echte Leidenschaft** — nicht als Hobby sondern als Lebensthema.

---

## Die drei realistischsten Pfade

### Pfad 1 — Sales Consulting / Freelance (schnellstes Geld, sofort)

**Was:** Arztpraxen und Healthcare-SaaS-Unternehmen als externer Sales-Berater oder Closer.

**Warum es passt:** Du kennst beide Seiten — den Käufer (Arzt) und das Produkt (SaaS). Das ist extrem selten. Agenturen und Startups zahlen für dieses Wissen gut.

**Realistische Zahlen:**
- Freelance B2B Sales Consultant Healthcare: 800–1.500 €/Tag
- Retainer-Modell: 3.000–8.000 €/Monat pro Kunde
- 2–3 Kunden parallel = 100–180k/Jahr, ortsunabhängig

**Über GmbH abgerechnet:** Körperschaftsteuer ~30% statt Einkommensteuer ~42%. Bei 150k Umsatz sparst du 15–25k Steuern vs. Angestelltenverhältnis.

**Zeitrahmen bis erste Einnahmen:** 1–3 Monate.

---

### Pfad 2 — Sport + Business kombinieren (mittelfristig, skalierbarer)

**Was:** Online Coaching, Performance-Content, oder ein Produkt rund um Sport und Gesundheit.

**Warum es passt:** Sport ist dein echtes Interesse — Authentizität ist der einzige nachhaltige Vorteil im Content-Markt. Kombiniert mit deinem Gesundheits-Hintergrund aus dem SaaS-Job hast du Glaubwürdigkeit.

**Konkrete Modelle:**
- Online Coaching (1:1 oder Gruppe): 300–800 €/Monat pro Kunde, 10–20 Kunden = 60–120k skalierbar
- Info-Produkt / Kurs: einmalig 100–500k Aufbauaufwand, dann passiv
- Brand + Affiliate im Sport/Health-Bereich

**Über GmbH:** Content-Produktion, Equipment, Reisen — alles absetzbar.

**Zeitrahmen bis relevante Einnahmen:** 12–24 Monate.

---

### Pfad 3 — Fashion Brand (längster Atem, höchstes Upside)

**Was:** Du hast das schon als Projekt. Kleidung + Sport + Lifestyle ist ein riesiger Markt.

**Ehrlich:** Fashion ist das kapitalintensivste und zeitaufwendigste der drei Modelle. Ohne starke Markenidentität und Vertriebskanal dauert es 3–5 Jahre bis relevante Zahlen entstehen. Nicht für schnelles Kapital geeignet.

**Sinnvoll als:** Langfristprojekt parallel zu Pfad 1 oder 2 — nicht als Haupteinkommensquelle.

---

## Was ich dir empfehlen würde

**Jetzt sofort:** Pfad 1 starten. Freelance Sales Consulting über deine bestehende GmbH. Keine neue Struktur, kein Kapital, keine Genehmigungen. Du brauchst nur zwei oder drei Kunden.

**Parallel ab Monat 6–12:** Pfad 2 aufbauen — Sport/Health Content oder Coaching als zweites Standbein. Das ist der Weg zu Ortsunabhängigkeit und passivem Einkommen.

**Fashion Brand:** Weiterführen als Projekt, aber nicht als Einkommenserwartung für die nächsten 2 Jahre.

**Zypern-Ziel:** Pfad 1 + 2 über GmbH abgerechnet, dann Wegzug — mit dem Newcomer-Steuervorteil auf Zypern zahlst du auf Ausschüttungen effektiv deutlich weniger als in Deutschland. Das passt perfekt zusammen.

---

Eine Frage noch — die alles entscheidet:

Willst du **aktiv verkaufen und beraten** (Pfad 1 — schnelles Geld, bewährte Stärke), oder willst du primär **etwas aufbauen das ohne dich läuft** (Pfad 2/3 — mehr Zeit, mehr Upside, mehr Risiko)?

Das bestimmt welchen Pfad wir als erstes konkret ausarbeiten.

---

**Du:**

Prüfe alle Branchen die aktuell stark performen und sicher sind für die nächsten 5 -10 Jahre

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Gut. Ich habe alle Daten. Jetzt kommt die ehrliche, auf dich zugeschnittene Analyse — keine generische Branchenliste.

---

## Branchen-Screening 2026–2035

Bewertung nach drei Kriterien die für dich relevant sind: **Marktwachstum, Zugänglichkeit ohne Kapital, Passung zu deinem Profil.**

---

### Tier 1 — Stark, sicher, sofort zugänglich für dich

**Healthcare SaaS / Digital Health**

Das ist dein Heimspiel. Der globale Healthcare SaaS Markt wächst mit 20% CAGR und wird bis 2030 74 Milliarden Dollar erreichen. Das Healthcare-Segment ist mit einer projizierten CAGR von über 30% bis 2030 besonders stark, getrieben durch Telemedizin und elektronische Patientenakten.

Du kennst Ärzte als Käufer, kennst Praxis-Software als Produkt, kennst den Verkaufsprozess. Das ist eine Kombination die kein Marktteilnehmer in 6 Monaten lernt. Dein Wettbewerbsvorteil ist strukturell.

**Konkret für dich:** Sales Consulting, Interim Sales Director, oder eigene Beratungsagentur für Healthcare-SaaS-Unternehmen die in DACH skalieren wollen. Tagesrate 800–1.500 €. Ortsunabhängig.

---

**B2B Sales als Service (spezialisiert)**

Upwork meldete, dass die Nachfrage nach KI-bezogenen Freelance-Skills um 109% gegenüber dem Vorjahr gestiegen ist. Gleichzeitig gilt: Generalisten stehen am meisten unter Druck durch KI. Tiefe Spezialisierung in einer spezifischen Branche schafft einen Graben den KI nicht leicht überqueren kann.

Genau das bist du: kein generischer Sales-Freelancer, sondern Healthcare-SaaS-Spezialist. Das ist der Graben.

---

### Tier 2 — Stark wachsend, mittelfristig für dich erreichbar

**Sport & Health Coaching (digitalisiert)**

Der Markt wächst. Das Healthcare & Rehabilitation Segment im AI-Fitness-Bereich wächst mit 24,7% CAGR von 2026 bis 2033. Aber: der Markt ist überflutet mit mittelmäßigen Coaches. Was funktioniert ist eine spitze Positionierung — z.B. Performance-Coaching für Unternehmer und Führungskräfte. Du bist beides: Sportler und erfolgreicher Sales-Professional. Das ist die Zielgruppe die zahlt.

Realistische Einnahmen: 500–1.500 €/Monat pro Coaching-Kunde, 10–15 Kunden = 60–150k, skalierbar durch Gruppe oder Programm.

**KI-gestützte Prozessberatung für KMU**

Nicht Technologie bauen — sondern Unternehmen zeigen wie sie KI in ihren Vertrieb integrieren. Du kennst B2B-Sales-Prozesse. KI-Tools in Sales-Workflows zu integrieren (CRM-Automation, Lead-Scoring, Outreach) ist eine Fähigkeit die du in 3–6 Monaten aufbauen kannst und für die der Markt gerade explodiert.

---

### Tier 3 — Wächst stark, aber nicht dein direkter Einstiegspunkt

Laut FutureManagementGroup sind die Top-Zukunftsbranchen bis 2040: Biotechindustrie, Logistik, Umweltwirtschaft, Medizintechnik, Chemie/Pharma.

Diese Branchen sind real und wachsen — aber sie erfordern Kapital, Fachausbildung oder Produktentwicklung. Kein direkter Einstieg für einen Solo-Unternehmer ohne spezifisches technisches Know-how.

**Fashion Brand** fällt hier rein: Wächst, aber kapitalintensiv, langsam, hart. Sinnvoll nur als paralleles Langzeitprojekt.

---

## Die ehrliche Zusammenfassung für dein Profil

| Pfad | Wachstum | Zeit bis Geld | Passung | Skalierbarkeit |
|---|---|---|---|---|
| Healthcare SaaS Consulting | ⭐⭐⭐⭐⭐ | 1–3 Monate | ⭐⭐⭐⭐⭐ | mittel |
| Sport Coaching (premium) | ⭐⭐⭐⭐ | 6–12 Monate | ⭐⭐⭐⭐ | hoch |
| KI-Sales-Beratung | ⭐⭐⭐⭐⭐ | 3–6 Monate | ⭐⭐⭐ | hoch |
| Fashion Brand | ⭐⭐⭐ | 24–48 Monate | ⭐⭐ | sehr hoch |
| Café / Gastronomie | ⭐⭐ | nie >100k | ⭐ | kaum |

---

## Was ich konkret empfehle

**Jetzt:** Healthcare SaaS Consulting über deine GmbH starten. Zwei bis drei Kunden, Retainer-Modell, 8–15k/Monat. Das ist dein Fundament — schnelles Geld, keine Investition, ortsunabhängig, Zypern-kompatibel.

**Parallel ab Monat 6:** Sport-Coaching-Positionierung aufbauen — aber nicht als "Fitness-Coach" sondern als Performance-Coach für Unternehmer. Das ist der Markt der zahlt und zu dir passt.

**Jahr 2–3:** Wenn Healthcare-Consulting läuft und Coaching Einnahmen hat — dann Fashion Brand als drittes Standbein mit echtem Kapital und Energie.

---

Soll ich für den Healthcare-Consulting-Pfad ein konkretes Go-to-Market ausarbeiten — Positionierung, Zielkunden, Preisstruktur, wie du die ersten Kunden gewinnst?

---

