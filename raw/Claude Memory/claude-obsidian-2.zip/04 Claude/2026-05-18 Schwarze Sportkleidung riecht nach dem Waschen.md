---
date: 2026-05-18
tags: [claude]
---

# Schwarze Sportkleidung riecht nach dem Waschen

**Du:**

Schwarze Wäsche richtig waschen 
Darunter Baumwolle und polyester Sport 

Aktuell wasche ich mit sensitive Waschmittel pflegeleicht 30 grad und sie riecht immer

---

**Claude:**

## Schwarze Wäsche richtig waschen

### Das Problem

**Sensitive-Waschmittel bei 30° ist zu schwach** für Sportkleidung. Körperfett, Schweiß und Bakterien werden nicht vollständig entfernt → bleibt-Geruch, auch nach dem Waschen.

---

### Optimale Einstellungen nach Material

| | **Schwarze Baumwolle** | **Schwarzes Polyester/Sport** |
|---|---|---|
| **Programm** | Pflegeleicht oder Feinwäsche | Synthetik / Feinwäsche |
| **Temperatur** | 30–40°C | 30°C (nicht höher!) |
| **Schleudern** | Max. 800 U/min | Max. 600 U/min |
| **Waschmittel** | Spezialwaschmittel für Dunkles | Sportwaschmittel |

---

### Konkrete Empfehlungen

**Waschmittel wechseln:**
- **Baumwolle schwarz** → *Perwoll Black* oder *Woolite Dark* — erhält die Farbe, bessere Reinigung als Sensitive
- **Sportkleidung** → *Grangers Performance Wash* oder *Nikwax Tekwash* — speziell für synthetische Fasern, löst Schweiß/Fett effektiv

**Gegen den Geruch konkret:**
- 1–2 EL **weißen Essig** direkt ins Waschmittelfach (kein Weichspüler! — versiegelt Polyesterfasern, verschlimmert Geruch langfristig)
- Sportkleidung vor dem Waschen **30 Min in kaltem Wasser + Essig einweichen**
- Nach dem Sport: **nicht knäueln/sofort in den Korb** — Luft trocknen lassen, bevor du sie in die Wäsche gibst

**Trommel/Maschine:**
- Einmal monatlich **Maschinenreiniger** (z.B. Calgon oder Dettol Washing Machine Cleaner) — Biofilm in der Trommel ist oft die eigentliche Geruchsquelle

---

### Farbe erhalten (Schwarz)

- Wäsche **auf links** drehen
- Kein direktes Sonnenlicht beim Trocknen
- Weichspüler vermeiden (bei Polyester sowieso, bei Baumwolle ebenfalls besser ohne)

---

**Nächster Schritt:** Waschmittel tauschen (Perwoll Black für Baumwolle, Grangers für Sport) + Essig-Einweichen bei der nächsten Ladung Sportkleidung — der Unterschied ist sofort spürbar.

---

