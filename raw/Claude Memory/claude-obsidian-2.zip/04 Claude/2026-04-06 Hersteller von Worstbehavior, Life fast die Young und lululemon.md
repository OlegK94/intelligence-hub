---
date: 2026-04-06
tags: [claude]
---

# Hersteller von Worstbehavior, Life fast die Young und lululemon

**Du:**

Prüfe bitte wo die Marke Worstbehavior, Life fast die Young lululemon produzieren 

Ich suche die Hersteller

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Hier eine übersichtliche Zusammenfassung für alle drei Marken:

---

## 🏭 WRSTBHVR (Worst Behavior, Berlin)

WRSTBHVR wurde 2014 gegründet, mit Headquarters in Berlin. Zu den konkreten Produktionsstätten und Herstellerpartnern macht die Marke **keine öffentlichen Angaben** — weder auf der Website noch in Nachhaltigkeitsberichten. Das ist für Brands dieser Größe (ca. 67 Mitarbeiter, ~1M Umsatz laut Rocketreach) üblich. Für gezielte Recherche wäre direkte Kontaktaufnahme oder ein Blick auf die Care-Labels der Produkte der schnellste Weg.

---

## 🏭 LFDY (Live Fast Die Young, Düsseldorf)

LFDY ist hier am transparentesten von allen dreien. Alle LFDY-Produkte werden dort hergestellt, wo sich große Teile der globalen Textilproduktion befinden — in der **Türkei, China und Pakistan**. In allen Fabriken werden detaillierte Gespräche geführt und verbindliche Richtlinien festgelegt. Zusätzlich ist LFDY der **amfori BSCI** (Business Social Compliance Initiative) beigetreten, um transparente Lieferketten zu gewährleisten.

---

## 🏭 lululemon (Vancouver, Kanada)

lululemon ist die transparenteste der drei — sie veröffentlichen sogar eine öffentliche Supplier List. Das Unternehmen arbeitet mit 138 Produktionsstätten in 19 Ländern zusammen, davon sind 113 als "Tier 1" (Endprodukt-Fertigung) eingestuft. Die wichtigsten Produktionsländer:

**China, Vietnam, Taiwan, Türkei und Peru** sind die Hauptstandorte laut der 2024 Supplier List.

Die wichtigsten Hersteller-Partner:
**Eclat Textile** (Taiwan) für technische Funktionstextilien und **MAS Holdings** (Sri Lanka) als ethisch ausgerichteter Produktionspartner — beide sind in den Impact Reports namentlich genannt.

---

**Fazit für ARYS:** Wenn du ähnliche Hersteller suchst, wäre der türkische Markt (relevant für LFDY & lululemon) ein guter Einstiegspunkt für Streetwear — qualitativ hochwertig, MOQ-freundlich, und näher an Europa. Soll ich das vertiefen?

---

**Du:**

Ich möchte eine Marke wie some Leon Dore aufbauen und erstmal mit Basics starten 

Prüfe wo ich am besten produzieren kann Vergleiche und zeig mir die Produzenten an wo qualitative Marken ggf produzieren 


Ich muss wissen wo ich produzieren könnte

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Hier ist eine vollständige Übersicht für dich — strukturiert nach Produktionsland mit konkreten Herstellern:

---

## 🗺️ Wo produziert ALD?

**Aimé Leon Dore produziert primär in Portugal** — bekannt für Premium-Textilien und Handwerksqualität. Für spezifische Stücke wie Outerwear oder Kollaborationen arbeitet ALD auch mit Herstellern in **Italien** zusammen, für technische Pieces und Accessories gelegentlich in **China**.

Stoffe bezieht ALD global — aus Italien, England, Japan, Kanada und den USA.

---

## 🏭 Die 3 realistischen Produktionsländer für ARYS Basics

### 🇵🇹 Portugal — *Premium, nah, "Made in Europe"*
Das ist dein stärkstes Argument nach außen. ALD macht es vor.

Portugal ist die beste Wahl für Premium-Qualität, geringes Risiko und starkes Nachhaltigkeitsprofil — ideal für europäische Brands und globale Premium-Segmente.

**Konkrete Hersteller:**

**ASBX** (Barcelos) — Portugals #1 Hersteller für mittelhohe bis hochwertige Startups, arbeitet mit über 1.500 Brands in 55 Ländern — spezialisiert auf Luxury Streetwear Jersey (Hoodies, Sweats, Tees). MOQ: 50–100 Stück pro Style/Farbe. → asbx.pt

**Athleisure Basics (ABM)** (Porto) — White Label ab 70 Stück, Custom ab 250 Stück. OEKO-TEX® zertifiziert, Lieferzeit 3–5 Wochen für White Label, 6–10 Wochen für Custom. → athleisurebasics.com

**CFB Textile** — Luxury Blanks, Private Label und Full Custom. Blanks-Customization ab 50 Stück, Full Custom ab 150 Stück, Produktionszeit 8–10 Wochen. → createfashionbrand.com

**Labwear Studios** — Netzwerk von 16+ spezialisierten Fabriken in Portugal, eigene digitale Plattform (LabwearOS) für Tech Pack Management. No-MOQ Blanks, Full Custom ab ca. 100 Stück, Sampling 5–7 Wochen. → labwearstudios.com

---

### 🇹🇷 Türkei — *Beste Preis-Qualität, ideal für Basics-Volume*
Türkei ist oft ein guter Mittelweg — solide Qualität, gute Preise, näher als Asien. Funktioniert besonders gut für Denim und Basics.

**Impaqqt Clothing** (Istanbul) — Streetwear-Hersteller mit Fokus auf T-Shirts, Hoodies, Sweatpants. MOQ ab 50–100 Stück, kurze Lead Times, kostengünstig, beliefert UK, Deutschland und Norwegen.

LFDY produziert ebenfalls in der Türkei — das zeigt, dass das Niveau für diese Kategorie stimmt.

---

### 🇵🇱 Polen / Osteuropa — *Backup-Option, günstig, EU-Qualität*
**Custom Top** (Katowice, Polen) — spezialisiert auf Streetwear und Knitwear, MOQ ab 50 Stück pro Kollektion, Full-Service von Pattern bis Produktion.

---

## ⚖️ Direkter Vergleich

| | Portugal 🇵🇹 | Türkei 🇹🇷 | Polen 🇵🇱 |
|---|---|---|---|
| **Qualität** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| **Preis/Stück** | €€€ | €€ | €€ |
| **MOQ** | 50–150 | 50–200 | 50–100 |
| **Lead Time** | 5–10 Wo | 5–8 Wo | 6–8 Wo |
| **Brand Story** | "Made in Europe / Portugal" ✅ | — | — |
| **Wie ALD** | ✅ Ja | — | — |

---

## 💡 Meine Empfehlung für ARYS

**Starte mit Portugal (ASBX oder Labwear Studios)** — MOQ 50–100 Stück, "Made in Portugal" ist ein echtes Brand-Asset, und du bist konzeptionell direkt im ALD-Territorium. Türkei kannst du parallel für höhere Stückzahlen bei Basics (Tees, Sweats) nutzen, sobald du Volumen hast.

Soll ich konkrete Kontaktinfos und einen Anschreiben-Template für die Hersteller vorbereiten?

---

**Du:**

Es gibt oft das Problem vom Fit daher möchte ich einen Hersteller finden mit dem wir den fit so gut wie möglich treffen ggf unisex

---

**Claude:**

```
This block is not supported on your current device yet.
```

Das Fit-Problem ist tatsächlich das kritischste Thema beim Aufbau einer Premium-Brand. Lass mich das strukturiert aufdröseln:

---

## 🎯 Warum Fit scheitert — und wie du es richtig machst

Das Grundproblem: Die meisten kleinen Brands schicken ein vages Bild oder ein Referenzstück und hoffen, dass der Hersteller den Rest versteht. Das klappt nie. Was wirklich funktioniert ist ein **mehrstufiger Fit-Prozess** — und dafür brauchst du den richtigen Partner.

---

## 🏭 Die besten Hersteller speziell für Fit-Entwicklung

### 1. **ExploreTex** (Portugal + Dhaka) — Stärkster Fit-Prozess
Das ist der technisch ausgefeilteste Ansatz, den ich gefunden habe.

ExploreTex arbeitet mit einem dedizierten Pattern Maker, der ausschließlich für deine Produktkategorie zuständig ist. Sie nutzen 3D Virtual Sampling vor der physischen Produktion und verlangen bewusst ein **professionelles Fit-Model** statt Selbstanprobe — weil individuelle Körperproportionen zu technischen Fehlern im Silhouette führen können. Außerdem betreiben sie mathematisches Size Grading, das die Original-Silhouette von XS bis 5XL proportional erhält.
→ exploretex.com

### 2. **Labwear Studios** (Portugal)
Vor der Produktion kannst du entweder ein **3D-Sample oder ein physisches Sample** zur finalen Genehmigung anfordern — für Materialien, Konstruktion, Fit, Farbe oder Verarbeitung. Der gesamte Prozess läuft über ihre Plattform LabwearOS, inkl. Echtzeit-Tracking.
→ labwearstudios.com

### 3. **IMPAQQT / Turkey Clothing Manufacturers** (Istanbul)
Sample Lead Time ca. 14 Tage wenn Stoffe verfügbar. Sie arbeiten mit **Fit Approval Samples und Pre-Production Samples (PPS)** — du siehst also genau was du bekommst, bevor die Bulk-Produktion startet.
→ turkeyclothingmanufacturers.com

---

## 👕 Unisex Fit — so gehst du es strategisch an

Ein Unisex-Fit ist nicht einfach "Männerschnitt größer gemacht." ALD, Fear of God Essentials, und andere Premium-Brands lösen das so:

**Die 3 Unisex-Fit-Prinzipien:**
- **Dropped shoulder** — neutralisiert Schulterbreiten-Unterschiede zwischen Geschlechtern
- **Längerer Body** — funktioniert für beide durch Layering
- **Mittlere Hüftkurve** — weder tailliert noch komplett gerade

**Was du dem Hersteller mitgeben musst:**
1. Ein **Tech Pack** mit exakten Maßen (keine Bilder allein)
2. **Referenzstücke** zum physischen Vergleich — z.B. ein ALD-Hoodie oder Fear of God Essentials Tee
3. Klare Angabe: *"Unisex, oversized, dropped shoulder, fits S–XL"*

---

## ✅ Mein konkreter Empfehlung-Stack für ARYS

| Phase | Hersteller | Warum |
|---|---|---|
| **Fit-Entwicklung** | ExploreTex | 3D Sampling, dedizierter Pattern Maker, professionelles Fit Model |
| **Erste Produktion** | ASBX oder Labwear | 50–100 Stück MOQ, "Made in Portugal", Unisex Streetwear Expertise |
| **Skalierung** | IMPAQQT Türkei | Günstigere Stückkosten bei höherem Volumen |

---

Der erste Schritt wäre: **1–2 Referenzstücke kaufen** (z.B. ALD Tee + Hoodie), die genau deinen Ziel-Fit zeigen, und diese mit einem ersten Tech Pack an ExploreTex schicken. So minimierst du Sampling-Runden und triffst den Fit beim ersten oder zweiten Versuch.

Soll ich dir ein **Anschreiben-Template auf Englisch** vorbereiten, das du an diese Hersteller schicken kannst — mit deinen Fit-Anforderungen für ARYS?

---

**Du:**

Wie könnte ich in meinem online Shop oder auch Store für alle passende t Shirts anbieten in verschiedenen fits

---

**Claude:**

Das ist eine sehr gute strategische Frage. So machen es die besten Brands:

---

## 👕 Das Fit-System für ARYS

Statt "Unisex" als Kompromiss anzubieten, bietest du **mehrere definierte Fits** an — jeder mit eigenem Namen. Das ist auch ein starkes Brand-Element.

**Beispiel wie andere es lösen:**

- **ALD** → nennt es einfach "Relaxed" vs. "Classic"
- **Fear of God Essentials** → einen einzigen Oversized-Fit, der universell funktioniert
- **Carhartt WIP** → "Regular", "Loose", "Slim" — klare Sprache

---

## 📐 Die 3 Fits die für ARYS Sinn machen

**01 — ARYS CLASSIC**
Leicht oversized, dropped shoulder, längerer Body. Funktioniert für alle Körper, männlich und weiblich. Das ist dein Kernprodukt — der eine Fit, den alle kennen.

**02 — ARYS LOOSE**
Sehr weit, kurze Länge, boxy. Streetwear-Statement-Stück. Für die, die den maximalen Look wollen.

**03 — ARYS FITTED**
Schultergerecht, leicht tailliert aber nicht eng. Für Frauen die keinen Oversized-Look wollen, oder Männer die cleaner angezogen wirken wollen.

---

## 🛒 Im Store / Online-Shop kommunizieren

Der entscheidende Punkt ist **nicht der Fit selbst, sondern wie du ihn erklärst.**

**Online:**
- Jedes Produkt mit **zwei Fotos pro Fit** — einmal an einem schlankeren, einmal an einem breiteren Körper
- Eine **Fit Guide Seite** mit Silhouetten-Grafiken (wie ALD es macht)
- Im Produkttitel: *"ARYS TEE — Classic Fit"* — immer sichtbar

**Im Store:**
- Jeder Fit auf einer anderen Körpertype am Mannequin
- Kleine Karte an jedem Kleidungsstück: *"Classic. Dropped shoulder. Fits true to size or size up."*
- Mitarbeiter können aktiv beraten — das ist ein Vorteil des physischen Stores

---

## 💡 Die einfachste Startlösung für ARYS

Starte mit **einem einzigen Fit** — dem CLASSIC. Perfektioniere ihn über 2–3 Sampling-Runden. Dann erst kommt Fit 2.

Der häufigste Fehler ist, zu früh zu viele Varianten anzubieten. ALD hat jahrelang fast nur einen Fit gebaut — und der war so gut, dass er zur Marke wurde.

Willst du, dass ich einen **Fit Guide als visuelle HTML-Seite** für ARYS erstelle — so wie du ihn im Shop einbetten könntest?

---

