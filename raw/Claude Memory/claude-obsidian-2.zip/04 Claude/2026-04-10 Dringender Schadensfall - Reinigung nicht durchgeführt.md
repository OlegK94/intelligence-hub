---
date: 2026-04-10
tags: [claude]
---

# Dringender Schadensfall - Reinigung nicht durchgeführt

**Du:**

Guten Morgen Herr Gehrke,
Wie eben telefonisch besprochen ist bisher kein Mitarbeiter für die fachgerechte Reinigung vorbeigekommen.
Ich habe bis 10 Uhr Zeit danach erst wieder 13:30 bis 16:45.
Auch eine Bestätigung nach der gestrigen Mail habe ich nicht erhalten.
Ich bitte sie daher heute den Schaden zu beheben sollte das nicht funktionieren können wir gerne diesen Fall über den Anwalt und Versicherung laufen lassen da es scheinbar nicht in ihrer Priorität liegt den Schaden zu beheben der seit 2 Wochen umangerührt besteht.
Es kann außerdem auch nicht sein das ich ihnen so wie Vonovia hinterherlaufen muss und ständig auf kommunikationsebene hingehalten werde oder mich noch gedulden soll während sie in ruhe ihre arbeiten in der Wohnung oben durchführen statt den schaden zu beheben.
 
Beste Grüße, Oleg Kober


Formuliere

---

**Claude:**

```
This block is not supported on your current device yet.
```

Welchen Ton soll die E-Mail haben?
```
This block is not supported on your current device yet.
```

---

**Du:**

Form submitted:
• ton: Formal & juristisch
• frist: Ja, heute

---

**Claude:**

```
This block is not supported on your current device yet.
```

Denk daran, im Betreff noch die genaue Adresse oder Wohnungsnummer einzutragen. Die Formulierung „letzte Frist" hat in Deutschland auch ohne Anwalt Gewicht – gut, dass das dokumentiert ist.

---

**Du:**

Sehr geehrter Herr Kober,
 
vielen Dank für Ihre E-Mail sowie die Übermittlung der Fotodokumentation und die Aufstellung der betroffenen Gegenstände.
 
Zu Ihren Anliegen möchte ich folgende Punkte klarstellen:
 
1. Sämtliche entstandenen Schäden werden durch die Betriebshaftpflichtversicherung des verantwortlichen Nachunternehmers reguliert. Daher bitten wir Sie, alle entsprechenden Rechnungen (z.B. Reinigungskosten) direkt an Herrn Gehrke weiterzuleiten.
2. Für die verschmutzten Bekleidungsstücke und Taschen dürfte die Fotodokumentation grundsätzlich ausreichend sein. Die abschließende Entscheidung obliegt allerdings der bearbeitenden Versicherung.
3. Hinsichtlich Ihres iPhones:
1. 
* Das Gerät ist auf den übermittelten Fotos nicht sichtbar.
* Nach aktueller Einschätzung – insbesondere anhand der Art des Schadens (Estrich-Durchlauf) sowie der typischen Verschmutzungen auf den abgelichteten Gegenständen – erscheint ein Wasserschaden am iPhone technisch unwahrscheinlich. Ein Handy in einer Tasche sollte unter diesen Umständen keinen Estrich-bedingten Wasserschaden erfahren haben.
* Sollte Ihrerseits dennoch eine Entschädigung für das iPhone beansprucht werden, benötigen wir hierfür ein offizielles Gutachten, das den Zusammenhang zwischen dem Schaden am Gerät und dem Estrichvorfall zweifelsfrei bestätigt.
 
Für die weiteren Schritte bitten wir Sie um eine entsprechende Rückmeldung bzw. die Zusendung etwaiger Nachweise.
 
Mit freundlichen Grüßen
Olaf Scholtka
Bauleiter

Gern erhalten sie ein Gutachten dazu und die gennanten Rechnungen

Weder sie noch ich müssen das beurteilen sondern die Fachinstanzen

---

**Claude:**

```
This block is not supported on your current device yet.
```

Kurz und auf den Punkt – du bestätigst die nächsten Schritte und stellst gleichzeitig klar, dass seine technische Einschätzung zum iPhone irrelevant ist. Das Gutachten wird das klären.

---

