---
date: 2026-04-11
tags: [claude]
---

# Template session setup

**Du:**

Template Session

---

**Claude:**

Gib mir mehr Kontext — was soll das Template abdecken?
```
This block is not supported on your current device yet.
```

---

**Du:**

F: Welche Art von Template?
A: Anderes

---

**Claude:**

Was soll das Template leisten — und in welchem Format brauchst du es (Word, Slides, HTML, plain Text)?

---

