---
date: 2026-04-11
tags: [claude]
---

# Tiramisu mit Marsala oder Amaretto

**Du:**

Wird Tiramisu mit Amaretto gemacht?

---

**Claude:**

Klassisches, authentisches Tiramisu enthält **keinen Amaretto**. Das Originalrezept aus den 1960er/70er Jahren (Venetien/Friaul) verwendet ausschließlich **Marsala** — einen sizilianischen Süßwein — oder gar keinen Alkohol.

Amaretto ist eine weit verbreitete **moderne Variante**, die vor allem in Haushaltsrezepten und Restaurants populär wurde, weil der Mandellikör gut mit Kaffee harmoniert. Beides schmeckt, aber es ist nicht dasselbe.

**Kurz zusammengefasst:**
- Original → Marsala (oder ohne Alkohol)
- Häufige Variante → Amaretto
- Andere Varianten → Rum, Kaffeelikör, Espresso pur

---

