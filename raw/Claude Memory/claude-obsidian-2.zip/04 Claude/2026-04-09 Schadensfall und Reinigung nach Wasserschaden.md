---
date: 2026-04-09
tags: [claude]
---

# Schadensfall und Reinigung nach Wasserschaden

**Du:**

SChreibe eine Nachricht an Herr Scholtka


hier ist die Fotodokumentation vom Schaden

In der Ecke stand noch mein Rucksack welchen ich für meine Arbeit nutze wo mein Laptop und I Phone so wie andere Dinge enthalten waren 

Ich mussste diesen Sofort reinigen da dieser vollständig mit der Flüssigkeit bedeckt war und ich die Geräte retten wollte.

Der aptop ist nicht beschädigt aber das Handy hat einen Wasserschaden 

So wie jacken Pulli und Rucksack Taschen dabei verunreinigt / beschädigt wurden.

Vorfall hat sich am Samstag 28. März gegen 13-15 Uhr erreigenet und hat dabei auch die Wohnung von Frau Hofmann ebenfalls beschädigt.

Die Reinigung muss wie auf den bildern zu erkennen ebenso fahclich durchgeführt werden.

Ich bitte sie all diese Dinge durch ihre Versicherung und Fachkräfte zu beheben. reinigung diese Woche spätestens da es bereits 2 Wochen sind

---

**Claude:**

```
This block is not supported on your current device yet.
```

Zwei Varianten — die erste etwas bestimmter im Ton, die zweite etwas diplomatischer. Vergiss nicht, deinen Namen am Ende hinzuzufügen und die Fotos anzuhängen. Soll ich noch etwas anpassen?

---

