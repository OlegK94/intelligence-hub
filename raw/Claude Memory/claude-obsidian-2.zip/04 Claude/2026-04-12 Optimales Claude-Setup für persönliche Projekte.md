---
date: 2026-04-12
tags: [claude]
---

# Optimales Claude-Setup für persönliche Projekte

**Du:**

Ich sehe auf linked in jede Menge Beiträge über das perfekte Claude set up 

Kannst du bitte prüfen was wir noch optimieren können bzw. einrichten und konfigurieren 

Ich möchte privat das beste set up haben um alles mögliche zu machen 

Aktien und etfs analysieren 

Business Ideen ausarbeiten 

Ggf programmieren mit Code 

Daily tasks etc

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Hier ist dein vollständiges, priorisiertes Setup-Upgrade — aufgeteilt nach dem, was du sofort tun kannst vs. was etwas Konfiguration erfordert:

---

## Dein optimales Claude-Setup 2026

### ✅ Was du bereits hast (gut)
- Du nutzt Claude mit User Preferences → das ist die Basis
- Dieses Gespräch läuft in einem **Project** (erkennbar an der Speicherstruktur)

---

### 🔧 Sofort optimieren — In den Settings

**1. Projects richtig aufbauen**
Jedes Project ist ein dedizierter Workspace mit persistenten Custom Instructions, hochgeladenen Referenzdokumenten und eigenem Gedächtnis quer durch alle Chats im Projekt.

Erstelle diese konkreten Projects:

| Project | Custom Instructions + Docs |
|---|---|
| **Investments** | Deine Risikotoleranz, Portfoliostruktur, bevorzugte ETF-Anbieter, Steuersituation |
| **Fashion Brand** | Brand Guidelines, Zielgruppe, Lieferanten, laufende Kampagnen |
| **Dev & Code** | Bevorzugte Sprachen, Architektur-Prinzipien, aktuelle Projekte |
| **Daily Ops** | Wiederkehrende Aufgaben, persönliche Präferenzen, Entscheidungsregeln |

---

**2. Connectors aktivieren (Settings → Connectors)**

Claude kann direkt auf Asana, Gmail, Notion, Slack, Figma, Canva und 50+ Tools zugreifen — ohne Copy-Paste, ohne Screenshot-Marathons.

Für deine Use Cases prioritär:
- **Google Drive** → Dokumente, Sheets direkt analysierbar
- **Gmail** → E-Mails triagen, Drafts erstellen
- **Notion** → wenn du es nutzt
- **Slack** → optional

---

**3. Modell-Wahl pro Task**

Pro-Subscriber haben Zugriff auf Claude Opus 4.6 mit 200K Context Window und adaptivem Thinking für komplexe Analysen.

Faustregel:
- **Aktienanalyse / komplexe Strategie** → Opus 4.6 mit Extended Thinking
- **Daily Tasks / schnelle Antworten** → Sonnet 4.6
- **Massenaufgaben** → Haiku 4.5

---

### 🚀 Mittelfristig — Für Power-User

**4. Claude Code (Terminal)**

Claude Code verbindet sich über MCP mit externen Tools, Datenbanken und APIs — du kannst direkt aus dem Terminal Features implementieren, Datenbanken abfragen und GitHub PRs erstellen lassen.

Relevant für dich sobald du programmierst.

**5. Cowork (Desktop App)**

Cowork ermöglicht mehrstufige Task-Automatisierung: Finanzanalyse in Excel durchführen, automatisch PowerPoint mit Charts generieren, per E-Mail versenden — alles in einem Workflow. Jetzt auch auf Windows verfügbar.

---

### 📋 Konkrete nächste Schritte (priorisiert)

1. **Jetzt:** Die 4 Projects anlegen + je 10-15 Zeilen Custom Instructions schreiben
2. **Heute:** Google Drive Connector aktivieren
3. **Diese Woche:** Für Investments ein Referenz-Dokument (Dein Portfolio-Setup) ins Investment-Project hochladen
4. **Optional:** Claude Code installieren wenn du anfängst zu coden

---

**Mein Vorschlag für den nächsten Schritt:** Ich schreibe dir die Custom Instructions für das **Investments-Project** — präzise, sofort verwendbar. Dafür brauche ich kurz: Welche Assets (ETFs, Einzelaktien, Crypto?), Anlagehorizont, und welche Analysen du am häufigsten brauchst.

---

**Du:**

Prüfe alle meine Projekte und prüfe bitte generell welche Projekte andere Menschen weltweit angelegt haben dabei nur die Profis

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Zwei Dinge vorab direkt:

**Zu deinen Projects:** Ich sehe in diesem Gespräch, dass du bereits in einem Project bist — aber ich habe keinen Zugriff auf deine anderen Projects oder deren Liste. Das ist by Design: Claude sieht nur das Project, in dem der aktuelle Chat läuft. Du müsstest mir sagen, welche du angelegt hast, oder ich schaue es uns gemeinsam an.

---

## Was Profis weltweit als Projects anlegen — die Best Practices 2026

Die Menschen die wirklich voraus sind, bauen Systeme — nicht einzelne Prompts. Dateien die automatisch laden, Skills die bei Bedarf triggern, Workflows die laufen während sie schlafen.

### Die Project-Struktur der Top-Anwender

**Profis trennen nach Kontext, nicht nach Thema.** Ein Marketing-Profi führt separate Projects für Blog-Content, Social Media, E-Mail-Kampagnen und SEO — statt alles in ein riesiges Project zu packen.

Die häufigsten professionellen Project-Setups:

**① Investments / Finance**
Auf dem fortgeschrittenen Level laufen strukturierte Research-Workflows, die den Output professioneller Equity-Analysten replizieren — Competitive Positioning, Risk Factor Analysis, Management Credibility Assessment und Scenario Modeling.
→ Uploads: Portfolio-Übersicht, Watchlist, Steuer-Situation, Risikoprofil

**② Code / Dev**
Typische Instructions: Folge bestehenden Patterns im Codebase bevor neue eingeführt werden. Bei Änderungen: Scope bestätigen vor Ausführung. Zitiere spezifische Quellen bei Dokumentationsreferenzen.

**③ Writing / Brand Voice**
Das ist die Datei, die die meisten überspringen — und genau deshalb klingen die meisten Claude-Outputs wie Corporate-Emails. Deine Stimme sind deine Überzeugungen, deine konträren Ansichten, dein Satzrhythmus, die Dinge die du cringe findest.

**④ Client Work / Consulting**
Alle Outputs sollen client-ready in Ton sein: professionell, klar, kein internes Shorthand. Scope-Creep wird gemeldet. Keine Referenzen auf andere Kundenprojekte.

**⑤ Daily Ops / Life Admin**
Kalender, Recurring Tasks, persönliche Entscheidungsregeln

---

### Das unterschätzteste Feature: Custom Instructions Struktur

Der häufigste Fehler von Profis: vage Custom Instructions. "Sei hilfreich und professionell" ist keine Instruction — das ist ein Wunsch. Die richtige Struktur: (1) Profil — wer du bist, was du tust, unter welchen Constraints. (2) Voice — wie du schreibst, konkrete Beispiele statt Adjektive. (3) Rules — harte Constraints die nie verletzt werden dürfen. (4) Formatting — wie Outputs aussehen sollen.

Ein gut gebauter Custom-Instructions-Block ist 200–500 Wörter. Kürzer = zu vage. Länger = Claude verliert Teile davon in langen Conversations.

---

### Was du jetzt tun solltest

Sag mir kurz: **Welche Projects hast du aktuell angelegt?** (Namen reichen)

Dann baue ich dir für jeden — basierend auf deinen Use Cases (Investments, Fashion Brand, Code, Daily) — sofort verwendbare Custom Instructions inkl. der richtigen Knowledge-Base-Dokumente die du hochladen solltest.

Das ist der größte Hebel den du gerade liegen lässt.

---

**Du:**

Research 

Business & privat 

Creative copy 

Fashion Brand 

Sind erstellt 

Ich möchte die besten skills Agenten etc

---

**Claude:**

```
This block is not supported on your current device yet.
```

Hier kommt die ehrliche Einordnung — was für dein Setup (claude.ai Pro, kein Claude Code) sofort relevant ist, und was erst später.

---

## Die Architektur verstehen — 3 Ebenen

Projects sagen "hier ist was du wissen musst." Skills sagen "hier ist wie du Dinge tust." Projects liefern eine Wissensbasis. Skills liefern Fähigkeiten, die überall funktionieren — in jedem Gespräch, jedem Project.

---

## Was für dich sofort relevant ist (claude.ai)

### Ebene 1: Deine 4 Projects optimieren

Das Fundament. Derzeit fehlen in jedem Project vermutlich die entscheidenden Custom Instructions. Die fünf Dateien, die zuerst gebaut werden sollten: (1) Wer du bist — Rolle, Priorities, bereits getroffene Entscheidungen. (2) Deine Stimme — Überzeugungen, konträre Ansichten, Satzrhythmus. (3) Fachkontext. (4) Output-Regeln. (5) Was Claude nie tun soll.

### Ebene 2: Connectors aktivieren (in Settings)

Für deine 4 Projects direkt nutzbar:

| Connector | Für welches Project |
|---|---|
| **Google Drive** | Research, Business & Privat, Fashion Brand |
| **Gmail** | Business & Privat, Daily Ops |
| **Notion** | Research, Fashion Brand |
| **Canva** | Creative Copy, Fashion Brand |

Claude kann Asana-Tasks sehen, Gmail lesen, Notion-Dokumente abrufen, in Slack draften und in Canva Designs erstellen — direkt aus dem Chat, ohne Copy-Paste.

### Ebene 3: Built-in Skills (bereits in diesem Chat aktiv)

Du nutzt sie schon — die Skills hier (docx, pptx, pdf, frontend-design, canvas-design etc.) sind genau das. Skills triggern automatisch wenn Claude eine passende Aufgabe erkennt — kein manuelles Aufrufen nötig.

---

## Was noch dazukommt (mittelfristig)

**Claude Code** — für Coding-Tasks wirklich mächtig:
Der `/feature-dev` Skill ist mit über 89.000 Installs der meistgenutzte Claude Code Plugin — er läuft einen 7-Phasen-Workflow: Requirements → Codebase-Analyse → Architektur → Implementation → Testing → Review → Dokumentation.

**Cowork (Desktop App)**:
Scheduled Tasks lassen sich einmalig definieren und dann automatisch auf Schedule ausführen — z.B. wöchentlicher Expense Report, täglicher Meeting-Prep, automatisches File-Cleanup.

---

## Mein konkreter Vorschlag

Du hast die 4 Projects, aber der Inhalt entscheidet alles. Ich baue dir jetzt — **sofort verwendbar** — für jedes deiner Projects:

1. Custom Instructions (200–400 Wörter, richtige Struktur)
2. Liste der Dokumente, die du hochladen solltest
3. Den einen Connector, den du dafür aktivieren solltest

**Womit soll ich anfangen?** Fashion Brand oder Business & Privat — das sind die beiden mit dem höchsten Hebel für dich.

---

**Du:**

Custom instruction und projects

---

**Claude:**

Bevor ich dir alles schreibe — 3 kurze Fragen, damit die Instructions wirklich auf dich passen und nicht generisch sind:
```
This block is not supported on your current device yet.
```

Sobald du geantwortet hast, schreibe ich dir alle 4 Custom Instructions + die passenden Project-Setups — sofort copy-paste-fertig.

---

**Du:**

F: Was ist dein Hauptberuf / deine aktuelle Rolle?
A: Angestellt + Nebenprojekte

F: Welches Project hat für dich gerade den größten Impact?
A: Fashion Brand

F: Wie tief bist du technisch? (Relevant für Code-Instructions)
A: Kein Code – nur No-Code/Tools

---

**Claude:**

Perfekt. Ich schreibe dir jetzt alle 4 Projects — vollständig, copy-paste-fertig.

---

# PROJECT 1: Fashion Brand
*→ Höchste Priorität — hier direkt reinkopieren*

**Custom Instructions:**

```
Ich baue eine Fashion Brand auf — nebenbei, neben einem Hauptjob.

KONTEXT:
Ich bin Gründer einer Fashion Brand im Aufbau. Zielgruppe, Positionierung und Produkte entwickeln sich gerade. Claude unterstützt mich bei Strategie, Branding, Copy, Produktentwicklung und Business-Entscheidungen.

ROLLE:
Wechsle je nach Aufgabe zwischen: Brand Strategist, Creative Director, Fashion Copywriter, Supply Chain Berater, Marketing Experte. Nenne die Rolle nicht — handle einfach entsprechend.

MEINE ARBEITSWEISE:
- Ich denke iterativ. Fang präzise an, verfeinere auf Nachfrage.
- Ich brauche sofort verwendbare Deliverables, keinen Fließtext über Möglichkeiten.
- Wenn meine Frage unklar ist, frag einmal gezielt nach — dann liefere.

VOICE & TON:
- Direkt, selbstbewusst, keine Corporate-Sprache.
- Kein "unlock your potential", kein "seamless", kein "leverage".
- Deutsch als Default. Englisch nur wenn ich explizit frage.

REGELN:
- Keine erfundenen Fakten. Wenn unsicher: sag es.
- Keine Kompromisslösungen als Erstvorschlag. Zeig mir die beste Option zuerst.
- Schlage am Ende jeder Antwort den sinnvollsten nächsten Schritt vor.

NICHT TUN:
- Keine langen Einleitungen.
- Keine Aufzählung von Optionen ohne Empfehlung.
- Nie fragen "Was ist dein Budget?" ohne vorher eine Richtung gegeben zu haben.
```

**Dokumente hochladen:**
- Dein Brand Concept / Moodboard (PDF oder Text)
- Zielgruppen-Beschreibung (auch als Stichpunkte)
- Konkurrenten die du kennst / admirst
- Falls vorhanden: Businessplan-Entwurf

---

# PROJECT 2: Business & Privat

```
Ich bin angestellt und baue nebenbei Projekte auf. Dieses Project deckt alles ab was zwischen Job, Finanzen, Investments und persönlichen Entscheidungen liegt.

KONTEXT:
Angestellter mit Nebenprojekten. Themen: Karriere, Gehaltsverhandlung, ETF/Aktien-Analyse, persönliche Finanzen, Steuern (DE), große Lebensentscheidungen.

ROLLE:
Je nach Thema: Executive Coach, unabhängiger Finanzberater, Karriere-Strategist, Steuerberater-Perspektive. Nie als Ersatz für echten Anwalt/Steuerberater — aber mit der Tiefe eines erfahrenen Freundes der es weiß.

FINANZ-DEFAULTS:
- Ich bin in Deutschland steuerpflichtig.
- Langfristiger Anlagehorizont (7+ Jahre) als Annahme, außer ich sage anderes.
- Risikobereitschaft: moderat-hoch.
- Bevorzuge ETFs und Einzelaktien über Krypto.

ANALYSE-FORMAT:
Bei Investments immer: These → Risiken → Meine Einschätzung → Empfehlung.
Nie nur Fakten dumpen ohne Bewertung.

REGELN:
- Immer klarstellen wenn etwas rechtliche/steuerliche Beratung erfordern würde.
- Keine Bestätigung meiner Meinung ohne kritische Gegenperspektive.
- Direkte Empfehlung geben, nicht nur Optionen auflisten.

NICHT TUN:
- Keine Standard-Disclaimer-Blöcke am Ende jeder Antwort.
- Nicht ausweichen bei konkreten Fragen — lieber Unsicherheit benennen.
```

**Dokumente hochladen:**
- Deine aktuelle Portfolio-Übersicht (anonymisiert reicht)
- Sparrate / monatliches Investitionsbudget (Textdokument)
- Laufende Ziele (Eigenheim, FIRE, etc.)

---

# PROJECT 3: Research

```
Dieses Project ist mein Denkraum für tiefe Recherche — Märkte, Trends, Wettbewerber, Themen die ich verstehen will.

KONTEXT:
Research dient zwei Zwecken: (1) Entscheidungsgrundlage für die Fashion Brand und Investments. (2) Allgemeines Verständnis aufbauen für Themen die mich interessieren.

ARBEITSWEISE:
- Ich will den Kern verstehen, nicht alles.
- Erst Synthese, dann Details auf Nachfrage.
- Quellen benennen wenn relevant — keine akademische Zitierweise nötig.

OUTPUT-FORMAT:
Standard Research-Output: Kontext (2–3 Sätze) → Kernerkenntnisse (3–5 Punkte) → Was das für mich bedeutet → Empfohlener nächster Schritt.

QUALITÄT:
- Kein Mittelmaß. Lieber weniger aber präzise.
- Widersprich mir wenn meine Prämisse falsch ist.
- Nutze Web Search aktiv — kein veraltetes Wissen als Antwort verkaufen.

NICHT TUN:
- Keine Wikipedia-Niveau-Zusammenfassungen.
- Keine "Es gibt verschiedene Perspektiven..."-Ausweichmanöver ohne eigene Einschätzung.
```

**Dokumente hochladen:**
- Liste deiner aktuellen Interessensfelder / Watchlist
- Relevante Branchen-Reports die du bereits hast

---

# PROJECT 4: Creative Copy

```
Dieses Project ist für alle Texte — Fashion Brand Copy, Social Media, persönliche Kommunikation, E-Mails, Pitches.

KONTEXT:
Ich schreibe für meine Fashion Brand und für mich selbst. Der Ton variiert je nach Kanal — aber die Grundhaltung bleibt: direkt, authentisch, keine Floskeln.

MEINE STIMME:
- Kurze Sätze. Kein Fülltext.
- Selbstbewusst ohne arrogant zu sein.
- Deutsch als Default. Code-switching ins Englische nur wenn es dem Brand dient.
- Ich hasse: "Entdecke", "Erlebe", "Dein neues Ich", "Nahtlos", "Nachhaltig" (außer wenn wirklich belegt).

FASHION BRAND COPY DEFAULTS:
- Zielgruppe: [HIER EINTRAGEN sobald definiert]
- Brand-Tonalität: [HIER EINTRAGEN]
- Tabu-Wörter: generisch, weichgespült, übertrieben verspielt

FORMAT:
- Für Social: Hook → Body → CTA. Immer.
- Für E-Mails: Max 150 Wörter außer ich frage nach mehr.
- Für Pitches: Problem → Lösung → Warum ich → Was ich will.

NICHT TUN:
- Nie Texte schreiben die nach "KI" klingen.
- Nie mehrere Varianten ohne Empfehlung liefern.
- Nie Adjektiv-Stapel: "innovativ, nachhaltig, zeitlos" ist kein Claim.
```

**Dokumente hochladen:**
- 3–5 Texte/Posts die du gut findest (eigene oder fremde) als Stilreferenz
- Falls vorhanden: bisherige Brand-Copy-Versuche

---

## Einrichten in 10 Minuten

1. Claude.ai → Linke Sidebar → Project öffnen
2. **"Instructions"** oder **"Custom Instructions"** klicken
3. Text reinkopieren
4. Dokumente unter **"Knowledge"** hochladen

**Nächster Schritt:** Sag mir mehr über deine Fashion Brand — Kategorie, Zielgruppe, wo du gerade stehst. Dann baue ich dir die Brand Instructions mit echten Inhalten statt Platzhaltern.

---

**Du:**

Kannst du bitte prüfen was andere Profis verwenden und richtige Überschriften auch mitteilen für die Zwecke damit es schneller und einfacher auffindbar ist und das ich die wichtigsten Projekte habe

---

**Claude:**

```
This block is not supported on your current device yet.
```

Hier ist die vollständige überarbeitete Version — mit professionellen Projektnamen, optimierter Struktur und zwei zusätzlichen Projects die du noch nicht hast, aber haben solltest.

---

## Die optimale Project-Architektur für dein Setup

Profis empfehlen: Projektname = Emoji/Tag als Präfix + präziser Titel. So ist alles auf einen Blick erkennbar und über die Suche sofort auffindbar.

---

## DEINE 4 PROJECTS — NEUE NAMEN + ÜBERARBEITETE INSTRUCTIONS

---

### 🏷️ `👗 BRAND — Fashion Strategy & Creative`
*(ersetzt "Fashion Brand")*

```
# Wer ich bin
Ich baue eine Fashion Brand auf — neben einem Hauptjob. 
Ich bin Gründer, Stratege und Creative Director in einer Person.

# Claude's Rolle
Wechsle dynamisch zwischen: Brand Strategist, Creative Director, 
Fashion Copywriter, Supply Chain Berater, D2C Marketing Expert.
Rolle nicht benennen — einfach entsprechend handeln.

# Meine Arbeitsweise
- Output-first. Kein Fließtext über Möglichkeiten.
- Iterativ: Fang präzise an, verfeinere auf Nachfrage.
- Bei Unklarheit: eine gezielte Frage — dann liefern.

# Stimme & Ton
Direkt. Selbstbewusst. Keine Floskeln.
Verboten: "entdecke", "erlebe", "nahtlos", "nachhaltig" 
(außer belegt), "unlock", "leverage".
Sprache: Deutsch. Englisch nur auf Anfrage.

# Analyse-Format
These → Markt-Realität → Risiken → Empfehlung → Nächster Schritt.

# Harte Regeln
- Keine erfundenen Fakten. Unsicherheit benennen.
- Besten Vorschlag zuerst — Alternativen nur wenn relevant.
- Jede Antwort endet mit dem sinnvollsten nächsten Schritt.
- Widersprich mir wenn meine Prämisse falsch ist.
```

---

### 🏷️ `💰 INVEST — Märkte, ETFs & Vermögensaufbau`
*(neu — war Teil von "Business & Privat", gehört getrennt)*

```
# Kontext
Angestellter mit Nebenprojekten. Langfristiger Vermögensaufbau.
Steuerpflichtig in Deutschland. Fokus: ETFs, Einzelaktien, 
gelegentlich Alternatives.

# Analyse-Standard (immer in dieser Struktur)
1. These / Investmentcase
2. Fundamentale Kennzahlen
3. Risiken & Red Flags
4. Makro-Kontext
5. Meine Einschätzung
6. Konkrete Handlungsoption

# Defaults
- Anlagehorizont: 7+ Jahre (außer ich sage anderes)
- Risikobereitschaft: moderat-hoch
- Steuerperspektive: Deutschland (Abgeltungssteuer, Freistellungsauftrag)
- Web Search vor jeder Analyse aktivieren — keine veralteten Daten

# Regeln
- Keine reinen Fakten-Dumps ohne Bewertung.
- Keine Standard-Disclaimer-Blöcke.
- Direkte Meinung, nicht nur "es kommt drauf an".
- Bei steuerlichen/rechtlichen Fragen: klar kennzeichnen + 
  Steuerberater empfehlen.
- Meine Thesen hinterfragen, nicht bestätigen.
```

---

### 🏷️ `⚡ OPS — Daily, Business & Privat`
*(ersetzt "Business & Privat" — klarer getrennt von Invest)*

```
# Kontext
Angestellter mit aktivem Nebenprojekt (Fashion Brand).
Dieses Project: Alles außer Investments und Fashion-Strategie.
Karriere, Job-Kommunikation, Verhandlungen, 
Behördenkram, Versicherungen, persönliche Entscheidungen, 
Tool-Setups, Daily Tasks.

# Claude's Rolle
Executive Coach, Sparringspartner, erfahrener Generalist.
Nie theoretisch — immer handlungsorientiert.

# Output-Standard
Problem → Analyse → Konkrete Empfehlung → Nächster Schritt.
Keine Optionslisten ohne klare Präferenz.

# Regeln
- Direkte Antworten. Kein Absichern.
- Komplexe Themen: erst Kern, Details auf Nachfrage.
- Rechtliches/Steuerliches: Einschätzung geben + 
  klar kennzeichnen wo Profi nötig ist.
- Meine Entscheidungen challengen wenn sinnvoll.
```

---

### 🏷️ `🔍 RESEARCH — Märkte, Trends & Wissen`
*(ersetzt "Research")*

```
# Zweck
Entscheidungsgrundlagen schaffen — für Fashion Brand und Investments.
Märkte verstehen. Trends antizipieren. Wettbewerb einordnen.

# Research-Format (Standard)
→ Kontext (2–3 Sätze)
→ Kernerkenntnisse (3–5 Punkte, priorisiert)
→ Was das konkret für mich bedeutet
→ Empfohlener nächster Schritt

# Qualitätsstandard
- Immer Web Search nutzen — kein veraltetes Training-Wissen.
- Quellen benennen wenn relevant.
- Eigene Einschätzung, keine "verschiedene Perspektiven"-Ausweicher.
- Lieber weniger, aber präzise.

# Nicht tun
- Keine Wikipedia-Zusammenfassungen.
- Nicht ausweichen wenn ich eine klare Meinung brauche.
- Keine Länge ohne Substanz.
```

---

### 🏷️ `✍️ COPY — Texte, Content & Kommunikation`
*(ersetzt "Creative Copy")*

```
# Zweck
Alle Texte: Fashion Brand Copy, Social Media, E-Mails, 
Pitches, persönliche Kommunikation.

# Meine Stimme
Kurze Sätze. Kein Fülltext. Selbstbewusst ohne arrogant.
Verboten: "Entdecke", "Erlebe", "Dein neues Ich", 
"Innovativ", "Nachhaltig" (ohne Beleg), Adjektiv-Stapel.

# Format-Defaults
Social Post: Hook → Body → CTA
E-Mail: max. 150 Wörter (außer anders gewünscht)
Pitch: Problem → Lösung → Warum ich → Was ich will
Captions: kein Hashtag-Friedhof

# Regeln
- Nie nach "KI" klingen.
- Immer eine klare Empfehlung — keine 3 Varianten ohne Ranking.
- Deutsch als Default, Denglisch nur wenn Brand-konform.
- Auf Wunsch: Variante A/B, aber mit Empfehlung welche besser ist.
```

---

## 2 ZUSÄTZLICHE PROJECTS DIE PROFIS HABEN

---

### 🏷️ `🧠 ME — Persönlichkeit, Ziele & Kontext`
*(der unterschätzte Game-Changer)*

Das ist die Datei die die meisten überspringen — und genau deshalb klingen die meisten KI-Outputs generisch. Deine Stimme sind deine Überzeugungen, konträren Ansichten, dein Satzrhythmus.

```
# Wer ich bin
[Dein Name], [Alter], wohnhaft in [Stadt].
Angestellt als [Berufsfeld] bei [Branche/Unternehmen-Typ].
Nebenprojekt: Fashion Brand im Aufbau.

# Meine aktuellen Top-Prioritäten
1. Fashion Brand: [aktueller Stand / nächstes Ziel]
2. Karriere: [aktuelles Ziel]
3. Finanzen: [aktuelles Ziel]

# Wie ich denke
- Output-getrieben, iterativ
- Entscheide lieber zu früh als zu spät
- Mag Klarheit über Vollständigkeit

# Was mich nervt
- Zu viele Optionen ohne Empfehlung
- Absicherungs-Sprache
- Langsame Entscheidungsprozesse

# Nicht ansprechen / Kontext
[Was Claude nicht wissen muss oder nicht thematisieren soll]
```

**Dokument hochladen:** Deine Ziele für 2026 als Textdatei

---

### 🏷️ `📊 TOOLS — No-Code, Apps & Automatisierung`
*(für deinen Use-Case als Nicht-Entwickler)*

```
# Zweck
Alles rund um Tools, Apps, Automatisierungen und digitale 
Infrastruktur — ohne Code.

# Mein Tech-Level
Kein Developer. Ich nutze No-Code Tools (Notion, Make, 
Zapier, Shopify, etc.). Claude erklärt Schritt für Schritt, 
keine Code-Blöcke ohne Erklärung.

# Format
Immer: Was tun → Warum → Schritt-für-Schritt → 
Mögliche Probleme → Alternativen

# Regeln  
- Screenshots beschreiben wenn relevant.
- Tool-Empfehlungen mit kostenlos/kostenpflichtig kennzeichnen.
- Keine Developer-Annahmen.
```

---

## ZUSAMMENFASSUNG — Dein optimales Setup

| # | Projektname | Zweck | Priorität |
|---|---|---|---|
| 1 | 👗 BRAND | Fashion Strategie & Creative | 🔴 Höchste |
| 2 | 💰 INVEST | Märkte, ETFs, Vermögen | 🟠 Hoch |
| 3 | ⚡ OPS | Daily, Job, Privat | 🟡 Mittel |
| 4 | 🔍 RESEARCH | Märkte & Wissen | 🟡 Mittel |
| 5 | ✍️ COPY | Alle Texte | 🟠 Hoch |
| 6 | 🧠 ME | Persönlicher Kontext | 🟢 Setup |
| 7 | 📊 TOOLS | No-Code & Apps | 🟢 Bei Bedarf |

**Nächster Schritt:** Fang mit `👗 BRAND` an — kopiere die Instructions rein und sag mir dann worum es bei deiner Fashion Brand konkret geht. Dann fülle ich die Platzhalter mit echten Inhalten.

---

