---
date: 2026-06-13
tags: [claude]
---

# Migration zu Obsidian vorbereiten

**Du:**

Kannst du mir alles vorbereitten zur migration zu obisidian aus diesem Projekt?

---

**Claude:**

The user wants to migrate everything from this Claude Project to Obsidian. Let me understand what they have in this project:

1. A Master Prompt HTML document for financial analysis (Gesamtfinanzanalyse)
2. Memory context about their personal/financial/fitness situation
3. Various conversations in this project

They want to prepare everything for migration to Obsidian. Let me think about what this entails:

1. Extract all relevant context/knowledge from the project memories
2. Create an Obsidian vault structure
3. Convert the HTML master prompt to a usable Obsidian note
4. Create proper MOC (Map of Content) notes
5. Organize the folder structure with proper linking

The project really centers around two main areas: finance work with Wagglz GmbH and OK Capital UG plus financial rehabilitation efforts, and fitness/performance focused on Hyrox training and body composition goals. I need to design an Obsidian vault that separates these tracks while keeping the Master Prompt accessible as a central reference tool.

Building the vault structure with a dashboard at the top level, then branching into Finance and Performance sections with their respective overviews and detailed notes, plus dedicated folders for templates and prompt resources. Now I'm creating the actual Markdown files and converting the HTML content into clean, interconnected notes that fit this structure. I should package this as a downloadable zip file with proper Obsidian vault structure, including YAML frontmatter and internal links, so they can import everything directly. I'll write the markdown files with all the financial and fitness context preserved, then compress the whole vault for easy migration. I'm finishing up the file list and realizing I should package everything as a zip file for easy import into Obsidian. Let me create the complete directory structure with all the markdown files and then compress it. Now I'm filling in the specific financial details—monthly net salary, quarterly commissions, current account balance in overdraft, minimal savings, outstanding loans for orthodontics and the company car benefit, plus my role as shareholder and managing director at Wagglz GmbH.

I'm also tracking the obligations from OK Capital UG, the shareholder loans running monthly, and the accounting fees due for both companies totaling around 8,000 euros annually, which traces back to an initial crypto investment financed through the VW Bank credit.

For the fitness metrics, I'm documenting my current body composition—height, weight, body fat percentage, lean mass—and noting the waist-to-hip ratio against my target threshold.

My basal metabolic rate comes to about 2,113 calories, and I'm aiming to reduce body fat while building upper body strength with a focus on longevity. Hyrox training is my main focus, though aerobic capacity is the limiting factor right now. I've identified postural issues—significant forward head posture and a rightward shift in my center of gravity—that need addressing alongside the training.

I'm targeting around 2,800 calories and 220 grams of protein daily based on a corrected TDEE calculation, timing cold exposure carefully to avoid interference with strength work, and combining Zone 2 training with postural correction as a unified high-leverage approach. Bloodwork is scheduled for late May with ApoB being requested separately from the standard panels.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

ZIP enthält 12 Dateien, vollständig verlinkt, sofort importierbar. Struktur:

```
ObsidianVault/
├── Home.md                          ← Dashboard mit Schnellzugriff + kritischen Zahlen
├── Finance/
│   ├── 00 Finanz-Übersicht.md       ← Alle Zahlen, Risiken, Allokationsplan
│   ├── Wagglz GmbH.md
│   ├── OK Capital UG.md
│   ├── Rehabilitation Plan.md       ← 3-Phasen-Plan komplett
│   └── Master Prompt – Gesamtanalyse.md  ← HTML konvertiert, Prompt kopierfertig
└── Performance/
│   ├── 00 Performance-Übersicht.md
│   ├── Körper & Scan.md             ← Scan-Daten 29.05.2026
│   ├── Hyrox Prep.md
│   └── Blutbild Panel.md            ← 24 Marker + Zielbereiche
└── Templates/
    ├── Claude Session – Finanzen.md  ← Kontext-Block + Session-Typen
    └── Claude Session – Performance.md
```

**Import:** ZIP entpacken → Ordner `ObsidianVault` in Obsidian als neues Vault öffnen (oder in bestehendes Vault einfügen). Alle `[[Links]]` funktionieren sofort. YAML-Frontmatter ist Dataview-kompatibel falls du das Plugin nutzt.

Die Templates sind der eigentliche Hebel — damit startest du jede neue Claude-Session ohne Kontext nochmal eintippen zu müssen.

---

