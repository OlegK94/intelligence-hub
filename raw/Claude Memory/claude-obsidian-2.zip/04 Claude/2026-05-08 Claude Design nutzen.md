---
date: 2026-05-08
tags: [claude]
---

# Claude Design nutzen

**Du:**

Wie nutze ich Claude Design ?

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

**Claude Design** ist ein neues Anthropic-Labs-Produkt, das am 17. April 2026 gestartet ist. Hier das Wesentliche kompakt:

---

## Was ist es?

Ein kollaboratives Tool, das visuelle Outputs erstellt — Designs, interaktive Prototypen, Slides, One-Pager und mehr. Es folgt einem natürlichen kreativen Workflow: du beschreibst, Claude generiert, du verfeinerst.

---

## Wer hat Zugang?

Verfügbar als Research Preview für **Pro, Max, Team und Enterprise**-Subscriber. Bei Enterprise ist es standardmäßig deaktiviert und muss vom Admin aktiviert werden.

---

## Wie funktioniert es?

**1. Starten** — Du startest mit einem Text-Prompt, kannst aber auch Screenshots, Bilder, Dokumente (DOCX, PPTX, XLSX) hochladen oder ein Code-Repository verlinken.

**2. Iterieren** — Das UX-Design ist auf intuitive Bearbeitung ausgelegt: ein Inline-Kommentar-System für spezifische Anpassungen, custom Slider für Feinabstimmungen wie Farbe und Schriftgröße, und direkte manuelle Edits.

**3. Design System** — Bei Onboarding baut Claude aus deinem Codebase und Design-Dateien ein Team-Design-System — danach werden deine Farben, Typografie und Komponenten automatisch in jedem Projekt angewendet.

**4. Exportieren** — Fertige Designs können als interne URL geteilt, als Ordner gespeichert oder nach Canva, PDF, PPTX oder standalone HTML exportiert werden.

**5. Übergabe an Claude Code** — Wenn ein Design bereit zum Bauen ist, verpackt Claude alles in ein Handoff-Bundle, das mit einer einzigen Anweisung an Claude Code übergeben werden kann — von der Exploration über den Prototyp bis zum Produktionscode, alles im Anthropic-Ökosystem.

---

## Typische Anwendungsfälle

Interaktive Prototypen zum User-Testing ohne Code-Review, Wireframes für Feature-Flows, Design-Explorations, Pitch Decks und Präsentationen — von der Rohfassung zu einem fertigen, markenkonsistenten Deck in Minuten.

---

## Praktischer Einstieg (für dich als Brand-Builder)

Für ARYS wäre das besonders relevant: Brand Deck, One-Pager für Investoren, Website-Prototyp — alles ohne Designer. Du beschreibst Ästhetik + Zielgruppe, Claude generiert, du verfeinerst per Kommentar oder Slider.

**Nächster Schritt:** Öffne claude.ai → suche oben nach „Design" oder dem Anthropic Labs-Bereich — sofern dein Plan (Pro/Max/Team) das freischaltet.

---

