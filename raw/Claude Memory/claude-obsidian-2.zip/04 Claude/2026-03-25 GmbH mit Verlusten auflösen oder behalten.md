---
date: 2026-03-25
tags: [claude]
---

# GmbH mit Verlusten auflösen oder behalten

**Du:**

Ich hab eine GmbH und die hat Verluste von 80k etc ohne Verbindlichkeiten 

Ich weiß nicht was ich machen soll und ob ich diese zu machen soll aktuell kostet sie mich nur

---

**Claude:**

Das ist eine klassische Situation – lass mich dir einen Überblick geben, was deine Optionen sind.

**Erstmal: Was bedeutet die Lage konkret?**

80k Verlust ohne Verbindlichkeiten ist eigentlich eine relativ komfortable Position – du schuldest niemandem Geld, die GmbH "blutet" nur durch laufende Kosten (Geschäftsführergehalt, Buchhaltung, IHK, etc.).

---

**Deine Hauptoptionen:**

**1. GmbH liquidieren (freiwillige Auflösung)**
- Du beschließt die Auflösung, ein Liquidator wird bestellt (meist du selbst)
- Sperrjahr abwarten (12 Monate Gläubigeraufruf)
- Dann Löschung im Handelsregister
- Kosten: Notar ~500–1.500€ + Steuerberater
- Dauer: ca. 1–1,5 Jahre

**2. GmbH "auf Eis legen" (ruhend stellen)**
- Keine aktive Geschäftstätigkeit, aber GmbH bleibt bestehen
- Laufende Kosten sinken stark (keine BWA nötig, nur Jahresabschluss)
- Sinnvoll wenn du die Hülle evtl. später wieder brauchst
- Kosten: ~500–1.000€/Jahr für Abschluss + IHK

**3. GmbH verkaufen / übertragen**
- Die 80k Verlust sind ein **steuerlicher Verlustvortrag** – für jemanden mit Gewinnen wertvoll
- Allerdings: Mantelkauf ist steuerrechtlich sehr eingeschränkt (§ 8c KStG), daher in der Praxis schwierig

**4. Weitermachen / Pivot**
- Nur sinnvoll wenn du einen konkreten Plan hast

---

**Was ich dir empfehlen würde zu klären:**

- Hat die GmbH noch einen **aktiven Geschäftszweck** oder eine Lizenz/einen Vorteil (z.B. Rahmenverträge)?
- Wie hoch sind die **monatlichen Fixkosten** aktuell genau?
- Hast du **Pläne**, die GmbH-Struktur in Zukunft zu brauchen?

Ich bin kein Steuerberater – für die finale Entscheidung solltest du einen hinzuziehen. Aber magst du mir mehr zu den Details sagen? Dann kann ich dir konkreter helfen, was wahrscheinlich am sinnvollsten ist.

---

**Du:**

Aktuell Kosten von 300-400€ mal

---

**Claude:**

Das ist eigentlich sehr wenig – bei 300–400€/Monat sind das nur ~4.000€/Jahr.

**Die entscheidende Frage ist:**

Kommt da in den nächsten 1–2 Jahren nochmal was, oder ist das Thema für dich durch?

Denn bei so niedrigen Fixkosten lohnt sich die Liquidation kaum, wenn du dir nicht 100% sicher bist – die kostet dich einmalig auch ~1.500–3.000€ und ein Jahr Nerven.
```
This block is not supported on your current device yet.
```

---

**Du:**

F: Was ist deine Tendenz für die GmbH?
A: Ruhend stellen / auf Eis

F: Was macht die GmbH / was war der Zweck?
A: App für Tierärzte

---

**Claude:**

Okay, das macht Sinn. Eine App-GmbH ruhend zu stellen ist oft die klügste Entscheidung – du behältst die Option, ohne weiter zu verbrennen.

**Was "ruhend stellen" konkret bedeutet:**

Du stellst einfach den aktiven Betrieb ein. Keine neuen Umsätze, keine Ausgaben mehr. Die GmbH existiert weiter, aber schläft.

**Was du trotzdem brauchst (Minimalaufwand):**
- Jahresabschluss beim Steuerberater (~500–800€/Jahr)
- Steuererklärungen einreichen (Körperschaft- + Gewerbesteuer, auch wenn 0€ rauskommt)
- IHK-Beitrag (~150–200€/Jahr, kannst du Befreiung beantragen bei Ruhe)
- Bundesanzeiger-Veröffentlichung des Abschlusses (~50€)

**Deine laufenden 300–400€ würden auf ~60–80€/Monat sinken.**

---

**Der echte Vorteil für dich:**

Die 80k Verlust bleiben als **Verlustvortrag** erhalten. Wenn du die App irgendwann neu aufziehst oder die GmbH für ein anderes Projekt nutzt, kannst du künftige Gewinne damit verrechnen – das ist bares Geld wert.

---

**Konkrete nächste Schritte:**

1. Alle laufenden Verträge kündigen (Server, Tools, Lizenzen)
2. Geschäftskonto auf Minimum reduzieren oder wechseln (z.B. kostenloses Konto)
3. Steuerberater kurz informieren, damit der Jahresabschluss korrekt als "ruhend" gemacht wird

Hast du noch Mitarbeiter oder laufende Kundenverträge, die du abwickeln müsstest?

---

**Du:**

Nur Mobilfunk läuft im September aus und Rechtschutz Firma und privat

---

**Claude:**

Perfekt, das ist überschaubar.

**Mobilfunk** – einfach im September auslaufen lassen, nicht verlängern. ✓

**Rechtsschutz Firma** – kündigen, brauchst du bei einer ruhenden GmbH nicht. Prüf kurz die Kündigungsfrist (meist 3 Monate zum Jahresende).

**Rechtsschutz privat** – das hat nichts mit der GmbH zu tun, den behältst du einfach persönlich wenn du willst.

---

Nach September hast du dann quasi **0€ laufende Kosten** in der GmbH, nur noch den Jahresabschluss einmal im Jahr.

Das ist eigentlich die perfekte Situation – minimaler Aufwand, maximale Flexibilität. Die 80k Verlustvortrag schlummern und warten auf bessere Zeiten. 

Gibt es noch ein Geschäftskonto mit Kontoführungsgebühren?

---

