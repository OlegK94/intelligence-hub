---
date: 2026-04-08
tags: [claude]
---

# Investor-Memo für Seed-Runde

**Claude:**

Oleg, das ist ein ambitionierter Analyseauftrag. Ich werde das als umfassendes Investor-Memo in einem professionellen PDF aufbereiten — das ist der richtige Rahmen für ein Dokument dieser Tiefe und Länge. Lass mich zuerst die Skill-Dokumentation lesen, dann lege ich los.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Good, I have solid data now. Let me build this comprehensive PDF.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Oleg, hier ist deine vollständige Investor-Analyse — 10 Kapitel, datengetrieben, mit realen Benchmarks.

Die drei wichtigsten Takeaways aus meiner Analyse:

**Die Marktlücke existiert.** Asket macht ~29 Mio. USD Umsatz mit reinem Produkt-Fokus, bootstrapped. CDLP und Sunspel beweisen, dass Premium Basics funktionieren. Aber keiner kombiniert Produktqualität mit Community-Kultur in deinem Preisband in Europa.

**Das größte Risiko bist du selbst** — genauer: die Versuchung, alles gleichzeitig aufzubauen. Cafe, Bar, Records, Events — das ist die Vision für Jahr 5. In Jahr 1 brauchst du ein perfektes T-Shirt und 500 Leute auf einer Waitlist. Sonst nichts.

**Was dir fehlt für eine Seed-Runde:** Ein physischer Prototyp, eine validierte Nachfrage (Pre-Orders), und ein Co-Founder oder starkes Advisory Board. Ohne diese drei Signale würde ich als Investor nicht investieren — egal wie gut das Konzept auf Papier aussieht.

---

**Du:**

https://www.uniqlo.com/de/de/
https://snocks.com
https://livefastdieyoung.com/?srsltid=AfmBOopeEYoqgDo8aE42SYJbb760rtuW5bvFbpNk89YxTwqQz-QODWVl
https://www2.hm.com/de_de/index.html?srsltid=AfmBOorxN11Fdf1hMm-X6INv1u83CLHmh1OuE385voSVHAWJvfQqR6Ii
https://www.cos.com/de-de
https://www.aimeleondore.com
https://www.carhartt-wip.com/de-de?srsltid=AfmBOoq-iUffDURV-F4vFeq0ZhiaqNWOveGgQRU_HuX2pKlUYvAIgQQJ
https://www.arket.com/de-de/?srsltid=AfmBOopdWx7HXvfog3SwLMcuBWW2OwKKag2VBu_LJsxd2pEO8A6IVJFR

Prüfe diese Marken ebenfalls und korrigiere bzw. prüfe Preise ganz genau gern auch andere marken

GMBH und UG habe ich in einer Holding Struktur schon, Bank etc, Handelsregister alles erledigt und ready to Start

Ich kann aktuell ca 1,6 pro Monat investiren und alle 4 Monate 5k

Ich möchte von anfang an profitable sein und ggf. dann nach Mengen wie bsp. 100 Shirts bestellen und verkaufen und sobald wir bei 30 sind nochmal nach bestellen oder in drops prüfe auch hier welche version am ebsten ist

---

**Claude:**

Ich werde die Websites analysieren und Preise prüfen, dann die Analyse mit deinen aktualisierten Rahmenbedingungen überarbeiten.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Now I have good price data. Let me get the remaining brands quickly.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Now I have enough data to build the updated analysis. Let me compile everything into the revised PDF.
```
This block is not supported on your current device yet.
```

Good — now I have comprehensive pricing data. Let me build the updated PDF with all corrections.
```
This block is not supported on your current device yet.
```

Excellent — now I have all the data I need. Let me create the updated, comprehensive PDF.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Oleg, hier ist die aktualisierte V2 mit allen Korrekturen. Die wichtigsten Änderungen gegenüber V1:

**Verifizierte Preislandschaft:** Alle Wettbewerber mit echten, recherchierten Preisen — von H&M (7,99 EUR T-Shirt) bis ALD (~135 EUR Hoodie). Dein Sweet Spot liegt bei **49 EUR T-Shirt / 89 EUR Hoodie**.

**Komplett neue Bootstrapping-Strategie:** Angepasst an dein reales Budget von 1.600 EUR/Monat + 5.000 EUR/Quartal. Wichtigste Erkenntnis: **White-Label-Blanks aus Portugal** (MOQ ab 50–70 Stk. für ~8–12 EUR/Stk.) senken dein Risiko massiv gegenüber Custom Cut-and-Sew. Damit ist ein erster Drop von 100 T-Shirts für unter 2.000 EUR machbar — und bei Sell-Through generiert er ~3.200 EUR Gewinn, der Drop 2 (Hoodie) finanziert.

**Hybrid-Modell statt reinem Reorder:** Core-SKUs (Schwarz/Weiß) permanent mit Reorder bei 30 Stk. Restbestand, plus limitierte Farb-Drops pro Quartal. Das gibt dir Revenue-Stabilität und Drop-Hype gleichzeitig.

**Dein größter Vorteil:** Die Holding-Struktur existiert bereits — das spart dir 3–5k EUR und 3 Monate. Erster konkreter Schritt: EUIPO-Markenanmeldung und 2–3 Sample-Blanks aus Portugal bestellen. Damit kannst du diese Woche noch anfangen.

---

