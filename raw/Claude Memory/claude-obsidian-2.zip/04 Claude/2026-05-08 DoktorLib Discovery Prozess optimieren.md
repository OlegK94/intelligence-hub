---
date: 2026-05-08
tags: [claude]
---

# DoktorLib Discovery Prozess optimieren

**Du:**

Ich würde gern bei DoktorLib unseren Discovery Prozess, äh, optimieren Und zwar läuft es aktuell so ab, wir bekommen Inbounds und diese Inbounds terminieren wir mit, wo der Arzt paar Fragen ausfüllen muss, wo wir dann auch feststellen, ob dieser Arzt oder nicht. Anschließend haben wir einen Demotermin wo ich aber schon zu dem Demotermin ganz viele andere Fragen dem Arzt oder der Praxis stellen wollte. Damit alle Informationen vor dem Demotermin schon ausgefüllt sind. Anschließend würden wir im Demotermin dann diese Daten validieren. Das heißt, sprechen ganz viel mit dem Arzt über Workflows und Anforderungen. Und stellen fest, ob die Praxis zum jetzigen Zeitpunkt auch passt, wie wir entwickelt sind und ob Sie mit der Praxissoftware direkt starten können oder ob wir das in die Zukunft terminieren. Anschließend muss noch ein Tech Audit durchgeführt werden von dem IT Servicepartner. Und im Nachgang muss das Ganze als Handover an Deployment übergeben werden. Hierbei die Frage, wie können wir das am besten konstruieren? Aktuell ist unser Salesforce nicht so flexibel beziehungsweise das Unternehmen ist in der Veränderung nicht so flexibel, weil wir jetzt weltweit skalieren. Wir möchten dennoch ein eine Lösung finden, wo wir alle Fragen vorher einholen können, dem Arzt auch eine Reise gewisser Weise auch vorzeigen können, eine Timeline, wo er sich grad befindet, welche Information braucht er, Systemvoraussetzungen, rund die ganzen Thematiken, die dabei anfallen. Daher brauch ich eine Lösung, wie wir das Problem am besten lösen. Sodass Deployment wirklich dann eine vernünftige Handoverübergabe bekommt in digital am besten alles. Sodass das nicht so fehleranfällig ist und nachbearbeitbar ist. Falls sich Dinge zum weiterentwickeln.

---

**Claude:**

Bevor ich eine Lösung vorschlage, drei gezielte Rückfragen:

**1. Salesforce-Nutzung heute**
Werden Inbounds, Demo-Notizen und der Handover an Deployment aktuell alle in Salesforce abgebildet – oder gibt es parallele Tools (Excel, E-Mail, Notion etc.)?

**2. Arzt-seitige Interaktion**
Soll der Arzt/die Praxis die Fragen aktiv in einem Portal/Formular ausfüllen und seinen Fortschritt sehen – oder soll das intern von euch gepflegt werden und der Arzt bekommt nur eine Übersicht per E-Mail/PDF?

**3. Deployment-Handover heute**
In welchem Format bekommt Deployment heute die Infos – Salesforce-Eintrag, E-Mail, Dokument? Und was fehlt konkret, damit es „sauber" ist?

---

**Du:**

Also aktuell machen wir in Salesforce Notizen, die Discovery Notes. Das heißt, alles rund das gesamte Demogeschpräch rund die Praxis, wie sie arbeitet, wie sie mit Labor und Co umgeht. Und dann gibt es einen KEB, Kundenerfassungsbogen, Dort werden nach Abschluss, sobald der Vertrag unterschrieben worden ist, alle Daten eingetragen und das ist dann das Handover für Deployment. Was ich mir vorstelle, ist, dass die Praxen selbstständig vorher Information angeben Das sind so Basic Informationen wie, mit welchem Labor arbeiten Sie? Haben Sie Medizingeräte? Wenn ja, welche haben Sie? Aktuell bekommt Deployment dieses KIB anhand 1 Exceltabelle.

---

**Claude:**

Perfekt, das reicht mir. Ich habe ein klares Bild.

**Die eigentliche Diagnose zuerst:**

Du hast drei strukturelle Probleme:

1. **Medienbruch** – Discovery in Salesforce-Notizen (Freitext), Handover als Excel-KEB = fehleranfällig, nicht skalierbar
2. **Informationslücke vor dem Demo** – der Arzt kommt unvorbereitet, du verlierst wertvolle Demominuten mit Basic-Datenerhebung
3. **Kein Arzt-seitiges Erlebnis** – die Praxis sieht nicht, wo sie im Prozess steht, was als nächstes kommt, was sie noch braucht

---

**Mein Lösungsvorschlag: Ein strukturierter Pre-Demo Intake-Flow außerhalb von Salesforce**

Da Salesforce nicht flexibel ist, baust du daneben einen schlanken, eigenständigen Prozess – der aber am Ende sauber in Salesforce/KEB mündet.

---

### Das Konstrukt

**Tool-Empfehlung: Tally.so + Notion (oder direkt HubSpot als Alternative)**

Aber erst das Prinzip, dann das Tool.

---

### Die 4 Phasen neu gedacht

**Phase 1 – Inbound & Terminierung**
Wie heute. Arzt bucht Termin. Direkt im Bestätigungs-E-Mail bekommt er einen Link zu einem strukturierten Intake-Formular.

**Phase 2 – Arzt-seitiger Intake (vor Demo)**
Ein strukturiertes Online-Formular (z.B. Tally oder Typeform) mit:
- Praxisart, Fachrichtung, Mitarbeiteranzahl
- Welche Praxissoftware?
- Welches Labor?
- Medizingeräte (ja/nein + welche)
- IT-Situation (eigener IT-Dienstleister, ja/nein)
- Patientenvolumen pro Quartal
- Aktueller Schmerzpunkt / Warum jetzt?

Der Arzt sieht dabei eine **Progress-Bar** (Schritt 1 von 3 ausgefüllt) und weiß, was noch kommt (Demo → Tech Audit → Go-Live).

**Phase 3 – Demo**
Du öffnest die Antworten live. Validierst, vertiefst, ergänzt. Keine Grundlagenerhebung mehr. Discovery Notes in Salesforce bleiben – aber du startest nicht bei null.

**Phase 4 – Handover an Deployment**
Nach Vertragsabschluss werden die Intake-Daten + deine Discovery Notes automatisch in einen **digitalen KEB** überführt – kein Excel mehr, sondern ein ausfüllbares Dokument oder Notion-Eintrag, das Deployment direkt weiterverarbeiten kann.

---

### Konkrete Tool-Architektur

```
Inbound → Kalender-Link (Calendly/Chili Piper)
              ↓
         Bestätigungs-Mail mit Intake-Link
              ↓
         Tally-Formular (strukturiert, mit Progress-Anzeige)
              ↓
         Antworten landen automatisch in Notion-Datenbank
              (oder per Zapier/Make direkt als Salesforce-Felder)
              ↓
         Demo: Validierung + Discovery Notes in SF
              ↓
         Vertragsabschluss → KEB wird aus Notion-Daten
         automatisch befüllt → Handover an Deployment
```

---

### Was du damit gewinnst

| Vorher | Nachher |
|--------|---------|
| Basic-Fragen im Demo | Demo = reiner Workflow-Deep-Dive |
| Freitext-Notizen in SF | Strukturierte Felder, validierbar |
| Excel-KEB manuell | Digitaler KEB, auto-befüllt |
| Arzt weiß nicht wo er steht | Progress-Timeline sichtbar |
| Fehleranfällig bei Übergabe | Single Source of Truth |

---

**Nächster Schritt:** Soll ich das Tally-Formular (Intake) konkret aufbauen – also alle Felder, Logik, Reihenfolge – und/oder die KEB-Struktur als digitales Template entwerfen?

---

**Du:**

Was ist denn genau Tallifformular und nicht Typeform oder andere? Was sind die Vorteile? Was sind die Vorteile davon? Also wieso hast Du die also insbesondere das

---

**Claude:**

**Ehrliche Antwort zuerst:** Ich habe Tally primär wegen eines spezifischen Vorteils empfohlen – aber lass mich das transparent aufschlüsseln, damit du selbst entscheiden kannst.

---

### Warum Tally – der entscheidende Vorteil

**Tally ist komplett kostenlos für unbegrenzte Formulare und unbegrenzte Antworten.**

Typeform limitiert im Free-Plan auf 10 Antworten/Monat. Jenseits davon kostet es schnell 50–100€/Monat. Für einen internen B2B-Prozess, der noch iteriert wird, ist das unnötig.

---

### Tally vs. Typeform vs. Alternativen – direkt verglichen

| Kriterium | Tally | Typeform | Jotform | Google Forms |
|-----------|-------|----------|---------|--------------|
| Preis (brauchbar) | **Kostenlos** | Ab ~50€/Mo | Ab ~34€/Mo | Kostenlos |
| Design/UX für Arzt | Sehr sauber, modern | Sehr gut | Mittel | Schlecht |
| Logik & Verzweigungen | ✅ Ja | ✅ Ja | ✅ Ja | ❌ Nein |
| Zapier/Make-Integration | ✅ | ✅ | ✅ | ✅ |
| Notion-Integration nativ | ✅ | ❌ | ❌ | ❌ |
| Progress-Bar | ✅ | ✅ | ✅ | ❌ |
| DSGVO/EU-Hosting | ✅ | ⚠️ US-Server | ⚠️ | ⚠️ |

---

### Der für euch relevanteste Punkt: DSGVO

Ihr erhebt Praxisdaten – das sind sensible Geschäftsdaten von Heilberuflern. Tally hostet auf EU-Infrastruktur und ist DSGVO-konform ohne großen Aufwand. Bei Typeform müsstest du aktiv prüfen und ggf. einen DPA abschließen.

---

### Wo Tally schwächer ist

- Kein nativer Salesforce-Connector → brauchst Zapier/Make als Middleware
- Weniger Brand-Customization als Typeform (aber für internen B2B-Prozess irrelevant)
- Kleineres Ökosystem, weniger Templates

---

**Fazit:** Für deinen Use Case – strukturierter B2B-Intake, DSGVO-relevant, noch in Iteration, kein festes Budget dafür – ist Tally die pragmatisch beste Wahl. Wenn DoktorLib irgendwann ein poliertes White-Label-Erlebnis für Ärzte braucht, würde ich Typeform oder ein Custom-Tool evaluieren.

---

**Nächster Schritt:** Soll ich direkt das Intake-Formular mit allen Feldern und der Verzweigungslogik ausarbeiten – ready to build in Tally?

---

**Du:**

Medizinwesen arbeiten beziehungsweise Gesundheitswesen und die c-fünf-Zertifizierung haben, müssen die Daten sehr stark nach Datenschutz und deutschen Gesetz verarbeitet werden.

---

**Claude:**

Sehr wichtiger Punkt – und du hast recht, das ändert die Tool-Entscheidung fundamental.

---

**Das eigentliche Problem:**

Im deutschen Gesundheitswesen gelten nicht nur DSGVO, sondern zusätzlich:

- **§ 22 BDSG** – besondere Kategorien von Gesundheitsdaten
- **KDG / DSG-EKD** (falls kirchliche Träger)
- Und für euch als SaaS-Anbieter im Gesundheitsumfeld potenziell **BSI C5** – das ist kein Marketing-Zertifikat, das ist ein ernsthafter Compliance-Rahmen

Das bedeutet: Jedes Tool, das Praxisdaten auch nur **durchleitet** – auch nur Name, Fachrichtung, Laborpartner – muss datenschutzrechtlich sauber sein.

---

**Tally fällt damit raus.**

Tally bietet keinen Auftragsverarbeitungsvertrag (AVV) auf Deutsch, keine C5-Attestierung, keine garantierte Datenverarbeitung in Deutschland.

---

### Was ihr stattdessen braucht

Drei realistische Optionen:

| Option | Tool | Vorteil | Nachteil |
|--------|------|---------|----------|
| **A – Formularlösung DE** | **Microsoft Forms** (wenn M365 vorhanden) | AVV vorhanden, EU-Hosting, kein Extra-Tool | Wenig Logik, kein schönes UX |
| **B – Eigenentwicklung** | Typeform Self-Hosted / eigenes Form auf eurer Infra | Volle Kontrolle | Aufwand |
| **C – Direkt in Salesforce** | Salesforce Experience Cloud / Survey | Alles in einem System, AVV bereits vorhanden | Salesforce-Flexibilitätsproblem bleibt |

---

**Meine ehrliche Empfehlung:**

Bevor wir das Tool final festlegen – eine direkte Frage:

Habt ihr mit eurem Datenschutzbeauftragten bereits definiert, **welche Daten im Intake-Formular als schützenswert eingestuft werden**? Denn wenn es nur Praxisstruktur-Daten sind (Software, Labor, Gerätelist) – also keine Patientendaten – ist der Rahmen deutlich weniger restriktiv als wenn Patientenbezug besteht.

Das entscheidet die Tool-Wahl.

---

**Du:**

Wir werden hier in diesem Formular keine medizinischen Daten verwenden, aber Praxisdaten werden dort hinterlegt. Das heißt, wir müssen wissen, wie die Praxis arbeitet. Was sind die Anforderungen? Wie ist die Infrastruktur? Welche Geräte und Co? Daher prüfe alles noch mal bitte und gib mir eine vernünftige Lösung.

---

**Claude:**

Gut. Dann lass mich das sauber neu bewerten.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Gut. Ich habe jetzt die konkreten Daten. Hier ist die saubere, finale Bewertung:

---

### Datenschutz-Neubewertung: Tally ist in Ordnung

**Die relevanten Fakten:**

Tally ist in Belgien (EU) ansässig, DSGVO-konform, alle Formulardaten werden verschlüsselt – sowohl in Transit als auch at rest – und ausschließlich in Europa gespeichert. Ein AVV ist automatisch durch die Nutzungsbedingungen abgedeckt, eine separate Unterschrift ist nicht erforderlich.

Das bedeutet konkret für euch: Praxisstruktur-Daten (Software, Labor, Geräte, IT-Infrastruktur) — **kein Problem mit Tally**, solange ihr keine Patientendaten erhebt, was ihr explizit ausgeschlossen habt.

---

### Die finale Lösung – vollständig ausgearbeitet

**Gesamtarchitektur:**

```
Inbound
  ↓
Terminbestätigung (E-Mail) + Intake-Link
  ↓
Tally-Formular (Arzt füllt selbstständig aus)
  ↓
Antworten → automatisch via Make/Zapier
  → Salesforce (strukturierte Felder)
  → Notion (interne Arbeitsdatenbank)
  ↓
Demo: Validierung, Workflow-Deep-Dive
  ↓
Discovery Notes in Salesforce (wie heute)
  ↓
Tech Audit durch IT-Partner
  ↓
Vertragsabschluss → KEB wird auto-befüllt
  ↓
Digitaler Handover an Deployment
```

---

### Das Tally-Formular – konkrete Feldstruktur

**Block 1 – Praxisidentifikation**
- Praxisname
- Fachrichtung / Fachbereich
- Anzahl Ärzte in der Praxis
- Anzahl medizinische Fachangestellte (MFA)
- PLZ / Standort

**Block 2 – Software & IT**
- Welche Praxisverwaltungssoftware nutzen Sie? *(Dropdown: Medistar, Turbomed, Dampsoft, x.comfort, andere)*
- Haben Sie einen eigenen IT-Dienstleister? *(Ja/Nein)*
- Wenn ja: Name des IT-Partners *(Freitext)*
- Wie alt ist Ihre IT-Infrastruktur ungefähr? *(< 2 Jahre / 2–5 Jahre / > 5 Jahre)*

**Block 3 – Labor & Geräte**
- Mit welchem Labor arbeiten Sie? *(Freitext)*
- Haben Sie Medizingeräte in der Praxis? *(Ja/Nein)*
- Wenn ja: Welche Geräte? *(Mehrfachauswahl + Freitext)*
- Sind diese Geräte digital angebunden? *(Ja / Nein / Teilweise)*

**Block 4 – Prozesse & Motivation**
- Wie viele Patienten behandeln Sie pro Quartal? *(< 500 / 500–1000 / > 1000)*
- Was ist Ihr größter Schmerzpunkt aktuell? *(Freitext)*
- Warum beschäftigen Sie sich gerade jetzt mit DoktorLib? *(Freitext)*

**Block 5 – Abschluss**
- Wer ist Ihr primärer Ansprechpartner für die Einführung? *(Name + Rolle)*
- Datenschutz-Checkbox + Link zu eurer Datenschutzerklärung

---

### Der Arzt sieht seine Journey

Tally zeigt eine **Progress-Bar** durch die Blöcke. Zusätzlich: In der Bestätigungsmail nach Formularabgabe bekommt der Arzt eine klare Timeline:

> ✅ Schritt 1: Praxisdaten ausgefüllt
> 📅 Schritt 2: Demo-Termin am [Datum]
> 🔧 Schritt 3: Tech Audit
> 🚀 Schritt 4: Go-Live

Das ist einfach umsetzbar per E-Mail-Template in Tally oder eurem Kalender-Tool.

---

### Handover an Deployment – sauber und digital

Der KEB wird nicht mehr manuell in Excel ausgefüllt. Stattdessen:

1. Tally-Antworten fließen via **Make** automatisch in eine **Notion-Datenbank**
2. Dort liegt jede Praxis als eigener Eintrag mit allen strukturierten Feldern
3. Nach Vertragsabschluss wird der Eintrag um Discovery Notes + Tech-Audit-Ergebnis ergänzt
4. Deployment bekommt einen **Link auf den Notion-Eintrag** – kein Excel, kein Medienbruch, alles an einem Ort, nachbearbeitbar

---

### Was das kostet

| Tool | Kosten |
|------|--------|
| Tally | Kostenlos |
| Make (Automation) | ~9€/Monat |
| Notion | Kostenlos bis Team-Plan (~10€/User/Mo) |
| **Gesamt** | **~9–30€/Monat** |

---

**Nächster Schritt:** Soll ich das Tally-Formular mit exakter Verzweigungslogik (z.B. Gerätefragen nur wenn „Ja" gewählt) und das Notion-Datenbank-Template konkret aufbauen?

---

**Du:**

Ich würd die gerne so aufsetzen, dass wir die Daten nicht mehr selbst eintippen müssen außer in einem Bereich. Sondern dass das, so viel es geht, automatisiert befüllt wird und das Handover dann vollständig ist, nachdem der ITler alles validiert hat und vor Ort den gemacht hat. Wie können wir das am besten denn lösen damit?

---

**Claude:**

Gute Richtung. Bevor ich die Automatisierungsarchitektur aufbaue, eine gezielte Frage:

**Salesforce:** Habt ihr dort aktuell die Möglichkeit, über Zapier oder Make auf Datensätze zuzugreifen und Felder zu schreiben – oder ist Salesforce komplett gesperrt für externe Integrationen? Und hat der IT-Partner ein eigenes Tool, in dem er seinen Audit dokumentiert, oder macht er das aktuell per E-Mail / mündlich?

Das entscheidet, ob Salesforce Teil der Automatisierung sein kann oder ob Notion die zentrale Datenbank wird, die Salesforce nur am Ende befüllt.

---

**Du:**

Also die Daten würden wir über ein Datenformular bei beispielsweise einholen, wie jetzt Tallye oder Typefonds, was auch immer Du vorschlägst. Und dann könnte man eine einfache Automatisierung aufsetzen. Also prüfe, wie wir das am einfachsten und schnellsten lösen können. Wir haben auch Dust intern und nutzen dort eigene Botkreierung. Das heißt, wir können auch da drauf zugreifen, Wichtig ist, dass die Daten gegebenenfalls auch in Salesforce irgendwo landen. Dass das quasi auch zentral und langfristig skaliert werden kann. Aber auch das Deployment eine vernünftige Version bekommt.

---

**Claude:**

Perfekt. Jetzt habe ich alles was ich brauche. Lass mich die optimale Architektur aufbauen.
```
This block is not supported on your current device yet.
```

Sehr gut. Jetzt habe ich das vollständige Bild — inklusive dem entscheidenden Punkt: Dust hat eine native Salesforce-Integration, über die Agents CRM-Records lesen, schreiben und aktualisieren können. Das verändert die Architektur erheblich zu euren Gunsten.

---

### Die vollautomatisierte Architektur für DoktorLib

Hier ist das Gesamtsystem — mit einem einzigen manuellen Eingriffspunkt:
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Hier ist die vollständige Logik dahinter:

---

### Was passiert wo — und warum

**Tally → Make → Salesforce** ist der Kern. Dust hat eine native Salesforce-Integration, über die Agents Records lesen, schreiben und automatisch aktualisieren können — das bedeutet: kein manuelles Übertragen, kein Excel-KEB mehr.

Der entscheidende Einsatz von Dust: ein Agent analysiert eingehende Daten und speist die Ergebnisse strukturiert in Salesforce zurück — in eurem Fall liest der Agent Tally-Antworten plus Discovery Notes und generiert daraus automatisch den KEB-Entwurf.

---

### Der einzige manuelle Schritt

Discovery Notes im Demo-Termin — das bleibt manuell, weil es inhaltliche Tiefe braucht, die kein Formular erfassen kann. Alles andere läuft durch.

---

### Was Deployment bekommt

Kein Excel. Einen Notion-Link mit:
- Praxisdaten (aus Tally, auto-befüllt)
- Discovery Notes (aus SF, manuell)
- Tech-Audit-Ergebnis (aus IT-Partner-Formular, auto-befüllt)
- KEB (von Dust generiert, versioniert)
- Slack-Benachrichtigung bei Übergabe

---

### Nächste konkrete Schritte

1. **Tally-Formular** mit Verzweigungslogik aufbauen (Arzt-Intake + separates IT-Audit-Formular)
2. **Make-Automatisierung** konfigurieren (Tally → SF-Felder + Notion)
3. **Dust-Agent** bauen: KEB-Generierung aus SF-Daten

Womit soll ich anfangen — Tally-Formular-Struktur oder dem Dust-Agent-Prompt für die KEB-Generierung?

---

