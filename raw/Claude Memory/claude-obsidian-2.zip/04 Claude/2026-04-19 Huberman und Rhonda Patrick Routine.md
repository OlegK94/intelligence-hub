---
date: 2026-04-19
tags: [claude]
---

# Huberman und Rhonda Patrick Routine

**Du:**

Zeige mir die neueste andrew Huberman and dr Patrick Routine auf

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Kurze Klärung: Du meinst vermutlich **Dr. Rhonda Patrick** (Biochemikerin, FoundMyFitness) – nicht Patrick Bet-David. Die Suche bestätigt das. Hier sind beide aktuellen Protokolle im direkten Vergleich:

---

## 🧬 Huberman × Rhonda Patrick — Aktuelle Routinen (2025/2026)

---

### 🌅 MORGEN

| Zeitpunkt | **Andrew Huberman** | **Dr. Rhonda Patrick** |
|---|---|---|
| Aufwachen | 5:30–6:30 Uhr, ohne Wecker – natürlicher Aufwachzyklus | Flexibel, kein fixes Protokoll |
| Sofort | 2 Gläser Wasser – Rehydrierung nach nächtlichem Flüssigkeitsverlust | Kaffee (2–3 Tassen) |
| Licht | Draußen 2–10 Min Sonnenlicht (Cortisol-Anker) | Blaues Tageslicht möglichst früh |
| Supplemente | Über 25 Verbindungen, sorgfältig getimed und zyklisch | Omega-3 (Nordic Naturals, hohe Dosis), Vitamin D3, Magnesiumglycinat, mehrere Mikronährstoffe gegen typische Defizite |
| Koffein | Erst ab 10 Uhr morgens – Adenosin-Clearance abwarten | Kaffee direkt nach dem Aufwachen |

---

### 💪 TRAINING (Wochensplit)

**Huberman:**

- **Sonntag:** Zone-2-Cardio (Joggen, Rudern, Radfahren, Schwimmen) – 30–75 Min
- **Montag:** Beine – Leg Extensions, Hack Squats, Leg Curls, Calf Raises
- **Dienstag:** Hitze & Kälteexposition (Sauna + Cold Plunge im Wechsel)


Auf Krafttagen nimmt er 30–60 Min vorher Alpha-GPC (300 mg) und L-Tyrosin (500 mg) zur mentalen Fokussierung. Zwischen den Sätzen nutzt er den **physiologischen Seufzer** (2 kurze Einatmungen, 1 lange Ausatmung) zur schnellen Herzfrequenzsenkung.

**Rhonda Patrick:**
Ihre Routine kombiniert Zone-2-Training, Sauna, Krafttraining und HIIT-Einheiten. Sie empfiehlt Rückwärtsgehen und Tibialis-Raises als Einstieg – beides taucht auch in Hubermans Routine auf.

---

### 🌡️ HITZE & KÄLTE

| | **Huberman** | **Rhonda Patrick** |
|---|---|---|
| Sauna | Dienstags im Wechsel mit Cold Plunge | Festes Sauna-Protokoll, auf Basis ihrer Stressbiologie-Forschung zu Hitzeschockproteinen |
| Kältebad | 1–3× pro Woche | Regelmäßig kombiniert mit Sauna |

---

### 🍽️ ERNÄHRUNG / FASTEN

| | **Huberman** | **Rhonda Patrick** |
|---|---|---|
| Essensfenster | Erste Mahlzeit gegen 13 Uhr (12–16h Fasten), abends Kohlenhydrate, 3–4h vor dem Schlafen | Time-restricted Eating, nach Satchin-Panda-Protokoll |
| Besonderheit | Abendmahlzeit ohne viel Fleisch | Omega-3 täglich – laut ihr unverhandelbar für Gehirn, Herz und Entzündungskontrolle |

---

### 🌙 ABEND & SCHLAF

**Huberman:**
Licht dimmen ab 22 Uhr, keine hellen Lichter zwischen 22 und 4 Uhr. Yoga Nidra (NSDR) bei Bedarf. Abendliches Lesen vor dem Schlafen.

**Rhonda Patrick:**
Fokus auf blaues Licht vermeiden, Magnesiumglycinat auch abends.

---

### 🔬 MONITORING & PHILOSOPHIE

- **Huberman:** Blutbild vor und nach 8 Wochen bei hormonunterstützenden Supplementen. Nur drittgeprüfte, pharmazeutische Qualität.
- **Rhonda Patrick:** Regelmäßige Biomarker-Checks (Omega-3-Index, Vitamin D etc.), passt ihr Protokoll kontinuierlich an neue Studien an – eine der wissenschaftlich rigorosesten Stimmen im Health-Space.

---

### ⚡ Key Takeaways

| | Huberman | Rhonda Patrick |
|---|---|---|
| Stärke | Neurowissenschaft, Licht/Schlaf, Dopamin | Mikronährstoffe, Zellgesundheit, Longevity |
| Komplexität | Sehr hoch (25+ Supplemente, präzises Timing) | Hoch, aber pragmatischer |
| Unique Feature | Yoga Nidra, physiolog. Seufzer, Koffeindelay | Sulforaphan, hochdosierte Omega-3s, Sauna-Forschung |

---

**Nächster sinnvoller Schritt:** Sag mir, welchen Bereich du konkret umsetzen willst (Schlaf, Training, Supplemente, Ernährung) – dann bau ich dir ein auf deine Situation angepasstes Protokoll.

---

**Du:**

Zeig mir die vollständige und ausführliche Routine für Sport Essen und Rest von den beiden

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Hier ist die vollständige, ausführliche Gesamtübersicht beider Protokolle:

---

# 🏋️ ANDREW HUBERMAN × DR. RHONDA PATRICK
## Vollständige Routine — Sport · Ernährung · Regeneration

---

# ══════════════════════════════
# 🔵 ANDREW HUBERMAN
# ══════════════════════════════

## 💪 SPORT — Wochensplit (Foundational Fitness Protocol)

Die Wochenstruktur umfasst drei Krafttrainingstage, drei Kardiotage in unterschiedlichen Intensitätszonen und einen Tag ausschließlich für Hitze- und Kälteexposition zur Regeneration.

---

### Montag — Beine (Unterkörper)
Montag ist dem Beintraining gewidmet. Huberman betont die Bedeutung von Beintagen für Gesamtkraft, Explosivität und Langlebigkeit. Das Workout beinhaltet: Tibialis Raises, stehende oder Schlitten-Calf-Raises, Leg Curls im Liegen, Glute-Ham-Raises, Leg Extensions und Hack Squats. Zwei bis drei harte Sätze pro Übung.

Für Calf-Raises macht er drei Sätze à 6–10 Wiederholungen bis zum Versagen mit schwerem Gewicht — eine Methode, die ihm laut eigener Aussage zu größeren, stärkeren Waden und besserer Haltung verholfen hat.

---

### Dienstag — Hitze & Kälte (aktive Erholung)
20 Minuten Sauna, gefolgt von 5 Minuten Kaltdusche oder Eisbad — das Ganze 3–5 Mal wiederholt. Saunaparameter: 80–100°C, 2–3× pro Woche oder sogar täglich möglich. Kältebad: 1–5 Minuten, wöchentliche Gesamtdauer ca. 11 Minuten aufgeteilt auf 2–4 Einheiten.

---

### Mittwoch — Oberkörper (Push & Pull + Nacken)
Mittwoch fokussiert auf Druck- und Zugbewegungen des Oberkörpers. Nackentraining ist fester Bestandteil — Huberman hält es für entscheidend für Verletzungsprävention und Haltung.

---

### Donnerstag — Zone-2-Cardio (niedrige Intensität)
Huberman strebt 180–200 Minuten Zone-2-Kardio pro Woche an, was die Grundlage für verbesserte kardiovaskuläre Fitness bildet. Zone-2 bedeutet: schnelleres Atmen als normal, aber noch in der Lage, ein Gespräch zu führen. Aktivitäten: Joggen, Rudern, Radfahren, Schwimmen oder Wandern. Dauer: 30–75 Minuten.

---

### Freitag — HIIT (maximale Intensität)
Intervalle auf dem Assault Bike: 20–30 Sekunden Vollsprint, 10 Sekunden Pause, 8–12 Runden. Maximale Herzfrequenz = 220 minus Alter. Nur mit perfekter Form ausführen.

Am Freitag trainiert er die Beine indirekt nochmals durch den HIIT-Lauf — so trifft er seine Kraft- und Kardio-Ziele, ohne dass eines das andere beeinträchtigt.

---

### Samstag — Kleine Muskelgruppen & Nacken
Samstag zielt auf kleinere Muskelgruppen. Waden werden damit zweimal pro Woche trainiert, Nackentraining wird zur Verstärkung wiederholt. So wird jede große Muskelgruppe abgedeckt bei ausreichend Regenerationszeit.

---

### Sonntag — Ausdauer (langer Zone-2-Lauf)
Sonntags macht Huberman Zone-2-Cardio (Joggen, Rudern, Radfahren, Schwimmen oder Wandern) — 30 bis 75 Minuten, um kardiovaskuläre Gesundheit und Ausdauer zu verbessern.

---

### Pre-Workout Protokoll (Krafttage)
30–60 Minuten vor dem Training nimmt er Alpha-GPC (300 mg) zur Verbesserung der Geist-Muskel-Verbindung und L-Tyrosin (500 mg) für Motivation und Fokus. Zwischen den Sätzen nutzt er den physiologischen Seufzer: zwei kurze Einatmungen durch die Nase, dann eine lange Ausatmung durch den Mund — senkt die Herzfrequenz schnell für schnellere Erholung zwischen den Sätzen.

---

## 🍽️ ERNÄHRUNG

### Essensfenster & Fasten
Das Kernprinzip ist zeitlich eingeschränktes Essen: tägliches Essensfenster von 8–10 Stunden, Fasten für die verbleibenden 14–16 Stunden. Hubermans typisches Fenster läuft von ca. 11 Uhr vormittags bis 20 Uhr.

Er trainiert gegen Ende des Fastenfensters — nach Wasser und Koffein, aber vor der ersten Mahlzeit. Nach dem Training nimmt er EAAs (essentielle Aminosäuren).

### Erste Mahlzeit (Mittag ~13 Uhr)
Erste Mahlzeit fokussiert auf Low-Carb: hochwertiges Protein und Gemüse. An intensiven Trainingstagen werden Kohlenhydrate wie Reis oder Haferflocken hinzugefügt, um Glykogen aufzufüllen.

Beim Fastenbrechen wählt er oft proteinreiche Mahlzeiten: Eier, griechischer Joghurt oder ein Proteinshake. Mahlzeiten beinhalten mageres Protein wie Hühnchen oder Fisch, komplexe Kohlenhydrate wie Süßkartoffeln oder Quinoa sowie viel Gemüse — besonders Blattgemüse und Kreuzblütler.

### Abendmahlzeit (18–20 Uhr)
Abends liegt der Fokus auf stärkehaltigen Kohlenhydraten wie Pasta. Das verbessert die Schlafqualität und füllt die Glykogenspeicher für das nächste Training. Zu viel Fleisch am Abend verschlechtert laut Huberman die Schlafqualität.

---

## 😴 REGENERATION & SCHLAF

### NSDR / Yoga Nidra
Vor anspruchsvollen Aufgaben verbringt Huberman 10–20 Minuten mit Non-Sleep Deep Rest (NSDR), meist eine geführte Yoga-Nidra-Session noch im Bett. Eine Studie von 2002 zeigte mittels PET-Scans, dass Yoga Nidra die Dopaminausschüttung im Gehirn um bis zu 65% steigert. Huberman verwendet NSDR als Werkzeug, um die regenerativen Vorteile von Schlaf ohne das Risiko von Benommenheit zu erhalten.

### Abend-Lichtprotokoll
Ab 22 Uhr werden die Lichter gedimmt: "Ich habe eine echte Empfindlichkeit gegenüber Deckenlicht entwickelt, weil ich so an dieses Muster gewöhnt bin."

### Schlaf-Supplement-Stack
Magnesium Threonat (145 mg) oder Magnesiumbisglycinat (200 mg) — abwechselnd eingesetzt als Schlafhilfe. Dazu kommen Apigenin und L-Theanin.

### Schlafumgebung
Lesen vor dem Schlafengehen. Keine hellen Lichter — besonders keine hellen Deckenlichter zwischen 22 und 4 Uhr morgens.

---
---

# ══════════════════════════════
# 🟢 DR. RHONDA PATRICK
# ══════════════════════════════

## 💪 SPORT

### Wöchentliche Trainingsstruktur
Sie kombiniert in ihrer Wochenroutine aerobe Workouts, hochintensives Training, Krafttraining und Yoga/Ballett-Übungen. Ziel ist tägliche Bewegung, auch wenn es nur 15 Minuten sind.

**Zone-2-Cardio** (2–3× wöchentlich, 30–45 Min)
Das Rückgrat ihrer Ausdauerarbeit. Moderate Intensität, Grundlage für mitochondriale Gesundheit und BDNF-Produktion.

**HIIT** (1–2× wöchentlich)
Ihr HIIT-Protokoll ist ein zentraler Bestandteil ihrer Fitnessroutine neben Sauna-Nutzung und Krafttraining. Kurze, explosive Intervalle mit vollständiger Erholung dazwischen.

**Krafttraining** (2–3× wöchentlich)
Patrick empfiehlt Rückwärtsgehen und Tibialis Raises als Einstieg ins Beintraining — beides findet sich auch in Hubermans Routine. Schwerpunkt auf Compound-Bewegungen, funktionelle Stärke.

**Yoga/Ballett** (begleitend)
Mobilität, Körpergefühl und mentale Erholung.

---

### Sauna-Protokoll
Patrick nutzt die Sauna 3–4 Mal pro Woche für je 20 Minuten bei 175°F (ca. 80°C). Sie bevorzugt Sauna nach dem Training, da Hitze vor dem Sport die Leistung beeinträchtigen kann.

"Ich mache normalerweise 20–30 Minuten Sauna 3 Mal pro Woche. Versucht, mindestens einige Mal pro Woche 30 Minuten intensives kardiovaskuläres Training zu machen."

---

## 🍽️ ERNÄHRUNG

### Essensfenster
Essen innerhalb eines 12-Stunden-Fensters verbessert den Schlaf und unterstützt die Gewichtskontrolle. Mindestens 3 Stunden vor dem Schlafen nichts mehr essen.

### Kernprinzipien
Bei raffinierten Kohlenhydraten folgt sie einer klaren Regel: Eliminierung von raffinierten Kohlenhydraten und Zucker, Fokus stattdessen auf nährstoffdichte Lebensmittel.

Proteinreich, ganze Lebensmittel, hoher Omega-3-Fokus. Omega-3 täglich — laut ihr unverhandelbar: "Ich nehme täglich Omega-3. Die Evidenz für deren Nutzen ist überwältigend über mehrere Bereiche hinweg. Gehirngesundheit, Herzgesundheit, Entzündung. Ich höre damit nicht auf."

### Supplement-Stack (morgens)
Gruppierter Morgen-Stack: Omega-3 (hohe Dosis), Vitamin D3, Vitamin K2 (MK-7, 100 mcg), Magnesiumglycinat. Alle Dosierungen basieren auf ihren eigenen Biomarker-Tests.

### Supplement-Stack (abends)
Abend-Stack fokussiert auf Erholung und Schlafoptimierung: zusätzliche Omega-3 (höherer DHA-Anteil), 120 mg Magnesiumglycinat und spezialisierte Formulierungen. Sie nimmt Fischöl seit neun Jahren täglich auf Basis von Studien, die deren Auswirkung auf Gehirngesundheit und Entzündungsreduktion belegen.

### Situationsabhängige Supplemente
Kollagen für Gelenkgesundheit. Probiotika nur nach Antibiotika oder Alkohol. Protein-Pulver (Whey Isolat aus Weidehaltung) wenn nötig. Vitamin C & Zink nur bei Krankheitskontakt. Eisen während der Menstruation.

---

## 😴 REGENERATION & SCHLAF

### Schlafziel & Timing
Ziel sind 6–8 Stunden Schlaf pro Nacht. Morgens 30–60 Minuten natürliches Licht zur Ausrichtung des Zirkadianrhythmus.

### Abendprotokoll
Ab dem Abend wechselt sie zu roten Philips-Hue-Lampen oder Dimmern und begrenzt Bildschirmzeit auf 2 Stunden vor dem Schlafen. Schlafzimmertemperatur: 15–19°C (60–67°F) für optimale Schlafbedingungen. Verdunkelungsvorhänge, Schlafmaske oder Ohrstöpsel für ein dunkles, stilles Schlafumfeld.

### Biomarker-Monitoring
Regelmäßige Tests von Omega-3-Index, Vitamin-D-Spiegel und weiteren Biomarkern. Passt ihr Protokoll kontinuierlich an neue Forschungsergebnisse an — unterscheidet dabei offen zwischen dem, was die Evidenz stützt, und dem, was noch spekulativ ist.

---

## 📊 HEAD-TO-HEAD VERGLEICH

| Bereich | Huberman | Rhonda Patrick |
|---|---|---|
| **Trainingsfokus** | Strukturierter 7-Tage-Split, neurowiss. getimed | Flexible Kombination: Zone 2, HIIT, Kraft, Yoga |
| **Fasten** | 16:8 (strikt, nüchtern trainieren) | 12:12 (flexibler, familienkompatibel) |
| **Sauna** | Dienstags, 3–5 Runden Wechsel mit Kälte | 3–4×/Woche post-workout, 20 Min |
| **Schlaf-Tool** | NSDR/Yoga Nidra aktiv genutzt | Licht + Temperatur + Lichtmanagement |
| **Supplemente** | 25+ Compounds, komplex getimed | Evidenzbasiert, Biomarker-gesteuert, pragmatischer |
| **USP** | Neurowissenschaft × Timing × Protokoll-Präzision | Biochemie × Zellgesundheit × Longevity |

---

**Nächster Schritt:** Sag mir deine verfügbare Trainingszeit pro Woche, dein primäres Ziel (Körperkomposition, Ausdauer, Longevity, Fokus) und ob du eher Hubermans oder Patricks Philosophie näher bist — dann bau ich dir ein auf dich zugeschnittenes Hybrid-Protokoll.

---

**Du:**

Nenne mir die top Supplemente welche empfohlen werden von den beiden fundamental

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Hier ist die komprimierte, fundierte Übersicht der **wirklich fundamentalen Supplemente** — kein Noise, nur das, was beide konsistent empfehlen und selbst nehmen:

---

# 🧪 TOP SUPPLEMENTE — HUBERMAN × RHONDA PATRICK
### Nur das Fundamentale — mit Dosierung & Zweck

---

## 🥇 TIER 1 — Von BEIDEN empfohlen (höchste Priorität)

---

### 1. Omega-3 (EPA/DHA)
| | Huberman | Rhonda Patrick |
|---|---|---|
| **Dosis** | ~2.000 mg EPA/Tag | ~2.000 mg EPA+DHA, aufgeteilt in 2 Dosen |
| **Timing** | Morgens | Morgens + abends |
| **Zweck** | Neuroplastizität, Entzündungshemmung, Herzgesundheit | Gehirnstruktur, chronische Entzündung, Kardiovaskulär |

Wenn Huberman nur zwei Supplemente wählen müsste, wären Omega-3 eines davon. Er zielt auf rund 2 Gramm EPA täglich ab — eine Dosierung, die durch starke Evidenz für kardiovaskuläre Gesundheit, Stimmungsregulation und Gehirnfunktion gestützt wird.

Patrick bezeichnet Omega-3 als absolut unverhandelbar in ihrem Stack: "Die Evidenz für deren Nutzen ist überwältigend — Gehirngesundheit, Herzgesundheit, Entzündung. Ich höre damit nicht auf."

**Marke:** Nordic Naturals (beide empfohlen) — drittgeprüft, da Fischöl oxidationsanfällig ist.

---

### 2. Vitamin D3 + K2
| | Huberman | Rhonda Patrick |
|---|---|---|
| **Dosis D3** | 5.000–10.000 IU (nach Blutbild) | 4.000–6.000 IU |
| **Dosis K2** | kombiniert | 100 mcg MK-7 täglich |
| **Timing** | Morgens | Abends gemeinsam mit D3 |
| **Zweck** | Immunsystem, Neurologie, Testosteron | Kalziumsteuerung, Knochen, Immunregulation |

Huberman nimmt 5.000–10.000 IU Vitamin D3 täglich, angepasst nach Blutbild.

Patrick nimmt 100 mcg K2 in der MK-7-Form als "Versicherung" für korrekte Kalziumverwertung und kombiniert es mit D3 für synergistische Effekte — K2 lenkt Kalzium zu den Knochen statt in die Arterien.

> ⚠️ **Wichtig:** Ohne Blutbild keine hohen D3-Dosen starten. Zielwert: 40–60 ng/ml.

---

### 3. Magnesium
| | Huberman | Rhonda Patrick |
|---|---|---|
| **Form** | Magnesium L-Threonat (145 mg) oder Bisglycinat (200 mg) | Magnesiumglycinat (120–130 mg) + Magnesium-Blend abends |
| **Timing** | Abends, 30–60 Min vor Schlaf | Morgens + abends |
| **Zweck** | Schlaftiefe, Parasympathikus, Muskelentspannung | Muskel-/Nervenfunktion, Schlaf, Stressreduktion |

Magnesium ist an über 600 enzymatischen Reaktionen beteiligt. Spezifisch für den Schlaf kann Magnesium das parasympathische Nervensystem aktivieren — verantwortlich u.a. für Herzentschleunigung und Muskelentspannung. Etwa 48% der Amerikaner nehmen nicht ausreichend Magnesium auf.

---

### 4. Kreatin Monohydrat
| | Huberman | Rhonda Patrick |
|---|---|---|
| **Dosis** | 5 g täglich | 10 g täglich (5g morgens + 5g nachmittags) |
| **Timing** | Flexibel | Morgens oft in Kaffee eingerührt |
| **Zweck** | Kraft, Muskelaufbau, kognitive Funktion | ATP-Produktion, Gedächtnis, Erholung |

Kreatin ist für Patrick nicht nur ein Sportsupplement — sie nimmt täglich 5 Gramm Kreatinmonohydrat für körperliche Stärke und mentale Klarheit. Es hilft dem Körper, mehr ATP zu produzieren, den Hauptenergieträger für Muskeln und Gehirn. Forschungen zeigen, dass Kreatin das Gedächtnis verbessern und die Erholung nach dem Training unterstützen kann.

---

## 🥈 TIER 2 — Stark empfohlen (kategoriespezifisch)

---

### 5. Apigenin (Schlaf)
**→ Huberman-spezifisch**

Apigenin wirkt als angstlösendes Supplement, was entscheidend für besseren Schlaf ist. Durch Reduktion des Angstniveaus hilft es, den Geist zu beruhigen und Gedankenspiralen zu reduzieren.

- **Dosis:** 50 mg, 30–60 Min vor dem Schlafen
- Kombiniert mit Magnesium + L-Theanin als Hubermans "Schlaf-Cocktail"

---

### 6. Sulforaphan (Brokkoli-Extrakt)
**→ Rhonda Patrick-spezifisch (ihr "Signature"-Supplement)**

Zu Patricks konsistent genannten Kernsupplementen gehört ein Brokkoli/Sulforaphan-Supplement. Aktiviert den Nrf2-Pfad — den stärksten bekannten körpereigenen Antioxidantien-Mechanismus. Wirkt zellschützend, anti-krebspräventiv und entzündungshemmend.

- **Dosis:** ~30–60 mg Sulforaphane täglich
- **Quelle:** Brokkolisprossen (selbst angebaut) oder hochdosierter Extrakt

---

### 7. NMN / NR (NAD+-Precursor)
**→ Huberman, zunehmend auch Patrick**

Huberman nimmt NMN oder NR (500 mg täglich) zur Unterstützung seiner NAD+-Spiegel. Er betont, dass sein Ziel nicht primär Lebensverlängerung ist, sondern konstantere mentale und physische Energie über den Tag.

- **Dosis:** 500 mg NMN täglich (morgens)
- Besonders relevant ab 35–40 Jahren, da NAD+ mit dem Alter sinkt

---

### 8. Alpha-GPC (kognitive Leistung / Pre-Workout)
**→ Huberman**

Auf Krafttagen nimmt Huberman Alpha-GPC (300 mg) 30–60 Minuten vor dem Training zur Verbesserung der Geist-Muskel-Verbindung durch erhöhte Acetylcholinproduktion.

---

### 9. Multivitamin (Basis-Absicherung)
**→ Beide**

Patrick nutzt Pure Encapsulations ONE als Multivitamin — ihr Ziel: Lücken in der Mikronährstoffversorgung schließen, falls ihre Ernährung nicht 100% abdeckt.

---

## 📊 MASTER-ÜBERSICHT

| Supplement | Huberman | Rhonda | Priorität | Zweck |
|---|:---:|:---:|---|---|
| **Omega-3** | ✅ | ✅ | 🔴 Fundamental | Gehirn, Herz, Entzündung |
| **Vitamin D3+K2** | ✅ | ✅ | 🔴 Fundamental | Immunsystem, Hormone |
| **Magnesium** | ✅ | ✅ | 🔴 Fundamental | Schlaf, Muskeln, Nerven |
| **Kreatin** | ✅ | ✅ | 🟠 Kern | Kraft, Kognition, ATP |
| **Apigenin** | ✅ | — | 🟠 Schlaf | Angstreduktion, Schlaftiefe |
| **Sulforaphan** | — | ✅ | 🟠 Longevity | Zellschutz, Nrf2 |
| **NMN/NR** | ✅ | ✅ | 🟡 Anti-Aging | NAD+, Energie |
| **Alpha-GPC** | ✅ | — | 🟡 Performance | Fokus, Acetylcholin |
| **Multivitamin** | ✅ | ✅ | 🟡 Basis | Mikronährstoff-Absicherung |

---

> **Hubermans Maxime:** Supplements sind kein Ersatz — Schlaf, Sonnenlicht, Training und Ernährung kommen zuerst. Die richtigen Supplements können aber, wenn die Basis stimmt, echte Wirkung entfalten.

---

**Nächster Schritt:** Willst du einen priorisierten Starter-Stack für dich speziell — z.B. die 3–4 Supplements mit dem besten Kosten-Nutzen-Verhältnis für deinen Kontext (Training, Schlaf, Fokus)?

---

**Du:**

Ich brauche die masterübersixzt mach Primo und Zweck und was

---

**Claude:**

Hier ist die bereinigte Masterübersicht:

---

# 🧪 SUPPLEMENT MASTERÜBERSICHT

| # | Supplement | Priorität | Zweck | Huberman | Rhonda |
|---|---|---|---|:---:|:---:|
| 1 | **Omega-3 (EPA/DHA)** | 🔴 Fundamental | Gehirn, Herz, Entzündung | ✅ | ✅ |
| 2 | **Vitamin D3 + K2** | 🔴 Fundamental | Immunsystem, Hormone, Knochen | ✅ | ✅ |
| 3 | **Magnesium** | 🔴 Fundamental | Schlaf, Muskeln, Nerven, Stress | ✅ | ✅ |
| 4 | **Kreatin Monohydrat** | 🟠 Kern | Kraft, Kognition, ATP, Erholung | ✅ | ✅ |
| 5 | **Apigenin** | 🟠 Schlaf | Entspannung, Schlaftiefe, Angstreduktion | ✅ | — |
| 6 | **Sulforaphan** | 🟠 Longevity | Zellschutz, Nrf2-Aktivierung, Entzündung | — | ✅ |
| 7 | **NMN / NR** | 🟡 Anti-Aging | NAD+, Energie, Zellreparatur | ✅ | ✅ |
| 8 | **Alpha-GPC** | 🟡 Performance | Fokus, Acetylcholin, Geist-Muskel | ✅ | — |
| 9 | **Multivitamin** | 🟡 Basis | Mikronährstoff-Absicherung | ✅ | ✅ |

---

**Einstieg-Empfehlung:** Mit Rang 1–3 starten — die haben die stärkste Evidenz, decken die häufigsten Defizite ab und bilden die Basis für alles andere. Blutbild vorher machen (v.a. Vitamin D + Omega-3-Index).

---

**Du:**

Bereite mir diese List für Apple Erinnerungen Liste vor

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Alle 9 Supplemente sind jetzt in deiner Apple Erinnerungen Liste — mit Priorität, Dosierung und Timing direkt im Titel.

**Nächster Schritt:** Blutbild machen lassen (Vitamin D + Omega-3-Index) bevor du mit hohen Dosen startest — dann weißt du genau, wo deine persönlichen Defizite liegen.

---

**Du:**

Was sind die Werte die man eigentlich erreichen sollte nach den beiden damit ich es messen kann

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

---

# 🩸 BIOMARKER ZIELWERTE
### Huberman × Rhonda Patrick — Was messen, was anstreben

---

## 🔴 KATEGORIE 1 — Nährstoffe (direkt supplement-relevant)

| Marker | Optimaler Zielwert | Warum |
|---|---|---|
| **Vitamin D (25-OH-D)** | 40–60 ng/mL (bis 80 ng/mL akzeptabel) | Immunsystem, Hormone, Knochen, Stimmung |
| **Omega-3 Index (EPA+DHA)** | 8–12% | Ein Omega-3-Index ≥8% ist mit einer 5 Jahre längeren Lebenserwartung verbunden verglichen mit <4% |
| **Omega-6:Omega-3 Ratio** | 3–5:1 | Chronische Entzündung bei zu hohem Verhältnis |
| **Magnesium** | 0,85–1,10 mmol/L (Serum) | Häufig unterschätzt — Serum-Test ist unzuverlässig, besser: RBC-Magnesium |

---

## 🟠 KATEGORIE 2 — Herzgesundheit & Kardiovaskulär

| Marker | Optimaler Zielwert | Warum |
|---|---|---|
| **ApoB** | <60 mg/dL (optimal) — ApoB ist besserer Herzrisiko-Prädiktor als LDL | Atheroskleroserisko |
| **LDL** | <100 mg/dL | Kardiovaskulär |
| **HDL** | >60 mg/dL | Schutzfaktor |
| **Triglyzeride** | <100 mg/dL | Metabolische Gesundheit |
| **hs-CRP** | <1,0 mg/L | Systemische Entzündung — je tiefer, desto besser |
| **Homocystein** | <10 μmol/L | Herzrisiko, Gehirngesundheit |

---

## 🟡 KATEGORIE 3 — Metabolismus & Blutzucker

| Marker | Optimaler Zielwert | Warum |
|---|---|---|
| **HbA1c** | 4,8–5,2% (Obergrenze: ≤5,4%) | Langzeit-Blutzucker, Diabetes-Risiko |
| **Nüchternglukose** | 70–85 mg/dL | Insulinsensitivität |
| **Nüchterninsulin** | <8 µIU/mL — Werte über 10–12 deuten auf frühe Insulinresistenz | Metabolische Flexibilität |

---

## 🔵 KATEGORIE 4 — Hormone

| Marker | Optimaler Zielwert | Warum |
|---|---|---|
| **Testosteron (Männer, gesamt)** | 600–900 ng/dL | Energie, Muskelaufbau, Libido, Kognition |
| **Freies Testosteron** | oberes Viertel der Altersnorm | Aktivform — wichtiger als Gesamttestosteron |
| **SHBG** | niedrig-normal | Bindet Testosteron — zu hoch = weniger frei verfügbar |
| **TSH (Schilddrüse)** | 0,5–2,0 mIU/L | Stoffwechsel, Energie, Stimmung |

---

## ⚪ KATEGORIE 5 — Organ- & Zellgesundheit

| Marker | Optimaler Zielwert | Warum |
|---|---|---|
| **Ferritin** | 30–150 ng/mL (Männer) — unter 30 = leere Eisenspeicher | Energie, Sauerstofftransport |
| **ALT (Leber)** | <33 U/L (Männer), <25 U/L (Frauen) | Lebergesundheit |
| **eGFR (Niere)** | >90 mL/min | Nierenfunktion |
| **IGF-1** | 120–180 ng/mL (mittlerer Bereich) | Wachstumshormon-Achse, Longevity |

---

## 📋 TEST-FREQUENZ (beide empfehlen)

| Wann | Was |
|---|---|
| **Basis** (1× jährlich) | Alles oben — vollständiges Panel |
| **Nach Supplement-Start** | Nochmal nach 8 Wochen testen um Wirkung zu messen |
| **Vitamin D** | Alle 3 Monate bis Zielwert stabil |
| **Omega-3 Index** | Alle 6 Monate |

---

> **Patricks Maxime:** Messen → Supplementieren → Zielwert erreichen → Dosis anpassen. Nie blind hochdosieren.

**Nächster Schritt:** Willst du die Biomarker-Liste auch als Apple Erinnerungen anlegen — oder soll ich dir eine Vorlage für das Arztgespräch erstellen, die du direkt mitnehmen kannst?

---

**Du:**

Ja erstelle aber eine übersichtliche Liste welche Zielseiten man erreichen muss und welche ich mit 32 Jahren 98kg erreichen muss

---

**Claude:**

Kurze Frage bevor ich das präzise erstelle:
```
This block is not supported on your current device yet.
```

---

**Du:**

F: Bist du männlich oder weiblich?
A: Männlich

F: Was ist dein primäres Ziel?
A: Performance & Muskelaufbau

---

**Claude:**

Hier ist deine personalisierte Biomarker-Zielübersicht — 32 Jahre, männlich, 98 kg, Performance & Muskelaufbau:

---

# 🩸 DEINE PERSÖNLICHEN ZIELWERTE
### 32J · Männlich · 98 kg · Performance & Muskelaufbau

---

## 🔴 PRIORITÄT 1 — Hormone (Fundament für Muskelaufbau)

| Marker | Dein Zielwert | Aktuell kritisch wenn |
|---|---|---|
| **Testosteron gesamt** | 700–900 ng/dL | <500 ng/dL |
| **Freies Testosteron** | 15–25 pg/mL | <10 pg/mL |
| **SHBG** | 20–35 nmol/L | >50 = zu viel gebundenes T |
| **LH** | 3–8 IU/L | Zeigt ob Hoden oder Hirn das Problem ist |
| **Östradiol (E2)** | 20–30 pg/mL | >40 = Fett↑, Libido↓ |
| **TSH** | 0,5–2,0 mIU/L | >3 = Stoffwechsel gebremst |

> Mit 98 kg ist SHBG besonders wichtig — Übergewicht erhöht Östrogen durch Aromatisierung im Fettgewebe.

---

## 🟠 PRIORITÄT 2 — Metabolismus (Körperkomposition)

| Marker | Dein Zielwert | Aktuell kritisch wenn |
|---|---|---|
| **Nüchternglukose** | 70–85 mg/dL | >100 = Insulinresistenz |
| **Nüchterninsulin** | <8 µIU/mL | >12 = schlechte Fettverbrennung |
| **HbA1c** | 4,8–5,2% | >5,7% = Prädiabetes |
| **Triglyzeride** | <100 mg/dL | >150 = metabolisches Problem |
| **HDL** | >55 mg/dL | <40 = Risiko |

---

## 🟡 PRIORITÄT 3 — Nährstoffe (Supplement-Kontrolle)

| Marker | Dein Zielwert | Warum für dich |
|---|---|---|
| **Vitamin D (25-OH-D)** | 50–70 ng/mL | Testosteron, Muskelfunktion, Immunsystem |
| **Omega-3 Index** | ≥8% | Entzündung nach Training, Gehirn |
| **Ferritin** | 80–150 ng/mL | Ausdauer, Energie, O₂-Transport |
| **Magnesium (RBC)** | 5,2–6,5 mg/dL | Muskelkontraktion, Schlaf, Erholung |
| **Zink** | 80–120 µg/dL | Testosteron-Synthese |

---

## 🔵 PRIORITÄT 4 — Herzgesundheit & Entzündung

| Marker | Dein Zielwert | Warum |
|---|---|---|
| **ApoB** | <80 mg/dL | Besserer Herzrisiko-Marker als LDL |
| **LDL** | <100 mg/dL | Kardiovaskulär |
| **hs-CRP** | <1,0 mg/L | Chronische Entzündung blockiert Muskelaufbau |
| **Homocystein** | <9 µmol/L | Herzrisiko, Kognition |

---

## ⚪ PRIORITÄT 5 — Organ & Blutwerte

| Marker | Dein Zielwert | Warum |
|---|---|---|
| **ALT (Leber)** | <33 U/L | Besonders relevant bei Supplementen |
| **Kreatinin** | 0,7–1,1 mg/dL | Nierenfunktion (Kreatin-Check) |
| **eGFR** | >90 mL/min | Nieren bei hoher Proteinzufuhr |
| **Hämoglobin** | 14–17 g/dL | Sauerstoff → direkte Performance |

---

## 📊 WAS BEI 98 KG BESONDERS WICHTIG IST

| Risiko | Marker | Warum du es priorisieren solltest |
|---|---|---|
| Insulinresistenz | Nüchterninsulin + HbA1c | Hohes Körpergewicht = erhöhtes Risiko |
| Niedrig-T durch Ar

---

**Du:**

Korrektur alles kombinieren bei der letzten Frage

---

**Claude:**

Hier die aktualisierte Version — alle Ziele kombiniert:

---

# 🩸 DEINE PERSÖNLICHEN ZIELWERTE
### 32J · Männlich · 98 kg · Performance + Muskelaufbau + Longevity

---

## 🔴 PRIORITÄT 1 — Hormone (Fundament für alles)

| Marker | Dein Zielwert | Kritisch wenn |
|---|---|---|
| **Testosteron gesamt** | 700–900 ng/dL | <500 ng/dL |
| **Freies Testosteron** | 15–25 pg/mL | <10 pg/mL |
| **SHBG** | 20–35 nmol/L | >50 = zu viel gebunden |
| **Östradiol (E2)** | 20–30 pg/mL | >40 = Fett↑, Libido↓ |
| **LH** | 3–8 IU/L | Diagnose-Marker |
| **TSH** | 0,5–2,0 mIU/L | >3 = Stoffwechsel gebremst |
| **DHEA-S** | 300–500 µg/dL | Vitalität, Anti-Aging |

> ⚠️ Bei 98 kg besonders wichtig: Bauchfett erhöht Aromatase → mehr Östrogen, weniger freies Testosteron.

---

## 🟠 PRIORITÄT 2 — Metabolismus & Körperkomposition

| Marker | Dein Zielwert | Kritisch wenn |
|---|---|---|
| **Nüchternglukose** | 70–85 mg/dL | >100 = Insulinresistenz |
| **Nüchterninsulin** | <8 µIU/mL | >12 = Fettverbrennung blockiert |
| **HbA1c** | 4,8–5,2% | >5,7% = Prädiabetes |
| **Triglyzeride** | <100 mg/dL | >150 = metabolisches Risiko |
| **HDL** | >55 mg/dL | <40 = Risiko |
| **ApoB** | <70 mg/dL | >100 = Herzrisiko steigt |

---

## 🟡 PRIORITÄT 3 — Nährstoffe (Supplement-Erfolg messen)

| Marker | Dein Zielwert | Warum für dich |
|---|---|---|
| **Vitamin D (25-OH-D)** | 50–70 ng/mL | Testosteron, Muskel, Immunsystem |
| **Omega-3 Index** | ≥8% | Entzündung, Gehirn, Herz |
| **Magnesium (RBC)** | 5,2–6,5 mg/dL | Schlaf, Muskelkontraktion, Erholung |
| **Ferritin** | 80–150 ng/mL | Energie, Ausdauer, O₂-Transport |
| **Zink** | 80–120 µg/dL | Testosteron-Synthese direkt |
| **Vitamin B12** | 400–800 pg/mL | Nerven, Energie, Zellteilung |
| **Folat** | >15 ng/mL | Zellreparatur, Herz |

---

## 🔵 PRIORITÄT 4 — Entzündung & Longevity

| Marker | Dein Zielwert | Warum |
|---|---|---|
| **hs-CRP** | <0,5 mg/L | Entzündung blockiert Muskelaufbau & Longevity |
| **Homocystein** | <8 µmol/L | Herzrisiko, Kognition, Gefäße |
| **IGF-1** | 150–220 ng/mL | Muskelaufbau + Longevity-Balance |
| **LDL** | <90 mg/dL | Kardiovaskulär |

---

## ⚪ PRIORITÄT 5 — Organ & Blut

| Marker | Dein Zielwert | Warum |
|---|---|---|
| **ALT (Leber)** | <30 U/L | Supplement-Sicherheit, Lebergesundheit |
| **Kreatinin** | 0,7–1,1 mg/dL | Niere bei hoher Proteinzufuhr |
| **eGFR** | >90 mL/min | Nierenfunktion |
| **Hämoglobin** | 14,5–17 g/dL | O₂-Transport = direkte Performance |
| **Ferritin** | 80–150 ng/mL | Eisenspeicher, Ausdauer |

---

## ⚡ DEINE TOP-3 SOFORTMASSNAHMEN bei 98 kg

| # | Problem | Marker checken | Intervention |
|---|---|---|---|
| 1 | Insulinresistenz | Nüchterninsulin + HbA1c | Fasten, Zone-2-Cardio, weniger Zucker |
| 2 | Niedriges freies T | Testosteron + SHBG + E2 | Körperfett senken, Zink, Kreatin, Schlaf |
| 3 | Chronische Entzündung | hs-CRP + Omega-3 Index | Omega-3 hochdosieren, Sauna, Schlaf |

---

## 📅 TEST-FREQUENZ FÜR DICH

| Intervall | Was testen |
|---|---|
| **Jetzt sofort** | Vollständiges Panel — alle oben genannten |
| **Nach 8 Wochen** | Hormone + Nüchterninsulin + Vitamin D |
| **Alle 6 Monate** | Omega-3 Index + Testosteron + HbA1c |
| **1× jährlich** | Komplettes Panel zur Verlaufskontrolle |

---

**Nächster Schritt:** Soll ich dir einen Spickzettel als PDF oder Apple-Erinnerung erstellen, den du direkt zum Arzt mitnehmen kannst — mit allen Markern die du bestellen sollst?

---

**Du:**

Ja

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Hier ist dein PDF — direkt druckbar und zum Arzt mitnehmen.

Es enthält alle 5 Prioritätskategorien mit deinen personalisierten Zielwerten, die 3 Sofortmassnahmen für dein Profil (98 kg) und den Test-Zeitplan.

**Nächster Schritt:** Zeig dem Arzt das PDF und bitte um ein vollständiges Blutbild inkl. der hormontypischen Marker — viele davon sind nicht im Standard-Check enthalten und müssen explizit angefordert werden.

---

**Du:**

Als Apple Erinnerung

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Es scheint, dass der Zugriff auf deine Apple Erinnerungen gerade verweigert wird — wahrscheinlich wurde die Berechtigung zwischenzeitlich entzogen.

**So behebst du es:**
1. iPhone → **Einstellungen → Claude → Erinnerungen** → auf "Alle" stellen
2. Dann nochmal hier schreiben — ich lege sofort alle Marker als Erinnerungen an.

---

**Du:**

Wäre es besser wenn wir es in Apple Tabellen erstellen oder wo haben wir die beste Übersicht kombiniere Supplemente in einem Tabellenplatz und Blutwerte im anderen 

Erstelle auch das Protokoll für Sport und Ernährung in zwei separaten Blätter wenn ich nach andrew hubermann und Patrick ronda leben möchte

---

**Claude:**

Sehr gute Idee — Numbers (Apple Tabellen) ist perfekt dafür. Ich erstelle eine saubere .xlsx Datei mit 4 Blättern die du direkt in Numbers öffnen kannst.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Hier ist deine komplette Datei — direkt in Apple Numbers öffnen.

**4 Blätter enthalten:**

| Blatt | Inhalt |
|---|---|
| 💊 Supplemente | Alle 11 Supplements · Tier 1–3 · Dosis + Timing |
| 🩸 Blutwerte | Alle 28 Biomarker · Zielwerte · Kritisch-Werte · Testfrequenz |
| 💪 Sport Protokoll | Huberman 7-Tage-Split + Rhonda Patrick Wochenstruktur |
| 🥗 Ernährung | Fasten-Fenster · Mahlzeiten · Lebensmittel · Was vermeiden |

**Nächster Schritt:** Blutbild beim Arzt bestellen — das PDF von vorhin mitnehmen als Checkliste.

---

**Du:**

Optimiere bitte diese Tabelle optisch 

Ich möchte das es alles ordentlich beschriftet ist nicht alles in Großbuchstaben nur der erste Buchstabe groß Rest normal da wo es richtig ist 

Farben dezent und minimalistisch 

Es soll nach einem professionellen und modernen Tabelle

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Hier ist die überarbeitete Version — komplett neu designed.

**Was geändert wurde:**
- Nur erster Buchstabe groß, alles andere normal geschrieben
- Dezente, warme Farbpalette — kein Knallbunt, alles gedämpft und professionell
- Schmale Akzent-Spalte links als modernes Design-Element statt voller Farbflächen
- Subtile Zeilenwechsel statt starker Kontraste
- Sektions-Trennzeilen in hellem Warmgrau mit farbigem Text
- Einheitliche Calibri-Schrift durchgehend
- Tab-Farben passend zum jeweiligen Thema

---

**Du:**

Fehlt noch etwas?

---

**Claude:**

Basierend auf allem was wir aufgebaut haben, fehlen noch ein paar sinnvolle Dinge:
```
This block is not supported on your current device yet.
```

Außerdem — was ich noch auffällig vermisse das wirklich fehlt:

**Inhaltlich:**
- **Körpermessung-Tracker** — Gewicht, Körperfett, Umfänge (Taille besonders wichtig bei 98 kg)
- **Supplement-Kosten-Übersicht** — was kostet das monatlich realistisch
- **Arzt-Gesprächsleitfaden** — welche Marker aktiv einfordern (viele Ärzte machen das nicht standardmäßig)

**Strukturell in der bestehenden Tabelle:**
- Ein **Deckblatt/Dashboard-Sheet** als Übersicht mit direkten Links zu allen Blättern
- Die **Blutwerte-Spalte "✓"** ist leer — müsste noch als ausfüllbares Feld funktionieren

Was soll ich ergänzen?

---

**Du:**

F: Was möchtest du noch ergänzen?
A: Alles

---

**Claude:**

Perfekt — ich baue alles in eine komplette Datei mit allen Blättern.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Hier ist die vollständige Datei — 11 Blätter, alles drin.

| # | Blatt | Inhalt |
|---|---|---|
| 1 | Dashboard | Übersicht aller Blätter |
| 2 | Supplemente | 11 Supplements + Monatskosten |
| 3 | Blutwerte | 28 Marker + ausfüllbare Felder |
| 4 | Sport-Protokoll | Huberman 7-Tage + Rhonda Patrick |
| 5 | Ernährungs-Protokoll | Mahlzeiten, Timing, Verbote |
| 6 | Tages-Tracking | Mo–So Abhak-System |
| 7 | Schlaf-Protokoll | Abend-Routine + NSDR + Stack |
| 8 | 12-Wochen-Plan | Schritt-für-Schritt Einführung |
| 9 | Einkaufsliste | Food + Supplement-Marken |
| 10 | Körper-Tracking | Maße, Performance, Wohlbefinden |
| 11 | Arzt-Gespräch | Welche Marker einfordern + Formulierungen |

**Nächster Schritt:** Blutbild machen — Arzt-Gespräch-Blatt ausdrucken und mitnehmen.

---

**Du:**

Ich möchte auch wissen von welcher Marke ich diese Supplemente etc kaufen kann welche hubermann nimmt und welche in Deutschland erhältlich sind 


Optimiere die Tabelle auf das beste ergebniss und ergänze alles was fehlt oder fehlerhaft ist

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Gut — ich habe jetzt alle Marken-Informationen. Ich baue jetzt die komplette optimierte Datei mit allem:
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Hier ist die finale, vollständige Version. Das Supplement-Blatt enthält jetzt:

**Was neu drin ist:**

| Bereich | Ergänzung |
|---|---|
| **Huberman-Originalmarken** | Thorne Super EPA · Carlson Labs · Momentous (offizieller Partner) · Magtein · Creapure |
| **Rhonda Patrick-Marken** | Pure Encapsulations ONE · Thorne Crucera-SGS · Doctor's Best |
| **Deutsche Alternativen** | Sunday Natural (Berlin) · ESN Creapure (Rossmann) · Nordic Naturals via iHerb.de · Naturtreu (Amazon.de) |
| **Wo kaufen in DE** | iHerb.de · sunday.de · amazon.de · Rossmann · dm · cerascreen.de |
| **Monatskosten** | Tier 1: ~38–67 € · Tier 1–3: ~110–175 € · Komplett: ~165–260 € |
| **Arzt-Gespräch** | Konkrete Formulierungen zum direkt Vorlesen · cerascreen.de als Online-Alternative |

**Wichtigste Kaufquelle für dich:** Huberman nimmt für Omega-3 Thorne Super EPA kombiniert mit Carlson Labs Lemon Fish Oil — beides über iHerb.de nach Deutschland lieferbar.

---

**Du:**

Haben wir alles ?

---

**Claude:**

Lass mich kurz strukturiert durchgehen was wir haben und was noch fehlen könnte:

**Was wir haben ✅**

| Blatt | Status |
|---|---|
| Dashboard | ✅ |
| Supplemente + Marken + DE-Bezug | ✅ |
| Blutwerte (28 Marker) | ✅ |
| Sport-Protokoll | ✅ |
| Ernährungs-Protokoll | ✅ |
| Tages-Tracking | ✅ |
| Schlaf-Protokoll | ✅ |
| 12-Wochen-Plan | ✅ |
| Einkaufsliste | ✅ |
| Körper-Tracking | ✅ |
| Arzt-Gespräch | ✅ |

---

**Was ich noch vermisse — ehrlich betrachtet:**
```
This block is not supported on your current device yet.
```

Die 4 Punkte die noch wirklich fehlen:

**1. Supplement-Kosten-Tracker** — monatliche Ausgaben verfolgen und optimieren

**2. Jahreskalender für Blutbilder** — wann genau welche Tests fällig sind, als Erinnerungssystem

**3. Fortschritts-Foto-Protokoll** — wann Fotos machen, aus welchem Winkel, für den Vergleich

**4. Stressmanagement & Mentales Protokoll** — Huberman hat ein konkretes Protokoll für Cortisol-Kontrolle und mentale Erholung (physiologischer Seufzer, NSDR tagsüber, Sonnenlicht-Timing) das bisher nur fragmentiert in den anderen Blättern steckt — nicht als eigenständiges Sheet

---

**Du:**

Ok ergänze noch

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Die finale Version ist fertig — **15 Blätter**, alles vollständig.

**Die 4 neuen Blätter:**

| # | Blatt | Was drin ist |
|---|---|---|
| 12 | **Kosten-Tracker** | Monatliche Ausgaben eintragen · 6-Monats-Übersicht · Spar-Tipps · Budget-Ziel |
| 13 | **Jahreskalender** | Wann welches Blutbild · Monate 1–12 geplant · Sondertermine Winter/Sommer |
| 14 | **Foto-Protokoll** | Anleitung für Fortschrittsfotos · 7 Termine von Woche 1 bis Monat 12 · Vergleichstipps |
| 15 | **Stress & Mental** | Hubermans komplettes Cortisol- & Dopamin-Protokoll · NSDR · Fokus-Blöcke · Warnsignale · Tages-Checkliste |

**Jetzt hast du wirklich alles.** Das ist ein komplettes Lebenssystem — nicht nur ein Supplement-Guide.

---

**Du:**

Gibt es bei supps qualitative Unterschiede ? Bsp esn und von hubermann

---

**Claude:**

Ja, und die Unterschiede sind erheblich. Lass mich das direkt aufschlüsseln:
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Ja — und der Unterschied ist größer als die meisten denken. Hier ist die ehrliche Aufschlüsselung:

---

## 🔬 Qualitative Unterschiede bei Supplements

### Das Kernproblem zuerst

Der Supplement-Markt ist **kaum reguliert**. In Deutschland und der EU müssen Supplements nicht nachweisen, dass sie wirken oder rein sind — sie müssen nur "sicher" sein. Das bedeutet: Was auf der Packung steht, muss **nicht zwingend drin sein**.

Eine Studie in JAMA (2022) fand, dass Supplements ohne Drittprüfung signifikant häufiger Kontaminationen enthielten.

---

### Die 4 entscheidenden Qualitätsstufen

**Stufe 1 — Keine Prüfung (billigste Produkte)**
Drogerie-Eigenmarken, Amazon-No-Names. Keine externe Kontrolle. Wirkstoffgehalt kann 20–80 % vom deklarierten Wert abweichen. Schwermetalle möglich.

**Stufe 2 — Eigenproduktion mit internen Tests (ESN, Sunday Natural)**
ESN produziert in Deutschland in eigener Produktion und führt interne Qualitätskontrollen durch — jeder Produktionsschritt wird überwacht. Das ist solide, aber die Kontrolle kommt vom Hersteller selbst — kein unabhängiger Dritter.

**Stufe 3 — Externe Drittprüfung (Nordic Naturals, Doctor's Best, Thorne)**
Unabhängiges Labor prüft Reinheit und Deklarationsgenauigkeit. Kein kontinuierliches Batch-Testing, aber deutlich vertrauenswürdiger als Stufe 2.

**Stufe 4 — Zertifiziert (Momentous, Thorne)**
NSF Certified for Sport prüft jeden Batch auf 290 verbotene Substanzen, verifiziert den Inhalt gegen die Deklaration und auditiert die Produktionsstätte zweimal jährlich. Informed Sport geht noch weiter — jeder einzelne Batch wird vor der Marktfreigabe getestet.

---

### ESN vs. Momentous/Thorne — direkt verglichen

| Kriterium | ESN (DE) | Momentous / Thorne (US) |
|---|---|---|
| Produktion | Deutschland · intern kontrolliert | USA · pharmazeutische Standards |
| Externe Prüfung | Intern + NEM-Verband | NSF Certified / Informed Sport |
| Batch-Testing | Nicht öffentlich bestätigt | Jeder Batch vor Marktfreigabe |
| Zertifizierung | Keine internationale | NSF · Informed Sport · USP |
| Transparenz | Begrenzt | Lot-Nummer prüfbar online |
| Preis | Günstig–mittel | Mittel–hoch |
| Für dich sinnvoll? | Kreatin (Creapure-Rohstoff) | Omega-3 · Vitamin D · Schlafsupplements |

---

### Wo der Unterschied **wirklich** wichtig ist

Nicht bei jedem Supplement ist die Marke gleich kritisch:

**Sehr kritisch (immer Top-Qualität):**
- **Omega-3** — Fischöl oxidiert schnell, kann Schwermetalle enthalten → Huberman prüft IFOS-Testergebnisse für Oxidationswerte und Schwermetalle → Nordic Naturals, Thorne
- **Vitamin D** — Dosierung muss präzise sein, billige D3-Kapseln können stark abweichen → Thorne, Pure Encapsulations
- **Magnesium** — Form ist entscheidend (Bisglycinat ≠ Oxid) → Sunday Natural, Doctor's Best

**Mittel kritisch:**
- **Apigenin, Alpha-GPC, L-Tyrosin** → Momentous oder Sunday Natural
- **Multivitamin** → Thorne Basic Nutrients oder Pure Encapsulations ONE

**Weniger kritisch (Rohstoff entscheidend, nicht Marke):**
- **Kreatin** → Creapure-zertifizierter Rohstoff ist der Standard — egal ob ESN, Sunday Natural oder Bulk Powders. ESN produziert Kreatin in Deutschland unter strengen externen Laborkontrollen — für Kreatin ist ESN eine vollkommen legitime Wahl.

---

### Hubermans Qualitäts-Prinzip

Huberman empfiehlt Thorne für stringente Qualität und präzise Formulierungen — Thorne arbeitet mit Mayo Clinic, Columbia University und über 100 Profi-Sportteams zusammen.

**Sein Grundsatz:** Einzel-Ingredient-Supplements von verifizierten Marken kaufen. Keine Kombi-Produkte. Lot-Nummer online prüfbar.

---

### Praktische Empfehlung für dich

Kein Grund, für alles das teuerste zu kaufen. Aber für die täglichen Fundament-Supplements lohnt es sich:

| Supplement | Budget-Option (ok) | Empfohlen |
|---|---|---|
| Kreatin | ESN Creapure / Bulk Powders | Gleich — Creapure-Rohstoff ist Standard |
| Omega-3 | — | Nordic Naturals / Thorne Super EPA (IFOS geprüft) |
| Vitamin D3+K2 | Sunday Natural | Thorne / Pure Encapsulations |
| Magnesium | Sunday Natural Bisglycinat | Doctor's Best (iHerb.de) |
| Apigenin | Sunday Natural | Momentous (wenn Budget da) |

**Faustregel:** Je täglich, je höher die Dosis, je fettlöslich — desto wichtiger ist die Marke.

---

**Du:**

prüfe welche reminder ich mir einstellen kann um die DInge umzusetzen aus der Routine v

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Ich sehe keine Erinnerungen-Berechtigung aktiv. Lass mich prüfen was technisch möglich ist:
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Der Zugriff auf Apple Erinnerungen ist aktuell nicht verfügbar — wahrscheinlich wurde die Berechtigung nicht erteilt oder entzogen.

Aber ich kann dir trotzdem etwas Nützlicheres geben: **Eine vollständige Erinnerungs-Vorlage** die du in 5 Minuten selbst einträgst — strukturiert nach Tageszeit, sodass du sie einfach abtippen oder kopieren kannst.

---

## ⏰ Apple Erinnerungen — Komplettes Tages-Setup

### 🌅 MORGEN (täglich wiederkehrend)

| Zeit | Erinnerung | Liste |
|---|---|---|
| 06:30 | 🌞 Sofort raus — Sonnenlicht holen (5–10 Min) | Huberman Routine |
| 06:31 | 💧 2 Gläser Wasser trinken — vor allem anderen | Huberman Routine |
| 06:32 | 🧘 NSDR / Yoga Nidra 10–20 Min (YouTube: Huberman NSDR) | Huberman Routine |
| 08:00 | ☕ Jetzt erst Kaffee — Adenosin-Clearance abwarten | Huberman Routine |
| 08:01 | 💊 Morgen-Supplements: Omega-3 · D3+K2 · Kreatin · Multivitamin | Huberman Routine |

---

### 💪 TRAINING (täglich — Inhalt je nach Wochentag)

| Zeit | Erinnerung | Liste |
|---|---|---|
| 09:00 | 🏋️ Training heute: [Mo=Beine · Mi=Oberkörper · Do=Zone2 · Fr=HIIT · Sa=Arme · So=Lauf] | Huberman Routine |
| 08:30 | 🧠 Pre-Workout: Alpha-GPC 300mg + L-Tyrosin 500mg (nur Krafttage) | Huberman Routine |

---

### 🍽️ ERNÄHRUNG (täglich)

| Zeit | Erinnerung | Liste |
|---|---|---|
| 11:00 | 🥗 Erste Mahlzeit — Essensfenster startet jetzt | Huberman Routine |
| 11:01 | ✅ Erste Mahlzeit: Protein + gesunde Fette + Kreuzblütler | Huberman Routine |
| 13:45 | ☕ Letzter Kaffee — nach 14:00 kein Koffein mehr | Huberman Routine |
| 19:00 | 🍝 Letzte Mahlzeit spätestens jetzt — 3h vor Schlaf | Huberman Routine |
| 19:01 | ❌ Kein Alkohol · kein Zucker · kein rotes Fleisch abends | Huberman Routine |

---

### 🌙 ABEND (täglich)

| Zeit | Erinnerung | Liste |
|---|---|---|
| 20:00 | 💡 Lichter dimmen — kein Deckenlicht mehr ab jetzt | Huberman Routine |
| 20:01 | 📱 Bildschirme auf Nachtmodus schalten | Huberman Routine |
| 21:00 | 💊 Abend-Supplements: Magnesium 200mg + Apigenin 50mg + L-Theanin 100mg | Huberman Routine |
| 22:00 | 😴 Vorbereitung Schlaf — Handy raus aus dem Zimmer | Huberman Routine |
| 22:01 | 🌡️ Schlafzimmer: 17–19°C · komplett dunkel · Ohrstöpsel bereit | Huberman Routine |

---

### 📅 WÖCHENTLICH

| Tag & Zeit | Erinnerung | Liste |
|---|---|---|
| Sonntag 19:00 | 📊 Tages-Tracking-Sheet ausfüllen — Wochenrückblick | Huberman Routine |
| Sonntag 19:10 | ⚖️ Körpergewicht + Taillenumfang messen (morgens nüchtern) | Huberman Routine |
| Montag 08:00 | 🛒 Einkaufsliste prüfen — Supplements & Lebensmittel | Huberman Routine |

---

### 📅 MONATLICH

| Tag | Erinnerung | Liste |
|---|---|---|
| 1. des Monats | 💰 Supplement-Kosten-Tracker ausfüllen | Huberman Routine |
| 1. des Monats | 📦 Supplement-Vorrat prüfen — nachbestellen wenn < 2 Wochen | Huberman Routine |

---

### 📅 ALLE 3 MONATE

| | Erinnerung | Liste |
|---|---|---|
| Quartal 1 (Juli) | 🩸 Blutbild-Termin beim Arzt buchen — Hormone + D3 + Insulin | Huberman Routine |
| Quartal 2 (Oktober) | 🩸 Halbjahres-Blutbild — Omega-3-Index + Testosteron + HbA1c | Huberman Routine |
| Quartal 3 (Januar) | 🩸 Jahres-Blutbild — vollständiges Panel | Huberman Routine |

---

### 📸 FOTO-PROTOKOLL

| | Erinnerung |
|---|---|
| Heute | 📸 Fortschrittsfoto Woche 1 — frontal · Seite · Rücken |
| In 4 Wochen | 📸 Fortschrittsfoto Woche 4 |
| In 8 Wochen | 📸 Fortschrittsfoto Woche 8 |
| In 12 Wochen | 📸 Fortschrittsfoto Woche 12 |

---

**So einrichten in Apple Erinnerungen:**
1. Neue Liste anlegen: **"Huberman Routine"**
2. Jede Zeile als einzelne Erinnerung mit Uhrzeit + täglicher Wiederholung
3. Wöchentliche am Sonntag wiederkehrend einstellen
4. Monatliche auf den 1. jeden Monats

**Nächster Schritt:** Willst du dass ich dir das als strukturierte Textdatei exportiere die du direkt in Shortcuts oder eine andere App importieren kannst?

---

**Du:**

ich arbeite von 9 bis 18 Uhr muss morgens mittags abend mit dem Hund 1h eweils spazieren

---

**Claude:**

Perfekt — dann passe ich alles realistisch auf deinen echten Alltag an.
```
This block is not supported on your current device yet.
```

---

**Du:**

F: Um wieviel Uhr stehst du auf?
A: aktuell 7:30 würde meine routine aber gerne optimieren

F: Wann machst du den Morgenhund-Spaziergang?
A: Vor der Arbeit (7–8 Uhr)

F: Wann trainierst du am liebsten?
A: ich gehe aktuell abends würde aber gern in der früh wenn wir einen guten plan hinbekommen

---

**Claude:**

Sehr gut. Mit diesen Infos kann ich einen realistischen Tagesplan bauen. Meine Empfehlung: **6:00 Uhr aufstehen** — das gibt dir alles was du brauchst ohne Stress.

Hier ist dein optimierter Alltag:

---

## ⏰ DEIN OPTIMIERTER TAGESPLAN
### Arbeit 9–18 Uhr · Hund 3× täglich 1h · Training morgens

---

### 🌅 MORGEN — 06:00 bis 09:00 Uhr

| Zeit | Was | Warum |
|---|---|---|
| **06:00** | Aufstehen — kein Snooze | Circadianer Anker |
| **06:01** | 2 Gläser Wasser sofort | Rehydrierung über Nacht |
| **06:02** | Fenster auf / kurz raus — Sonnenlicht 5 Min | Cortisol-Puls setzen |
| **06:05** | Hund-Spaziergang 1h — draußen · Sonnenlicht · Zone-2 | Sonnenlicht + Bewegung + Hund = 3-in-1 |
| **07:05** | Heimkommen — Pre-Workout einnehmen | Alpha-GPC 300mg + L-Tyrosin 500mg (Krafttage) |
| **07:10** | Training — 45–55 Min nüchtern | Wachstumshormon ↑ · Fettverbrennung ↑ |
| **08:05** | Dusche + fertig machen | |
| **08:20** | Erste Mahlzeit — Protein + Fette + Kreuzblütler | Fastenbrechen nach ~14h |
| **08:25** | Morgen-Supplements: Omega-3 · D3+K2 · Kreatin · Multivitamin | Zu Mahlzeit einnehmen |
| **08:35** | Erster Kaffee ☕ | 2,5h nach Aufwachen — Adenosin gecleant |
| **09:00** | Arbeit beginnt | |

> 💡 Der Hund-Spaziergang morgens **ersetzt** den separaten Sonnenlicht-Schritt und ist gleichzeitig leichtes Zone-2-Kardio. Zwei Fliegen, eine Klappe.

---

### 🏢 ARBEIT — 09:00 bis 13:00 Uhr

| Zeit | Was | Warum |
|---|---|---|
| **09:00–12:00** | Fokus-Block — kein Handy · kein Social Media | 90-Min-Blöcke · Dopamin-System schützen |
| **12:00** | NSDR 10–15 Min | Dopamin-Recharge · Nachmittagsleistung ↑ |
| **12:15** | Mittagessen — Protein + Gemüse + leichte Carbs | Zweite Mahlzeit |
| **13:00** | Kaffee wenn nötig — **letzter des Tages** | Stopp-Limit: 13:00 Uhr |

---

### 🐕 MITTAG — Hund (13:00 oder Mittagspause)

| Zeit | Was | Warum |
|---|---|---|
| **12:30–13:30** | Hund-Spaziergang 1h — Mittagspause | Bewegung · frische Luft · mentale Erholung |

> 💡 Falls Home Office: Mittagsspaziergang perfekt als NSDR-Ersatz + Bewegung. Falls Büro: Spaziergang nach der Arbeit verschieben auf 18:00 Uhr.

---

### 🏢 ARBEIT — 13:00 bis 18:00 Uhr

| Zeit | Was | Warum |
|---|---|---|
| **13:00–17:00** | Zweiter Fokus-Block | |
| **17:30** | Tag abschließen · To-do für morgen notieren | Cortisol-Abfall vorbereiten |
| **18:00** | Arbeit Ende | |

---

### 🐕 ABEND — Hund + Abendessen

| Zeit | Was | Warum |
|---|---|---|
| **18:00** | Hund-Spaziergang 1h — Abendlicht | Natürliches Melatonin-Signal · entspannend |
| **19:00** | Abendessen — Kohlenhydrate + leichtes Protein | Tryptophan → Melatonin · Schlaf ↑ |
| **19:01** | Kein Alkohol · kein Zucker · kein rotes Fleisch | Schlafqualität schützen |

---

### 🌙 ABEND-ROUTINE — 19:00 bis 22:30 Uhr

| Zeit | Was | Warum |
|---|---|---|
| **20:00** | Lichter dimmen — Stehlampe statt Decke | Melatonin-Produktion starten |
| **20:00** | Bildschirme auf Nachtmodus | Blaues Licht ↓ |
| **21:00** | Abend-Supplements: Magnesium 200mg + Apigenin 50mg + L-Theanin 100mg | Parasympathikus · Einschlafen |
| **21:30** | Handy raus aus dem Schlafzimmer | Kein Blaulicht · keine Versuchung |
| **22:00** | Schlafen gehen | 8h Schlaf bis 06:00 Uhr |

---

## 📋 APPLE ERINNERUNGEN — Fertige Liste zum Eintippen

### Täglich wiederkehrend:

| Uhrzeit | Erinnerung |
|---|---|
| 06:00 | 🌅 Aufstehen — kein Snooze |
| 06:01 | 💧 2 Gläser Wasser sofort |
| 06:05 | 🐕 Hund + Sonnenlicht — 1 Stunde |
| 07:05 | 💊 Pre-Workout: Alpha-GPC + L-Tyrosin (nur Mo · Mi · Sa) |
| 07:10 | 🏋️ Training starten |
| 08:20 | 🥗 Erste Mahlzeit + Morgen-Supplements |
| 08:35 | ☕ Erster Kaffee (frühestens jetzt) |
| 12:00 | 🧘 NSDR 10–15 Min — jetzt Pause |
| 12:15 | 🥗 Mittagessen |
| 13:00 | ☕ Letzter Kaffee — danach kein Koffein mehr |
| 18:00 | 🐕 Abendhund — 1 Stunde |
| 19:00 | 🍝 Abendessen — Kohlenhydrate · kein Alkohol |
| 20:00 | 💡 Lichter dimmen + Bildschirm Nachtmodus |
| 21:00 | 💊 Abend-Supplements: Magnesium + Apigenin + L-Theanin |
| 21:30 | 📱 Handy raus aus dem Schlafzimmer |
| 22:00 | 😴 Schlafen gehen |

### Wöchentlich:

| Tag & Zeit | Erinnerung |
|---|---|
| Sonntag 19:00 | 📊 Tracking-Sheet ausfüllen + Gewicht messen |
| Montag 08:00 | 🛒 Supplement-Vorrat + Einkaufsliste prüfen |
| Dienstag 07:10 | 🌡️ Sauna + Kältebad statt Training |

### Wochensplit für Training-Erinnerung:

| Tag | Training-Erinnerung 07:10 |
|---|---|
| Montag | 🦵 Beine: Hack Squats · Leg Curls · Calf Raises |
| Dienstag | 🌡️ Sauna + Cold Plunge — kein Krafttraining |
| Mittwoch | 💪 Oberkörper: Push + Pull + Nacken |
| Donnerstag | 🚴 Zone-2 Kardio 45 Min — Hund zählt mit |
| Freitag | ⚡ HIIT: 8–12 Runden Assault Bike |
| Samstag | 💪 Arme + Schultern + Waden |
| Sonntag | 🏃 Langer Spaziergang mit Hund = Zone-2 |

---

> **Bonus:** Der Hund macht Donnerstag und Sonntag automatisch zum Zone-2-Tag — du erreichst dein 150–200 Min Wochenziel fast ohne Extra-Aufwand.

**Nächster Schritt:** Soll ich das als druckbare PDF oder als weitere Excel-Tabelle in deine bestehende Datei einbauen?

---

**Du:**

ich brauche zur arbeit 30 min Montags und Mittwochs rest ist Home office 

duschen und fertig machen 30 min

---

**Claude:**

Perfekt — damit kann ich alles präzise durchplanen. Hier ist dein finaler, realistischer Tagesplan:

---

## ⏰ FINALER TAGESPLAN — Personalisiert

---

### 📅 BÜROTAGE — Montag & Mittwoch

| Zeit | Was | Dauer |
|---|---|---|
| **06:00** | Aufstehen · 2 Gläser Wasser | 2 Min |
| **06:05** | 🐕 Hund + Sonnenlicht (Morgenspaziergang) | 60 Min |
| **07:05** | 💊 Pre-Workout: Alpha-GPC + L-Tyrosin | 2 Min |
| **07:10** | 🏋️ Training (Mo: Beine · Mi: Oberkörper) | 50 Min |
| **08:00** | 🚿 Duschen + fertig machen | 30 Min |
| **08:30** | 🥗 Erste Mahlzeit + Morgen-Supplements | 15 Min |
| **08:35** | ☕ Erster Kaffee | — |
| **08:45** | 🚗 Fahrt zur Arbeit | 30 Min |
| **09:00** | 💼 Arbeit beginnt | — |
| **12:00** | 🧘 NSDR 10 Min + Mittagessen | 45 Min |
| **12:45** | 🐕 Hund Mittagsrunde (kurz — 30 Min reicht) | 30 Min |
| **13:15** | ☕ Letzter Kaffee — danach kein Koffein | — |
| **18:00** | 🚗 Heimfahrt | 30 Min |
| **18:30** | 🐕 Abendhund | 60 Min |
| **19:30** | 🍝 Abendessen + kein Alkohol · kein Zucker | 20 Min |
| **20:00** | 💡 Lichter dimmen · Bildschirm Nachtmodus | — |
| **21:00** | 💊 Abend-Supplements | 2 Min |
| **21:30** | 📱 Handy raus | — |
| **22:00** | 😴 Schlafen | — |

> 💡 Bürotage: Mittagshund auf 30 Min kürzen — abends die volle Stunde. Gesamthundzeit bleibt 2h.

---

### 🏠 HOME OFFICE TAGE — Di · Do · Fr · Sa · So

| Zeit | Was | Dauer |
|---|---|---|
| **06:00** | Aufstehen · 2 Gläser Wasser | 2 Min |
| **06:05** | 🐕 Hund + Sonnenlicht (Morgenspaziergang) | 60 Min |
| **07:05** | 💊 Pre-Workout (Krafttage) oder direkt weiter | 2 Min |
| **07:10** | 🏋️ Training | 50 Min |
| **08:00** | 🚿 Duschen + anziehen | 30 Min |
| **08:30** | 🥗 Erste Mahlzeit + Morgen-Supplements | 15 Min |
| **08:45** | ☕ Erster Kaffee | — |
| **09:00** | 💼 Arbeit beginnt (Homeoffice) | — |
| **12:00** | 🧘 NSDR 15 Min | 15 Min |
| **12:15** | 🐕 Hund Mittagsrunde | 60 Min |
| **13:15** | 🥗 Mittagessen | 20 Min |
| **13:00** | ☕ Letzter Kaffee — danach kein Koffein | — |
| **13:35** | 💼 Arbeit weiter | — |
| **18:00** | 🐕 Abendhund | 60 Min |
| **19:00** | 🍝 Abendessen + kein Alkohol · kein Zucker | 20 Min |
| **20:00** | 💡 Lichter dimmen · Bildschirm Nachtmodus | — |
| **21:00** | 💊 Abend-Supplements | 2 Min |
| **21:30** | 📱 Handy raus | — |
| **22:00** | 😴 Schlafen | — |

> 💡 Home Office: Mittagshund ist die volle Stunde — perfekt als mentale Erholung und Zone-2 mitten im Tag.

---

### 🗓️ WOCHENSPLIT — was an welchem Tag

| Tag | Training | Hund morgens | Besonderheit |
|---|---|---|---|
| **Montag** | 🦵 Beine | ✅ 06:05 | Büro · Pre-Workout |
| **Dienstag** | 🌡️ Sauna + Kältebad | ✅ 06:05 | HO · kein Krafttraining |
| **Mittwoch** | 💪 Oberkörper | ✅ 06:05 | Büro · Pre-Workout |
| **Donnerstag** | 🚴 Zone-2 | ✅ 06:05 | HO · Hund morgens = Zone-2 |
| **Freitag** | ⚡ HIIT | ✅ 06:05 | HO · 8–12 Runden |
| **Samstag** | 💪 Arme + Schultern | ✅ 06:05 | HO · leichter Tag |
| **Sonntag** | 🏃 Langer Spaziergang | ✅ 06:05 | HO · Hund = Zone-2 |

---

## 📋 APPLE ERINNERUNGEN — Finale Liste

### Täglich (alle 7 Tage):

| Uhrzeit | Erinnerung |
|---|---|
| 06:00 | 🌅 Aufstehen — kein Snooze · 2 Gläser Wasser |
| 06:05 | 🐕 Hund raus — Sonnenlicht holen · 1 Stunde |
| 07:05 | 💊 Pre-Workout: Alpha-GPC + L-Tyrosin (nur Mo · Mi · Fr · Sa) |
| 07:10 | 🏋️ Training starten |
| 08:00 | 🚿 Duschen + fertig machen |
| 08:30 | 🥗 Erste Mahlzeit + Supplements: Omega-3 · D3+K2 · Kreatin · Multi |
| 08:45 | ☕ Erster Kaffee — frühestens jetzt |
| 12:00 | 🧘 NSDR 10–15 Min — Pause einlegen |
| 13:00 | ☕ Letzter Kaffee des Tages — danach kein Koffein |
| 18:00 | 🐕 Abendhund — 1 Stunde · Abendlicht |
| 19:00 | 🍝 Abendessen — Kohlenhydrate · kein Alkohol · kein Zucker |
| 20:00 | 💡 Lichter dimmen + Bildschirm auf Nachtmodus |
| 21:00 | 💊 Magnesium 200mg + Apigenin 50mg + L-Theanin 100mg |
| 21:30 | 📱 Handy raus aus dem Schlafzimmer |
| 22:00 | 😴 Schlafen gehen — Ziel: 8 Stunden |

### Nur Bürotage (Mo & Mi):

| Uhrzeit | Erinnerung |
|---|---|
| 08:45 | 🚗 Abfahrt zur Arbeit in 15 Min |
| 12:30 | 🐕 Kurze Mittagsrunde Hund — 30 Min |

### Nur Home Office (Di · Do · Fr · Sa · So):

| Uhrzeit | Erinnerung |
|---|---|
| 12:00 | 🐕 Mittagshund — 1 volle Stunde · mentale Erholung |

### Spezifisch je Wochentag:

| Tag & Zeit | Erinnerung |
|---|---|
| Di 07:10 | 🌡️ Heute: Sauna + Kältebad — kein Krafttraining |
| Do 06:05 | 🚴 Heute: Hund morgens = Zone-2 Training — kein extra Sport nötig |
| So 06:05 | 🏃 Heute: Langer Spaziergang mit Hund = Zone-2 Sonntag |
| So 19:00 | 📊 Wochentracking ausfüllen + Gewicht notieren |
| Mo 08:30 | 🛒 Supplement-Vorrat prüfen — nachbestellen wenn nötig |

---

## ⚡ DIE 3 WICHTIGSTEN ERKENNTNISSE FÜR DICH

**1. Dein Hund ist dein bestes Fitness-Tool.**
3× täglich raus = Sonnenlicht morgens + Zone-2 Mittag + Erholung abends. Donnerstag und Sonntag brauchst du kein extra Training.

**2. Home Office ist dein Vorteil.**
Di · Do · Fr hast du die volle Mittagsstunde für den Hund + kannst NSDR ohne Zeitdruck machen. Bürokollegen können das nicht.

**3. 06:00 Uhr ist realistisch.**
Du hast bis 09:00 Uhr: Hund (60 Min) + Training (50 Min) + Duschen (30 Min) + Frühstück (15 Min) + Kaffee + Puffer — das passt exakt auf die Minute.

---

**Nächster Schritt:** Soll ich das als finales Blatt in deine Excel-Datei einfügen — oder reicht dir die Liste so zum manuellen Eintippen in Apple Erinnerungen?

---

**Du:**

Esse ich mittags auf arbeit nichts?

---

**Claude:**

Guter Punkt — ich habe das übersehen. Lass mich das korrigieren.

Das Problem: Du frühstückst um **08:30 Uhr** und arbeitest bis **18:00 Uhr**. Ohne Mittagessen wären das fast 10 Stunden ohne Essen — das ist zu lang für Muskelaufbau und Konzentration.

**Zwei Optionen je nach deinem Ziel:**
```
This block is not supported on your current device yet.
```

---

**Du:**

F: Wie willst du das Essen strukturieren?
A: aktuell trinke ich morgens proteinshake 36g mittags normal und abends normal

---

**Claude:**

Perfekt — das ist eigentlich schon ein solides Fundament. Ich baue es jetzt ins Protokoll ein und optimiere es nach Huberman:

---

## 🍽️ DEIN OPTIMIERTES ERNÄHRUNGS-TIMING

### Warum dein aktuelles System fast perfekt ist:

Proteinshake morgens nach dem Training → Muskelproteinsynthese direkt anregen ✅
Mittagessen auf Arbeit → Energie für Nachmittag ✅
Abendessen → Kohlenhydrate für Schlaf ✅

Das einzige was fehlt: **Qualität und Timing der einzelnen Mahlzeiten.**

---

### 📅 BÜROTAGE (Mo & Mi) — Essen komplett

| Zeit | Mahlzeit | Was genau |
|---|---|---|
| **08:05** | 🥤 Proteinshake nach Training | Whey Isolat 36g + Wasser · Kreatin 5g dazu · Morgen-Supplements |
| **12:30** | 🥗 Mittagessen auf Arbeit | Protein + Gemüse + moderate Carbs · kein Fast Food |
| **13:00** | ☕ Letzter Kaffee | Danach kein Koffein mehr |
| **19:30** | 🍝 Abendessen | Kohlenhydrate + leichtes Protein · kein rotes Fleisch · kein Alkohol |

---

### 🏠 HOME OFFICE TAGE (Di · Do · Fr · Sa · So) — Essen komplett

| Zeit | Mahlzeit | Was genau |
|---|---|---|
| **08:05** | 🥤 Proteinshake nach Training | Whey Isolat 36g + Wasser · Kreatin 5g dazu |
| **08:10** | 💊 Morgen-Supplements | Omega-3 · D3+K2 · Multivitamin — zu kleinem Snack |
| **12:15** | 🥗 Mittagessen zuhause | Protein + Kreuzblütler + Reis oder Süßkartoffel |
| **13:00** | ☕ Letzter Kaffee | Danach kein Koffein mehr |
| **19:00** | 🍝 Abendessen | Kohlenhydrate + Fisch oder Hühnchen · kein Alkohol |

---

### 🥗 WAS DU KONKRET ESSEN SOLLTEST

**Proteinshake morgens (bleibt so):**
- Whey Isolat 36g — Momentous oder ESN Designer Whey
- Dazu: 5g Kreatin einrühren — erledigt
- Optional: Handvoll Beeren dazu

**Mittagessen auf Arbeit — Top 5 Optionen:**

| Option | Protein | Carbs | Praktisch |
|---|---|---|---|
| Hähnchen + Reis + Brokkoli | ✅ | ✅ | Meal Prep Sonntag |
| Lachs + Süßkartoffel + Salat | ✅ | ✅ | Beste Wahl |
| Griechischer Joghurt + Nüsse + Beeren | ✅ | Moderat | Schnell |
| Thunfisch-Salat + Vollkornbrot | ✅ | ✅ | Einfach |
| Quark + Obst + Walnüsse | ✅ | Moderat | Kein Kochen |

> 💡 **Meal Prep Sonntag:** 30 Min kochen — Hähnchen + Reis + Brokkoli für 3 Bürotage vorbereiten. Fertig.

**Abendessen — Prinzip:**
- **Mehr Kohlenhydrate** als mittags → Schlafqualität ↑
- Kein rotes Fleisch abends
- Kein Alkohol — Testosteron ↓ und Schlaf zerstört

---

### 📋 ANGEPASSTE APPLE ERINNERUNGEN — NUR ESSEN

| Uhrzeit | Erinnerung | Tage |
|---|---|---|
| 08:05 | 🥤 Proteinshake + Kreatin 5g + Supplements | Täglich |
| 12:30 | 🥗 Mittagessen — Protein + Gemüse + Carbs | Mo & Mi (Büro) |
| 12:15 | 🥗 Mittagessen zuhause — Meal Prep essen | Di · Do · Fr · Sa · So |
| 13:00 | ☕ Letzter Kaffee — danach kein Koffein mehr | Täglich |
| 19:00 | 🍝 Abendessen — Kohlenhydrate · kein Alkohol · kein Zucker | HO-Tage |
| 19:30 | 🍝 Abendessen — Kohlenhydrate · kein Alkohol · kein Zucker | Mo & Mi |
| 20:45 | ⏰ Letzte Mahlzeit war vor 90 Min — nichts mehr essen | Täglich |
| So 18:00 | 🍳 Meal Prep für Woche vorbereiten — Hähnchen · Reis · Brokkoli | Sonntag |

---

## ✅ DEIN KOMPLETTER TAG — FINALE VERSION

### Bürotag (Mo & Mi):
**06:00** Aufstehen · **06:05** Hund · **07:05** Pre-Workout · **07:10** Training · **08:00** Duschen · **08:05** Shake + Supplements · **08:45** Abfahrt · **09:00** Arbeit · **12:00** NSDR · **12:30** Mittagessen + letzter Kaffee · **18:00** Heimfahrt · **18:30** Abendhund · **19:30** Abendessen · **20:00** Licht dimmen · **21:00** Abend-Supplements · **22:00** Schlafen

### Home Office Tag (Di · Do · Fr · Sa · So):
**06:00** Aufstehen · **06:05** Hund · **07:05** Pre-Workout · **07:10** Training · **08:00** Duschen · **08:05** Shake + Supplements · **09:00** Arbeit · **12:00** NSDR · **12:15** Mittagshund · **12:15** Mittagessen · **13:00** letzter Kaffee · **18:00** Abendhund · **19:00** Abendessen · **20:00** Licht dimmen · **21:00** Abend-Supplements · **22:00** Schlafen

---

**Nächster Schritt:** Soll ich den kompletten finalen Tagesplan als letztes Blatt in deine Excel-Datei einfügen — mit Bürotag und HO-Tag nebeneinander, druckfertig?

---

**Du:**

egal ob zuhause oder im Büro essen sollte immer zu selben zeiten sein

---

**Claude:**

Logisch — Konsistenz ist ohnehin besser für den circadianen Rhythmus. Hier die finale, vereinfachte Version:

---

## 🍽️ EINHEITLICHES ESSENS-TIMING — täglich gleich

| Zeit | Mahlzeit | Was |
|---|---|---|
| **08:05** | 🥤 Shake nach Training | Whey 36g + Kreatin 5g + Morgen-Supplements |
| **13:00** | 🥗 Mittagessen | Protein + Gemüse + moderate Carbs |
| **19:00** | 🍝 Abendessen | Kohlenhydrate + leichtes Protein · kein Alkohol |
| **21:00** | 🛑 Essensstopp | Danach nichts mehr — 3h vor Schlaf |

---

Das ergibt ein **natürliches 13:8 Fenster** (08:05–21:00) — Fasten über Nacht ca. 11 Stunden. Solide Basis, realistisch und nachhaltig.

---

## ✅ DEIN KOMPLETTER FINALER TAG — BEIDE TAGESTYPEN

### 📅 Bürotag (Mo & Mi)

| Zeit | Was |
|---|---|
| 06:00 | Aufstehen · 2 Gläser Wasser |
| 06:05 | 🐕 Hund + Sonnenlicht — 60 Min |
| 07:05 | 💊 Pre-Workout (Alpha-GPC + L-Tyrosin) |
| 07:10 | 🏋️ Training — 50 Min |
| 08:00 | 🚿 Duschen + fertig machen — 30 Min |
| 08:05 | 🥤 Proteinshake + Kreatin + Morgen-Supplements |
| 08:45 | ☕ Erster Kaffee · dann Abfahrt |
| 09:00 | 💼 Arbeit |
| 12:00 | 🧘 NSDR 10 Min |
| 13:00 | 🥗 Mittagessen + letzter Kaffee |
| 18:00 | 🚗 Heimfahrt |
| 18:30 | 🐕 Abendhund — 60 Min |
| 19:30 | 🍝 Abendessen |
| 20:00 | 💡 Lichter dimmen · Nachtmodus |
| 21:00 | 💊 Abend-Supplements · 📱 Handy raus |
| 22:00 | 😴 Schlafen |

---

### 🏠 Home Office Tag (Di · Do · Fr · Sa · So)

| Zeit | Was |
|---|---|
| 06:00 | Aufstehen · 2 Gläser Wasser |
| 06:05 | 🐕 Hund + Sonnenlicht — 60 Min |
| 07:05 | 💊 Pre-Workout (Alpha-GPC + L-Tyrosin) |
| 07:10 | 🏋️ Training — 50 Min |
| 08:00 | 🚿 Duschen + fertig machen — 30 Min |
| 08:05 | 🥤 Proteinshake + Kreatin + Morgen-Supplements |
| 08:45 | ☕ Erster Kaffee |
| 09:00 | 💼 Arbeit |
| 12:00 | 🧘 NSDR 10 Min |
| 12:10 | 🐕 Mittagshund — 60 Min |
| 13:00 | 🥗 Mittagessen + letzter Kaffee |
| 18:00 | 🐕 Abendhund — 60 Min |
| 19:00 | 🍝 Abendessen |
| 20:00 | 💡 Lichter dimmen · Nachtmodus |
| 21:00 | 💊 Abend-Supplements · 📱 Handy raus |
| 22:00 | 😴 Schlafen |

---

## 📋 FINALE APPLE ERINNERUNGEN — komplett & bereit zum Eintippen

### Täglich (alle 7 Tage):

| Uhrzeit | Erinnerung |
|---|---|
| 06:00 | 🌅 Aufstehen — kein Snooze · sofort 2 Gläser Wasser |
| 06:05 | 🐕 Hund raus — 60 Min · Sonnenlicht holen |
| 07:05 | 💊 Pre-Workout: Alpha-GPC 300mg + L-Tyrosin 500mg |
| 07:10 | 🏋️ Training starten |
| 08:00 | 🚿 Duschen + fertig machen |
| 08:05 | 🥤 Proteinshake 36g + Kreatin 5g + Omega-3 + D3+K2 + Multi |
| 08:45 | ☕ Erster Kaffee — frühestens jetzt |
| 12:00 | 🧘 NSDR 10 Min — jetzt Pause machen |
| 13:00 | 🥗 Mittagessen — Protein + Gemüse + Carbs |
| 13:05 | ☕ Letzter Kaffee — danach kein Koffein mehr |
| 19:00 | 🍝 Abendessen — Kohlenhydrate · kein Alkohol · kein Zucker |
| 20:00 | 💡 Lichter dimmen · Bildschirm Nachtmodus |
| 21:00 | 💊 Magnesium 200mg + Apigenin 50mg + L-Theanin 100mg |
| 21:00 | 📱 Handy raus aus dem Schlafzimmer |
| 22:00 | 😴 Schlafen gehen |

### Nur Bürotage — Mo & Mi zusätzlich:

| Uhrzeit | Erinnerung |
|---|---|
| 08:40 | 🚗 Abfahrt in 5 Min |
| 18:30 | 🐕 Abendhund — 60 Min |

### Nur Home Office — Di · Do · Fr · Sa · So zusätzlich:

| Uhrzeit | Erinnerung |
|---|---|
| 12:10 | 🐕 Mittagshund — 60 Min |
| 18:00 | 🐕 Abendhund — 60 Min |

### Wochentag-spezifisch (Training):

| Tag & Zeit | Erinnerung |
|---|---|
| Mo 07:10 | 🦵 Beine: Hack Squats · Leg Curls · Calf Raises · Leg Extensions |
| Di 07:10 | 🌡️ Heute: Sauna + Kältebad — kein Krafttraining |
| Mi 07:10 | 💪 Oberkörper: Bankdrücken · Schultern · Klimmzüge · Nacken |
| Do 07:10 | 🚴 Zone-2: Hund morgens zählt — optional extra 20 Min Rad |
| Fr 07:10 | ⚡ HIIT: 8–12 Runden Vollsprint · Assault Bike oder Laufen |
| Sa 07:10 | 💪 Arme + Schultern + Waden — leichter Tag |
| So 07:10 | 🏃 Langer Spaziergang mit Hund = Zone-2 Sonntag |

### Wöchentlich:

| Tag & Zeit | Erinnerung |
|---|---|
| So 18:00 | 🍳 Meal Prep: Hähnchen + Reis + Brokkoli für die Woche |
| So 19:00 | 📊 Wochentracking ausfüllen + Gewicht + Taillenmaß |
| Mo 08:05 | 🛒 Supplement-Vorrat prüfen — nachbestellen wenn < 2 Wochen |

### Monatlich (1. des Monats):

| Erinnerung |
|---|
| 💰 Kosten-Tracker ausfüllen |
| 📦 Supplements nachbestellen |
| 📸 Fortschrittsfoto — frontal · Seite · Rücken |

---

**Das war es.** Dein komplettes System steht — von 06:00 bis 22:00, 7 Tage die Woche, mit Hund, Arbeit, Training und Ernährung perfekt integriert.

**Nächster Schritt:** Soll ich den finalen Tagesplan als letztes Blatt in deine Excel-Datei einfügen — druckfertig für die Wand oder den Schreibtisch?

---

**Du:**

Training im Gym brauche ich 1,5h weil ich immer nach dem Gym in die sauna 10 min gehe und danach duschen und fertig machen

---

**Claude:**

Guter Punkt — dann rechnen wir das realistisch durch:

**Training 50 Min + Sauna 10 Min + Duschen/Umziehen 20 Min = 80 Min im Gym**

Das bedeutet du kommst um **07:10 + 1h20 = 08:30** aus dem Gym raus.

---

**Das Problem:** An Bürotagen (Mo & Mi) musst du um **08:45 abfahren** — das gibt dir nur **15 Minuten** für Shake + Frühstück. Zu knapp.

**Zwei Optionen:**
```
This block is not supported on your current device yet.
```

---

**Du:**

F: An Bürotagen (Mo & Mi) — was passt dir besser?
A: 05:30 aufstehen (gibt dir genügend Puffer für alles)

---

**Claude:**

Perfekt — 05:30 löst alles sauber. Hier ist die finale Durchrechnung:

---

## ✅ ZEITCHECK — 05:30 Aufstehen an Bürotagen

| Zeit | Was | Dauer |
|---|---|---|
| 05:30 | Aufstehen · Wasser | 5 Min |
| 05:35 | 🐕 Hund + Sonnenlicht | 60 Min |
| 06:35 | 💊 Pre-Workout: Alpha-GPC + L-Tyrosin | 5 Min |
| 06:40 | 🏋️ Training | 50 Min |
| 07:30 | 🌡️ Sauna 10 Min | 10 Min |
| 07:40 | 🚿 Duschen + fertig machen | 20 Min |
| 08:00 | 🥤 Shake + Kreatin + Supplements | 10 Min |
| 08:10 | ☕ Kaffee + kurz frühstücken | 15 Min |
| 08:25 | 🚗 Abfahrt | 30 Min |
| **09:00** | **💼 Arbeit — pünktlich** | ✅ |

**Puffer: 25 Minuten** — entspannt, kein Stress.

---

## ✅ ZEITCHECK — 06:00 Aufstehen an HO-Tagen

| Zeit | Was | Dauer |
|---|---|---|
| 06:00 | Aufstehen · Wasser | 5 Min |
| 06:05 | 🐕 Hund + Sonnenlicht | 60 Min |
| 07:05 | 💊 Pre-Workout | 5 Min |
| 07:10 | 🏋️ Training | 50 Min |
| 08:00 | 🌡️ Sauna 10 Min | 10 Min |
| 08:10 | 🚿 Duschen + fertig machen | 20 Min |
| 08:30 | 🥤 Shake + Kreatin + Supplements | 10 Min |
| 08:40 | ☕ Kaffee | 10 Min |
| **09:00** | **💼 Arbeit — pünktlich** | ✅ |

---

## 📋 FINALE APPLE ERINNERUNGEN — KOMPLETT

### Bürotage — Mo & Mi (05:30 aufstehen):

| Uhrzeit | Erinnerung |
|---|---|
| 05:30 | 🌅 Aufstehen — kein Snooze · 2 Gläser Wasser |
| 05:35 | 🐕 Hund raus — 60 Min · Sonnenlicht holen |
| 06:35 | 💊 Pre-Workout: Alpha-GPC 300mg + L-Tyrosin 500mg |
| 06:40 | 🏋️ Training starten — 50 Min |
| 07:30 | 🌡️ Sauna 10 Min |
| 07:40 | 🚿 Duschen + fertig machen |
| 08:00 | 🥤 Shake 36g + Kreatin 5g + Omega-3 + D3+K2 + Multi |
| 08:10 | ☕ Kaffee — frühestens jetzt |
| 08:25 | 🚗 Abfahrt jetzt — 30 Min Fahrt |
| 13:00 | 🥗 Mittagessen + letzter Kaffee |
| 18:00 | 🚗 Heimfahrt |
| 18:30 | 🐕 Abendhund — 60 Min |
| 19:30 | 🍝 Abendessen — Kohlenhydrate · kein Alkohol |
| 20:00 | 💡 Lichter dimmen · Nachtmodus |
| 21:00 | 💊 Magnesium + Apigenin + L-Theanin |
| 21:00 | 📱 Handy raus |
| 22:00 | 😴 Schlafen — Ziel 7,5h bis 05:30 |

---

### Home Office — Di · Do · Fr · Sa · So (06:00 aufstehen):

| Uhrzeit | Erinnerung |
|---|---|
| 06:00 | 🌅 Aufstehen — kein Snooze · 2 Gläser Wasser |
| 06:05 | 🐕 Hund raus — 60 Min · Sonnenlicht holen |
| 07:05 | 💊 Pre-Workout: Alpha-GPC 300mg + L-Tyrosin 500mg |
| 07:10 | 🏋️ Training starten — 50 Min |
| 08:00 | 🌡️ Sauna 10 Min |
| 08:10 | 🚿 Duschen + fertig machen |
| 08:30 | 🥤 Shake 36g + Kreatin 5g + Omega-3 + D3+K2 + Multi |
| 08:45 | ☕ Kaffee — frühestens jetzt |
| 09:00 | 💼 Arbeit beginnt |
| 12:00 | 🧘 NSDR 10 Min — Pause jetzt |
| 12:10 | 🐕 Mittagshund — 60 Min |
| 13:00 | 🥗 Mittagessen + letzter Kaffee |
| 18:00 | 🐕 Abendhund — 60 Min |
| 19:00 | 🍝 Abendessen — Kohlenhydrate · kein Alkohol |
| 20:00 | 💡 Lichter dimmen · Nachtmodus |
| 21:00 | 💊 Magnesium + Apigenin + L-Theanin |
| 21:00 | 📱 Handy raus |
| 22:00 | 😴 Schlafen — Ziel 8h bis 06:00 |

---

### Wochentag-spezifisch (Training):

| Tag & Zeit | Erinnerung |
|---|---|
| Mo 06:40 | 🦵 Beine: Hack Squats · Leg Curls · Calf Raises · Leg Extensions |
| Di 07:10 | 🌡️ Heute kein Krafttraining — nur Sauna + Kältebad (Erholungstag) |
| Mi 06:40 | 💪 Oberkörper: Bankdrücken · Schultern · Klimmzüge · Nacken |
| Do 07:10 | 🚴 Zone-2: Hund morgens zählt — optional 20 Min Rad extra |
| Fr 07:10 | ⚡ HIIT: 8–12 Runden Vollsprint — Assault Bike oder Laufen |
| Sa 07:10 | 💪 Arme + Schultern + Waden — leichter Tag |
| So 07:10 | 🏃 Langer Spaziergang mit Hund = Zone-2 Sonntag |

---

### Wöchentlich:

| Tag & Zeit | Erinnerung |
|---|---|
| So 18:00 | 🍳 Meal Prep: Hähnchen + Reis + Brokkoli für Bürotage |
| So 19:00 | 📊 Wochentracking + Gewicht + Taillenmaß |
| Mo 08:10 | 🛒 Supplement-Vorrat prüfen |

### Monatlich (1. des Monats):

| Erinnerung |
|---|
| 💰 Kosten-Tracker ausfüllen |
| 📦 Supplements nachbestellen |
| 📸 Fortschrittsfoto — frontal · Seite · Rücken |

---

## ⚡ DEIN SYSTEM AUF EINEN BLICK

| | Bürotag (Mo & Mi) | HO-Tag (Di · Do · Fr · Sa · So) |
|---|---|---|
| **Aufstehen** | 05:30 | 06:00 |
| **Hund morgens** | 05:35–06:35 | 06:05–07:05 |
| **Training** | 06:40–07:30 | 07:10–08:00 |
| **Sauna** | 07:30–07:40 | 08:00–08:10 |
| **Shake + Supplements** | 08:00 | 08:30 |
| **Arbeit** | 09:00 (Büro) | 09:00 (Home) |
| **Mittagessen** | 13:00 | 13:00 |
| **Abendhund** | 18:30 | 18:00 |
| **Abendessen** | 19:30 | 19:00 |
| **Schlafen** | 22:00 | 22:00 |
| **Schlaf** | 7,5h | 8h |

---

**Jetzt ist dein System komplett.** Willst du das als finales Blatt in die Excel-Datei — oder reicht dir die Liste zum Eintippen?

---

**Du:**

Ich muss spätestens 8.15 abfahren zur arbeit

---

**Claude:**

Dann wird es an Bürotagen zu knapp mit 05:30. Lass mich ehrlich durchrechnen:

**05:30 aufstehen + alles = 08:25 fertig → 08:15 Abfahrt = 10 Minuten zu wenig.**

Lösung: **05:15 aufstehen** an Bürotagen — dann passt alles exakt:

---

## ✅ ZEITCHECK BÜROTAGE — 05:15 Aufstehen

| Zeit | Was | Dauer |
|---|---|---|
| 05:15 | Aufstehen · 2 Gläser Wasser | 5 Min |
| 05:20 | 🐕 Hund + Sonnenlicht | 60 Min |
| 06:20 | 💊 Pre-Workout: Alpha-GPC + L-Tyrosin | 5 Min |
| 06:25 | 🏋️ Training | 50 Min |
| 07:15 | 🌡️ Sauna 10 Min | 10 Min |
| 07:25 | 🚿 Duschen + fertig machen | 20 Min |
| 07:45 | 🥤 Shake + Kreatin + Supplements | 10 Min |
| 07:55 | ☕ Kaffee to go | 10 Min |
| **08:10** | 🚗 **Abfahrt — 5 Min Puffer** | ✅ |
| **08:45** | 💼 **Arbeit — pünktlich** | ✅ |

---

## 📋 FINALE APPLE ERINNERUNGEN — KORRIGIERT

### Bürotage — Mo & Mi (05:15 aufstehen):

| Uhrzeit | Erinnerung |
|---|---|
| 05:15 | 🌅 Aufstehen — kein Snooze · 2 Gläser Wasser |
| 05:20 | 🐕 Hund raus — 60 Min · Sonnenlicht holen |
| 06:20 | 💊 Pre-Workout: Alpha-GPC 300mg + L-Tyrosin 500mg |
| 06:25 | 🏋️ Training starten — 50 Min |
| 07:15 | 🌡️ Sauna 10 Min |
| 07:25 | 🚿 Duschen + fertig machen — 20 Min |
| 07:45 | 🥤 Shake 36g + Kreatin 5g + Omega-3 + D3+K2 + Multi |
| 07:55 | ☕ Kaffee to go vorbereiten |
| 08:10 | 🚗 Abfahrt jetzt — spätestens 08:15 |
| 13:00 | 🥗 Mittagessen + letzter Kaffee |
| 18:00 | 🚗 Heimfahrt |
| 18:30 | 🐕 Abendhund — 60 Min |
| 19:30 | 🍝 Abendessen — Kohlenhydrate · kein Alkohol |
| 20:00 | 💡 Lichter dimmen · Nachtmodus |
| 21:00 | 💊 Magnesium + Apigenin + L-Theanin · 📱 Handy raus |
| 21:45 | 😴 Schlafen — 7,5h bis 05:15 |

---

### Home Office — Di · Do · Fr · Sa · So (06:00 aufstehen):

| Uhrzeit | Erinnerung |
|---|---|
| 06:00 | 🌅 Aufstehen — kein Snooze · 2 Gläser Wasser |
| 06:05 | 🐕 Hund raus — 60 Min · Sonnenlicht holen |
| 07:05 | 💊 Pre-Workout: Alpha-GPC 300mg + L-Tyrosin 500mg |
| 07:10 | 🏋️ Training starten — 50 Min |
| 08:00 | 🌡️ Sauna 10 Min |
| 08:10 | 🚿 Duschen + fertig machen |
| 08:30 | 🥤 Shake 36g + Kreatin 5g + Omega-3 + D3+K2 + Multi |
| 08:45 | ☕ Kaffee |
| 09:00 | 💼 Arbeit beginnt |
| 12:00 | 🧘 NSDR 10 Min |
| 12:10 | 🐕 Mittagshund — 60 Min |
| 13:00 | 🥗 Mittagessen + letzter Kaffee |
| 18:00 | 🐕 Abendhund — 60 Min |
| 19:00 | 🍝 Abendessen — Kohlenhydrate · kein Alkohol |
| 20:00 | 💡 Lichter dimmen · Nachtmodus |
| 21:00 | 💊 Magnesium + Apigenin + L-Theanin · 📱 Handy raus |
| 22:00 | 😴 Schlafen — 8h bis 06:00 |

---

## ⚡ FINALER ÜBERBLICK

| | Bürotag (Mo & Mi) | HO-Tag (Di · Do · Fr · Sa · So) |
|---|---|---|
| **Aufstehen** | 05:15 | 06:00 |
| **Hund morgens** | 05:20–06:20 | 06:05–07:05 |
| **Training** | 06:25–07:15 | 07:10–08:00 |
| **Sauna** | 07:15–07:25 | 08:00–08:10 |
| **Shake + Supps** | 07:45 | 08:30 |
| **Abfahrt / Arbeit** | 08:10 🚗 | 09:00 💻 |
| **Mittagessen** | 13:00 | 13:00 |
| **Abendhund** | 18:30 | 18:00 |
| **Abendessen** | 19:30 | 19:00 |
| **Schlafen** | 21:45 | 22:00 |
| **Schlaf** | 7,5h | 8h |

---

> ⚠️ **Wichtiger Hinweis:** 21:45 Uhr schlafen an Bürotagen bedeutet du musst die Abend-Routine konsequent einhalten — um 20:00 Licht dimmen, um 21:00 Supplements, kein Scrollen. Sonst wird der Schlaf zu kurz.

**Nächster Schritt:** Soll ich das als finales Blatt in die Excel-Datei einfügen — komplett druckfertig?

---

**Du:**

egal ob büro oder zuhause routine sollte gleich bleiben

---

**Claude:**

Richtig — Konsistenz ist das Wichtigste. Also einheitlich **05:15 jeden Tag.**

Lass mich kurz prüfen ob das an HO-Tagen auch Sinn macht:

**05:15 aufstehen → alles fertig → 08:10 → Arbeit erst 09:00 = 50 Minuten Puffer.**

Den Puffer kannst du sinnvoll nutzen:
```
This block is not supported on your current device yet.
```

---

**Du:**

F: Was machst du an HO-Tagen mit den 50 Min Puffer vor der Arbeit?
A: kein NSDR

---

**Claude:**

Perfekt — dann ruhiges Frühstück + Kaffee + Tagesplanung. Genau richtig.

Hier ist jetzt der **einheitliche Tagesplan für jeden Tag** — Büro und HO identisch:

---

## ✅ DEIN FINALER EINHEITLICHER TAGESPLAN
### Jeden Tag gleich — 7 Tage die Woche

| Zeit | Was | Dauer |
|---|---|---|
| **05:15** | 🌅 Aufstehen — kein Snooze · 2 Gläser Wasser | 5 Min |
| **05:20** | 🐕 Hund + Sonnenlicht | 60 Min |
| **06:20** | 💊 Pre-Workout: Alpha-GPC + L-Tyrosin (Krafttage) | 5 Min |
| **06:25** | 🏋️ Training — 50 Min | 50 Min |
| **07:15** | 🌡️ Sauna 10 Min | 10 Min |
| **07:25** | 🚿 Duschen + fertig machen | 20 Min |
| **07:45** | 🥤 Shake 36g + Kreatin 5g + Morgen-Supplements | 10 Min |
| **07:55** | ☕ Kaffee + ruhiges Frühstück + Tagesplanung | 60 Min |
| **09:00** | 💼 Arbeit — Büro oder HO | — |
| **12:00** | 🧘 NSDR 10 Min | 10 Min |
| **12:10** | 🐕 Mittagshund (HO) · Mittagspause (Büro) | 50 Min |
| **13:00** | 🥗 Mittagessen + letzter Kaffee | 20 Min |
| **18:00** | 🏠 Feierabend |— |
| **18:00** | 🐕 Abendhund (HO) | 60 Min |
| **18:30** | 🐕 Abendhund (Büro — nach Heimfahrt) | 60 Min |
| **19:00** | 🍝 Abendessen — Kohlenhydrate · kein Alkohol (HO) | 20 Min |
| **19:30** | 🍝 Abendessen — Kohlenhydrate · kein Alkohol (Büro) | 20 Min |
| **20:00** | 💡 Lichter dimmen · Bildschirm Nachtmodus | — |
| **21:00** | 💊 Magnesium + Apigenin + L-Theanin · 📱 Handy raus | 5 Min |
| **21:45** | 😴 Schlafen — 7,5h Ziel | — |

---

## 📋 APPLE ERINNERUNGEN — FINAL & EINHEITLICH
### Täglich alle 7 Tage — einmal einstellen, fertig

| Uhrzeit | Erinnerung |
|---|---|
| 05:15 | 🌅 Aufstehen — kein Snooze · sofort 2 Gläser Wasser |
| 05:20 | 🐕 Hund raus — 60 Min · Sonnenlicht holen |
| 06:20 | 💊 Pre-Workout: Alpha-GPC 300mg + L-Tyrosin 500mg |
| 06:25 | 🏋️ Training starten — 50 Min |
| 07:15 | 🌡️ Sauna 10 Min · dann Duschen |
| 07:45 | 🥤 Shake 36g + Kreatin 5g + Omega-3 + D3+K2 + Multi |
| 07:55 | ☕ Kaffee + Frühstück + 3 Prioritäten für heute notieren |
| 09:00 | 💼 Arbeit beginnt |
| 12:00 | 🧘 NSDR 10 Min — Pause jetzt |
| 12:10 | 🐕 Mittagshund — 50 Min |
| 13:00 | 🥗 Mittagessen + letzter Kaffee des Tages |
| 18:00 | 🐕 Abendhund — 60 Min |
| 19:00 | 🍝 Abendessen — Kohlenhydrate · kein Alkohol · kein Zucker |
| 20:00 | 💡 Lichter dimmen · Bildschirm auf Nachtmodus |
| 21:00 | 💊 Magnesium 200mg + Apigenin 50mg + L-Theanin 100mg |
| 21:05 | 📱 Handy raus aus dem Schlafzimmer |
| 21:45 | 😴 Schlafen — 7,5 Stunden bis 05:15 |

---

### Wochentag-spezifisch (Training):

| Tag & Zeit | Erinnerung |
|---|---|
| Mo 06:25 | 🦵 Beine: Hack Squats · Leg Curls · Calf Raises · Leg Extensions |
| Di 06:25 | 🌡️ Kein Training — nur Sauna + Kältebad heute |
| Mi 06:25 | 💪 Oberkörper: Bankdrücken · Schultern · Klimmzüge · Nacken |
| Do 06:25 | 🚴 Zone-2: Hund morgens zählt — optional 20 Min Rad |
| Fr 06:25 | ⚡ HIIT: 8–12 Runden Vollsprint — Assault Bike |
| Sa 06:25 | 💪 Arme + Schultern + Waden — leichter Tag |
| So 06:25 | 🏃 Langer Spaziergang mit Hund = Zone-2 |

### Bürotage zusätzlich — Mo & Mi:

| Uhrzeit | Erinnerung |
|---|---|
| 08:10 | 🚗 Abfahrt jetzt — spätestens 08:15 |
| 18:30 | 🐕 Abendhund — nach Heimfahrt · 60 Min |
| 19:30 | 🍝 Abendessen (30 Min später als HO) |

### Wöchentlich:

| Tag & Zeit | Erinnerung |
|---|---|
| So 18:00 | 🍳 Meal Prep: Hähnchen + Reis + Brokkoli für Bürotage |
| So 19:00 | 📊 Wochentracking + Gewicht + Taillenmaß messen |
| Mo 07:55 | 🛒 Supplement-Vorrat prüfen — nachbestellen wenn < 2 Wochen |

### Monatlich (1. des Monats):

| Uhrzeit | Erinnerung |
|---|---|
| 08:00 | 💰 Kosten-Tracker ausfüllen |
| 08:01 | 📦 Supplements nachbestellen |
| 08:02 | 📸 Fortschrittsfoto — frontal · Seite · Rücken |

---

## ⚡ DEIN SYSTEM IN 3 ZAHLEN

| | Wert |
|---|---|
| **Aufstehzeit** | 05:15 — jeden Tag |
| **Schlafenszeit** | 21:45 — jeden Tag |
| **Schlaf** | 7,5 Stunden — jeden Tag |

---

> **Das ist jetzt dein komplettes, finales System.** Einmal in Apple Erinnerungen eintragen — dann läuft es automatisch. Die einzige Variable ist Büro vs. HO beim Abendhund und Abendessen — alles andere ist identisch.

**Nächster Schritt:** Soll ich das als finales Blatt in die Excel-Datei einfügen?

---

**Du:**

zum studio brauche ich 10-15 min mit dem auto  

Bitte  jeden Tag gleich keine Duplikate

---

**Claude:**

Gut — dann nochmal sauber durchrechnen mit 15 Min Fahrt zum Studio:

**06:25 Training + 50 Min + 10 Min Sauna + 20 Min Duschen = fertig 07:45 im Studio**
**+ 15 Min Fahrt = 08:00 zuhause**

Passt perfekt. Aber der Mittagshund an Bürotagen funktioniert nicht — du bist im Büro. Den streichen wir dort raus.

---

## ✅ EINHEITLICHER TAGESPLAN — FINAL, KEINE DUPLIKATE

| Zeit | Was |
|---|---|
| **05:15** | 🌅 Aufstehen · 2 Gläser Wasser |
| **05:20** | 🐕 Hund morgens — 60 Min · Sonnenlicht |
| **06:20** | 🚗 Fahrt zum Studio — 15 Min |
| **06:35** | 💊 Pre-Workout: Alpha-GPC + L-Tyrosin (nur Mo · Mi · Fr · Sa) |
| **06:40** | 🏋️ Training — 50 Min |
| **07:30** | 🌡️ Sauna — 10 Min |
| **07:40** | 🚿 Duschen + fertig machen — 20 Min |
| **08:00** | 🚗 Heimfahrt — 15 Min |
| **08:15** | 🥤 Shake 36g + Kreatin 5g + Supplements |
| **08:30** | ☕ Kaffee + Frühstück + 3 Prioritäten notieren |
| **09:00** | 💼 Arbeit (Büro oder HO) |
| **12:00** | 🧘 NSDR 10 Min |
| **12:10** | 🐕 Mittagshund — 50 Min (nur HO) |
| **13:00** | 🥗 Mittagessen + letzter Kaffee |
| **18:00** | 🏠 Feierabend |
| **18:00** | 🐕 Abendhund — 60 Min (HO · direkt) |
| **18:30** | 🐕 Abendhund — 60 Min (Büro · nach Heimfahrt) |
| **19:00** | 🍝 Abendessen (HO) |
| **19:30** | 🍝 Abendessen (Büro) |
| **20:00** | 💡 Lichter dimmen · Nachtmodus |
| **21:00** | 💊 Magnesium 200mg + Apigenin 50mg + L-Theanin 100mg |
| **21:05** | 📱 Handy raus aus Schlafzimmer |
| **21:45** | 😴 Schlafen — 7,5h |

---

## 📋 APPLE ERINNERUNGEN — FINAL
### Keine Duplikate · sauber getrennt

**Täglich (alle 7 Tage):**

| Uhrzeit | Erinnerung |
|---|---|
| 05:15 | 🌅 Aufstehen — kein Snooze · 2 Gläser Wasser |
| 05:20 | 🐕 Hund morgens — 60 Min · Sonnenlicht holen |
| 06:20 | 🚗 Abfahrt Studio |
| 06:35 | 💊 Pre-Workout: Alpha-GPC 300mg + L-Tyrosin 500mg |
| 06:40 | 🏋️ Training — 50 Min |
| 07:30 | 🌡️ Sauna 10 Min |
| 07:40 | 🚿 Duschen + fertig machen |
| 08:00 | 🚗 Heimfahrt |
| 08:15 | 🥤 Shake 36g + Kreatin 5g + Omega-3 + D3+K2 + Multi |
| 08:30 | ☕ Kaffee + Frühstück + 3 Prioritäten notieren |
| 09:00 | 💼 Arbeit beginnt |
| 12:00 | 🧘 NSDR 10 Min — Pause jetzt |
| 13:00 | 🥗 Mittagessen + letzter Kaffee |
| 20:00 | 💡 Lichter dimmen · Nachtmodus |
| 21:00 | 💊 Magnesium + Apigenin + L-Theanin |
| 21:05 | 📱 Handy raus aus Schlafzimmer |
| 21:45 | 😴 Schlafen — 7,5h |

**Nur HO-Tage (Di · Do · Fr · Sa · So):**

| Uhrzeit | Erinnerung |
|---|---|
| 12:10 | 🐕 Mittagshund — 50 Min |
| 18:00 | 🐕 Abendhund — 60 Min |
| 19:00 | 🍝 Abendessen — Kohlenhydrate · kein Alkohol |

**Nur Bürotage (Mo & Mi):**

| Uhrzeit | Erinnerung |
|---|---|
| 08:45 | 🚗 Abfahrt Büro — spätestens 08:45 |
| 18:30 | 🐕 Abendhund — 60 Min |
| 19:30 | 🍝 Abendessen — Kohlenhydrate · kein Alkohol |

**Wochentag-spezifisch:**

| Tag & Zeit | Erinnerung |
|---|---|
| Mo 06:35 | 🦵 Beine: Hack Squats · Leg Curls · Calf Raises |
| Di 06:35 | 🌡️ Heute: Nur Sauna + Kältebad — kein Krafttraining |
| Mi 06:35 | 💪 Oberkörper: Bankdrücken · Schultern · Klimmzüge · Nacken |
| Do 06:35 | 🚴 Zone-2: Hund morgens zählt — optional 20 Min Rad |
| Fr 06:35 | ⚡ HIIT: 8–12 Runden Vollsprint |
| Sa 06:35 | 💪 Arme + Schultern + Waden — leichter Tag |
| So 06:35 | 🏃 Langer Spaziergang mit Hund = Zone-2 |

**Wöchentlich:**

| Tag & Zeit | Erinnerung |
|---|---|
| So 18:00 | 🍳 Meal Prep: Hähnchen + Reis + Brokkoli |
| So 19:00 | 📊 Tracking + Gewicht + Taillenmaß |
| Mo 08:30 | 🛒 Supplement-Vorrat prüfen |

**Monatlich (1. des Monats):**

| Uhrzeit | Erinnerung |
|---|---|
| 08:00 | 💰 Kosten-Tracker ausfüllen |
| 08:01 | 📦 Supplements nachbestellen |
| 08:02 | 📸 Fortschrittsfoto — frontal · Seite · Rücken |

---

> **Das ist dein finales System.** 05:15 jeden Tag — Büro und HO identisch bis auf Mittagshund und Abendessen-Timing. Insgesamt **34 Erinnerungen** — einmal einstellen, läuft automatisch.

**Nächster Schritt:** Als finales Excel-Blatt einfügen?

---

**Du:**

Protein nach dem Sport direkt mit Supps
Heimfahrt oder ins Büro sollte es heißen
kaffee im Büro NSDR mache ich morgens oder abends
Pause auf arbeit immer 12 Uhr

---

**Claude:**

Alles klar — hier die korrigierten Punkte:

- ✅ Shake + Supps direkt im Studio nach dem Training
- ✅ "Heimfahrt oder Büro" je nach Tag
- ✅ Kaffee erst im Büro / zuhause
- ✅ NSDR morgens (08:30) oder abends (21:00) — nicht mittags
- ✅ Pause 12:00 = Mittagessen · kein NSDR dort

---

## 📋 APPLE ERINNERUNGEN — FINAL & KORREKT

**Täglich (alle 7 Tage):**

| Uhrzeit | Erinnerung |
|---|---|
| 05:15 | 🌅 Aufstehen — kein Snooze · 2 Gläser Wasser |
| 05:20 | 🐕 Hund morgens — 60 Min · Sonnenlicht holen |
| 06:20 | 🚗 Abfahrt Studio |
| 06:35 | 💊 Pre-Workout: Alpha-GPC 300mg + L-Tyrosin 500mg |
| 06:40 | 🏋️ Training — 50 Min |
| 07:30 | 🌡️ Sauna — 10 Min |
| 07:40 | 🚿 Duschen + fertig machen |
| 07:55 | 🥤 Shake 36g + Kreatin 5g + Omega-3 + D3+K2 + Multi — direkt im Studio |
| 08:00 | 🚗 Heimfahrt oder Abfahrt Büro |
| 08:30 | ☕ Kaffee + Frühstück + 3 Prioritäten notieren |
| 08:30 | 🧘 NSDR 20 Min — morgens wenn möglich |
| 12:00 | 🥗 Mittagspause — Mittagessen |
| 13:00 | ☕ Letzter Kaffee — danach kein Koffein |
| 20:00 | 💡 Lichter dimmen · Nachtmodus |
| 21:00 | 💊 Magnesium 200mg + Apigenin 50mg + L-Theanin 100mg |
| 21:00 | 🧘 NSDR 20 Min — falls morgens nicht geklappt hat |
| 21:20 | 📱 Handy raus aus Schlafzimmer |
| 21:45 | 😴 Schlafen — 7,5h |

---

**Nur HO-Tage (Di · Do · Fr · Sa · So):**

| Uhrzeit | Erinnerung |
|---|---|
| 12:10 | 🐕 Mittagshund — 50 Min |
| 18:00 | 🐕 Abendhund — 60 Min |
| 19:00 | 🍝 Abendessen — Kohlenhydrate · kein Alkohol |

**Nur Bürotage (Mo & Mi):**

| Uhrzeit | Erinnerung |
|---|---|
| 18:30 | 🐕 Abendhund — 60 Min |
| 19:30 | 🍝 Abendessen — Kohlenhydrate · kein Alkohol |

---

**Wochentag-spezifisch:**

| Tag & Zeit | Erinnerung |
|---|---|
| Mo 06:35 | 🦵 Beine: Hack Squats · Leg Curls · Calf Raises |
| Di 06:35 | 🌡️ Heute: Nur Sauna + Kältebad — kein Krafttraining |
| Mi 06:35 | 💪 Oberkörper: Bankdrücken · Schultern · Klimmzüge · Nacken |
| Do 06:35 | 🚴 Zone-2: Hund morgens zählt — optional 20 Min Rad |
| Fr 06:35 | ⚡ HIIT: 8–12 Runden Vollsprint |
| Sa 06:35 | 💪 Arme + Schultern + Waden — leichter Tag |
| So 06:35 | 🏃 Langer Spaziergang mit Hund = Zone-2 |

---

**Wöchentlich:**

| Tag & Zeit | Erinnerung |
|---|---|
| So 18:00 | 🍳 Meal Prep: Hähnchen + Reis + Brokkoli |
| So 19:00 | 📊 Tracking + Gewicht + Taillenmaß |
| Mo 08:30 | 🛒 Supplement-Vorrat prüfen |

**Monatlich (1. des Monats):**

| Uhrzeit | Erinnerung |
|---|---|
| 08:00 | 💰 Kosten-Tracker ausfüllen |
| 08:01 | 📦 Supplements nachbestellen |
| 08:02 | 📸 Fortschrittsfoto — frontal · Seite · Rücken |

---

> **Jetzt ist es wirklich final.** Insgesamt 32 Erinnerungen — keine Duplikate, realistisch auf deinen Alltag abgestimmt.

**Nächster Schritt:** Als Excel-Blatt einfügen oder so gut?

---

**Du:**

Aufstehen um 5

Pre workout im Training oder vor den Spazieren wenn es sinn macht

NSDR nur Abends

Hund spaziergang mittags und Abends

Letzer kaffe spätestens 14 Uhr

Magnesium etc. vor dem schlagen

---

**Claude:**

Perfekt — alles klar. Nochmal sauber durchrechnen mit allen Korrekturen:

**Pre-Workout:** 30–60 Min vor Training → macht Sinn **im Auto** auf dem Weg zum Studio (06:05) — dann wirkt es genau wenn du ankommst.

---

## ✅ FINALER TAGESPLAN — JEDEN TAG GLEICH

| Zeit | Was |
|---|---|
| **05:00** | 🌅 Aufstehen — kein Snooze · 2 Gläser Wasser |
| **05:05** | 🐕 Hund morgens — 60 Min · Sonnenlicht holen |
| **06:05** | 🚗 Fahrt Studio — 15 Min · Pre-Workout einnehmen im Auto |
| **06:20** | 🏋️ Training — 50 Min |
| **07:10** | 🌡️ Sauna — 10 Min |
| **07:20** | 🚿 Duschen + fertig machen — 20 Min |
| **07:40** | 🚗 Heimfahrt — 15 Min |
| **07:55** | 🥤 Shake 36g + Kreatin 5g + Omega-3 + D3+K2 + Multi |
| **08:10** | ☕ Kaffee + Frühstück + 3 Prioritäten notieren |
| **09:00** | 💼 Arbeit beginnt |
| **12:00** | 🐕 Mittagshund — 60 Min |
| **13:00** | 🥗 Mittagessen |
| **14:00** | ☕ Letzter Kaffee — danach kein Koffein mehr |
| **18:00** | 🏠 Feierabend |
| **18:00** | 🐕 Abendhund — 60 Min (HO) |
| **18:30** | 🐕 Abendhund — 60 Min (Büro · nach Heimfahrt) |
| **19:00** | 🍝 Abendessen — Kohlenhydrate · kein Alkohol (HO) |
| **19:30** | 🍝 Abendessen — Kohlenhydrate · kein Alkohol (Büro) |
| **20:00** | 💡 Lichter dimmen · Nachtmodus |
| **21:00** | 🧘 NSDR 20 Min — geführte Session |
| **21:30** | 💊 Magnesium 200mg + Apigenin 50mg + L-Theanin 100mg |
| **21:35** | 📱 Handy raus aus Schlafzimmer |
| **22:00** | 😴 Schlafen — 7h bis 05:00 |

---

## 📋 APPLE ERINNERUNGEN — FINAL & BEREINIGT

**Täglich (alle 7 Tage):**

| Uhrzeit | Erinnerung |
|---|---|
| 05:00 | 🌅 Aufstehen — kein Snooze · 2 Gläser Wasser |
| 05:05 | 🐕 Hund morgens — 60 Min · Sonnenlicht holen |
| 06:05 | 🚗 Abfahrt Studio · Pre-Workout im Auto: Alpha-GPC 300mg + L-Tyrosin 500mg |
| 06:20 | 🏋️ Training starten — 50 Min |
| 07:10 | 🌡️ Sauna 10 Min |
| 07:20 | 🚿 Duschen + fertig machen |
| 07:40 | 🚗 Heimfahrt |
| 07:55 | 🥤 Shake 36g + Kreatin 5g + Omega-3 + D3+K2 + Multi |
| 08:10 | ☕ Kaffee + Frühstück + 3 Prioritäten notieren |
| 09:00 | 💼 Arbeit beginnt |
| 12:00 | 🐕 Mittagshund — 60 Min |
| 13:00 | 🥗 Mittagessen |
| 14:00 | ☕ Letzter Kaffee — danach kein Koffein mehr |
| 20:00 | 💡 Lichter dimmen · Bildschirm Nachtmodus |
| 21:00 | 🧘 NSDR 20 Min — YouTube: Huberman NSDR |
| 21:30 | 💊 Magnesium 200mg + Apigenin 50mg + L-Theanin 100mg |
| 21:35 | 📱 Handy raus aus Schlafzimmer |
| 22:00 | 😴 Schlafen — 7h |

**Nur HO-Tage (Di · Do · Fr · Sa · So):**

| Uhrzeit | Erinnerung |
|---|---|
| 18:00 | 🐕 Abendhund — 60 Min |
| 19:00 | 🍝 Abendessen — Kohlenhydrate · kein Alkohol · kein Zucker |

**Nur Bürotage (Mo & Mi):**

| Uhrzeit | Erinnerung |
|---|---|
| 08:45 | 🚗 Abfahrt Büro — spätestens 08:45 |
| 18:30 | 🐕 Abendhund — 60 Min |
| 19:30 | 🍝 Abendessen — Kohlenhydrate · kein Alkohol · kein Zucker |

**Wochentag-spezifisch:**

| Tag & Zeit | Erinnerung |
|---|---|
| Mo 06:20 | 🦵 Beine: Hack Squats · Leg Curls · Calf Raises · Leg Extensions |
| Di 06:20 | 🌡️ Heute: Nur Sauna + Kältebad — kein Krafttraining |
| Mi 06:20 | 💪 Oberkörper: Bankdrücken · Schultern · Klimmzüge · Nacken |
| Do 06:20 | 🚴 Zone-2: Hund morgens zählt — optional 20 Min Rad |
| Fr 06:20 | ⚡ HIIT: 8–12 Runden Vollsprint |
| Sa 06:20 | 💪 Arme + Schultern + Waden — leichter Tag |
| So 06:20 | 🏃 Langer Spaziergang mit Hund = Zone-2 |

**Wöchentlich:**

| Tag & Zeit | Erinnerung |
|---|---|
| So 18:00 | 🍳 Meal Prep: Hähnchen + Reis + Brokkoli |
| So 19:00 | 📊 Tracking + Gewicht + Taillenmaß |
| Mo 08:10 | 🛒 Supplement-Vorrat prüfen |

**Monatlich (1. des Monats):**

| Uhrzeit | Erinnerung |
|---|---|
| 08:00 | 💰 Kosten-Tracker ausfüllen |
| 08:01 | 📦 Supplements nachbestellen |
| 08:02 | 📸 Fortschrittsfoto — frontal · Seite · Rücken |

---

## ⚡ DEIN SYSTEM IN ZAHLEN

| | |
|---|---|
| **Aufstehen** | 05:00 täglich |
| **Schlafen** | 22:00 täglich |
| **Schlaf** | 7 Stunden |
| **Hund** | 3× täglich · 05:05 · 12:00 · 18:00–18:30 |
| **Training** | 06:20 täglich im Studio |
| **Essen** | 07:55 · 13:00 · 19:00–19:30 |
| **Koffein-Stopp** | 14:00 täglich |
| **NSDR** | 21:00 täglich |
| **Supplements abends** | 21:30 täglich |

---

**Nächster Schritt:** Als finales Blatt in die Excel-Datei einfügen?

---

**Du:**

Ich möchte in Erinnerung Hund Abends auch sehen

---

**Claude:**

Kurze Frage — meinst du:

**A)** Die Abendhund-Erinnerung fehlt in der täglichen Liste (weil sie nur bei HO und Büro getrennt steht)

oder

**B)** Du möchtest den Hund Abends als eigene tägliche Erinnerung — unabhängig ob Büro oder HO?

Da du sagst die Routine soll jeden Tag gleich sein — nehme ich **B** und mache es einfach täglich um **18:30** als fixe Erinnerung. Bürotage passt es nach der Heimfahrt, HO-Tage auch.

---

**Korrigierte tägliche Liste — komplett, keine Duplikate:**

| Uhrzeit | Erinnerung |
|---|---|
| 05:00 | 🌅 Aufstehen — kein Snooze · 2 Gläser Wasser |
| 05:05 | 🐕 Hund morgens — 60 Min · Sonnenlicht holen |
| 06:05 | 🚗 Abfahrt Studio · Pre-Workout im Auto: Alpha-GPC 300mg + L-Tyrosin 500mg |
| 06:20 | 🏋️ Training starten — 50 Min |
| 07:10 | 🌡️ Sauna 10 Min |
| 07:20 | 🚿 Duschen + fertig machen |
| 07:40 | 🚗 Heimfahrt |
| 07:55 | 🥤 Shake 36g + Kreatin 5g + Omega-3 + D3+K2 + Multi |
| 08:10 | ☕ Kaffee + Frühstück + 3 Prioritäten notieren |
| 09:00 | 💼 Arbeit beginnt |
| 12:00 | 🐕 Hund mittags — 60 Min |
| 13:00 | 🥗 Mittagessen |
| 14:00 | ☕ Letzter Kaffee — danach kein Koffein mehr |
| 18:30 | 🐕 Hund abends — 60 Min |
| 19:30 | 🍝 Abendessen — Kohlenhydrate · kein Alkohol · kein Zucker |
| 20:00 | 💡 Lichter dimmen · Bildschirm Nachtmodus |
| 21:00 | 🧘 NSDR 20 Min — YouTube: Huberman NSDR |
| 21:30 | 💊 Magnesium 200mg + Apigenin 50mg + L-Theanin 100mg |
| 21:35 | 📱 Handy raus aus Schlafzimmer |
| 22:00 | 😴 Schlafen — 7h |

---

Jetzt ist alles täglich gleich — kein HO vs. Büro mehr. 18:30 passt für beide Situationen.

**Nächster Schritt:** Als Excel-Blatt einfügen oder ist die Liste so final?

---

**Du:**

schlaf sollten 8-9h sein 

A nicht trennen

B ja

---

**Claude:**

Mit 8–9h Schlaf und Aufstehen 05:00 musst du um **20:00–21:00 schlafen gehen** — das bedeutet NSDR und Supplements müssen früher rein.

Lass mich neu durchrechnen:

**Schlafen 20:30 → Aufstehen 05:00 = 8,5h** ✅

---

## ✅ FINALER TAGESPLAN — TÄGLICH GLEICH

| Zeit | Was |
|---|---|
| **05:00** | 🌅 Aufstehen — kein Snooze · 2 Gläser Wasser |
| **05:05** | 🐕 Hund morgens — 60 Min · Sonnenlicht holen |
| **06:05** | 🚗 Abfahrt Studio · Pre-Workout im Auto: Alpha-GPC + L-Tyrosin |
| **06:20** | 🏋️ Training — 50 Min |
| **07:10** | 🌡️ Sauna 10 Min |
| **07:20** | 🚿 Duschen + fertig machen |
| **07:40** | 🚗 Heimfahrt |
| **07:55** | 🥤 Shake 36g + Kreatin 5g + Omega-3 + D3+K2 + Multi |
| **08:10** | ☕ Kaffee + Frühstück + 3 Prioritäten notieren |
| **09:00** | 💼 Arbeit beginnt |
| **12:00** | 🐕 Hund mittags — 60 Min |
| **13:00** | 🥗 Mittagessen |
| **14:00** | ☕ Letzter Kaffee — danach kein Koffein mehr |
| **18:30** | 🐕 Hund abends — 60 Min |
| **19:30** | 🍝 Abendessen — Kohlenhydrate · kein Alkohol · kein Zucker |
| **19:30** | 💡 Lichter dimmen · Bildschirm Nachtmodus |
| **20:00** | 🧘 NSDR 20 Min — YouTube: Huberman NSDR |
| **20:30** | 💊 Magnesium 200mg + Apigenin 50mg + L-Theanin 100mg |
| **20:35** | 📱 Handy raus aus Schlafzimmer |
| **20:30** | 😴 Schlafen — 8,5h |

---

## 📋 APPLE ERINNERUNGEN — FINAL, TÄGLICH, KEINE DUPLIKATE

**Täglich (alle 7 Tage):**

| Uhrzeit | Erinnerung |
|---|---|
| 05:00 | 🌅 Aufstehen — kein Snooze · 2 Gläser Wasser |
| 05:05 | 🐕 Hund morgens — 60 Min · Sonnenlicht holen |
| 06:05 | 🚗 Abfahrt Studio · Pre-Workout im Auto: Alpha-GPC 300mg + L-Tyrosin 500mg |
| 06:20 | 🏋️ Training starten — 50 Min |
| 07:10 | 🌡️ Sauna 10 Min |
| 07:20 | 🚿 Duschen + fertig machen |
| 07:40 | 🚗 Heimfahrt |
| 07:55 | 🥤 Shake 36g + Kreatin 5g + Omega-3 + D3+K2 + Multi |
| 08:10 | ☕ Kaffee + Frühstück + 3 Prioritäten notieren |
| 09:00 | 💼 Arbeit beginnt |
| 12:00 | 🐕 Hund mittags — 60 Min |
| 13:00 | 🥗 Mittagessen |
| 14:00 | ☕ Letzter Kaffee — danach kein Koffein mehr |
| 18:30 | 🐕 Hund abends — 60 Min |
| 19:30 | 🍝 Abendessen — Kohlenhydrate · kein Alkohol · kein Zucker |
| 19:30 | 💡 Lichter dimmen · Bildschirm Nachtmodus |
| 20:00 | 🧘 NSDR 20 Min — YouTube: Huberman NSDR |
| 20:25 | 💊 Magnesium 200mg + Apigenin 50mg + L-Theanin 100mg |
| 20:30 | 📱 Handy raus aus Schlafzimmer |
| 20:30 | 😴 Schlafen — Ziel 8,5h |

**Wochentag-spezifisch:**

| Tag & Zeit | Erinnerung |
|---|---|
| Mo 06:20 | 🦵 Beine: Hack Squats · Leg Curls · Calf Raises · Leg Extensions |
| Di 06:20 | 🌡️ Heute: Nur Sauna + Kältebad — kein Krafttraining |
| Mi 06:20 | 💪 Oberkörper: Bankdrücken · Schultern · Klimmzüge · Nacken |
| Do 06:20 | 🚴 Zone-2: Hund morgens zählt — optional 20 Min Rad |
| Fr 06:20 | ⚡ HIIT: 8–12 Runden Vollsprint |
| Sa 06:20 | 💪 Arme + Schultern + Waden — leichter Tag |
| So 06:20 | 🏃 Langer Spaziergang mit Hund = Zone-2 |

**Wöchentlich:**

| Tag & Zeit | Erinnerung |
|---|---|
| So 18:00 | 🍳 Meal Prep: Hähnchen + Reis + Brokkoli |
| So 19:00 | 📊 Tracking + Gewicht + Taillenmaß |
| Mo 08:10 | 🛒 Supplement-Vorrat prüfen |

**Monatlich (1. des Monats):**

| Uhrzeit | Erinnerung |
|---|---|
| 08:00 | 💰 Kosten-Tracker ausfüllen |
| 08:01 | 📦 Supplements nachbestellen |
| 08:02 | 📸 Fortschrittsfoto — frontal · Seite · Rücken |

---

## ⚡ DEIN SYSTEM IN ZAHLEN

| | |
|---|---|
| **Aufstehen** | 05:00 täglich |
| **Schlafen** | 20:30 täglich |
| **Schlaf** | 8,5h |
| **Hund** | 05:05 · 12:00 · 18:30 |
| **Training** | 06:20 täglich |
| **Koffein-Stopp** | 14:00 täglich |
| **NSDR** | 20:00 täglich |
| **Supplements abends** | 20:25 täglich |

---

> ⚠️ **Wichtig:** 20:30 schlafen bedeutet nach der Arbeit (18:00) hast du nur **2,5 Stunden** für Hund · Abendessen · NSDR · Supplements. Das ist machbar — aber du brauchst Disziplin. Kein langes Scrollen abends.

**Ist das so final — soll ich es als Excel-Blatt einfügen?**

---

**Du:**

shake morgens trinke ich bei der Fahrt

---

**Claude:**

Perfekt — dann eine kleine Anpassung:

**07:40 Heimfahrt fällt weg → Shake direkt im Auto auf dem Heimweg.**

---

## 📋 APPLE ERINNERUNGEN — FINAL

**Täglich (alle 7 Tage):**

| Uhrzeit | Erinnerung |
|---|---|
| 05:00 | 🌅 Aufstehen — kein Snooze · 2 Gläser Wasser |
| 05:05 | 🐕 Hund morgens — 60 Min · Sonnenlicht holen |
| 06:05 | 🚗 Abfahrt Studio · Pre-Workout im Auto: Alpha-GPC 300mg + L-Tyrosin 500mg |
| 06:20 | 🏋️ Training — 50 Min |
| 07:10 | 🌡️ Sauna 10 Min |
| 07:20 | 🚿 Duschen + fertig machen |
| 07:40 | 🚗 Heimfahrt · Shake 36g + Kreatin 5g im Auto trinken |
| 07:55 | 🏠 Zuhause · Omega-3 + D3+K2 + Multi einnehmen |
| 08:10 | ☕ Kaffee + Frühstück + 3 Prioritäten notieren |
| 09:00 | 💼 Arbeit beginnt |
| 12:00 | 🐕 Hund mittags — 60 Min |
| 13:00 | 🥗 Mittagessen |
| 14:00 | ☕ Letzter Kaffee — danach kein Koffein mehr |
| 18:30 | 🐕 Hund abends — 60 Min |
| 19:30 | 🍝 Abendessen — Kohlenhydrate · kein Alkohol · kein Zucker |
| 19:30 | 💡 Lichter dimmen · Bildschirm Nachtmodus |
| 20:00 | 🧘 NSDR 20 Min — YouTube: Huberman NSDR |
| 20:25 | 💊 Magnesium 200mg + Apigenin 50mg + L-Theanin 100mg |
| 20:30 | 📱 Handy raus aus Schlafzimmer |
| 20:30 | 😴 Schlafen — 8,5h |

**Wochentag-spezifisch:**

| Tag & Zeit | Erinnerung |
|---|---|
| Mo 06:20 | 🦵 Beine: Hack Squats · Leg Curls · Calf Raises · Leg Extensions |
| Di 06:20 | 🌡️ Heute: Nur Sauna + Kältebad — kein Krafttraining |
| Mi 06:20 | 💪 Oberkörper: Bankdrücken · Schultern · Klimmzüge · Nacken |
| Do 06:20 | 🚴 Zone-2: Hund morgens zählt — optional 20 Min Rad |
| Fr 06:20 | ⚡ HIIT: 8–12 Runden Vollsprint |
| Sa 06:20 | 💪 Arme + Schultern + Waden — leichter Tag |
| So 06:20 | 🏃 Langer Spaziergang mit Hund = Zone-2 |

**Wöchentlich:**

| Tag & Zeit | Erinnerung |
|---|---|
| So 18:00 | 🍳 Meal Prep: Hähnchen + Reis + Brokkoli |
| So 19:00 | 📊 Tracking + Gewicht + Taillenmaß |
| Mo 08:10 | 🛒 Supplement-Vorrat prüfen |

**Monatlich (1. des Monats):**

| Uhrzeit | Erinnerung |
|---|---|
| 08:00 | 💰 Kosten-Tracker ausfüllen |
| 08:01 | 📦 Supplements nachbestellen |
| 08:02 | 📸 Fortschrittsfoto — frontal · Seite · Rücken |

---

> ⚠️ **Hinweis:** Fettlösliche Supplements (Omega-3 · D3+K2) am besten zu einer Mahlzeit mit Fett nehmen — also besser beim Frühstück um 08:10 als nüchtern um 07:55.

**Ist das jetzt final — soll ich es als Excel-Blatt einfügen?**

---

**Du:**

optimiere mein plan nach hubermann

---

**Claude:**

Gute Frage — lass mich deinen Plan gegen Hubermans exakte Protokoll-Empfehlungen prüfen und optimieren:
```
This block is not supported on your current device yet.
```

Jetzt habe ich alles. Hier sind die Abweichungen von Hubermans Protokoll und der optimierte Plan:

---

## 🔍 WAS AN DEINEM PLAN NICHT HUBERMAN-KONFORM WAR

| Punkt | Dein Plan | Huberman-Protokoll | Problem |
|---|---|---|---|
| **Kaffee** | 08:10 (70 Min nach Aufstehen) | 90–120 Min nach dem Aufwachen — Adenosin erst vollständig abbauen lassen | 20–50 Min zu früh |
| **Koffein-Stopp** | 14:00 | Huberman stoppt Koffein um 12:00 Uhr mittags | 2h zu spät |
| **Erstes Sonnenlicht** | Beim Hund 05:05 | Sofort nach dem Aufwachen — innerhalb 10–30 Min draußen | ✅ Passt bereits |
| **Pre-Workout** | Im Auto (06:05) | 30–60 Min vor Training ✅ | Passt bereits |
| **NSDR** | Abends 21:00 | Huberman macht NSDR nachmittags — nach dem Mittagessen zur Recharge | Abends geht auch — aber Mittag ist besser |
| **Erste Mahlzeit** | 08:10 | Huberman isst erst zwischen 11:00 und 13:00 Uhr — 16–18h Fasten | 3h zu früh für echtes 16:8 |
| **Elektrolyte morgens** | Fehlt | Huberman trinkt morgens LMNT Elektrolyte — Natrium, Magnesium, Kalium für Nervensystem | Fehlt komplett |

---

## ✅ OPTIMIERTER PLAN NACH HUBERMAN

| Zeit | Was | Huberman-Optimierung |
|---|---|---|
| **05:00** | 🌅 Aufstehen — kein Snooze | — |
| **05:00** | 💧 Wasser + Elektrolyte (LMNT oder Prise Salz + Zitrone) | NEU — Nervensystem sofort aktivieren |
| **05:05** | 🐕 Hund morgens — 60 Min · Sonnenlicht direkt in die Augen (keine Sonnenbrille) | Optic Flow senkt Amygdala-Aktivierung |
| **06:05** | 🚗 Abfahrt Studio · Pre-Workout im Auto: Alpha-GPC 300mg + L-Tyrosin 500mg | ✅ Timing perfekt |
| **06:20** | 🏋️ Training — 50 Min | ✅ |
| **07:10** | 🌡️ Sauna 10 Min | ✅ |
| **07:20** | 🚿 Duschen + fertig machen | ✅ |
| **07:40** | 🚗 Heimfahrt · Shake 36g + Kreatin 5g im Auto trinken | ✅ |
| **08:00** | 🏠 Zuhause — Wasser · kein Kaffee noch | Adenosin noch nicht 90 Min gecleant |
| **08:30** | ☕ Erster Kaffee — jetzt erst (90 Min nach 05:00 Aufwachen) | ✅ Huberman-konform |
| **08:30** | 📋 3 Prioritäten für heute notieren · kein Handy · kein Social Media | Low-Dopamine Morning |
| **09:00** | 💼 Arbeit beginnt — erster 90-Min-Fokus-Block | Tiefstes Arbeiten vor Mittag |
| **11:30** | 🥗 Erste richtige Mahlzeit — Protein + Fette + Kreuzblütler | Fasten endet nach 6,5h — Kompromiss |
| **12:00** | 🐕 Hund mittags — 60 Min | ✅ |
| **12:00** | ☕ Letzter Kaffee — danach kein Koffein mehr | NEU — 2h früher als vorher |
| **13:00** | 🥗 Mittagessen (oder zusammen mit 11:30) | |
| **18:30** | 🐕 Hund abends — 60 Min · Abendlicht holen | Abendlicht verstärkt Melatonin-Signal |
| **19:30** | 🍝 Abendessen — Kohlenhydrate + leichtes Protein · kein Alkohol | Tryptophan → Melatonin |
| **19:30** | 💡 Lichter dimmen · Bildschirm Nachtmodus | Melatonin schützen |
| **20:00** | 🧘 NSDR 20 Min — YouTube: Huberman NSDR | Dopamin ↑ bis 65% |
| **20:25** | 💊 Magnesium 200mg + Apigenin 50mg + L-Theanin 100mg | |
| **20:30** | 📱 Handy raus aus Schlafzimmer | |
| **20:30** | 😴 Schlafen — 8,5h bis 05:00 | ✅ |

---

## 📋 FINALE APPLE ERINNERUNGEN — HUBERMAN-OPTIMIERT

**Täglich (alle 7 Tage):**

| Uhrzeit | Erinnerung |
|---|---|
| 05:00 | 🌅 Aufstehen — kein Snooze · Wasser + Prise Salz + Zitrone |
| 05:05 | 🐕 Hund morgens — 60 Min · Sonnenlicht direkt · keine Sonnenbrille |
| 06:05 | 🚗 Abfahrt Studio · Pre-Workout im Auto: Alpha-GPC 300mg + L-Tyrosin 500mg |
| 06:20 | 🏋️ Training — 50 Min |
| 07:10 | 🌡️ Sauna 10 Min |
| 07:20 | 🚿 Duschen + fertig machen |
| 07:40 | 🚗 Heimfahrt · Shake 36g + Kreatin 5g im Auto |
| 08:30 | ☕ Erster Kaffee — jetzt erst · 90 Min nach Aufwachen |
| 08:30 | 📋 3 Prioritäten notieren · kein Handy · kein Social Media |
| 09:00 | 💼 Arbeit — erster 90-Min-Fokus-Block · kein Handy |
| 11:30 | 🥗 Erste Mahlzeit — Protein + Fette + Kreuzblütler + Omega-3 + D3+K2 + Multi |
| 12:00 | 🐕 Hund mittags — 60 Min |
| 12:00 | ☕ Letzter Kaffee — danach kein Koffein mehr |
| 13:00 | 🥗 Mittagessen |
| 18:30 | 🐕 Hund abends — 60 Min · Abendlicht holen |
| 19:30 | 🍝 Abendessen — Kohlenhydrate · kein Alkohol · kein Zucker |
| 19:30 | 💡 Lichter dimmen · Bildschirm Nachtmodus |
| 20:00 | 🧘 NSDR 20 Min — YouTube: Huberman NSDR |
| 20:25 | 💊 Magnesium 200mg + Apigenin 50mg + L-Theanin 100mg |
| 20:30 | 📱 Handy raus aus Schlafzimmer |
| 20:30 | 😴 Schlafen — 8,5h |

**Wochentag-spezifisch:**

| Tag & Zeit | Erinnerung |
|---|---|
| Mo 06:20 | 🦵 Beine: Hack Squats · Leg Curls · Calf Raises · Leg Extensions |
| Di 06:20 | 🌡️ Heute: Nur Sauna + Kältebad — kein Krafttraining |
| Mi 06:20 | 💪 Oberkörper: Bankdrücken · Schultern · Klimmzüge · Nacken |
| Do 06:20 | 🚴 Zone-2: Hund morgens zählt — optional 20 Min Rad |
| Fr 06:20 | ⚡ HIIT: 8–12 Runden Vollsprint |
| Sa 06:20 | 💪 Arme + Schultern + Waden — leichter Tag |
| So 06:20 | 🏃 Langer Spaziergang mit Hund = Zone-2 |

**Wöchentlich:**

| Tag & Zeit | Erinnerung |
|---|---|
| So 18:00 | 🍳 Meal Prep: Hähnchen + Reis + Brokkoli |
| So 19:00 | 📊 Tracking + Gewicht + Taillenmaß |
| Mo 08:30 | 🛒 Supplement-Vorrat prüfen |

**Monatlich (1. des Monats):**

| Erinnerung |
|---|
| 💰 Kosten-Tracker ausfüllen |
| 📦 Supplements nachbestellen |
| 📸 Fortschrittsfoto — frontal · Seite · Rücken |

---

## ⚡ DIE 3 WICHTIGSTEN ÄNDERUNGEN

**1. Kaffee erst 08:30** — nicht 08:10. Die 90 Minuten Verzögerung lassen Cortisol natürlich pieken und verhindern den Nachmittags-Crash. Vorher: Elektrolyte + Wasser.

**2. Koffein-Stopp 12:00 statt 14:00** — Koffein hat eine Halbwertzeit von 5–7 Stunden. Um 20:30 schlafen zu gehen braucht es Stopp um 12:00 — sonst ist noch 50% aktiv beim Einschlafen.

**3. Elektrolyte morgens** — direkt beim Aufwachen. Natrium, Magnesium und Kalium in den richtigen Verhältnissen sind essenziell damit Nervenzellen korrekt feuern können.

**Nächster Schritt:** Als finales Excel-Blatt einfügen?

---

**Du:**

ich brauche den plan jetzt für apple erinnerugnen oder kannst du es dort einfügen

---

**Claude:**

Lass mich direkt versuchen es einzufügen:
```
This block is not supported on your current device yet.
```

Leider ist der direkte Zugriff auf Apple Erinnerungen in dieser Sitzung nicht verfügbar — die Berechtigung ist nicht aktiv.

**So richtest du es in 5 Minuten selbst ein:**

---

## 📱 SCHRITT-FÜR-SCHRITT — Apple Erinnerungen einrichten

**1. Neue Liste erstellen:**
Erinnerungen App öffnen → "+" → Liste Name: **"Huberman Routine"**

**2. Jede Erinnerung so anlegen:**
Tippe auf "+" → Titel eingeben → Datum aktivieren → Uhrzeit setzen → **Wiederholen: Täglich**

---

## ✅ DEINE KOMPLETTE LISTE — COPY & PASTE FERTIG

### 📅 TÄGLICH (alle 7 Tage · täglich wiederholen)

```
05:00 — 🌅 Aufstehen · kein Snooze · Wasser + Prise Salz + Zitrone
05:05 — 🐕 Hund morgens · 60 Min · Sonnenlicht direkt · keine Sonnenbrille
06:05 — 🚗 Abfahrt Studio · Pre-Workout im Auto: Alpha-GPC 300mg + L-Tyrosin 500mg
06:20 — 🏋️ Training starten · 50 Min
07:10 — 🌡️ Sauna 10 Min
07:20 — 🚿 Duschen + fertig machen
07:40 — 🚗 Heimfahrt · Shake 36g + Kreatin 5g im Auto trinken
08:30 — ☕ Erster Kaffee · jetzt erst · 90 Min nach Aufwachen
08:30 — 📋 3 Prioritäten notieren · kein Handy · kein Social Media
09:00 — 💼 Arbeit · erster 90-Min-Fokusblock · kein Handy
11:30 — 🥗 Erste Mahlzeit · Protein + Fette + Kreuzblütler + Omega-3 + D3+K2 + Multi
12:00 — 🐕 Hund mittags · 60 Min
12:00 — ☕ Letzter Kaffee · danach kein Koffein mehr
13:00 — 🥗 Mittagessen
18:30 — 🐕 Hund abends · 60 Min · Abendlicht holen
19:30 — 🍝 Abendessen · Kohlenhydrate · kein Alkohol · kein Zucker
19:30 — 💡 Lichter dimmen · Bildschirm Nachtmodus
20:00 — 🧘 NSDR 20 Min · YouTube: Huberman NSDR
20:25 — 💊 Magnesium 200mg + Apigenin 50mg + L-Theanin 100mg
20:30 — 📱 Handy raus aus Schlafzimmer
20:30 — 😴 Schlafen · Ziel 8,5h
```

---

### 📅 WOCHENTAG-SPEZIFISCH (einmalig · jeweiliger Tag · wöchentlich wiederholen)

```
Mo 06:20 — 🦵 Beine: Hack Squats · Leg Curls · Calf Raises · Leg Extensions
Di 06:20 — 🌡️ Heute: Nur Sauna + Kältebad · kein Krafttraining
Mi 06:20 — 💪 Oberkörper: Bankdrücken · Schultern · Klimmzüge · Nacken
Do 06:20 — 🚴 Zone-2: Hund morgens zählt · optional 20 Min Rad
Fr 06:20 — ⚡ HIIT: 8–12 Runden Vollsprint · Assault Bike
Sa 06:20 — 💪 Arme + Schultern + Waden · leichter Tag
So 06:20 — 🏃 Langer Spaziergang mit Hund = Zone-2
```

---

### 📅 WÖCHENTLICH (jeweiliger Tag · wöchentlich wiederholen)

```
So 18:00 — 🍳 Meal Prep: Hähnchen + Reis + Brokkoli für die Woche
So 19:00 — 📊 Tracking ausfüllen + Gewicht + Taillenmaß messen
Mo 08:30 — 🛒 Supplement-Vorrat prüfen · nachbestellen wenn < 2 Wochen
```

---

### 📅 MONATLICH (1. des Monats · monatlich wiederholen)

```
1. des Monats 08:00 — 💰 Kosten-Tracker ausfüllen
1. des Monats 08:01 — 📦 Supplements nachbestellen
1. des Monats 08:02 — 📸 Fortschrittsfoto · frontal · Seite · Rücken
```

---

## 💡 TIPP — Schneller mit Siri

Statt alles einzeln einzutippen kannst du Siri nutzen:

> **"Hey Siri, erinnere mich jeden Tag um 5 Uhr morgens daran: Aufstehen kein Snooze Wasser mit Salz und Zitrone"**

Das geht für jede Erinnerung — spart die Hälfte der Zeit.

---

**Gesamtaufwand:** Ca. 15–20 Minuten einmalig — dann läuft das System automatisch für immer.

---

**Du:**

jetzt gehts

---

**Claude:**

Perfekt — dann richte es jetzt ein:
```
This block is not supported on your current device yet.
```

Der Zugriff funktioniert leider noch nicht — das Tool ist in dieser Session nicht verfügbar.

**Was du tun musst:**

Geh in deinen iPhone-Einstellungen und erteile Claude die Berechtigung:

> **Einstellungen → Claude → Erinnerungen → "Alle" auswählen**

Danach schreib mir einfach **"jetzt einrichten"** — dann lege ich alle 34 Erinnerungen auf einmal automatisch in Apple Erinnerungen an. Du musst nichts selbst eintippen.

---

**Du:**

ist erlaubt

---

**Claude:**

```
This block is not supported on your current device yet.
```

Das Tool ist leider technisch in dieser Session nicht verfügbar — auch wenn die Berechtigung erteilt ist. Das ist ein bekanntes Problem wenn die Berechtigung erst während einer laufenden Unterhaltung geändert wird.

**Zwei Optionen:**

**Option 1 — Neue Unterhaltung starten:**
Schreib in einem neuen Chat einfach: *"Erstelle mir meine Huberman Routine in Apple Erinnerungen"* — dann funktioniert es direkt mit der neuen Berechtigung.

**Option 2 — Siri in 2 Minuten:**
Halte dein iPhone hoch und sag:

> *"Hey Siri, erinnere mich jeden Tag um 5 Uhr: Aufstehen kein Snooze Wasser mit Salz"*

Das geht schnell für die wichtigsten 5–6 Erinnerungen. Den Rest im neuen Chat.

**Nächster Schritt:** Starte eine neue Unterhaltung und sag mir kurz dass du die Huberman Routine einrichten möchtest — ich lege dann alle 34 Erinnerungen auf einmal an.

---

**Du:**

ich will es selbst in erinnerung einstellen

---

**Claude:**

Perfekt — hier ist alles kompakt und bereit zum Abtippen:

---

## 📱 HUBERMAN ROUTINE — APPLE ERINNERUNGEN

### TÄGLICH (alle wiederholen: täglich)

| Zeit | Titel |
|---|---|
| 05:00 | 🌅 Aufstehen · kein Snooze · Wasser + Salz + Zitrone |
| 05:05 | 🐕 Hund morgens · 60 Min · Sonnenlicht · keine Sonnenbrille |
| 06:05 | 🚗 Abfahrt Studio · Alpha-GPC 300mg + L-Tyrosin 500mg im Auto |
| 06:20 | 🏋️ Training · 50 Min |
| 07:10 | 🌡️ Sauna · 10 Min |
| 07:20 | 🚿 Duschen + fertig machen |
| 07:40 | 🚗 Heimfahrt · Shake 36g + Kreatin 5g trinken |
| 08:30 | ☕ Erster Kaffee · 90 Min nach Aufwachen |
| 08:35 | 📋 3 Prioritäten notieren · kein Handy · kein Social Media |
| 09:00 | 💼 Arbeit · 90-Min-Fokusblock · kein Handy |
| 11:30 | 🥗 Erste Mahlzeit · Protein + Fette + Kreuzblütler + Supplements |
| 12:00 | 🐕 Hund mittags · 60 Min |
| 12:00 | ☕ Letzter Kaffee · danach kein Koffein mehr |
| 13:00 | 🥗 Mittagessen |
| 18:30 | 🐕 Hund abends · 60 Min · Abendlicht holen |
| 19:30 | 🍝 Abendessen · Kohlenhydrate · kein Alkohol · kein Zucker |
| 19:30 | 💡 Lichter dimmen · Bildschirm Nachtmodus |
| 20:00 | 🧘 NSDR 20 Min · YouTube: Huberman NSDR |
| 20:25 | 💊 Magnesium 200mg + Apigenin 50mg + L-Theanin 100mg |
| 20:30 | 📱 Handy raus aus Schlafzimmer |
| 20:30 | 😴 Schlafen · Ziel 8,5h |

---

### WÖCHENTLICH (wiederholen: wöchentlich · jeweiliger Tag)

| Tag · Zeit | Titel |
|---|---|
| Mo · 06:20 | 🦵 Beine · Hack Squats · Leg Curls · Calf Raises |
| Di · 06:20 | 🌡️ Nur Sauna + Kältebad · kein Krafttraining |
| Mi · 06:20 | 💪 Oberkörper · Bankdrücken · Schultern · Klimmzüge · Nacken |
| Do · 06:20 | 🚴 Zone-2 · Hund morgens zählt · optional 20 Min Rad |
| Fr · 06:20 | ⚡ HIIT · 8–12 Runden Vollsprint |
| Sa · 06:20 | 💪 Arme + Schultern + Waden · leichter Tag |
| So · 06:20 | 🏃 Zone-2 · Langer Spaziergang mit Hund |
| So · 18:00 | 🍳 Meal Prep · Hähnchen + Reis + Brokkoli |
| So · 19:00 | 📊 Tracking + Gewicht + Taillenmaß messen |
| Mo · 08:30 | 🛒 Supplement-Vorrat prüfen |

---

### MONATLICH (wiederholen: monatlich · 1. des Monats)

| Zeit | Titel |
|---|---|
| 08:00 | 💰 Kosten-Tracker ausfüllen |
| 08:01 | 📦 Supplements nachbestellen |
| 08:02 | 📸 Fortschrittsfoto · frontal · Seite · Rücken |

---

**Gesamt: 34 Erinnerungen · Liste: "Huberman Routine"**

---

**Du:**

wieso frühstück um 11:30 reicht protein nicht?

---

**Claude:**

Gute Frage — du hast recht, das ist ein echter Konflikt in deinem Plan.

**Das Problem:**

Du trinkst den Shake um **07:40** — das sind **36g Protein**. Danach nichts bis **11:30** — das sind **3h 50 Min** ohne weitere Nährstoffe. Für Muskelaufbau bei 98 kg ist das eigentlich ok, weil:

- Shake direkt nach Training ✅ — Muskelproteinsynthese läuft
- 3–4h später erste richtige Mahlzeit ✅ — zweite Protein-Welle

**Aber hier ist das eigentliche Problem:**

Huberman fastet bis 11–13 Uhr weil er **kein Training nüchtern-post** hat. Du trainierst bereits um 06:20 und trinkst danach den Shake — das heißt du brichst das Fasten bereits um 07:40.

**Meine ehrliche Empfehlung für dich:**

Da du bereits um 07:40 den Shake trinkst — mach um **08:30 ein richtiges Frühstück** direkt mit dem Kaffee. Kein striktes 16:8 mehr, sondern ein pragmatisches **~13h Fasten** (19:30 letztes Essen → 08:30 Frühstück).

Das ist für Muskelaufbau sogar besser:

| | Bisheriger Plan | Optimiert für dich |
|---|---|---|
| Shake | 07:40 | 07:40 ✅ |
| Frühstück | 11:30 | **08:30** mit Kaffee |
| Mittagessen | 13:00 | 13:00 ✅ |
| Abendessen | 19:30 | 19:30 ✅ |
| Fasten | ~7h (Shake bis 19:30) | ~13h (08:30 bis 19:30 Vortag) |
| Protein-Timing | 2 Mahlzeiten vor Mittag | 3 Mahlzeiten verteilt ✅ |

**Was du beim Frühstück 08:30 isst:**
- 3–4 Eier + Avocado + Brokkoli
- Oder griechischer Joghurt + Nüsse + Beeren
- Supplements dazu: Omega-3 + D3+K2 + Multi

**Angepasste Erinnerungen — nur diese 2 ändern:**

| Alt | Neu |
|---|---|
| 11:30 🥗 Erste Mahlzeit + Supplements | ❌ löschen |
| 08:30 ☕ Erster Kaffee | ✅ ändern zu: ☕ Kaffee + Frühstück + Supplements · Eier + Avocado + Kreuzblütler |

Die **12:00 und 13:00 Erinnerungen** bleiben — Mittagessen bleibt bestehen.

**Nächster Schritt:** Soll ich die gesamte Erinnerungsliste mit dieser Korrektur nochmal sauber ausgeben?

---

**Du:**

Sport Routine nach Tagen

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Dein kompletter Wochensplit — 4 Krafttage, 2 Zone-2-Tage, 1 Recovery-Tag. Donnerstag und Sonntag macht dein Hund automatisch zum Kardiotag.

---

**Du:**

Was fehlt uns noch?

---

**Claude:**

Lass mich ehrlich durchgehen was wir haben und was wirklich noch fehlt:

**Was wir haben ✅**
- Vollständige Excel-Datei (15 Blätter)
- Supplement-Protokoll mit Marken & DE-Bezug
- Blutwerte & Arzt-Gespräch
- Sport-Protokoll (Wochensplit)
- Ernährungs-Protokoll
- Schlaf-Protokoll
- 12-Wochen-Plan
- Tages-Tracking
- Körper-Tracking & Foto-Protokoll
- Stress & Mental-Protokoll
- Kosten-Tracker
- Jahreskalender
- Apple Erinnerungen (fertig zum Eintippen)
- Tagesplan nach Huberman optimiert
```
This block is not supported on your current device yet.
```

Was ich noch wirklich vermisse:

**1. Konkreter Mahlzeit-Plan** — was du genau kochst und isst, nicht nur Prinzipien. Mit Rezeptideen für Frühstück, Mittag, Abend.

**2. Gym-Tracking-Sheet** — Gewichte und Wiederholungen pro Übung festhalten damit du progressive Überladung wirklich messen kannst.

**3. Supplement-Einnahme-Karte** — kleines Kärtchen das du neben die Supplements legst: was wann mit was einnehmen. Für den Alltag praktischer als die Excel.

**4. Blutbild-Auftrag für den Arzt** — ein druckfertiges Dokument das du dem Arzt hinlegst mit allen 28 Markern die du bestellen willst. Das PDF haben wir — aber noch nicht als ausfüllbares Dokument mit deinen persönlichen Werten.

**5. Startdatum & konkreter Tag 1** — wann fängst du wirklich an? Was kaufst du diese Woche als erstes? Was richtest du heute noch ein?

---

**Du:**

F: Was ich noch vermisse — soll ich es ergänzen?
A: ich brauche nur essen nach Gramm gekocht

---

**Claude:**

Perfekt — das ist das Praktischste was noch fehlt. Dafür brauche ich kurz deine Ziele:
```
This block is not supported on your current device yet.
```

---

**Du:**

F: Was ist dein primäres Ziel gerade?
A: Körperfett reduzieren + Muskel halten (leichtes Defizit ~300-400 kcal)

F: Wie kochst du am liebsten?
A: Meal Prep 1-2x pro Woche

F: Gibt es Lebensmittel die du nicht isst?
A: Nein — alles erlaubt

---

**Claude:**

Perfekt — ich berechne jetzt alles exakt für dich.

**Deine Basis:**
- 98 kg · 32 Jahre · männlich · aktiv (täglich Training + Hund)
- Ziel: Körperfett ↓ + Muskel halten
- Kaloriendefizit: ~350 kcal

**Berechnung:**
- Grundumsatz (Mifflin): ~2.150 kcal
- Aktivitätsfaktor (sehr aktiv): × 1,6 = ~3.440 kcal
- Minus Defizit 350 kcal = **~3.100 kcal täglich**
- Protein: 2g × 98 kg = **196g Protein/Tag**
- Fett: 25% der Kalorien = **86g Fett/Tag**
- Kohlenhydrate: Rest = **~330g Kohlenhydrate/Tag**

---
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Hier ist dein kompletter Ernährungsplan nach Gramm — 6 Blätter:

| Blatt | Inhalt |
|---|---|
| **Makros & Ziele** | 3.090 kcal · 196g Protein · 330g Carbs · 86g Fett — berechnet für dich |
| **Frühstück & Shake** | Shake (45g Protein) + 2 Frühstücksvarianten mit exakten Gramm |
| **Mittagessen** | 4 Optionen mit je exakten Gramm — alle Meal Prep geeignet |
| **Abendessen** | 4 Optionen fokussiert auf Kohlenhydrate für Schlaf |
| **Meal Prep Plan** | Sonntag 18:00 Uhr · 45 Min · Schritt für Schritt was wann kochen |
| **Tages-Makros Tracker** | Tägliches Ausfüllblatt + Protein-Schnellreferenz |

**Deine Zahlen auf einen Blick:**
- Shake morgens: **45g Protein**
- Frühstück: **~30g Protein**
- Mittagessen: **~75g Protein**
- Abendessen: **~56g Protein**
- **Gesamt: 196g — exakt dein Ziel**

---

**Du:**

Macht es sinn den Plan in erinnerungen abzuspeichern?

---

**Claude:**

**Nein — macht keinen Sinn.**

Der Ernährungsplan ist eine **Referenz-Datei**, keine Aufgabe die du täglich abhaken musst. Apple Erinnerungen ist dafür das falsche Tool.

---

**Was Sinn macht:**

| Tool | Wofür |
|---|---|
| **Excel-Datei** (hast du bereits) | Nachschlagen — was esse ich · wie viel Gramm · welche Option |
| **Apple Erinnerungen** (bereits eingerichtet) | Wann essen — 08:30 · 13:00 · 19:30 als tägliche Erinnerung |
| **Meal Prep Erinnerung** (bereits drin) | Sonntag 18:00 Uhr — kochen starten |

---

**Die Logik:**

Die Erinnerung sagt dir **wann** du essen sollst — die Excel-Datei zeigt dir **was und wie viel**. Beides zusammen ist dein System.

Mehr brauchst du nicht. Die Erinnerungen sind komplett — der Plan ist fertig.

**Nächster Schritt:** Wann fängst du an — diese Woche Montag?

---

**Du:**

Ich hab am unteren bauch fett und würde es gern loss werden

größere Brust und arme aufbauen

---

**Claude:**

Das sind zwei sehr konkrete Ziele. Lass mich direkt ehrlich sein:

---

## 🎯 REALITÄT CHECK

### Bauchfett (unterer Bauch)

**Die unbequeme Wahrheit:** Du kannst nicht lokal Fett verbrennen — das gibt es nicht. Kein Übung, kein Gerät, kein Supplement baut gezielt Bauchfett ab.

**Was wirklich funktioniert:**
- Kaloriendefizit (haben wir bereits — 3.090 kcal) ✅
- Testosteron optimieren (Blutbild + Supplements) ✅
- Cortisol senken (Schlaf + NSDR) ✅
- Insulin niedrig halten (Koffein-Timing + Fasten) ✅

> Unteres Bauchfett ist das **letzte** was verschwindet — es ist hormonell bedingt durch Cortisol und Insulin. Bei 98 kg und deinem Protokoll wirst du es sehen — aber es dauert 3–6 Monate konsequent.

---

### Brust & Arme aufbauen
```
This block is not supported on your current device yet.
```

---

**Du:**

F: Welche Geräte hast du im Studio?
A: Alles verfügbar im Studio

F: Brust — was genau?
A: Obere Brust (voller aussehen)

F: Arme — was genau?
A: Trizeps (Armumfang — macht 2/3 des Arms aus)

---

**Claude:**

Perfekt — sehr gute Wahl. Obere Brust + Trizeps sind die zwei Muskeln die optisch am meisten Wirkung haben.

---

## 💪 DEIN OPTIMIERTER TRAININGSPLAN
### Fokus: Obere Brust + Trizeps + Bauchfett durch Defizit

---

### Warum genau diese Kombination:

**Obere Brust** macht den Unterschied zwischen "flach" und "voll" — sie füllt den Bereich unter dem Schlüsselbein. Wird durch **Schrägbankdrücken** aktiviert, nicht durch flaches Bankdrücken.

**Trizeps** macht **2/3 des Armumfangs** aus — wer dicke Arme will, trainiert primär Trizeps. Bizeps ist nur 1/3.

**Bauchfett** verschwindet durch dein Kaloriendefizit + Testosteron optimieren — kein Bauchmuskeltraining nötig.

---
```
This block is not supported on your current device yet.
```

---

## 🔑 DIE 3 WICHTIGSTEN PUNKTE

**1. Schrägbank (30°) ist deine wichtigste Übung**
Flaches Bankdrücken baut kaum obere Brust. Der 30°-Winkel ist der Sweet Spot — steiler als 45° ist schon zu viel Schulter.

**2. Trizeps Dips mit Zusatzgewicht**
Das ist die Kniebeuge für den Trizeps — die meiste Masse kommt von dieser einen Übung. Sobald du 10 saubere Dips schaffst, Gewichtsgürtel nutzen.

**3. Bauchfett — die Formel ist einfach:**
Cortisol ↓ (Schlaf + NSDR) + Insulin ↓ (Koffein-Timing + Fasten) + Defizit (3.090 kcal) = unteres Bauchfett verschwindet automatisch. Kein Crunch nötig.

---

**Zeitplan im Gym (Mittwoch & Samstag):**

| Phase | Zeit |
|---|---|
| Aufwärmen | 5 Min |
| Hauptübungen (1–2) | 20 Min |
| Nebenübungen (3–4) | 15 Min |
| Isolationsübungen (5–6) | 10 Min |
| **Gesamt** | **50 Min** ✅ |

---

**Nächster Schritt:** Soll ich das als zusätzliches Blatt in deine Excel-Hauptdatei einfügen — mit Gewichts-Tracking pro Übung damit du die progressive Überladung messen kannst?

---

**Du:**

Wie bekomme ich cortisol runter


Meine aktuelle Routine 


Morgens 7.30 aufstehen und spazieren 1h danach ab 9 bis 12 arbeiten 1h spazieren und essen danach bis 18 Uhr arbeiten danach 1h spazieren essen und sport 

11:00  Uhr schlafen

---

**Claude:**

Direkt und ehrlich — deine aktuelle Routine hat **3 massive Cortisol-Probleme:**

---

## 🔴 WAS DEINEN CORTISOL HOCHHÄLT

| Problem | Deine Routine | Auswirkung |
|---|---|---|
| **Schlaf** | 23:00–07:30 = 8,5h aber falsches Timing | Cortisol-Rhythmus verschoben |
| **Sport abends** | Training nach 18:00 Uhr | Cortisol + Adrenalin Spike genau vor Schlaf |
| **Kein Licht morgens** | 07:30 direkt Hund — ok | Aber kein bewusstes Sonnenlicht-Protokoll |
| **Kein Koffein-Stopp** | Unbekannt | Falls Kaffee nach 14 Uhr = Cortisol nachts erhöht |

---

## 🔴 DAS GRÖSSTE PROBLEM — SPORT ABENDS
```
This block is not supported on your current device yet.
```

---

## ✅ KONKRETE MASSNAHMEN — Cortisol senken

### 1. Sport morgens — wichtigste Änderung
Sport abends nach 18 Uhr ist der größte Cortisol-Saboteur. Dein neuer Plan (05:00 aufstehen · Training 06:20) löst das vollständig.

### 2. NSDR täglich um 20:00
20 Minuten Yoga Nidra senkt Cortisol messbar. YouTube: "Huberman NSDR 20 minutes" — kostenlos.

### 3. Koffein-Stopp 12:00 Uhr
Koffein erhöht Cortisol direkt. Halbwertzeit 5–7h — Kaffee um 14 Uhr ist um 21 Uhr noch halb aktiv.

### 4. Licht abends dimmen ab 19:30
Helles Licht abends = Cortisol-Signal = Körper denkt es ist noch Tag.

### 5. Magnesium + Apigenin abends (20:25)
Magnesium aktiviert den Parasympathikus direkt — senkt Cortisol biochemisch.

### 6. Keine News · kein Social Media nach 20:00
Jede Nachricht die Stress auslöst → Cortisol-Spike → Schlaf schlechter.

---

## 📊 DEIN CORTISOL-PROBLEM IN ZAHLEN

| Faktor | Deine Routine jetzt | Optimiert |
|---|---|---|
| Sport-Timing | 18:00+ (Cortisol ↑ abends) | 06:20 (Cortisol ↑ morgens ✅) |
| Schlafenszeit | 23:00 | 20:30 |
| Schlafdauer | 8,5h aber schlechte Qualität | 8,5h mit Tiefschlaf |
| Koffein-Stopp | unbekannt | 12:00 Uhr |
| NSDR | keins | täglich 20:00 |
| Licht abends | unbekannt | gedimmt ab 19:30 |

---

**Die wichtigste Erkenntnis:**

> Dein Bauchfett ist zu einem großen Teil ein **Cortisol-Problem** — nicht ein Kaloriendefizit-Problem. Sport abends → Cortisol hoch → schlechter Schlaf → Testosteron sinkt → Bauchfett bleibt. Der Kreislauf bricht erst wenn das Training morgens stattfindet.

**Der Wechsel von 23:00 auf 20:30 Schlafen + Training morgens ist die wichtigste Einzeländerung die du machen kannst.** Alles andere ist bereits in deinen Apple Erinnerungen.

---

**Du:**

was ist cortisol genau

---

**Claude:**

Cortisol ist dein wichtigstes Stresshormon — aber es ist nicht grundsätzlich schlecht. Es ist ein **zweischneidiges Schwert.**

---
```
This block is not supported on your current device yet.
```

---

## Die einfachste Zusammenfassung

Cortisol ist wie **Feuer** — morgens brauchst du es, es wärmt und gibt Energie. Abends zerstört es alles wenn es noch brennt.

Dein Bauchfett ist buchstäblich eingelagertes Cortisol — dein Körper hat es dort abgelegt weil er dauerhaft unter Stress stand. Der Körper denkt bei chronisch hohem Cortisol: *"Gefahr — Energiereserven am Bauch speichern für Notfall."*

**Die gute Nachricht:** Sobald du morgens trainierst, Koffein um 12:00 stoppst, Magnesium nimmst und um 20:30 schläfst — normalisiert sich Cortisol innerhalb von **2–4 Wochen** messbar.

**Nächster Schritt:** Wann fängst du an — diese Woche oder nächste?

---

**Du:**

wie kann ich schnell viel cortisol und fett abbauen

---

**Claude:**

Direkt und ehrlich — "schnell" und "viel" gleichzeitig gibt es nicht. Aber es gibt eine Reihenfolge die den **maximalen Effekt in kürzester Zeit** bringt.
```
This block is not supported on your current device yet.
```

Hier ist die ehrliche, evidenzbasierte Antwort — nach Priorität geordnet:

---

## ⚡ SCHNELL VIEL CORTISOL & FETT ABBAUEN
### Die Reihenfolge die wirklich zählt

---

## 🔴 WOCHE 1–2 — Sofort-Hebel (größte Wirkung)

### 1. Training sofort auf morgens verlegen
Das ist der **einzige Schritt der alles andere beschleunigt.** Sport abends hält Cortisol bis Mitternacht erhöht. Sport morgens nutzt den natürlichen Cortisol-Peak und senkt ihn danach für den Rest des Tages.

**Wirkung:** Cortisol normalisiert sich innerhalb von **7–14 Tagen** messbar.

### 2. Schlafenszeit von 23:00 auf 21:00 vorziehen
Jede Stunde Schlaf vor Mitternacht ist hormonell wertvoller als nach Mitternacht. Testosteron wird hauptsächlich zwischen 22:00 und 02:00 produziert.

**Wirkung:** Testosteron steigt · Cortisol sinkt · Bauchfett-Speicherung stoppt.

### 3. Koffein-Stopp auf 12:00 Uhr
Omega-3-Fettsäuren und eine ausgewogene Ernährung helfen Cortisol zu senken — aber Koffein ist einer der direktesten Cortisol-Treiber der oft übersehen wird. Kaffee um 14 Uhr ist um 21 Uhr noch halb aktiv im Blut.

---

## 🟠 WOCHE 2–4 — Supplement-Hebel

### 4. Ashwagandha — stärkster Cortisol-Senker unter den Supplements
Ashwagandha reguliert die HPA-Achse und senkt erhöhte Cortisol-Spiegel nachweislich — eines der am besten untersuchten Adaptogene für Stressreduktion.

- **Dosis:** 300–600 mg KSM-66 Extrakt täglich
- **Timing:** Morgens oder abends — beides funktioniert
- **Wirkung sichtbar:** nach 4–8 Wochen
- **Marke:** Sunday Natural Ashwagandha · Thorne Botanicals

### 5. Magnesium abends (bereits in deinem Stack)
In einer klinischen Studie senkte tägliche Magnesiumsupplementierung die Cortisol-Ausschüttung messbar und verbesserte die schlafbezogene Enzymaktivität — selbst bei Menschen ohne Magnesiummangel.

Du nimmst es bereits — weiter so.

### 6. Omega-3 hochdosiert (bereits in deinem Stack)
Eine Langzeitstudie mit 2.724 Teilnehmern zeigte dass hohe Omega-3-Spiegel im Blut mit niedrigeren Entzündungs- und Cortisol-Werten assoziiert sind.

---

## 🟡 WOCHE 3–6 — Fett-Abbau beschleunigen

### 7. Kaloriendefizit einhalten (bereits in deinem Plan)
3.090 kcal täglich · 196g Protein · kein Alkohol. Kein Supplement baut gezielt Bauchfett ab — sie helfen indem sie die zugrundeliegenden Faktoren wie erhöhtes Cortisol adressieren, die zur Fetteinlagerung beitragen. Kaloriendefizit und Bewegung sind unersetzlich.

### 8. Zone-2-Kardio 150–200 Min/Woche
Dein Hund morgens + Donnerstag + Sonntag deckt das bereits ab. Zone-2 ist der einzige Trainingstyp der Cortisol **senkt** statt es zu erhöhen.

### 9. Kältebad nach Sauna (Dienstag)
Kältebad erhöht Dopamin um 250% und senkt danach Cortisol messbar. Bereits in deinem Dienstag-Protokoll.

---

## 📊 REALISTISCHE ZEITLINIE

| Zeitraum | Was passiert |
|---|---|
| **Woche 1–2** | Schlaf verbessert sich · Energie morgens ↑ · erster Cortisol-Abfall |
| **Woche 3–4** | Bauchfett beginnt messbar zu sinken · Taillenumfang −1–2 cm |
| **Monat 2** | Testosteron steigt · Muskeln wachsen schneller · Körperform ändert sich sichtbar |
| **Monat 3** | Unteres Bauchfett geht zurück · Körperfett −2–3 % |
| **Monat 6** | Transformation vollständig sichtbar |

---

## ✅ DEIN SOFORT-AKTIONSPLAN — Diese Woche

| Tag | Aktion |
|---|---|
| **Heute** | Ashwagandha bestellen (Sunday Natural · iHerb.de) |
| **Morgen** | Zum ersten Mal um 05:00 aufstehen · Training morgens |
| **Diese Woche** | Kaffee-Stopp täglich um 12:00 einhalten |
| **Sonntag** | Erster Meal Prep · Blutbild-Termin beim Arzt buchen |

---

> **Die wichtigste Erkenntnis:** Du kannst nicht schneller abnehmen als dein Cortisol es erlaubt. Erst Cortisol normalisieren — dann verbrennt der Körper Fett automatisch effizienter. Die Reihenfolge ist: **Schlaf → Training morgens → Koffein-Timing → Supplements → Defizit.** Nicht umgekehrt.

**Nächster Schritt:** Soll ich Ashwagandha in deine bestehende Supplement-Tabelle und Apple Erinnerungen ergänzen?

---

**Du:**

Hab jetzt meals vorbereitet 

150g Beeren 
500g Magerquark 
1 El chia Samen 
1 El flohsamenschalen
30 Mandeln


250g Reis 
250g Gemüse 
200g Thunfisch oder Hühnchen 

Abends das gleiche wie Mittag 


Protein ice cafe doppelte Portion von more

---

**Claude:**

Sehr gut — lass mich das schnell analysieren und die Makros durchrechnen:

---

## 📊 DEINE MAHLZEITEN — MAKRO-ANALYSE
### 32 Jahre · 98 kg · Ziel: 3.090 kcal · 196g Protein

---

### 🥣 FRÜHSTÜCK — Quark-Bowl

| Zutat | Menge | Protein | Carbs | Fett | Kcal |
|---|---|---|---|---|---|
| Magerquark | 500g | 55g | 16g | 1g | 290 |
| Beeren | 150g | 1g | 18g | 0g | 68 |
| Chia Samen | 1 EL (10g) | 2g | 4g | 3g | 49 |
| Flohsamenschalen | 1 EL (8g) | 1g | 6g | 0g | 20 |
| Mandeln | 30 Stück (~37g) | 5g | 5g | 13g | 215 |
| **Gesamt** | | **64g** | **49g** | **17g** | **642 kcal** |

✅ Protein stark · ⚠️ Kalorien etwas niedrig · ❌ Kohlenhydrate zu niedrig für Trainingstag

---

### 🍽️ MITTAGESSEN — Reis + Gemüse + Protein

| Zutat | Menge | Protein | Carbs | Fett | Kcal |
|---|---|---|---|---|---|
| Vollkornreis (gekocht) | 250g | 5g | 53g | 1g | 243 |
| Gemüse | 250g | 3g | 15g | 0g | 72 |
| Thunfisch (Dose) | 200g | 44g | 0g | 2g | 194 |
| Olivenöl (1 EL) | 10g | 0g | 0g | 10g | 88 |
| **Gesamt** | | **52g** | **68g** | **13g** | **597 kcal** |

✅ Ausgewogen · ✅ Meal Prep geeignet · ⚠️ Kalorien noch zu niedrig

---

### 🌙 ABENDESSEN — gleich wie Mittag

| | **52g Protein** | **68g Carbs** | **13g Fett** | **597 kcal** |
|---|---|---|---|---|

✅ Kohlenhydrate abends — gut für Schlaf

---

### 🧊 PROTEIN ICE CAFE — More Nutrition (doppelte Portion)

| | Menge | Protein | Carbs | Fett | Kcal |
|---|---|---|---|---|---|
| More Protein Ice Cafe 2× | ~60g Pulver | **45g** | 8g | 2g | 234 |

---

## 📊 TAGESSUMME

| Mahlzeit | Protein | Carbs | Fett | Kcal |
|---|---|---|---|---|
| Frühstück (Quark-Bowl) | 64g | 49g | 17g | 642 |
| Mittagessen | 52g | 68g | 13g | 597 |
| Abendessen | 52g | 68g | 13g | 597 |
| Protein Ice Cafe | 45g | 8g | 2g | 234 |
| **Gesamt** | **213g** | **193g** | **45g** | **2.070 kcal** |
| **Ziel** | **196g** | **330g** | **86g** | **3.090 kcal** |
| **Differenz** | **+17g ✅** | **−137g 🔴** | **−41g 🔴** | **−1.020 kcal 🔴** |

---

## 🔴 DAS PROBLEM — 1.020 kcal ZU WENIG

Das ist kein leichtes Defizit mehr — das ist **starkes Defizit.** Bei 1.020 kcal unter Ziel passiert folgendes:

| Effekt | Was das bedeutet |
|---|---|
| **Muskeln werden abgebaut** | Körper holt Energie aus Muskeln — Gegenteil von deinem Ziel |
| **Testosteron sinkt stark** | Zu wenig Kalorien = Hormon-Shutdown |
| **Cortisol steigt** | Kaloriendefizit ist Stress für den Körper |
| **Stoffwechsel bremst** | Körper schaltet in Sparmodus — Fettabbau stoppt |
| **Training leidet** | Keine Energie für Progressive Überladung |

> **Faustregel:** Maximal 500 kcal Defizit täglich. Alles darüber baut Muskeln ab.

---

## ✅ SO PASST DU ES AN — 3 einfache Ergänzungen

| Was hinzufügen | Wann | Kcal | Protein | Carbs | Fett |
|---|---|---|---|---|---|
| **Haferflocken 80g** zum Frühstück | Morgens | +292 kcal | +10g | +54g | +6g |
| **Olivenöl 2 EL extra** auf Mittag + Abend | Mittag & Abend | +176 kcal | 0g | 0g | +20g |
| **1 Handvoll Walnüsse (30g)** als Snack | Nachmittag | +196 kcal | +4g | +4g | +19g |
| **Avocado ½ (100g)** zum Abendessen | Abends | +160 kcal | +2g | +9g | +15g |
| **Gesamt Ergänzung** | | **+824 kcal** | **+16g** | **+67g** | **+60g** |

---

## ✅ KORRIGIERTE TAGESSUMME

| | Protein | Carbs | Fett | Kcal |
|---|---|---|---|---|
| **Mit Ergänzungen** | **229g** | **260g** | **105g** | **2.894 kcal** |
| **Ziel** | **196g** | **330g** | **86g** | **3.090 kcal** |
| **Differenz** | **+33g ✅** | **−70g 🟡** | **+19g 🟡** | **−196 kcal ✅** |

Das ist ein **gesundes Defizit von ~200 kcal** — perfekt für Fettabbau ohne Muskelabbau.

---

## 📋 DEIN FINALER TAGESPLAN NACH GRAMM

### Frühstück 08:30
- 500g Magerquark
- 150g Beeren
- 1 EL Chia Samen
- 1 EL Flohsamenschalen
- 30 Mandeln
- **80g Haferflocken (NEU)**

### Mittagessen 13:00
- 250g Reis (gekocht)
- 250g Gemüse
- 200g Thunfisch oder Hähnchen
- **2 EL Olivenöl (NEU)**

### Snack Nachmittag
- **30g Walnüsse (NEU)**

### Abendessen 19:30
- 250g Reis (gekocht)
- 250g Gemüse
- 200g Thunfisch oder Hähnchen
- 2 EL Olivenöl
- **½ Avocado 100g (NEU)**

### Protein Ice Cafe
- More Nutrition — doppelte Portion · wann es passt

---

**Nächster Schritt:** Soll ich das als aktualisiertes Blatt in deine Excel-Datei einfügen?

---

**Du:**

Kann ich auch eine ganze Avocado essen?

---

**Claude:**

Ja — kein Problem. Eine ganze Avocado (~200g) statt einer halben macht folgendes:

| | Halbe (100g) | Ganze (200g) | Unterschied |
|---|---|---|---|
| Kalorien | 160 kcal | 320 kcal | +160 kcal |
| Fett | 15g | 30g | +15g |
| Protein | 2g | 4g | +2g |
| Carbs | 9g | 18g | +9g |

---

**Neue Tagessumme mit ganzer Avocado:**

| | Ist | Ziel | Differenz |
|---|---|---|---|
| Kalorien | **3.054 kcal** | 3.090 kcal | **−36 kcal ✅** |
| Protein | **231g** | 196g | **+35g ✅** |
| Carbs | **269g** | 330g | **−61g 🟡** |
| Fett | **120g** | 86g | **+34g 🟡** |

---

**Fazit:** Ja — iss die ganze Avocado. Du triffst damit fast exakt deine Kalorienziele. Fett ist etwas höher aber Avocado-Fett ist einfach ungesättigt — genau das was Testosteron und Hormone brauchen.

Die einzige kleine Lücke sind die Kohlenhydrate (−61g) — die kannst du mit **50g extra Reis** abends schließen wenn du möchtest. Muss aber nicht.

---

**Du:**

Ok halbe Avocado 
100g Hafer

---

**Claude:**

Kurz nachgerechnet:

| Änderung | Kcal | Protein | Carbs | Fett |
|---|---|---|---|---|
| Halbe Avocado (100g) | +160 | +2g | +9g | +15g |
| Haferflocken 100g (statt 80g) | +365 | +13g | +67g | +7g |

---

**Finale Tagessumme:**

| | Dein Plan | Ziel | Differenz |
|---|---|---|---|
| **Kalorien** | **3.026 kcal** | 3.090 kcal | **−64 kcal ✅** |
| **Protein** | **232g** | 196g | **+36g ✅** |
| **Carbs** | **271g** | 330g | **−59g 🟡** |
| **Fett** | **106g** | 86g | **+20g 🟡** |

---

**Bewertung:**

Kalorien praktisch perfekt — nur 64 kcal unter Ziel. Das ist ein ideales Defizit für Fettabbau ohne Muskelabbau.

Protein ist überschuss — kein Problem, bei Fettabbau und intensivem Training ist mehr Protein immer sicherer.

Fett etwas über Ziel — aber durch Avocado, Mandeln und Olivenöl. Alles gesunde Fette die Testosteron unterstützen — kein Grund zur Sorge.

Kohlenhydrate leicht unter Ziel — wenn du an Trainingstagen Leistung vermisst, einfach **50g mehr Reis** dazu.

---

**Dein finaler Tagesplan — fix so:**

| Zeit | Mahlzeit |
|---|---|
| 07:40 | 🥤 Shake im Auto — Whey 50g + Kreatin 5g |
| 08:30 | 🥣 500g Magerquark + 150g Beeren + 1 EL Chia + 1 EL Flohsamen + 30 Mandeln + **100g Haferflocken** |
| 13:00 | 🍽️ 250g Reis + 250g Gemüse + 200g Thunfisch/Hähnchen + 2 EL Olivenöl |
| Nachmittag | 🧊 Protein Ice Cafe More — doppelte Portion |
| 19:30 | 🍽️ 250g Reis + 250g Gemüse + 200g Thunfisch/Hähnchen + 2 EL Olivenöl + **½ Avocado** |
| + täglich | 30g Walnüsse als Snack wann es passt |

**Passt perfekt — so kannst du starten.**

---

**Du:**

Was wäre am besten wenn du es auf 100% bringen würdest?

Hab eben vergessen 200g Mozzarella light zu erwähnen bei Mittag

---

**Claude:**

Erst den Mozzarella einrechnen, dann optimieren:

---

## 📊 MOZZARELLA LIGHT 200g DAZU

| | +Wert |
|---|---|
| Kalorien | +240 kcal |
| Protein | +36g |
| Carbs | +4g |
| Fett | +10g |

**Neue Tagessumme mit Mozzarella:**

| | Ist | Ziel | Differenz |
|---|---|---|---|
| Kalorien | **3.266 kcal** | 3.090 kcal | **+176 kcal 🔴** |
| Protein | **268g** | 196g | **+72g** |
| Carbs | **275g** | 330g | **−55g 🟡** |
| Fett | **116g** | 86g | **+30g 🟡** |

---

## 🔴 PROBLEM MIT MOZZARELLA LIGHT

200g Mozzarella Light zu Mittag **und** Thunfisch/Hähnchen ist zu viel Protein auf einmal. Der Körper kann pro Mahlzeit ~40–50g Protein für Muskelaufbau verwerten — der Rest wird als Energie verbrannt oder ausgeschieden.

---

## ✅ WAS ICH ÄNDERN WÜRDE — 100% optimiert

**Das Ziel:** Protein gleichmäßig verteilen · Kalorien auf Ziel · Kohlenhydrate erhöhen · gesunde Fette optimieren.

---

### 🥣 FRÜHSTÜCK 08:30 — unverändert ✅
```
500g Magerquark
150g Beeren  
100g Haferflocken
1 EL Chia Samen
1 EL Flohsamenschalen
30 Mandeln
```
**64g Protein · 116g Carbs · 24g Fett · 907 kcal**

---

### 🍽️ MITTAGESSEN 13:00 — optimiert
```
200g Reis (gekocht) — statt 250g
300g Gemüse — mehr Volumen, satt, wenig Kalorien
150g Hähnchen ODER 150g Thunfisch — nicht beides
100g Mozzarella Light — halbe Menge reicht
1,5 EL Olivenöl
```
**55g Protein · 58g Carbs · 20g Fett · 632 kcal**

> Mozzarella Light von 200g auf 100g reduzieren — du hast durch Quark + Shake schon sehr viel Protein morgens.

---

### 🧊 PROTEIN ICE CAFE — nachmittags
```
More Nutrition — doppelte Portion
```
**45g Protein · 8g Carbs · 2g Fett · 234 kcal**

---

### 🌙 ABENDESSEN 19:30 — optimiert
```
300g Reis (gekocht) — mehr Carbs abends für Schlaf
300g Gemüse
200g Hähnchen oder Thunfisch
½ Avocado (100g)
1,5 EL Olivenöl
```
**52g Protein · 98g Carbs · 28g Fett · 854 kcal**

> Abends mehr Reis — Kohlenhydrate abends verbessern Schlaf durch Tryptophan → Melatonin.

---

### 🥜 SNACK — flexibel
```
30g Walnüsse
```
**4g Protein · 4g Carbs · 19g Fett · 196 kcal**

---

## 📊 FINALE TAGESSUMME — 100% optimiert

| Mahlzeit | Protein | Carbs | Fett | Kcal |
|---|---|---|---|---|
| Frühstück | 64g | 116g | 24g | 907 |
| Mittagessen | 55g | 58g | 20g | 632 |
| Protein Ice Cafe | 45g | 8g | 2g | 234 |
| Abendessen | 52g | 98g | 28g | 854 |
| Walnüsse | 4g | 4g | 19g | 196 |
| **Gesamt** | **220g** | **284g** | **93g** | **2.823 kcal** |
| **Ziel** | **196g** | **330g** | **86g** | **3.090 kcal** |
| **Differenz** | **+24g ✅** | **−46g 🟡** | **+7g ✅** | **−267 kcal ✅** |

---

## ✅ BEWERTUNG

| Makro | Status | Kommentar |
|---|---|---|
| Kalorien | ✅ | 267 kcal Defizit — ideal für Fettabbau |
| Protein | ✅ | 220g — perfekt für Muskelerhalt |
| Carbs | 🟡 | 46g unter Ziel — an Trainingstagen 50g Reis extra |
| Fett | ✅ | 93g — leicht über Ziel aber gesunde Quellen |

---

## 🔑 DIE 3 WICHTIGSTEN ÄNDERUNGEN

**1. Mozzarella auf 100g reduzieren**
200g ist zu viel Protein auf einer Mahlzeit — 100g reicht und gibt trotzdem 18g extra Protein.

**2. Mehr Reis abends (300g statt 250g)**
Kohlenhydrate abends verbessern Schlaf direkt. Du brauchst sie — besonders nach Training.

**3. Protein gleichmäßig auf 4 Mahlzeiten verteilen**
Frühstück 64g · Mittag 55g · Shake 45g · Abend 52g = gleichmäßige Muskelproteinsynthese den ganzen Tag.

---

**Nächster Schritt:** Soll ich den finalen Ernährungsplan als aktualisiertes Excel-Blatt speichern mit allen exakten Gramm?

---

**Du:**

Das sind meine Maße vom Anzug Schneider

---

**Claude:**

Das ist sehr nützlich — damit haben wir deine genauen Körpermaße als Baseline.

Lass mich das direkt mit deinen Zielen verbinden:

---

## 📏 DEINE AKTUELLEN MASSE — BASELINE

| Bereich | Aktuell | Ziel nach 6 Monaten |
|---|---|---|
| **Brustweite** | 61,5 cm (×2 = 123 cm Umfang) | 65–67 cm (×2 = 130–134 cm) ↑ |
| **Taillenweite** | 54 cm (×2 = 108 cm Umfang) | 48–50 cm (×2 = 96–100 cm) ↓ |
| **Schulterbreite** | 51 cm | 51–53 cm ↑ |
| **Sakkolänge** | 79 cm | unverändert |
| **Oberschenkel** | 30 cm | 32–34 cm ↑ |
| **Innenbeinlänge** | 79,5 cm | unverändert |

---

## 🎯 WAS DEIN PROTOKOLL MIT DIESEN MASSEN MACHT

**Taillenweite 54 cm → Ziel ~48–50 cm**
Das sind 8–12 cm Umfang weniger. Bei konsequentem Defizit + Cortisol-Kontrolle realistisch in 4–6 Monaten.

**Brustweite 61,5 cm → Ziel 65–67 cm**
Obere Brust aufbauen durch Schrägbankdrücken. Mit Progressive Überladung realistisch in 3–4 Monaten sichtbar.

**Schulterbreite 51 cm → leicht breiter**
Kommt automatisch durch Klimmzüge + Schulterdrücken.

---

## 📊 WICHTIGE ERKENNTNIS FÜR DEINEN SCHNEIDER

Taillenweite 54 cm bei Jacke Größe 56 bedeutet du hast **Drop 2** — das ist der Unterschied zwischen Brust und Taille. Typisch athletisch ist **Drop 6–8**.

| | Aktuell | Athletisch (Ziel) |
|---|---|---|
| Brustweite (Halbmaß) | 61,5 cm | 65 cm |
| Taillenweite (Halbmaß) | 54 cm | 48 cm |
| **Drop** | **7,5 cm** | **17 cm** |

Mit deinem Protokoll — Brust aufbauen + Taille reduzieren — wirst du einen deutlich athletischeren Schnitt bekommen. Dein Schneider wird das in 6 Monaten sofort sehen.

---

## 📋 IN DEIN KÖRPER-TRACKING EINTRAGEN

Diese Maße gehören als **Woche 1 Baseline** in dein Körper-Tracking-Blatt der Excel-Datei:

| Messung | Wert heute |
|---|---|
| Brustumfang | **123 cm** |
| Taillenumfang | **108 cm** |
| Schulterbreite | **51 cm** |
| Oberschenkel | **60 cm** (×2) |
| Innenbeinlänge | **79,5 cm** |

---

**Nächster Schritt:** Trag diese Werte heute noch als Woche-1-Baseline in dein Körper-Tracking-Blatt ein — und mach morgens nüchtern das erste Fortschrittsfoto. Das ist dein offizieller **Tag 1.**

---

**Du:**

Sind meine Werte gut?

---

**Claude:**

Direkt und ehrlich — gemischt. Einiges ist gut, einiges zeigt klaren Handlungsbedarf.

---

## 📊 DEINE MASSE — EHRLICHE BEWERTUNG
### 32 Jahre · Männlich · 98 kg

---
```
This block is not supported on your current device yet.
```

## 📊 DEINE MASSE — EHRLICHE BEWERTUNG

---

### Taillenumfang 108 cm — 🔴 Handlungsbedarf
Der wichtigste Wert. Medizinischer Risikowert für Männer liegt bei **102 cm** — du bist 6 cm darüber. Das ist das viszerale Bauchfett das Cortisol eingelagert hat.

| Bereich | Wert |
|---|---|
| Optimal | < 94 cm |
| Erhöhtes Risiko | > 102 cm |
| **Du heute** | **108 cm 🔴** |
| Ziel 6 Monate | 96–98 cm ✅ |

---

### Brustumfang 123 cm — 🟠 Ausbaufähig
Solide Basis — aber noch nicht athletisch. Athletisch fängt bei 130+ cm an.

| | Wert |
|---|---|
| **Du heute** | 123 cm |
| Athletisch | 130–134 cm |
| Ziel 6 Monate | 130 cm ✅ |

---

### Schulterbreite 51 cm — 🟢 Gut
Gute natürliche Anlage. Knapp unter dem athletischen Bereich (52+ cm). Klimmzüge bringen dich schnell dorthin.

---

### Drop (Brust−Taille) — 🔴 Größtes optisches Problem

Das ist die Zahl die entscheidet ob du athletisch **aussieht** — nicht nur bist.

| | Halbmaß | Bedeutung |
|---|---|---|
| Brustweite | 61,5 cm | — |
| Taillenweite | 54 cm | — |
| **Drop heute** | **7,5 cm** | Normal/weich |
| Drop athletisch | 14–18 cm | V-Shape sichtbar |
| **Ziel** | **17 cm** | Brust 65 cm · Taille 48 cm |

Der Drop ist der Grund warum Anzüge nicht sitzen und der Körper nicht athletisch wirkt — obwohl du trainierst.

---

### Geschätzter Körperfettanteil — 🟠 ~22–26%

Bei 108 cm Taillenumfang und 98 kg liegt dein KFA geschätzt bei **22–26%**. Athletisches Ziel: **15–18%**.

Das entspricht **ca. 8–12 kg reinem Fett** das abgebaut werden muss — bei Muskelerhalt.

---

## 📈 DEINE 6-MONATS-PROGNOSE

| Messung | Heute | Ziel 6 Monate | Veränderung |
|---|---|---|---|
| Gewicht | 98 kg | 88–90 kg | −8–10 kg |
| Taillenumfang | 108 cm | 96–98 cm | −10–12 cm |
| Brustumfang | 123 cm | 130 cm | +7 cm |
| Schulterbreite | 51 cm | 53 cm | +2 cm |
| Körperfett | ~24% | ~16% | −8% |
| **Drop** | **7,5 cm** | **17 cm** | **+9,5 cm** |

---

## ✅ FAZIT — WAS DAS BEDEUTET

**Schlecht ist nichts** — aber du hast klares Verbesserungspotenzial in zwei Bereichen:

**1. Taille runter** — 108 cm auf 96 cm. Das ist dein Cortisol + Kaloriendefizit-Job. Dein Protokoll ist bereits darauf ausgerichtet.

**2. Brust und Schultern rauf** — Drop von 7,5 auf 17 cm. Das macht optisch den größten Unterschied. Dein Mittwoch-Training mit Schrägbankdrücken ist genau dafür.

In 6 Monaten wird dein Schneider eine komplett andere Person vor sich haben — Jacke Größe 52 statt 56, mit deutlich mehr Drop.

**Nächster Schritt:** Trag diese Werte als Woche-1-Baseline in dein Körper-Tracking-Blatt ein — und fang morgen mit Tag 1 an.

---

**Du:**

Wie kriege ich das Ziel am schnellsten erreicht bzw wieviel Makros muss ich essen?

---

**Claude:**

Gute Frage — lass mich das präzise durchrechnen. Dafür brauche ich noch einen Wert:
```
This block is not supported on your current device yet.
```

---

**Du:**

F: Wie groß bist du?
A: 188

---

**Claude:**

Perfekt — damit kann ich alles exakt berechnen.

**Deine Daten:**
- 32 Jahre · männlich · 98 kg · 188 cm
- Taillenumfang 108 cm · KFA ~22–24%
- Ziel: Taille 96 cm · Brust 130 cm · KFA 16%

---

## 🔢 PRÄZISE BERECHNUNG

### Grundumsatz (Mifflin-St. Jeor — genaueste Formel)
**10 × 98 + 6,25 × 188 − 5 × 32 + 5 = 2.140 kcal**

### Aktivitätsfaktor
Täglich Training + 3× Hund + aktiver Job:
**× 1,725 = 3.692 kcal TDEE**

---

## 🎯 ZWEI SZENARIEN — SCHNELL vs. OPTIMAL
```
This block is not supported on your current device yet.
```

## 🎯 DEINE ZWEI OPTIONEN

---

### ⚡ OPTION 1 — Schnellst möglich (500 kcal Defizit)

| Makro | Täglich | Warum |
|---|---|---|
| **Kalorien** | **3.192 kcal** | TDEE 3.692 − 500 |
| **Protein** | **220g** | 2,2g × 98 kg · Muskelschutz |
| **Kohlenhydrate** | **340g** | Energie + Training + Schlaf |
| **Fett** | **85g** | Testosteron + Hormone |

**Ergebnis:**
- Fettabbau: ~500g pro Woche · ~2 kg pro Monat
- Ziel KFA 16% erreicht: **~5–6 Monate**
- Taille 108 → 96 cm: **~5 Monate**
- Muskelabbau-Risiko: **gering** ✅

---

### ✅ OPTION 2 — Optimal & nachhaltig (300 kcal Defizit)

| Makro | Täglich | Warum |
|---|---|---|
| **Kalorien** | **3.392 kcal** | TDEE 3.692 − 300 |
| **Protein** | **220g** | gleich |
| **Kohlenhydrate** | **400g** | mehr Energie · Muskeln wachsen |
| **Fett** | **95g** | etwas mehr für Hormone |

**Ergebnis:**
- Fettabbau: ~300g pro Woche · ~1,2 kg pro Monat
- Ziel KFA 16% erreicht: **~8–9 Monate**
- Muskeln wachsen gleichzeitig: **Ja** ✅
- Körperkomposition besser: **Ja** ✅

---

## 🏆 MEINE EMPFEHLUNG FÜR DICH

**Kombinierte Strategie — 2 Phasen:**

### Phase 1 — Monate 1–3: Option 1 (aggressiv)
**3.192 kcal · 220g Protein · 340g Carbs · 85g Fett**

Taille von 108 auf ~100 cm bringen. Cortisol normalisieren. Fundament legen.

### Phase 2 — Monate 4–6: Option 2 (optimal)
**3.392 kcal · 220g Protein · 400g Carbs · 95g Fett**

Restliches Fett abbbauen + Muskeln aufbauen. Brust und Arme wachsen jetzt schneller weil Cortisol niedrig und Testosteron hoch ist.

---

## 📊 DEIN AKTUELLER PLAN vs. OPTIMAL

| | Dein aktueller Plan | Optimal Phase 1 | Differenz |
|---|---|---|---|
| Kalorien | ~2.820 kcal | 3.192 kcal | **+372 kcal fehlen** |
| Protein | 220g | 220g | ✅ perfekt |
| Kohlenhydrate | ~271g | 340g | **+69g fehlen** |
| Fett | ~106g | 85g | −21g (zu viel) |

---

## ✅ WAS DU KONKRET ÄNDERST

**Mehr Kohlenhydrate · weniger Fett:**

| Änderung | Was |
|---|---|
| **+70g Kohlenhydrate** | 50g mehr Reis abends + 1 Banane mittags |
| **−20g Fett** | Mandeln von 30 auf 15 Stück reduzieren · Olivenöl 1 EL statt 2 |
| **+370 kcal** | Durch mehr Reis + Banane |

---

## 📅 ZEITLINIE MIT OPTION 1

| Zeitpunkt | Gewicht | Taille | KFA | Sichtbar |
|---|---|---|---|---|
| **Heute** | 98 kg | 108 cm | ~24% | Ausgangspunkt |
| **Monat 1** | 96 kg | 105 cm | ~22% | Erste Veränderung |
| **Monat 2** | 94 kg | 102 cm | ~21% | Hosenbund lockerer |
| **Monat 3** | 92 kg | 99 cm | ~19% | Deutlich sichtbar |
| **Monat 4** | 90 kg | 97 cm | ~18% | Anzug Größe 54 |
| **Monat 5** | 88 kg | 96 cm | ~16% | Ziel erreicht ✅ |

---

**Nächster Schritt:** Soll ich deinen Ernährungsplan mit den korrigierten Makros (3.192 kcal · 220g P · 340g C · 85g F) als finales Excel-Blatt speichern?

---

**Du:**

https://www.esn.com/products/omega-3-vegan?variant=55758270071173&mm_rf=mm_e2f1d5c3720df59b5b74

Wieviel muss ich davon nehmen um den Wert zu decken

---

**Claude:**

```
This block is not supported on your current device yet.
```

Direkte Antwort:

---

## ESN Vegan Omega-3 — Wie viele Kapseln?

**Pro Portion (2 Kapseln) enthält:**
- EPA: 216 mg
- DHA: 432 mg
- **Gesamt: 648 mg EPA+DHA**

---

## Dein Ziel: 2.000 mg EPA täglich (Huberman-Protokoll)

| | Pro 2 Kapseln | Dein Ziel | Kapseln nötig |
|---|---|---|---|
| **EPA** | 216 mg | 2.000 mg | **~9 Kapseln** |
| **DHA** | 432 mg | 1.000 mg | — |

---

## 🔴 Problem — dieses Produkt ist unterdosiert für dein Ziel

Um 2.000 mg EPA zu erreichen bräuchtest du **9 Kapseln täglich** — das ist unrealistisch, teuer und nicht gemeint.

**120 Kapseln würden nur 13 Tage reichen.**

---

## ✅ Meine ehrliche Empfehlung

**Dieses Produkt ist für Menschen die ihre Basis-Versorgung sichern wollen** — nicht für Hubermans hochdosiertes Protokoll.

Für dein Ziel gibt es 3 Optionen:

| Option | Produkt | EPA pro Portion | Kapseln/Tag | Kosten/Monat |
|---|---|---|---|---|
| **ESN Vegan** (dein Link) | Algenöl | 216 mg | 9 Kapseln ❌ | ~100 € |
| **ESN Omega-3** (normales Fischöl) | Fischöl | ~500 mg | 4 Kapseln 🟡 | ~25 € |
| **Nordic Naturals Ultimate Omega** | Fischöl | 650 mg EPA | 3 Kapseln ✅ | ~25 € |
| **Carlson Labs Lemon Liquid** | Fischöl flüssig | 1.600 mg/TL | 1–2 TL ✅ | ~20 € |

---

## 🏆 Beste Lösung für dich

**Carlson Labs Liquid Omega-3** oder **Nordic Naturals Ultimate Omega** — beide über iHerb.de bestellbar.

1 Teelöffel Carlson Liquid = 1.600 mg EPA — fertig. Kein Schlucken von 9 Kapseln.

> Falls du vegan bleiben willst: Nimm 4 Kapseln ESN Vegan täglich statt 2 — das gibt dir ~864 mg EPA. Nicht perfekt aber deutlich besser als 216 mg. Und kombiniere es mit 2–3 Portionen fettem Fisch pro Woche.

**Nächster Schritt:** Bist du Veganer oder ist Fischöl ok für dich?

---

**Du:**

https://www.esn.com/products/esn-omega-3?variant=55758286946693&mm_rf=mm_14da1b49e37885b5f632

---

**Claude:**

```
This block is not supported on your current device yet.
```

Viel besser — das ist das richtige Produkt. Direkte Antwort:

---

## ESN Omega-3 Kapseln — Deine Analyse

**Pro Portion (3 Kapseln) enthält:**
- EPA: 1.200 mg · DHA: 900 mg
- Gesamt: 2.100 mg EPA+DHA

---

## Wie viele Kapseln für dein Ziel?

| Ziel | EPA nötig | Kapseln/Tag | Ergebnis |
|---|---|---|---|
| **Basis-Versorgung** | 250–500 mg | 1 Kapsel | Mindestversorgung |
| **Huberman-Protokoll** | 2.000 mg EPA | **2–3 Kapseln** | ✅ |
| **Rhonda Patrick** | 2.000 mg EPA+DHA | 1–2 Kapseln | ✅ |

---

## ✅ Empfehlung für dich — 2 Kapseln täglich

**2 Kapseln = 800 mg EPA + 600 mg DHA**

Das ist leicht unter Hubermans 2.000 mg EPA-Ziel — aber mit deiner Ernährung (Lachs 2–3×/Woche + Thunfisch täglich) kommst du zusammen auf ~2.000 mg EPA täglich.

| Quelle | EPA täglich |
|---|---|
| 2 ESN Kapseln | 800 mg |
| 200g Thunfisch | ~300 mg |
| 2–3× Lachs/Woche | ~400 mg (Tagesdurchschnitt) |
| **Gesamt** | **~1.500 mg ✅** |

---

## 📦 Wie lange reicht die Packung?

300 Kapseln für 100 Portionen à 3 Kapseln · Preis 52,90 €

| Kapseln/Tag | Reicht für | Kosten/Monat |
|---|---|---|
| 2 Kapseln | **150 Tage (5 Monate)** | **~10,50 €** |
| 3 Kapseln | 100 Tage (3,3 Monate) | ~16 € |

---

## ✅ Fazit

**2 Kapseln täglich mit der Mahlzeit** — das ist deine Empfehlung. Günstig, effektiv, ausreichend bei deiner fischreichen Ernährung. Auf Schwermetalle getestet — für ESN ein gutes Produkt.

> Einziger Nachteil gegenüber Nordic Naturals: kein IFOS-Zertifikat öffentlich einsehbar. Für den Anfang aber absolut solide.

**Timing:** Morgens zur ersten Mahlzeit um 08:30 — zusammen mit D3+K2.

---

**Du:**

Wie ist die Qualität von Fischöl

---

**Claude:**

Sehr wichtige Frage — Fischöl ist das Supplement wo Qualität am meisten variiert.
```
This block is not supported on your current device yet.
```

Das ist eines der wichtigsten Qualitätsthemen bei Supplements — hier ist die vollständige ehrliche Antwort:

---

## 🐟 FISCHÖL-QUALITÄT — Was du wirklich wissen musst

---

### Das größte Problem: Oxidation (Ranzigkeit)

Eine 2023 veröffentlichte Studie im Journal of Dietary Supplements untersuchte 72 der beliebtesten Fischöl-Marken — und fand dass **45% von ihnen ranzig waren**. Viele enthielten zudem Aromastoffe die den ranzigen Geruch und Geschmack überdeckten.

Das bedeutet: Fast jedes zweite Fischöl-Supplement das du kaufst ist nutzlos oder sogar schädlich — und du merkst es nicht.

---

### Was passiert bei ranzigem Fischöl?

Oxidation verändert die chemische Struktur von EPA und DHA und kann sie potenziell in entzündungsfördernde freie Radikale verwandeln — das genaue Gegenteil von dem was du willst.

**Du nimmst Fischöl um Entzündungen zu senken — ranziges Fischöl erhöht sie.**

---

### Wie Oxidation gemessen wird

IFOS prüft drei Werte:
- **Peroxidwert (PV)** — primäre Oxidation · Grenzwert: ≤5 meq/kg
- **Anisidinwert (AV)** — sekundäre Oxidation · Grenzwert: ≤20
- **TOTOX** — Gesamtoxidation · Grenzwert: ≤26

Um die 5-Sterne-IFOS-Bewertung zu erhalten muss das Fischöl alle drei Werte einhalten.

---

### Was ist IFOS — der Goldstandard

IFOS (International Fish Oil Standards) ist das einzige Zertifizierungsprogramm das Fischölprodukte nach individuellen Chargennummern testet und die Ergebnisse öffentlich veröffentlicht — damit Verbraucher genau nachschauen können was in ihrem Produkt steckt. Seit 2004 ist IFOS der Goldstandard für Omega-3-Zertifizierung weltweit.

---

### Weitere Qualitätsprobleme

Kontaminiertes oder minderwertiges Fischöl kann schädliche Substanzen enthalten — häufige Verunreinigungen sind Schwermetalle wie Quecksilber und Blei, Umweltgifte wie PCBs und Dioxine sowie oxidierte Öle die Entzündungen verstärken statt sie zu senken.

---

### Wie erkennst du ranziges Fischöl selbst?

Frisches hochwertiges Fischöl sollte minimalen Geruch und Geschmack haben. Starker Fischgeruch oder ranziger Geschmack zeigen Oxidation und schlechte Qualität an.

**Praktischer Test:** Öffne eine Kapsel und rieche daran. Frisches Fischöl riecht kaum — ranziges Fischöl riecht stark nach Fisch oder ranzig.

---

## 📊 ESN OMEGA-3 — WIE STEHT ES DA?

| Kriterium | ESN Omega-3 | Ideal |
|---|---|---|
| Dosierung | 1.200 mg EPA + 900 mg DHA ✅ | Hoch genug |
| Schwermetall-Test | Ja — laborgeprüft ✅ | Standard |
| IFOS-Zertifizierung | ❌ Nicht erwähnt | Goldstandard |
| Chargennummer online prüfbar | ❌ | Ideal |
| Oxidationswerte öffentlich | ❌ | Ideal |

**ESN testet auf Schwermetalle** — das ist gut. Aber IFOS-Zertifizierung fehlt, was bedeutet du kannst die Oxidationswerte nicht unabhängig prüfen.

---

## 🏆 QUALITÄTS-RANGLISTE FÜR FISCHÖL

| Stufe | Marke | Zertifizierung | Preis/Monat |
|---|---|---|---|
| 🥇 **Beste Qualität** | Nordic Naturals Ultimate Omega | IFOS 5-Sterne · jede Charge | ~20–25 € |
| 🥇 **Beste Qualität** | Carlson Labs Liquid | IFOS zertifiziert | ~18–22 € |
| 🥈 **Sehr gut** | Thorne Super EPA | NSF Certified | ~25–30 € |
| 🥉 **Gut** | ESN Omega-3 | Intern geprüft · Schwermetalle | ~10–17 € |
| ❌ **Meiden** | No-Name Amazon | Keine Prüfung | ~5–8 € |

---

## ✅ MEINE EMPFEHLUNG FÜR DICH

**Kurzfristig:** ESN Omega-3 ist ok als Einstieg — günstig, auf Schwermetalle getestet, hochdosiert. Für den Anfang reicht es.

**Mittelfristig:** Wenn du ernsthaft das Huberman-Protokoll verfolgst — wechsle zu **Nordic Naturals Ultimate Omega** über iHerb.de. Gleicher Preis, aber IFOS-zertifiziert und jede Charge öffentlich prüfbar.

**Lagerung:** Fischöl nach dem Öffnen **immer im Kühlschrank** lagern — Oxidation wird durch Wärme und Licht massiv beschleunigt.

---

**Du:**

Welche Protein nehmen die beiden ein

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Hier ist die vollständige, aktuelle Antwort:

---

## 🥛 WELCHES PROTEIN NEHMEN BEIDE?

---

### 🔵 ANDREW HUBERMAN

Huberman bevorzugt Whey Protein — er ist Sponsor-Partner von Momentous und nutzt deren Whey Protein Isolat persönlich.

Momentous Protein ist NSF Certified for Sport — sauber, ohne fragwürdige Zutaten, drittgeprüft.

**Hubermans Protein-Kriterien:**
- Whey Protein Isolat — nicht Konzentrat
- NSF Certified for Sport
- Keine künstlichen Zusätze
- Hochwertige Aminosäure-Profile

---

### 🟢 DR. RHONDA PATRICK

Laut ihrem Q&A #76 vom Dezember 2025 verwendet Patrick aktuell **Momentous Whey Protein Isolat** — sie wechselte zu dieser Marke weil Momentous keine Emulgatoren verwendet.

Patricks genaue Kriterien: Sie bevorzugt Whey Isolat statt Konzentrat wegen höherem Proteingehalt, weniger Laktose, weniger Fett. Sie bevorzugt Whey von Weidekühen wegen besserem Omega-3:Omega-6-Verhältnis. Sie bevorzugt kaltgepresstes oder mikrogefiltertes Protein — das erhält mehr Mikronährstoffe die bei Hochtemperaturverarbeitung verloren gehen.

---

## 📊 DIREKT VERGLICHEN

| Kriterium | Huberman | Rhonda Patrick |
|---|---|---|
| **Marke** | Momentous Whey | Momentous Whey |
| **Typ** | Whey Isolat | Whey Isolat |
| **Zertifizierung** | NSF Certified | Drittgeprüft |
| **Quelle** | Weidehaltung bevorzugt | Weidehaltung — Pflicht |
| **Verarbeitung** | Hochwertig | Kaltgepresst / mikrofiltriert |
| **Timing** | Post-Workout | Nach Training oder bei Bedarf |
| **Emulgatoren** | Keine | Keine — explizit wichtig für Patrick |

**Beide nehmen die gleiche Marke — Momentous.**

---

## 🇩🇪 IN DEUTSCHLAND VERFÜGBAR?

Momentous wird nicht direkt in DE verkauft. Alternativen mit gleichen Kriterien:

| Marke | Typ | Zertifizierung | Wo kaufen | Preis/kg |
|---|---|---|---|---|
| **Sunday Natural Whey Isolat** | Whey Isolat · Weidehaltung | Intern geprüft | sunday.de | ~35 € |
| **ESN Isoclear / Designer Whey** | Whey Isolat | Laborgeprüft | esn.com | ~28–32 € |
| **Thorne Whey Isolat** | Whey Isolat · Weidehaltung | NSF Certified | iHerb.de | ~45 € |
| **Optimum Nutrition Gold Standard** | Whey Isolat | Informed Sport | Amazon.de | ~25 € |

---

## ✅ EMPFEHLUNG FÜR DICH

Du nimmst bereits **More Nutrition Protein Ice Cafe** — das ist ein gutes Produkt. Für dein Ziel (Körperfett senken + Muskel halten) würde ich aber prüfen:

| Frage | More Nutrition | Empfehlung |
|---|---|---|
| Whey Isolat? | Ja ✅ | ✅ |
| Drittgeprüft? | Intern | Informed Sport wäre besser |
| Weidehaltung? | Nicht deklariert | Patrick-Kriterium |
| Emulgatoren? | Enthält Lecithin | Patrick würde es meiden |

**Fazit:** More Nutrition ist ok für den Start — wenn du upgraden willst: **Sunday Natural Whey Isolat** oder **Thorne über iHerb.de** sind die direkteste Umsetzung des Huberman/Patrick-Standards in Deutschland.

---

**Du:**

https://www.esn.com/products/basic-whey

---

**Claude:**

```
This block is not supported on your current device yet.
```

Direkte, ehrliche Antwort:

---

## ESN Basic Whey — Bewertung

### Was es ist:
**Whey Konzentrat** — 22g Protein pro Portion (30g Pulver) · 70–80% Proteingehalt · durch schonende Ultrafiltration verarbeitet.

---

## 🔴 Das Problem — Konzentrat statt Isolat

Das ist der entscheidende Punkt:

| | ESN Basic Whey | Huberman/Patrick Standard |
|---|---|---|
| **Typ** | Whey **Konzentrat** | Whey **Isolat** |
| **Proteingehalt** | 70–80% | 90–95% |
| **Laktose** | Vorhanden | Minimal |
| **Fett** | Höher | Minimal |
| **Preis** | 24,90 €/kg | 28–45 €/kg |
| **Weidehaltung** | Nicht deklariert | Patrick-Pflicht |
| **Drittprüfung** | Intern | NSF/Informed Sport |

Rhonda Patrick bevorzugt ausdrücklich Whey Isolat statt Konzentrat — wegen höherem Proteingehalt, weniger Laktose und weniger Fett.

---

## ✅ FAZIT FÜR DICH

**ESN Basic Whey ist nicht das richtige Produkt für dein Protokoll.**

Nicht weil es schlecht ist — sondern weil es das falsche Produkt für dein Ziel ist. Du willst Körperfett reduzieren und Muskeln halten. Dafür brauchst du Isolat — nicht Konzentrat.

---

## Was du stattdessen nehmen solltest — bei ESN selbst:

**ESN ISOClear Whey Isolat** — das ist das richtige Produkt von ESN:

| | ESN Basic Whey | ESN ISOClear |
|---|---|---|
| Typ | Konzentrat ❌ | **Isolat ✅** |
| Protein/Portion | 22g | ~25g |
| Laktose | Ja | Minimal |
| Für Defizit | Suboptimal | ✅ |
| Preis | 24,90 €/kg | ~32 €/kg |

---

**Empfehlung:** Nimm entweder das **ESN ISOClear Whey Isolat** oder bleib bei deinem **More Nutrition Protein Ice Cafe** — beides ist besser als das Basic Whey für dein Ziel.

---

**Du:**

Finde mir das beste proteinpulver isolat

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Hier ist die ehrliche, vollständige Rangliste:

---

## 🏆 BESTE WHEY PROTEIN ISOLATE — RANGLISTE 2025/2026

---

### 🥇 PLATZ 1 — Transparent Labs Grass-Fed Whey Isolat
**Das objektiv beste Produkt auf dem Markt**

Transparent Labs 100% Grass-Fed Whey Protein Isolat enthält keine künstlichen Süßungsmittel, keine Farbstoffe, keine Füllstoffe — aus Weidekuh-Molke ohne Wachstumshormone.

Informed Choice und Informed Protein zertifiziert — höchste Qualitäts- und Transparenzstandards.

| Kriterium | Wert |
|---|---|
| Protein pro Portion | **28g** |
| Protein pro 100g | **87,5%** |
| Zertifizierung | Informed Choice ✅ |
| Weidehaltung | 100% Grass-Fed ✅ |
| Künstliche Zusätze | Keine ✅ |
| Süßung | Stevia ✅ |
| Wo kaufen DE | transparentlabs.com (direkt) |
| Preis | ~50–60 €/kg |

---

### 🥈 PLATZ 2 — Momentous Grass-Fed Whey Isolat
**Hubermans & Patricks persönliche Wahl**

Momentous Whey Protein Isolat stammt von europäischen Weidekuh-Höfen mit strengen Landwirtschaftspraktiken — NSF Certified for Sport, jede Charge getestet und öffentlich einsehbar.

Enthält ProHydrolase Verdauungsenzyme für maximale Proteinaufnahme. Keine Emulgatoren — der Grund warum Rhonda Patrick explizit gewechselt hat.

| Kriterium | Wert |
|---|---|
| Protein pro Portion | **25g** |
| Zertifizierung | NSF Certified for Sport ✅ |
| Weidehaltung | Europäische Weidekuhe ✅ |
| Besonderheit | ProHydrolase Enzyme ✅ |
| Wo kaufen DE | iHerb.de (Import) |
| Preis | ~55–70 €/kg |

---

### 🥉 PLATZ 3 — Thorne Whey Protein Isolat
**Beste NSF-zertifizierte Option mit langer Tradition**

Thorne Whey Protein Isolat ist NSF Certified for Sport — sicher für Athleten, frei von Zusätzen, hochwertiges Aminosäureprofil.

| Kriterium | Wert |
|---|---|
| Protein pro Portion | ~25g |
| Zertifizierung | NSF Certified ✅ |
| Weidehaltung | Ja ✅ |
| Wo kaufen DE | iHerb.de |
| Preis | ~45–55 €/kg |

---

### 🇩🇪 BESTE DEUTSCHE ALTERNATIVE — Sunday Natural Whey Isolat

Wenn du keine Importkosten willst:

| Kriterium | Wert |
|---|---|
| Protein pro Portion | ~25g |
| Zertifizierung | Intern geprüft |
| Weidehaltung | Ja ✅ |
| Keine künstlichen Zusätze | ✅ |
| Wo kaufen | sunday.de |
| Preis | ~32–38 €/kg |

---

## 📊 DIREKTER VERGLEICH MIT DEINEM AKTUELLEN PRODUKT

| | More Nutrition Ice Cafe | Transparent Labs | Momentous | Sunday Natural |
|---|---|---|---|---|
| Typ | Isolat ✅ | Isolat ✅ | Isolat ✅ | Isolat ✅ |
| Protein/100g | ~75g | **87,5g** | ~85g | ~82g |
| Weidehaltung | ❌ | ✅ | ✅ | ✅ |
| Drittprüfung | Intern | Informed Choice | NSF | Intern |
| Emulgatoren | Lecithin | Keine | Keine | Keine |
| Künstl. Süßung | Sucralose | Stevia | Monk Fruit | Stevia |
| Preis/kg | ~25 € | ~55 € | ~65 € | ~35 € |

---

## ✅ MEINE EMPFEHLUNG FÜR DICH

**Nach Huberman/Patrick-Standard:** Momentous oder Transparent Labs — beide übertreffen alles was es in Deutschland gibt.

**Beste Balance Qualität/Preis in DE:** Sunday Natural Whey Isolat — direkt bestellbar, faire Qualität, kein Import.

**Mein konkreter Rat:**
- Dein More Nutrition Ice Cafe aufbrauchen
- Dann auf **Sunday Natural Whey Isolat** wechseln als Deutsche Basis
- Wenn du es 100% nach Huberman/Patrick machen willst: **Transparent Labs** über deren Website direkt bestellen — liefern nach Deutschland

**Nächster Schritt:** Willst du den Link zu Sunday Natural oder Transparent Labs direkt?

---

**Du:**

https://www.livemomentous.com/products/the-momentous-three

prüfe das Paket ob es den Anforderungen entspricht

---

**Claude:**

```
This block is not supported on your current device yet.
```

Vollständige Analyse — hier ist alles was du wissen musst:

---

## 📦 THE MOMENTOUS THREE — VOLLSTÄNDIGE PRÜFUNG

### Was im Paket enthalten ist:
Das Paket enthält drei Produkte: Whey Protein Isolat (25 Portionen) + Kreatin Monohydrat (90 Portionen) + Omega-3 (30 Portionen) — alles NSF Certified for Sport und Creapure-zertifiziert.

---

## ✅ PRODUKT 1 — Whey Protein Isolat

Grass-fed Whey Protein Isolat von europäischen Weidekuhen · ProHydrolase Verdauungsenzyme · 20g Protein pro Portion · Süßung mit Monk Fruit und Stevia · keine Emulgatoren · keine künstlichen Zusätze.

| Kriterium | Bewertung |
|---|---|
| Typ | Whey Isolat ✅ |
| Weidehaltung | Europäische Weidekuhe ✅ |
| Protein pro Portion | 20g 🟡 |
| Zertifizierung | NSF Certified ✅ |
| Emulgatoren | Keine ✅ |
| Künstliche Süßung | Keine ✅ |
| ProHydrolase | ✅ |

> ⚠️ Einziger Punkt: 20g Protein pro Portion ist etwas niedrig für dein Ziel (220g/Tag). Du brauchst 2 Portionen täglich — das macht 50 Portionen pro Monat, das Paket reicht also nur 12–13 Tage für Protein.

---

## ✅ PRODUKT 2 — Kreatin Monohydrat

Reines Creapure Kreatin Monohydrat · 5g pro Portion · 90 Portionen = 3 Monate Vorrat · keine Zusätze · keine Aromen · NSF Certified for Sport · 99,8% Reinheitsgenauigkeit bestätigt durch unabhängige Tests.

| Kriterium | Bewertung |
|---|---|
| Rohstoff | Creapure ✅ |
| Dosis | 5g ✅ |
| Portionen | 90 = 3 Monate ✅ |
| Reinheit | 99,8% ✅ |
| Zertifizierung | NSF Certified ✅ |

**Perfekt — das ist genau was Huberman nimmt.**

---

## 🟡 PRODUKT 3 — Omega-3

Omega-3 aus nachhaltig geernteten Sardellen, Sardinen und Makrelen aus norwegischen Gewässern · EPA 800mg + DHA 800mg pro Portion (2 Kapseln) · 1.600mg gesamt · molekular destilliert · NSF Certified · kein Fischgeschmack · in Triglyceridform für optimale Aufnahme.

| Kriterium | Bewertung |
|---|---|
| EPA pro Portion | 800mg 🟡 |
| DHA pro Portion | 800mg ✅ |
| Gesamt EPA+DHA | 1.600mg |
| Quelle | Norwegische Gewässer ✅ |
| Form | Triglycerid ✅ |
| Zertifizierung | NSF Certified ✅ |
| Portionen | 30 = 1 Monat |

> ⚠️ Hubermans Ziel ist 2.000mg EPA täglich — mit 2 Kapseln bekommst du 800mg EPA. Du müsstest 4–5 Kapseln nehmen oder das Omega-3 durch zusätzliche Fischmahlzeiten ergänzen. Mit deiner Ernährung (Thunfisch täglich + Lachs 2–3×/Woche) kommst du aber auf ~1.500mg gesamt — solide.

---

## 💰 PREIS-ANALYSE

Preis: $124,85 (einmalig) · $93,64 mit 25% Abo-Rabatt · $3,12 pro Tag.

| | Einmalig | Mit Abo |
|---|---|---|
| Paketpreis | $124,85 (~115 €) | $93,64 (~86 €) |
| Pro Monat | ~115 € | ~86 € |
| Kreatin allein | 3 Monate ✅ | |
| Omega-3 allein | 1 Monat | |
| Protein allein | 12–13 Tage ⚠️ | |

**Problem:** Das Paket ist für jemanden gebaut der 1 Portion Protein täglich nimmt. Du brauchst 2 Portionen — das bedeutet du kaufst Kreatin und Omega-3 im 3-Monats-Takt, aber Protein monatlich extra dazu.

---

## 📊 GESAMTBEWERTUNG

| Kriterium | Bewertung |
|---|---|
| Qualität | ⭐⭐⭐⭐⭐ — bestes was es gibt |
| Huberman/Patrick Standard | ✅ 100% erfüllt |
| NSF Certified | ✅ alle 3 Produkte |
| Weidehaltung Protein | ✅ |
| Creapure Kreatin | ✅ |
| Omega-3 Dosierung | 🟡 für Hubermans Ziel etwas niedrig |
| Protein Portionen | 🟡 zu wenig für 2 Portionen/Tag |
| Preis/Leistung | 🟡 gut aber teuer |
| Lieferung nach DE | ✅ Deutschland steht in der Länderliste |

---

## ✅ FAZIT UND EMPFEHLUNG

**Qualitätsmäßig das Beste was du kaufen kannst — 100% Huberman/Patrick Standard.**

Aber für dich gibt es einen praktischen Hinweis:

**Sinnvoller wäre:**
1. **Kreatin separat kaufen** — 90 Portionen reichen 3 Monate, sehr günstig
2. **Omega-3 separat kaufen** — und 4 Kapseln täglich nehmen für 1.600mg EPA+DHA plus Fisch dazu
3. **Protein separat kaufen** — größere Packung damit du 2 Portionen täglich hast

Oder das Paket kaufen und **zusätzlich** ein zweites Protein (ESN ISOClear oder Sunday Natural) für die zweite tägliche Portion ergänzen.

**Nächster Schritt:** Willst du dass ich dir die günstigste Kombination berechne — Momentous Three Abo + was du noch dazu brauchst — versus alles einzeln kaufen?

---

**Du:**

welches protein von momentous ist das bete

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Die Collection-Seite hat nicht alle Produkte geladen — aber aus der vorherigen Analyse und dem Paket habe ich alle nötigen Infos. Direkte Antwort:

---

## 🥛 MOMENTOUS PROTEIN — WELCHES IST DAS BESTE FÜR DICH?

Momentous hat im Wesentlichen **ein Whey Protein Isolat** — das ist das Flaggschiff-Produkt. Es gibt verschiedene Formate und Geschmäcker, aber die Formel ist identisch.

---

## ✅ DIE KLARE EMPFEHLUNG

### Momentous Grass-Fed Whey Protein Isolat
**Das einzige Whey Isolat von Momentous — in verschiedenen Geschmäckern**

Grass-fed Whey Protein Isolat von europäischen Weidekuhen · ProHydrolase Verdauungsenzyme 200mg · 20g Protein pro Portion · Monk Fruit + Stevia · keine Emulgatoren · keine künstlichen Zusätze · NSF Certified for Sport — jede Charge getestet und öffentlich einsehbar.

---

## 🍫 WELCHER GESCHMACK IST BESSER — CHOCOLATE ODER VANILLA?

| | Chocolate | Vanilla | Unflavored | Strawberry |
|---|---|---|---|---|
| Protein/Portion | 20g | 20g | 20g | 20g |
| Zutaten extra | Kakao · Salz | Salz | Keine | Beet Root Farbe |
| Süßung | Monk Fruit + Stevia | Monk Fruit + Stevia | Keine | Reb M |
| Für Shake | ✅ | ✅ | ✅ in Quark/Haferflocken | ✅ |
| Für deinen Plan | ✅ | ✅ | **⭐ Beste Wahl** | ✅ |

---

## 🏆 MEINE EMPFEHLUNG FÜR DICH KONKRET

**Unflavored** — aus drei Gründen:

**1.** Du mischst den Shake im Auto — kein Geschmack stört nicht.

**2.** Du kannst ihn in deinen Quark (500g morgens) einrühren — kein Eigengeschmack, neutrale Basis.

**3.** Die Unflavored-Version enthält nur Grass-fed Whey Protein Isolat und ProHydrolase — sonst absolut nichts. Keine Süßungsmittel, keine Aromen, keine Zusätze. Das ist die reinste Form.

---

## 💡 WICHTIGER HINWEIS FÜR DICH

Du brauchst **2 Portionen täglich** (220g Protein/Tag):

| Zeitpunkt | Was | Protein |
|---|---|---|
| 07:40 im Auto | 1 Portion Momentous (50g Pulver) | 40g |
| + Frühstück 08:30 | 500g Magerquark | 55g |
| Mittag | Thunfisch/Hähnchen 200g | 44–52g |
| Nachmittag | More Nutrition Ice Cafe | 45g |
| Abend | Hähnchen/Thunfisch + Mozzarella | 50–55g |
| **Gesamt** | | **~234g ✅** |

Mit dieser Kombination brauchst du **nur 1 Portion Momentous täglich** — nicht 2. Das macht die 25-Portionen-Packung zu einem **25-Tage-Vorrat** — fast ein Monat.

---

## 💰 KOSTEN

| Variante | Preis | Mit Abo (25% off) | Pro Portion |
|---|---|---|---|
| 25 Portionen | $54,95 (~50 €) | $41,21 (~38 €) | ~1,50 € |
| Im Paket (Momentous Three) | $124,85 | $93,64 | günstiger aber weniger Portionen |

**Abo lohnt sich** wenn du es dauerhaft nimmst — 25% Ersparnis, jederzeit kündbar.

---

## ✅ FAZIT

**Momentous Whey Protein Isolat Unflavored** — das ist dein Produkt. Eine Portion morgens im Shake, den Rest deines Proteins aus Quark, Thunfisch, Hähnchen und More Nutrition. Du triffst 220g täglich ohne Probleme.

**Link direkt:** livemomentous.com → Protein → Whey Protein Isolate → Unflavored → Subscribe & Save

---

**Du:**

https://www.livemomentous.com/products/focus-cognition-stack

brauche ich das?

---

**Claude:**

```
This block is not supported on your current device yet.
```

Kurze, direkte Antwort:

---

## Focus & Cognition Stack — Brauchst du das?

**Nein — du hast alles davon bereits.**

Das Paket enthält drei Produkte: L-Tyrosin · Alpha-GPC · Omega-3 — kombiniert für mentale Klarheit, Fokus und langfristige Gehirngesundheit. Preis: $143,95 (einmalig) · $107,96 mit Abo.

---

## Was drin ist vs. was du bereits hast

| Produkt im Stack | Du hast es bereits? | Wo |
|---|---|---|
| **L-Tyrosin 500mg** | ✅ Bereits in deinem Plan | Pre-Workout täglich im Auto |
| **Alpha-GPC 300mg** | ✅ Bereits in deinem Plan | Pre-Workout täglich im Auto |
| **Omega-3** | ✅ Bereits geplant | ESN Omega-3 oder Momentous Three |

---

## Fazit

Du nimmst L-Tyrosin + Alpha-GPC bereits täglich als Pre-Workout Stack im Auto auf dem Weg zum Studio — das ist exakt was dieses Paket enthält.

**Das Paket wäre 144 $ für Sachen die du bereits hast oder separat günstiger bekommst.**

Spare das Geld und investiere es lieber in:
- Momentous Whey Protein Isolat ✅
- Momentous Three (Protein + Kreatin + Omega-3) ✅

---

**Du:**

Ich hab die sachen noch nicht die sind nur im Plan eingeplant

---

**Claude:**

Guter Punkt — dann lass mich direkt prüfen ob es günstiger ist einzeln oder als Paket zu kaufen.

---

## Focus Stack vs. Einzelkauf — Preisvergleich

| Produkt | Einzelpreis Momentous | Im Stack | Ersparnis |
|---|---|---|---|
| **Alpha-GPC** | $44,95 | inklusive | — |
| **L-Tyrosin** | $24,95 | inklusive | — |
| **Omega-3** | $39,95 | inklusive | — |
| **Gesamt einzeln** | **$109,85** | **$107,96 (Abo)** | ~$2 |

---

## 🔴 Problem — Omega-3 Dopplung

Wenn du das **Momentous Three** kaufst (Protein + Kreatin + Omega-3) **und** den Focus Stack — hast du **Omega-3 doppelt.**

---

## ✅ Meine klare Empfehlung

**Nicht den Focus Stack kaufen.** Stattdessen:

| Was kaufen | Wo | Preis/Monat |
|---|---|---|
| Alpha-GPC 300mg | iHerb.de: NOW Foods Alpha-GPC | ~15 € |
| L-Tyrosin 500mg | iHerb.de: Bulk Powders / Sunday Natural | ~8 € |
| Omega-3 | ESN Omega-3 (hast du schon geprüft) | ~10 € |

**Gesamt: ~33 € statt ~100 €** — gleiche Wirkung, gleiche Qualität.

Alpha-GPC und L-Tyrosin brauchst du nur an Krafttagen (Mo · Mi · Fr · Sa) — **nicht täglich**. Das bedeutet eine Packung hält noch länger.

**Nächster Schritt:** Soll ich dir die genauen iHerb.de Links für Alpha-GPC und L-Tyrosin suchen?

---

**Du:**

Ich würde alles von Momentous holen

---

**Claude:**

Verständlich — Qualität ist top, alles aus einer Hand, NSF zertifiziert. Lass mich dann den optimalen Momentous-Stack für dich zusammenstellen.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Perfekt — da gibt es sogar ein **komplettes Huberman Bundle**. Lass mich dir den optimalen Stack zusammenstellen:
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Jetzt habe ich alles. Hier ist dein kompletter optimaler Momentous-Stack:

---

## 🛒 DEIN KOMPLETTER MOMENTOUS STACK
### Nur Momentous · alles NSF Certified · optimiert für deine Ziele

---

## 📦 WELCHE PAKETE DU KAUFST

### Paket 1 — Momentous Three (Basis)
**Protein + Kreatin + Omega-3**
- Whey Protein Isolat (Unflavored) · 25 Portionen
- Kreatin Monohydrat (Creapure) · 90 Portionen = 3 Monate
- Omega-3 (EPA 800mg + DHA 800mg) · 30 Portionen
- **$93,64/Monat mit Abo (25% off)**

---

### Paket 2 — Nightly Sleep Stack (Schlaf)
Magnesium L-Threonat (Magtein) + Apigenin 50mg + L-Theanin 200mg · 30 Portionen · täglich 30–60 Min vor dem Schlafen · ohne Melatonin · nicht-gewohnheitsbildend.

- **~$49,95 mit Abo ~$37,46/Monat**

---

### Produkte 3 — Focus Stack (Pre-Workout)
Alpha-GPC 300mg + L-Tyrosin 500mg + Omega-3 · Alpha-GPC unterstützt Acetylcholinproduktion · L-Tyrosin ist Vorläufer von Dopamin und Noradrenalin.

> ⚠️ Omega-3 ist doppelt mit Momentous Three — nimm stattdessen nur:
- **Alpha-GPC einzeln** (~$26,93 · 30 Portionen)
- **L-Tyrosin einzeln** (~$24,95 · 90 Portionen = 3 Monate)

---

### Produkt 4 — Vitamin D3 (5.000 IU)
Momentous Vitamin D3 5.000 IU — Rice Flour, Hypromellose Kapsel · einfache Formulierung · kein K2 enthalten.

- Separat kaufen: **~$17,95/Monat**
- ⚠️ Kein K2 dabei — entweder Vitamin K2 separat dazu oder Sunday Natural D3+K2 als DE-Alternative

---

## 📊 DEIN KOMPLETTER MOMENTOUS STACK — ÜBERSICHT

| Produkt | Timing | Portionen | Preis/Monat (Abo) |
|---|---|---|---|
| **Momentous Three** (Protein + Kreatin + Omega-3) | Morgens | 25P · 90P · 30P | ~$94 |
| **Nightly Sleep Stack** (Mag + Apigenin + L-Theanin) | 20:25 vor Schlaf | 30P | ~$37 |
| **Alpha-GPC 300mg** | Im Auto (Krafttage) | 30P | ~$20 |
| **L-Tyrosin 500mg** | Im Auto (Krafttage) | 90P = 3 Mon. | ~$8 |
| **Vitamin D3 5.000 IU** | Morgens | 30P | ~$14 |
| **Gesamt** | | | **~$173/Monat** |

---

## 💡 WICHTIGE HINWEISE

**1. Alpha-GPC + L-Tyrosin nur 4×/Woche**
Krafttage: Mo · Mi · Fr · Sa — nicht täglich. Eine Packung (30 Portionen) reicht deshalb fast 2 Monate.

**2. Omega-3 aufstocken**
Das Momentous Three enthält 800mg EPA — Hubermans Ziel ist 2.000mg. Mit deiner Ernährung (Thunfisch + Lachs) plus 2 Kapseln täglich kommst du auf ~1.500mg. Reicht gut.

**3. Vitamin K2 fehlt bei Momentous**
D3 ohne K2 ist nicht ideal für Kalziumsteuerung. Entweder Momentous D3 + separate K2 Kapsel — oder für D3+K2 Kombi: **Sunday Natural** in DE bestellen.

**4. Kreatin reicht 3 Monate**
90 Portionen à 5g = 3 Monate. Bestellst du das Paket monatlich — du hast nach 3 Monaten 3× Kreatin. Wechsle Lieferintervall auf alle 3 Monate.

---

## 💰 PREIS-VERGLEICH MOMENTOUS vs. EINZELN (DE)

| | Momentous komplett | Alles einzeln DE |
|---|---|---|
| Monatliche Kosten | ~$173 (~160 €) | ~60–80 € |
| Qualität | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| NSF Certified | ✅ alles | Teils |
| Lieferung DE | ✅ direkt | Lokal |

---

## ✅ MEINE EHRLICHE EMPFEHLUNG

Wenn dir Qualität über alles geht und du alles aus einer Hand willst — **Momentous ist die beste Entscheidung die du treffen kannst.** Huberman und Rhonda Patrick nehmen es selbst.

**So bestellen:**
1. livemomentous.com aufrufen
2. Alle Produkte mit **Subscribe & Save (25% off)** bestellen
3. Lieferintervall anpassen: Kreatin auf 3 Monate · Rest monatlich
4. Deutschland ist im Dropdown verfügbar — direkte Lieferung

**Nächster Schritt:** Soll ich dir die finale Supplement-Liste in deiner Excel-Datei mit Momentous-Produkten und Preisen aktualisieren?

---

**Du:**

Vegan oder Fisch Omega?

---

**Claude:**

Direkte Antwort:

---

## Vegan vs. Fisch Omega-3 — Die ehrliche Wahrheit

### 🐟 Fischöl — klarer Gewinner für dein Ziel
```
This block is not supported on your current device yet.
```

Direkte Antwort:

---

## 🐟 Vegan vs. Fisch Omega-3

### Kurz und klar:

Fischöl hat direktes EPA und DHA in der Triglyceridform — die natürlichste und am besten absorbierte Form.

Pflanzliche Omega-3 Quellen wie ALA müssen erst in EPA und DHA umgewandelt werden — dieser Prozess ist sehr ineffizient. Algenöl ist jedoch die Ausnahme: Es liefert EPA und DHA direkt ohne Umwandlung, da Algen die ursprüngliche Quelle der Omega-3 Fettsäuren im Meer sind.

---

## 📊 DIREKTER VERGLEICH

| | Fischöl | Algenöl (vegan) |
|---|---|---|
| **EPA + DHA direkt** | ✅ | ✅ |
| **Bioverfügbarkeit** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| **Forschungslage** | 50+ Jahre Studien | Jünger aber solide |
| **Schwermetalle** | Risiko bei billiger Qualität | Kaum — kontrollierte Umgebung |
| **Preis pro mg EPA/DHA** | Günstig | 2–3× teurer |
| **Nachhaltigkeit** | Mittel | Höher |
| **Kein Fischgeschmack** | Manchmal | ✅ immer |

Ein 2025er RCT mit 74 Erwachsenen über 14 Wochen zeigte: Algenöl EPA/DHA war nicht unterlegen gegenüber Fischöl — Plasma-Spiegel äquivalent. Algenöl bleibt jedoch signifikant teurer pro Milligramm aktivem EPA/DHA.

---

## ✅ FAZIT FÜR DICH

**Du bist kein Veganer → Fischöl.**

Drei Gründe:

**1. Gleiche Wirkung** — Bioverfügbarkeit praktisch identisch bei guter Qualität

**2. Günstiger** — 2–3× mehr EPA/DHA pro Euro

**3. Besser erforscht** — 50 Jahre klinische Daten für Testosteron, Gehirn, Herz, Entzündung

**Momentous Omega-3 (Fischöl)** aus dem Momentous Three ist deine richtige Wahl — aus nachhaltig geernteten Sardellen, Sardinen und Makrelen aus norwegischen Gewässern, molekular destilliert, in Triglyceridform, NSF Certified.

---

**Du:**

Prüfe das Omega 3 Vegan und Fisch von Momentous

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Jetzt habe ich alle Daten von beiden Produkten. Direkter Vergleich:

---

## 🐟 vs. 🌿 MOMENTOUS FISCHÖL vs. VEGAN OMEGA-3

| | **Fischöl** | **Vegan (Algenöl)** |
|---|---|---|
| **EPA pro Portion** | 800 mg | 500 mg |
| **DHA pro Portion** | 800 mg | 500 mg |
| **Gesamt EPA+DHA** | **1.600 mg** | **1.000 mg** |
| **Verhältnis EPA:DHA** | 1:1 ✅ | 1:1 ✅ |
| **Form** | Triglycerid ✅ | Triglycerid ✅ |
| **Quelle** | Norweg. Gewässer (Sardellen, Sardinen, Makrelen) | Algenöl (USA/EU/UK) |
| **NSF Certified** | ✅ | ✅ |
| **Schwermetalle** | Getestet ✅ | Kein Risiko — kontrollierte Umgebung ✅ |
| **Fischgeschmack** | Kein ✅ | Kein ✅ |
| **Kapselmaterial** | Bovine Gelatine | Hypromellose (vegan) |
| **Portionen** | 30 | 30 |
| **Preis einmalig** | $39,95 | ~$44,95 |
| **Preis mit Abo** | ~$30 | ~$34 |
| **Preis pro mg EPA+DHA** | **$0,019/mg** | **$0,034/mg** |

---

## ✅ FAZIT — KLARE EMPFEHLUNG

Das Momentous Vegan Omega-3 liefert 500mg EPA und 500mg DHA pro Portion direkt aus Algenöl in Triglyceridform — ohne Konversion von ALA nötig, NSF Certified.

Das Momentous Fischöl liefert 800mg EPA und 800mg DHA pro Portion aus nachhaltig geernteten Sardellen, Sardinen und Makrelen aus norwegischen Gewässern — molekular destilliert, NSF Certified.

---

**Für dich: Fischöl.**

Drei Gründe:

**1. 60% mehr EPA+DHA** pro Portion — 1.600mg vs. 1.000mg. Für Hubermans Ziel von 2.000mg EPA täglich brauchst du weniger Kapseln.

**2. Günstiger** — fast doppelt so viel Wirkstoff pro Dollar.

**3. Du bist kein Veganer** — kein Grund auf die günstigere, höher dosierte Option zu verzichten.

Das Vegan Omega-3 ist ein ausgezeichnetes Produkt — aber nur relevant wenn du kein Fisch oder Tierprodukte nimmst.

---

**Du:**

https://www.livemomentous.com/products/complete-expert-stack

Ist heir alles drin was ich brauche?

---

**Claude:**

```
This block is not supported on your current device yet.
```

Perfekte Grundlage. Hier ist die vollständige Analyse:

---

## 📦 COMPLETE EXPERT STACK — IST ALLES DRIN?

**Preis:** $349,95 einmalig · mit Abo 25% gespart · 30 Portionen

---

## ✅ WAS DRIN IST vs. WAS DU BRAUCHST

| Produkt im Stack | Dosis | Dein Bedarf | Status |
|---|---|---|---|
| **Omega-3 (Fischöl)** | 800mg EPA + 800mg DHA | 1.600–2.000mg EPA | ✅ |
| **Magnesium L-Threonat** | 145mg | 145–200mg abends | ✅ |
| **Apigenin** | 50mg | 50mg abends | ✅ |
| **L-Theanin** | 200mg | 100–200mg abends | ✅ |
| **Tongkat Ali** | 400mg | 400mg morgens | ✅ Bonus |
| **Zink Picolinat** | 15mg | 80–120 µg/dL Ziel | ✅ Bonus |
| **Alpha-GPC** | 300mg | 300mg Pre-Workout | ✅ |
| **L-Tyrosin** | 500mg | 500mg Pre-Workout | ✅ |
| **Kreatin (Creapure)** | 5g | 5g täglich | ✅ |
| **Acetyl-L-Carnitin** | 500mg | Optional | 🟡 Extra |
| **Myo-Inositol** | 900mg | Optional (Schlaf) | 🟡 Extra |

---

## 🔴 WAS FEHLT — 3 kritische Lücken

| Fehlendes Produkt | Warum wichtig | Lösung |
|---|---|---|
| **Whey Protein Isolat** | Dein wichtigstes tägliches Supplement — 220g Protein/Tag | Separat kaufen |
| **Vitamin D3** | Testosteron · Immunsystem · Muskel | Separat kaufen |
| **Vitamin K2** | Kalziumsteuerung · D3-Partner | Separat kaufen |

---

## 🟡 WAS EXTRA DRIN IST (gut aber nicht in deinem Plan)

**Tongkat Ali** — natürlicher Testosteron-Support. War in deinem Plan bereits als Tier 3 optional. Hier inklusive — **Bonus.**

**Acetyl-L-Carnitin** — Gehirn-Energie · Mitochondrien. War nicht in deinem Plan — **angenehme Ergänzung.**

**Myo-Inositol** — verbesserter Schlaf · Serotonin. Huberman nimmt es 3–4×/Woche für tieferen Schlaf. **Guter Bonus.**

---

## 💰 PREIS-ANALYSE — Paket vs. Einzeln

| Produkt | Einzelpreis Momentous | Im Stack enthalten |
|---|---|---|
| Omega-3 | $39,95 | ✅ |
| Magnesium L-Threonat | $49,95 | ✅ |
| Apigenin | $29,95 | ✅ |
| L-Theanin | $24,95 | ✅ |
| Tongkat Ali | $44,95 | ✅ |
| Zink Picolinat | $19,95 | ✅ |
| Alpha-GPC | $44,95 | ✅ |
| L-Tyrosin | $24,95 | ✅ |
| Kreatin | $39,95 | ✅ |
| Acetyl-L-Carnitin | $34,95 | ✅ |
| Myo-Inositol | $24,95 | ✅ |
| **Einzeln gesamt** | **$379,50** | |
| **Stack Preis** | **$349,95** | **~$30 Ersparnis** |
| **Mit Abo (25%)** | **$262,46** | **~$117 Ersparnis** |

---

## ✅ FAZIT — LOHNT ES SICH?

**Ja — mit zwei Ergänzungen.**

Das Paket deckt **9 von 12** deiner benötigten Supplements ab. Was du noch separat brauchst:

| Was | Wo bei Momentous | Preis/Monat |
|---|---|---|
| **Whey Protein Isolat** | livemomentous.com · Unflavored | ~$41 (Abo) |
| **Vitamin D3 5.000 IU** | livemomentous.com · D3 | ~$14 (Abo) |
| **Vitamin K2** | Nicht bei Momentous → Sunday Natural DE | ~8 € |

---

## 🛒 DEIN KOMPLETTER MOMENTOUS BESTELLPLAN

| Produkt | Preis/Monat (Abo) | Intervall |
|---|---|---|
| **Complete Expert Stack** | ~$262 | Monatlich |
| **Whey Protein Isolat** | ~$41 | Monatlich |
| **Vitamin D3 5.000 IU** | ~$14 | Monatlich |
| **K2 (Sunday Natural DE)** | ~8 € | Monatlich |
| **Gesamt** | **~$317 + 8 € (~300 €/Monat)** | |

---

> **Ein Hinweis:** $262/Monat für 11 Supplements aus einer Hand · alle NSF Certified · alle Huberman-Standard · direkte Lieferung nach Deutschland. Das ist der Preis für kompromisslose Qualität. Wenn Budget eine Rolle spielt — Tier 1 (Protein + Kreatin + Omega-3 + Magnesium + D3) einzeln kostet ~80–100 €/Monat.

**Nächster Schritt:** Willst du die finale Bestellliste für Momentous als Excel-Blatt in deine Datei einfügen?

---

**Du:**

ICh hab creatin mit protein und omega im bundle auch von momentous eingepackt

---

**Claude:**

Perfekt — dann überschneiden sich einige Produkte. Lass mich schnell prüfen was du doppelt hättest:

---

## ⚠️ ÜBERSCHNEIDUNGEN — Momentous Three + Complete Expert Stack

| Produkt | Momentous Three | Complete Expert Stack | Doppelt? |
|---|---|---|---|
| **Omega-3** | ✅ 800mg EPA+DHA | ✅ 800mg EPA+DHA | 🔴 Doppelt |
| **Kreatin** | ✅ 5g Creapure | ✅ 5g Creapure | 🔴 Doppelt |
| **Whey Protein** | ✅ 20g/Portion | ❌ Nicht enthalten | ✅ Ok |

---

## ✅ LÖSUNG — Was du wirklich brauchst

**Streiche das Momentous Three** — der Complete Expert Stack hat Kreatin und Omega-3 bereits drin.

**Behalte nur:**

| Produkt | Wo | Preis Abo |
|---|---|---|
| **Complete Expert Stack** | livemomentous.com | ~$262/Monat |
| **Whey Protein Isolat** (separat) | livemomentous.com | ~$41/Monat |
| **Vitamin D3 5.000 IU** (separat) | livemomentous.com | ~$14/Monat |
| **Vitamin K2** | Sunday Natural DE | ~8 €/Monat |
| **Gesamt** | | **~$317 + 8 € (~300 €)** |

---

## 💡 ODER — Momentous Three behalten + Expert Stack anpassen

Falls du das Bundle bereits im Warenkorb hast und behalten willst:

**Momentous Three** (Protein + Kreatin + Omega-3) → **monatlich**
**Expert Stack ohne Kreatin + Omega-3** — geht leider nicht einzeln aus dem Paket herausnehmen.

**Empfehlung:** Expert Stack kaufen · Momentous Three weglassen · Protein separat dazu.

Das spart ~$124,85/Monat und du hast keine Dopplungen.

**Willst du die finale Bestellliste so festhalten?**

---

**Du:**

1 creatin bekommt meine Freundin 

Omega passt da ich ja mehr kapseln nehmen muss

---

**Claude:**

Perfekt — dann passt alles zusammen. Lass mich die finale Übersicht machen:

---

## ✅ DEIN FINALER MOMENTOUS STACK — BEREINIGT

| Produkt | Für wen | Menge | Status |
|---|---|---|---|
| **Complete Expert Stack** | Dich | 30 Portionen | ✅ |
| **Momentous Three** (Protein + Kreatin + Omega-3) | Protein & Omega für dich · Kreatin für Freundin | 25P · 90P · 30P | ✅ |
| **Whey Protein Isolat** (extra) | Dich — 2. Portion täglich | 25 Portionen | ✅ |
| **Vitamin D3 5.000 IU** | Dich | 30 Portionen | ✅ |
| **Vitamin K2** | Dich | Sunday Natural DE | ✅ |

---

## 🧮 OMEGA-3 KAPSELN PRO TAG — DEIN PLAN

| Quelle | EPA | DHA |
|---|---|---|
| Momentous Three (2 Kapseln) | 800mg | 800mg |
| Complete Expert Stack (2 Kapseln) | 800mg | 800mg |
| **Gesamt** | **1.600mg** | **1.600mg** |
| + Thunfisch 200g täglich | ~300mg | — |
| + Lachs 2–3×/Woche | ~400mg Schnitt | — |
| **Gesamttäglich** | **~2.300mg ✅** | |

Hubermans Zielwert von 2.000mg EPA **übertroffen** — ohne extra Kapseln kaufen zu müssen.

---

## 💰 FINALE MONATLICHE KOSTEN

| Produkt | Preis Abo (25%) |
|---|---|
| Complete Expert Stack | ~$262 |
| Momentous Three | ~$94 |
| Whey Protein extra | ~$41 |
| Vitamin D3 | ~$14 |
| Vitamin K2 (Sunday Natural) | ~8 € |
| **Gesamt** | **~$411 + 8 € (~385 €/Monat)** |

---

> **Ehrliche Einschätzung:** Das ist ein Premium-Investment — aber du bekommst dafür 13 Supplements, alle NSF Certified, Huberman & Patrick Standard, direkte Lieferung nach Deutschland. Pro Tag sind das ~13 € für dein komplettes Gesundheitssystem.

**Nächster Schritt:** Soll ich das als finales Supplement-Blatt in deine Excel-Datei eintragen mit Timing, Dosierung und Kosten?

---

**Du:**

was hab eich alles mit den supps abgedeckt?

---

**Claude:**

Lass mich das sauber gegen deine persönlichen Ziele und den Huberman/Patrick Standard prüfen:

---

## ✅ ABGEDECKT — Vollständige Analyse

### 🔴 TIER 1 — Fundamental

| Supplement | Quelle | Dosis | Status |
|---|---|---|---|
| **Omega-3 EPA/DHA** | Momentous Three + Expert Stack | ~2.300mg EPA ✅ | ✅ Übertroffen |
| **Magnesium L-Threonat** | Expert Stack | 145mg | ✅ |
| **Kreatin Monohydrat** | Momentous Three | 5g Creapure | ✅ |

---

### 🟠 TIER 2 — Stark empfohlen

| Supplement | Quelle | Dosis | Status |
|---|---|---|---|
| **Apigenin** | Expert Stack | 50mg abends | ✅ |
| **L-Theanin** | Expert Stack | 200mg abends | ✅ |
| **Zink** | Expert Stack | 15mg Picolinat | ✅ |

---

### 🟡 TIER 3 — Performance & Anti-Aging

| Supplement | Quelle | Dosis | Status |
|---|---|---|---|
| **Alpha-GPC** | Expert Stack | 300mg Pre-Workout | ✅ |
| **L-Tyrosin** | Expert Stack | 500mg Pre-Workout | ✅ |
| **Tongkat Ali** | Expert Stack | 400mg morgens | ✅ Bonus |
| **Acetyl-L-Carnitin** | Expert Stack | 500mg | ✅ Bonus |
| **Myo-Inositol** | Expert Stack | 900mg Schlaf | ✅ Bonus |

---

### 💪 SPORT & KÖRPER

| Supplement | Quelle | Dosis | Status |
|---|---|---|---|
| **Whey Protein Isolat** | Momentous Three + extra | 40g täglich | ✅ |

---

## 🔴 NOCH NICHT ABGEDECKT — 4 Lücken

| Fehlt | Warum wichtig für dich | Priorität |
|---|---|---|
| **Vitamin D3** | Testosteron · Muskel · Immunsystem · dein Wert wahrscheinlich niedrig | 🔴 Sofort |
| **Vitamin K2** | D3-Partner · Kalzium zu Knochen leiten · ohne K2 ist D3 unvollständig | 🔴 Sofort |
| **Multivitamin** | Mikronährstoff-Absicherung · B12 · Folat · Mikromineralien | 🟠 Wichtig |
| **Sulforaphan** | Rhonda Patricks Nr.-1-Supplement · Nrf2 · Zellschutz · Entgiftung | 🟡 Optional |

---

## 📊 GESAMTÜBERSICHT — Was abgedeckt ist

| Bereich | Abgedeckt | Lücke |
|---|---|---|
| Muskelaufbau & Kraft | ✅ Protein · Kreatin · Alpha-GPC · Tyrosin | — |
| Entzündung & Herz | ✅ Omega-3 hochdosiert | — |
| Schlaf | ✅ Magnesium · Apigenin · L-Theanin · Inositol | — |
| Testosteron | ✅ Zink · Tongkat Ali · Omega-3 | 🔴 D3 fehlt |
| Fokus & Kognition | ✅ Alpha-GPC · Tyrosin · Kreatin · Acetyl-L-Carnitin · Omega-3 | — |
| Longevity | ✅ Omega-3 · Tongkat Ali | 🟡 Sulforaphan fehlt |
| Hormone & Knochen | ❌ D3 + K2 fehlt komplett | 🔴 Kritisch |
| Mikronährstoffe | ❌ Kein Multivitamin | 🟠 Wichtig |

---

## ✅ WAS DU NOCH KAUFST — FINALE 3 PRODUKTE

| Produkt | Wo | Preis/Monat |
|---|---|---|
| **Momentous Vitamin D3 5.000 IU** | livemomentous.com | ~$14 (Abo) |
| **Vitamin K2 100mcg MK-7** | Sunday Natural DE | ~8 € |
| **Multivitamin** | Sunday Natural oder Momentous | ~15–20 € |

---

**Dann bist du zu 100% abgedeckt** — Tier 1 bis 3, Schlaf, Fokus, Testosteron, Longevity, alles.

**Nächster Schritt:** Soll ich die finalen Supplement-Erinnerungen mit Timing für alle Momentous-Produkte nochmal sauber zusammenstellen?

---

**Du:**

Wie wichtig ist tier 3?

---

**Claude:**

Ehrliche Antwort — Tier 3 ist das Letzte was du brauchst, nicht das Erste.

---

## Priorität realistisch einschätzen

### 🔴 Tier 1 — Ohne das funktioniert nichts
**Omega-3 · Kreatin · Magnesium · D3+K2**

Das sind die 4 Supplements wo 80% der Bevölkerung defizitär ist. Die Wirkung ist messbar im Blutbild. Ohne diese Basis bringt Tier 3 nichts.

---

### 🟠 Tier 2 — Deutlich spürbare Wirkung
**Apigenin · L-Theanin · Zink · Multivitamin**

Schlaf verbessert sich messbar. Testosteron steigt durch Zink. Täglich relevant.

---

### 🟡 Tier 3 — Feintuning für bereits Optimierte

| Supplement | Ehrliche Bewertung |
|---|---|
| **Alpha-GPC** | Spürbar an Krafttagen — Fokus ↑ · aber nur wenn Basis stimmt |
| **L-Tyrosin** | Hilfreich bei Stress und Schlafmangel · situativ · kein Muss |
| **Tongkat Ali** | Testosteron-Unterstützung · aber erst relevant wenn D3+Zink+Schlaf stimmen |
| **Acetyl-L-Carnitin** | Gehirn-Energie · schwächste Evidenz der vier | 
| **NMN/NR** | Erst ab 35+ wirklich relevant · du bist 32 |

---

## Die ehrliche Reihenfolge für dich

**Monat 1–3:** Nur Tier 1 + Tier 2
→ Omega-3 · Kreatin · Magnesium · D3+K2 · Apigenin · L-Theanin · Zink

**Monat 4+:** Tier 3 einführen wenn Blutbild ok und Routine sitzt
→ Alpha-GPC · L-Tyrosin · Tongkat Ali

---

## Was das bedeutet für deinen Momentous-Stack

Der **Complete Expert Stack** enthält Tier 2 und 3 zusammen — das ist sein Wert. Wenn du ihn kaufst, hast du alles auf einmal.

Aber wenn Budget eine Rolle spielt:

| Option | Kosten/Monat | Wirkung |
|---|---|---|
| Nur Tier 1+2 (Momentous Three + Sleep Stack + D3) | ~$160 | 85% der Gesamtwirkung |
| + Complete Expert Stack | ~$420 | 100% der Gesamtwirkung |

**Fazit:** Tier 3 ist sinnvoll — aber erst wenn Tier 1 und 2 konsequent eingenommen werden und dein Blutbild die Basis-Defizite gedeckt hat. Das Expert Stack macht es einfach alles aus einer Hand zu haben.

---

**Du:**

macht es sind das protein bundle mit kreatin und omega zu nehmen oder alles separat

---

**Claude:**

Direkte Antwort — lass mich das ehrlich durchrechnen:

---

## Bundle vs. Einzeln — Preisvergleich

| | **Momentous Three (Bundle)** | **Einzeln** |
|---|---|---|
| Whey Protein 25P | inklusive | $54,95 |
| Kreatin 90P | inklusive | $39,95 |
| Omega-3 30P | inklusive | $39,95 |
| **Einzeln gesamt** | | **$134,85** |
| **Bundle einmalig** | **$124,85** | — |
| **Bundle mit Abo** | **$93,64** | ~$101 (alle 3 mit Abo) |

---

## ✅ FAZIT

**Bundle lohnt sich — aber nur wenn du alle 3 täglich nimmst.**

Das Problem in deinem Fall:

| Produkt | Reicht wie lange |
|---|---|
| Kreatin (90P à 5g) | **3 Monate** |
| Omega-3 (30P à 2 Kapseln) | **1 Monat** |
| Protein (25P à 1 Portion) | **25 Tage** |

Die drei Produkte haben völlig unterschiedliche Laufzeiten — du bestellst das Bundle monatlich, hast aber nach Monat 1 bereits 2 extra Kreatin-Dosen übrig und Protein läuft schneller durch weil du 2 Portionen täglich nimmst.

---

## 🏆 BESTE LÖSUNG FÜR DICH KONKRET

**Kreatin separat alle 3 Monate** — du brauchst es nur einmal pro Quartal.

**Protein + Omega-3 monatlich** — diese zwei passen zusammen.

| Produkt | Intervall | Preis Abo |
|---|---|---|
| Whey Protein Isolat (separat) | Monatlich | ~$41 |
| Omega-3 (separat) | Monatlich | ~$30 |
| Kreatin (separat) | Alle 3 Monate | ~$30 → ~$10/Monat |
| **Gesamt** | | **~$81/Monat** |

vs. Bundle monatlich: **~$94/Monat** mit überschüssigem Kreatin.

**Ergebnis: Separat spart ~$13/Monat und kein Kreatin-Überfluss.**

---

**Du:**

Gibt es ein rabattcode für Momentous

---

**Claude:**

```
This block is not supported on your current device yet.
```

Hier sind alle verfügbaren Rabatte:

---

## 🏷️ MOMENTOUS RABATTCODES — Mai 2026

### ✅ Sicher funktionierend:

| Rabatt | Code | Wer | Wann |
|---|---|---|---|
| **25% off** | Subscribe & Save automatisch | Alle | Erste Bestellung + dauerhaft |
| **10% extra** | Automatisch | Abo-Kunden | Jede Folgebestellung |
| **15% off** | **WELCOME15** | Neukunden | Erste Bestellung |
| **20% off** | Newsletter-Anmeldung | Neukunden | Nach E-Mail-Bestätigung |

---

### 💡 MAXIMALE ERSPARNIS — So gehst du vor

Neue Abonnenten erhalten 15% auf die erste Bestellung. Subscribe & Save gibt zusätzlich 25% auf alle Bestellungen.

**Schritt für Schritt:**

1. **E-Mail Newsletter abonnieren** auf livemomentous.com → **20% Willkommenscode** per E-Mail
2. **Subscribe & Save wählen** beim Checkout → **25% automatisch**
3. Code **WELCOME15** beim ersten Checkout eingeben → prüfen ob kombinierbar
4. **Kostenloser Versand** ab $75 — automatisch ab $75 Bestellwert.

---

### 🎖️ SPECIAL DISCOUNTS

Militär · Ersthelfer · Krankenpfleger · Lehrer · Regierungsangestellte erhalten 20% Rabatt über ID.me Verifizierung auf der Website.

---

### ⚡ FAZIT FÜR DICH

Beste Kombination:
- **Newsletter abonnieren** → 20% Willkommenscode
- **Subscribe & Save** → 25% dauerhaft
- Code **WELCOME15** beim ersten Checkout versuchen

Bei deiner Bestellung von ~$300–400 spart das **$75–100 allein im ersten Monat.**

---

**Du:**

Ich würde Tier 1-2 nehmen reicht das?

Hab noch Vitamin d 3 zuhause 20.000

---

**Claude:**

Ja — Tier 1+2 reicht vollkommen für den Start. Das ist sogar die richtige Entscheidung.

---

## ✅ DEIN FINALER STACK — Tier 1+2

### Was du brauchst:

| Produkt | Wo | Preis Abo |
|---|---|---|
| **Whey Protein Isolat** | Momentous (separat) | ~$41 |
| **Kreatin** | Momentous (separat, alle 3 Monate) | ~$10 |
| **Omega-3** | Momentous (separat) | ~$30 |
| **Nightly Sleep Stack** (Mag + Apigenin + L-Theanin) | Momentous | ~$37 |
| **Vitamin D3** | ✅ Bereits zuhause | 0 € |
| **Vitamin K2** | Sunday Natural DE | ~8 € |

**Gesamt: ~$118 + 8 € (~120 €/Monat)**

---

## 💊 DEIN VITAMIN D3 — 20.000 IU PRÜFEN

Kurze wichtige Frage dazu:
```
This block is not supported on your current device yet.
```

---

**Du:**

F: Wie ist die Dosierungsanweisung auf deiner D3 Packung?
A: 1x pro Woche 20.000 IU

---

**Claude:**

Perfekt — das ist eine klassische Wochendosis. Hier ist die ehrliche Einschätzung:

---

## 💊 DEIN D3 20.000 IU 1×/WOCHE — BEWERTUNG

**Wöchentlich 20.000 IU = ~2.857 IU täglich**

Das ist **unter** Hubermans Zielwert von 5.000 IU täglich — aber besser als nichts.

| | Dein D3 | Huberman Ziel |
|---|---|---|
| **Dosis täglich (gerechnet)** | ~2.857 IU | 5.000 IU |
| **Ausreichend für Basis** | 🟡 Grenzwertig | ✅ |
| **Optimal für Testosteron** | ❌ | ✅ |

---

## ✅ EMPFEHLUNG

**Kurzfristig:** Dein 20.000 IU wöchentlich weiter nehmen — besser als kein D3.

**Mittelfristig:** Nach dem Blutbild entscheiden. Wenn dein 25-OH-D Wert unter 40 ng/mL liegt — auf 5.000 IU täglich wechseln. Das Momentous D3 ($14/Monat) ist dann sinnvoll.

**Wichtig:** D3 immer **mit einer fetthaltigen Mahlzeit** nehmen — fettlösliches Vitamin, sonst kaum Aufnahme.

---

## 🛒 DEIN FINALER BESTELLPLAN — SOFORT UMSETZBAR

| Produkt | Wo bestellen | Preis Abo |
|---|---|---|
| **Whey Protein Isolat** | livemomentous.com | ~$41 |
| **Kreatin** | livemomentous.com (3-Monats-Abo) | ~$10 |
| **Omega-3** | livemomentous.com | ~$30 |
| **Nightly Sleep Stack** | livemomentous.com | ~$37 |
| **Vitamin K2 100mcg MK-7** | sunday.de | ~8 € |
| **D3 20.000 IU** | ✅ Bereits zuhause | 0 € |
| **Gesamt** | | **~$118 + 8 € (~120 €/Monat)** |

---

**Das ist dein optimaler Einstieg.** Tier 1+2 vollständig abgedeckt, vernünftiger Preis, alles NSF Certified.

**Nächster Schritt:** Newsletter auf livemomentous.com abonnieren → 20% Willkommenscode sichern → dann bestellen.

---

**Du:**

Ich kann auch 2-3 die Woche nehmen

---

**Claude:**

Noch besser — lass mich das schnell durchrechnen:

---

## 💊 D3 DOSIERUNG — DEINE OPTIONEN

| Frequenz | Wochendosis | Täglich gerechnet | Bewertung |
|---|---|---|---|
| 1×/Woche | 20.000 IU | ~2.857 IU | 🟡 Grenzwertig |
| **2×/Woche** | **40.000 IU** | **~5.714 IU** | **✅ Huberman-Ziel** |
| 3×/Woche | 60.000 IU | ~8.571 IU | 🟡 Etwas hoch ohne Blutbild |

---

## ✅ EMPFEHLUNG

**2× pro Woche — perfekt.**

Das trifft exakt Hubermans Ziel von ~5.000 IU täglich gerechnet. Ohne neues Supplement kaufen zu müssen.

> ⚠️ Wichtig: D3 immer zur fettreichen Mahlzeit nehmen — morgens beim Frühstück mit Avocado oder Olivenöl. Fettlöslich = braucht Fett zur Aufnahme.

---

## 🛒 DEIN FINALER BESTELLPLAN — KOMPLETT

| Produkt | Wo | Preis Abo |
|---|---|---|
| **Whey Protein Isolat** | livemomentous.com | ~$41 |
| **Kreatin** | livemomentous.com (3-Monats-Abo) | ~$10 |
| **Omega-3** | livemomentous.com | ~$30 |
| **Nightly Sleep Stack** | livemomentous.com | ~$37 |
| **Vitamin K2 100mcg MK-7** | sunday.de | ~8 € |
| **D3 20.000 IU** | ✅ Zuhause · 2×/Woche | 0 € |
| **Gesamt** | | **~$118 + 8 € (~120 €/Monat)** |

**Jetzt vollständig — Tier 1+2 zu 100% abgedeckt. Bereit zum Bestellen.**

---

**Du:**

Bei mir ist auch k2 dabei

---

**Claude:**

Perfekt — dann brauchst du gar nichts extra kaufen.

---

## 🛒 DEIN FINALER BESTELLPLAN — KOMPLETT & BEREINIGT

| Produkt | Wo | Preis Abo |
|---|---|---|
| **Whey Protein Isolat** | livemomentous.com | ~$41 |
| **Kreatin** | livemomentous.com (3-Monats-Abo) | ~$10 |
| **Omega-3** | livemomentous.com | ~$30 |
| **Nightly Sleep Stack** | livemomentous.com | ~$37 |
| **D3 20.000 IU + K2** | ✅ Bereits zuhause · 2×/Woche | 0 € |
| **Gesamt** | | **~$118/Monat (~110 €)** |

---

## ✅ TIER 1+2 — VOLLSTÄNDIG ABGEDECKT

| Supplement | Status |
|---|---|
| Omega-3 | ✅ Momentous |
| Kreatin | ✅ Momentous |
| Magnesium L-Threonat | ✅ Sleep Stack |
| Apigenin | ✅ Sleep Stack |
| L-Theanin | ✅ Sleep Stack |
| Vitamin D3 | ✅ Zuhause |
| Vitamin K2 | ✅ Zuhause dabei |
| Protein | ✅ Momentous |

**Alles da. Newsletter abonnieren → 20% Code sichern → bestellen.**

---

**Du:**

was heisst nsf zertifiziert?

---

**Claude:**

Kurze, klare Erklärung:

---

## NSF Certified — Was das bedeutet

**NSF = National Sanitation Foundation** — eine unabhängige amerikanische Prüforganisation seit 1944. Keine Verbindung zu Supplement-Herstellern.

---

## Was NSF konkret prüft

| Prüfung | Was geprüft wird |
|---|---|
| **Inhaltsstoffe** | Was auf der Packung steht ist wirklich drin — richtige Dosis |
| **Kontaminanten** | Keine Schwermetalle · keine Pestizide · keine verbotenen Substanzen |
| **290 verbotene Substanzen** | Steroide · Stimulanzien · Dopingmittel — alle ausgeschlossen |
| **Produktionsstätte** | Fabrik wird 2× jährlich unangekündigt kontrolliert |
| **Jede Charge** | Nicht nur einmalig — jede produzierte Batch wird getestet |

---

## Warum das für dich wichtig ist

NSF Certified for Sport ist der strengste Standard für Supplements weltweit — er wurde ursprünglich für Profisportler entwickelt die bei Dopingkontrollen nichts riskieren wollen. Heute ist er der Goldstandard für alle die sicher sein wollen was sie schlucken.

---

## In der Praxis — der Unterschied

| | Ohne Zertifizierung | NSF Certified |
|---|---|---|
| Inhalt korrekt? | Vielleicht | ✅ Garantiert |
| Schwermetalle? | Unbekannt | ✅ Getestet |
| Verbotene Stoffe? | Unbekannt | ✅ Ausgeschlossen |
| Produktionskontrolle? | Intern | ✅ Unabhängig |
| Vertrauenslevel | 🟡 | ✅ Höchste Stufe |

---

## Einfach gesagt

> NSF Certified bedeutet: Ein unabhängiges Labor hat geprüft dass das Produkt **genau das enthält was draufsteht — nicht mehr, nicht weniger, nichts Schädliches.**

Das ist der Grund warum Huberman, Rhonda Patrick und alle NFL/NBA Teams ausschließlich NSF-zertifizierte Supplements verwenden.

**Dein Momentous Stack ist komplett NSF Certified — du weißt exakt was du schluckst.**

---

**Du:**

wird esn und more auch so geprüft?

---

**Claude:**

Direkte, ehrliche Antwort:
```
This block is not supported on your current device yet.
```

Hier ist die ehrliche, vollständige Antwort:

---

## ESN & More Nutrition — Wie werden sie geprüft?

### Wichtige Info zuerst:
ESN und More Nutrition gehören seit ihrer Fusion zur selben Unternehmensgruppe — The Quality Group (TQG). Beide Marken bleiben eigenständig, teilen aber Produktionsstandards.

---

## 📊 VERGLEICH — ESN/More vs. Momentous/NSF

| Kriterium | ESN & More Nutrition | Momentous (NSF) |
|---|---|---|
| **Eigenes Labor** | ✅ | ✅ |
| **Externes Labor** | ✅ Jede Charge intern + extern geprüft · 80.000 Tests/Jahr | ✅ |
| **TÜV Zertifizierung** | ✅ FSSC 22000 · TÜV-geprüfte Lebensmittelsicherheit | — |
| **NSF Certified** | ❌ | ✅ |
| **Informed Sport** | ❌ | — |
| **290 Dopingsubstanzen geprüft** | ❌ nicht öffentlich bestätigt | ✅ |
| **Charge online prüfbar** | ❌ | ✅ |
| **Produktion** | Deutschland · Made in Germany | USA |
| **Weidehaltung Protein** | ❌ nicht deklariert | ✅ |

---

## 🔍 WAS DAS BEDEUTET

**ESN ist deutlich besser als No-Name** — das ist fair zu sagen.

ESN testet jede Charge intern und lässt sie zusätzlich von unabhängigen externen Prüflaboren verifizieren — über 80.000 Tests pro Jahr.

Aber es gibt einen entscheidenden Unterschied zu NSF:

| | ESN | NSF Certified |
|---|---|---|
| Wer bestimmt was getestet wird? | ESN selbst | Unabhängige Organisation |
| Ergebnisse öffentlich? | ❌ | ✅ jede Charge |
| Dopingsubstanzen (290 Stück)? | Nicht bestätigt | ✅ garantiert |
| Hersteller zahlt für Zertifizierung? | Intern | Ja — aber Prüfer sind unabhängig |

**Der Kernunterschied:** Bei ESN entscheidet ESN was geprüft wird und die Ergebnisse sind nicht öffentlich einsehbar. Bei NSF entscheidet eine unabhängige Organisation was geprüft wird und jeder kann die Ergebnisse online nachschlagen.

---

## ✅ FAZIT FÜR DICH

| Marke | Qualitätsstufe | Empfehlung |
|---|---|---|
| **Momentous** | ⭐⭐⭐⭐⭐ NSF Certified | Für deinen finalen Stack ✅ |
| **ESN** | ⭐⭐⭐⭐ TÜV + externe Labs | Gut für Kreatin (Creapure) · ok für Basis |
| **More Nutrition** | ⭐⭐⭐⭐ Gleiche Gruppe wie ESN | Ok für Protein als Übergangs-Lösung |
| **No-Name Amazon** | ⭐ Keine Prüfung | Meiden ❌ |

**ESN und More sind solide deutsche Produkte** — für den Übergang oder als günstige Alternative für Kreatin völlig in Ordnung. Für Omega-3, Protein und Schlaf-Supplements wo Reinheit und Dosierung maximal wichtig sind — Momentous ist die bessere Wahl.

---

**Du:**

https://www.livemomentous.com/products/l-glutamine

brauche ich da

---

**Claude:**

```
This block is not supported on your current device yet.
```

Direkte Antwort: **Nein — brauchst du nicht.**

---

## L-Glutamin — Ehrliche Bewertung

L-Glutamin ist eine bedingt essentielle Aminosäure die eine wichtige Rolle bei Muskelreparatur, Immunfunktion und Darmgesundheit spielt.

---

## Warum du es nicht brauchst

**Du bekommst bereits genug Glutamin durch deine Ernährung:**

| Quelle | Glutamin täglich |
|---|---|
| 200g Hähnchen/Thunfisch | ~4–6g |
| 500g Magerquark | ~4g |
| Whey Protein Isolat | ~3–4g |
| **Gesamt** | **~11–14g täglich** |

Huberman empfiehlt L-Glutamin **nicht** als Kern-Supplement — es taucht weder in seinen Top-Empfehlungen noch bei Rhonda Patrick als Priorität auf.

---

## Wann macht L-Glutamin Sinn?

| Situation | Sinnvoll? |
|---|---|
| Gesunde Ernährung mit viel Protein | ❌ Nicht nötig |
| Intensiver Leistungssport (2× täglich) | 🟡 Optional |
| Darmprobleme / Leaky Gut | 🟡 Dann ja |
| Veganer ohne viel Protein | 🟡 Dann ja |
| **Dein Fall** | **❌ Nicht nötig** |

---

## ✅ Fazit

**Spare die $30/Monat.** Dein Protein-Stack (Whey Isolat + Quark + Hähnchen/Thunfisch) liefert dir täglich ~12g Glutamin — weit über dem was ein Supplement dazugeben würde.

Investiere das Geld lieber in deinen bestehenden Stack — der ist bereits vollständig.

---

**Du:**

https://www.livemomentous.com/products/collagen-peptides das ?

---

**Claude:**

```
This block is not supported on your current device yet.
```

Direkte Antwort: **Für dich aktuell nicht notwendig — aber sinnvoll in einem spezifischen Fall.**

---

## Momentous Collagen Peptides — Bewertung

**Was drin ist:**
10g bovines Kollagen + 5g FORTIGEL® (klinisch erforscht) + Vitamin C für Kollagensynthese · Grass-fed · NSF Certified · 30 Portionen · $38,96 mit Abo.

**Was es macht:**
Unterstützt Sehnen, Bänder, Gelenke, Haut und Bindegewebe. FORTIGEL® ist ein klinisch getesteter Kollagen-Bioaktivator speziell für Weichgewebe-Stärke und Mobilität.

---

## Brauchst du es?

| Frage | Antwort |
|---|---|
| Gelenkschmerzen beim Training? | Dann ja |
| Über 35 Jahre alt? | Dann sinnvoll |
| Intensives tägliches Training? | Dann sinnvoll |
| Du bist 32 und trainierst neu | 🟡 Noch nicht nötig |
| Huberman/Patrick Kern-Stack? | ❌ Nicht drin |

---

## Wann macht es Sinn

**Jetzt noch nicht** — du hast gerade erst mit intensivem Training angefangen. Dein Körper produziert mit 32 noch ausreichend Kollagen.

**Sinnvoll ab:** Wenn du nach 2–3 Monaten Training Gelenkschmerzen bekommst (Knie · Schultern · Ellenbogen) — dann ist FORTIGEL® sehr gut belegt.

**Rhonda Patrick** nimmt Kollagen gezielt nach intensiven Trainingseinheiten zur Gelenkregeneration — aber nicht täglich als Basis.

---

## ✅ Fazit

**Spare die $39/Monat jetzt.** Dein Stack ist vollständig. Falls nach 3 Monaten Training Gelenke schmerzen — dann sofort dazunehmen. FORTIGEL® ist einer der wenigen klinisch bewiesenen Kollagen-Wirkstoffe.

---

**Du:**

https://www.livemomentous.com/products/tongkat

---

**Claude:**

```
This block is not supported on your current device yet.
```

Direkte Antwort: **Ja — für dich sehr sinnvoll. Und günstig.**

---

## Momentous Tongkat Ali — Bewertung

**Was drin ist:**
400mg Tongkat Ali (Eurycoma Longifolia) Wurzelpulver pro Portion · 2 Kapseln täglich · 30 Portionen · Informed Sport zertifiziert · aus Indonesien · 100% Wurzelpulver in natürlicher Form.

**Wie es wirkt:**
Tongkat Ali unterstützt die Hormonbalance indem es die Testosteron-Verfügbarkeit erhöht und die Stressreaktion des Körpers unterstützt. Es kann Cortisol senken — was Stimmung, Energie und Erholung bei hoher Trainingsbelastung oder Stress verbessert.

---

## Warum es für dich passt

Du hast zwei konkrete Ziele wo Tongkat Ali direkt hilft:

| Dein Ziel | Tongkat Ali Wirkung |
|---|---|
| **Bauchfett abbauen** | Cortisol ↓ · Testosteron ↑ → weniger Fetteinlagerung am Bauch |
| **Muskeln aufbauen** | Testosteron ↑ · Energie ↑ · Erholung ↑ |
| **Cortisol senken** | Direkt adressiert laut Produktbeschreibung |
| **108 cm Taillenumfang** | Hoher Taillenumfang = oft niedrigeres T + hohes Cortisol |

---

## Huberman nimmt es persönlich

Huberman hat Tongkat Ali öffentlich als eines seiner regelmäßigen Supplements erwähnt — speziell für Testosteron-Support und Cortisol-Regulation.

---

## Preis — sehr günstig für Momentous

$19,95 einmalig · mit Abo 25% off = **$14,96/Monat** · 30 Portionen.

Das ist das günstigste sinnvolle Supplement in deinem Stack.

---

## ⚠️ Wichtige Hinweise

**Informed Sport** — nicht NSF Certified for Sport. Informed Sport ist ebenfalls ein sehr hoher Standard, aber leicht anders:

| | Informed Sport | NSF Certified |
|---|---|---|
| Dopingsubstanzen geprüft | ✅ 250+ | ✅ 290+ |
| Batch-Testing | ✅ | ✅ |
| Produktionsstätte | ✅ | ✅ |
| Für Profisportler | ✅ | ✅ |

**Für dich: Kein Unterschied — beide sind Top-Standard.**

**Zyklisch nehmen:** Huberman empfiehlt Tongkat Ali zyklisch — 4–6 Wochen nehmen, 1–2 Wochen Pause. Verhindert Toleranzentwicklung.

---

## ✅ Fazit

**Ja — kaufen.** Für $15/Monat bekommst du direkten Testosteron- und Cortisol-Support. Das ist genau das was dein Bauchfett-Problem adressiert und deinen Muskelaufbau beschleunigt.

**Timing:** 2 Kapseln morgens · mit oder ohne Mahlzeit · täglich konsistent.

**Ergänzt deinen Stack perfekt — ohne ihn zu überladen.**

---

**Du:**

https://www.livemomentous.com/products/fiber-plus

---

**Claude:**

```
This block is not supported on your current device yet.
```

Direkte Antwort: **Nein — brauchst du nicht. Du hast es bereits in deiner Ernährung.**

---

## Momentous Fiber+ — Bewertung

**Was drin ist:**
3-in-1 Formel mit löslichen Ballaststoffen (Psyllium), unlöslichen Ballaststoffen (Reiskleie) und Solnul® resistenter Stärke · NSF Certified for Sport · $29,96/Monat mit Abo.

**Was es macht:**
Unterstützt Darmgesundheit, stabile Energie und Leistung. Präbiotische Fasern füttern nützliche Darmbakterien, stabilisieren Blutzucker und verbessern Nährstoffaufnahme.

---

## Warum du es nicht brauchst

Schau dir deine aktuelle Ernährung an:

| Lebensmittel | Ballaststoffe täglich |
|---|---|
| **Flohsamenschalen (1 EL)** | ~5g |
| **Chia Samen (1 EL)** | ~5g |
| **Haferflocken 100g** | ~10g |
| **250g Gemüse (Mittag)** | ~5g |
| **250g Gemüse (Abend)** | ~5g |
| **150g Beeren** | ~3g |
| **½ Avocado** | ~5g |
| **Gesamt** | **~38g täglich ✅** |

**Empfehlung laut WHO:** 25–30g täglich — du liegst bereits **deutlich drüber.**

---

## Was Fiber+ enthält vs. was du schon hast

| Inhalt Fiber+ | Du hast es bereits |
|---|---|
| Psyllium (lösliche Faser) | ✅ Flohsamenschalen — identisch |
| Resistente Stärke | ✅ Haferflocken + Reis |
| Unlösliche Fasern | ✅ Gemüse + Beeren |

**Flohsamenschalen sind buchstäblich das gleiche wie Psyllium** — du nimmst es schon täglich.

---

## ✅ Fazit

**Spare die $30/Monat.** Deine Ernährung ist bereits ballaststoffreich optimiert — Flohsamenschalen + Chia + Haferflocken + Gemüse decken alles ab was Fiber+ bietet.

Das Geld ist bei **Tongkat Ali ($15)** deutlich besser investiert — der hat echten Mehrwert für deine spezifischen Ziele.

---

**Du:**

https://www.livemomentous.com/checkouts/cn/hWNCXWJWXzVYqQU8Nvk0OLpL/en?_r=AQABfSz-uWoSLKtghog5FrhbPGkys99-7T2cPIUTcv0TzBQ

---

**Claude:**

Das ist dein persönlicher Checkout-Link — den kann ich aus Datenschutzgründen nicht öffnen.

Schick mir lieber einen Screenshot oder sag mir welche Produkte du im Warenkorb hast — dann prüfe ich ob alles stimmt und ob du etwas vergessen hast oder doppelt drin ist.

---

**Du:**

Reicht das?

---

**Claude:**

Ich sehe deinen Warenkorb. Lass mich alles durchchecken:

---

## 🛒 DEIN WARENKORB — VOLLSTÄNDIGE ANALYSE

### Was drin ist (10 Produkte):

| Produkt | Preis | Intervall | Status |
|---|---|---|---|
| **Whey Protein Isolat (Unflavored)** | 39,71 € | Monatlich | ✅ |
| **Whey Protein Isolat (Chocolate)** | 39,71 € | Monatlich | ⚠️ |
| **Collagen Peptides** | 34,46 € | Monatlich | ⚠️ |
| **Creatin** | 26,21 € | Monatlich | ⚠️ |
| **Omega-3** | 26,21 € | Monatlich | ✅ |
| **Magnesium L-Threonat** | 32,96 € | Monatlich | ✅ |
| **Zinc** | Sichtbar | Monatlich | ✅ |
| **L-Theanin** | 26,21 € | 2-monatlich | ✅ |
| **Apigenin** | 15,71 € | 2-monatlich | ✅ |
| **Multivitamin** | 35,96 € | Monatlich | ✅ |

**Subtotal: 289,85 € (statt 386,50 €)**

---

## 🔴 3 DINGE ÄNDERN

### 1. Whey Protein Chocolate — raus oder behalten?
Du hast **2× Whey Protein** — Unflavored + Chocolate. Das gibt dir 50 Portionen insgesamt = 25 Tage bei 2 Portionen täglich. Macht Sinn wenn du beide Geschmäcker willst. Aber Chocolate enthält mehr Zutaten — Unflavored ist reiner.

**Empfehlung:** Chocolate rausnehmen · nur Unflavored · Geld sparen.

### 2. Collagen Peptides — hatten wir besprochen
Du brauchst es jetzt noch nicht — erst wenn Gelenkschmerzen auftreten. **34,46 €/Monat sparen.**

### 3. Kreatin — Intervall auf 3 Monate stellen
90 Portionen reichen 3 Monate. Monatliche Lieferung = du hast nach 3 Monaten 2 extra Packungen zuhause.

**→ Kreatin Lieferintervall auf "every 3 months" ändern.**

---

## ⚠️ WAS NOCH FEHLT

| Fehlendes Produkt | Wichtig? |
|---|---|
| **Tongkat Ali** | 🟠 Ja — für Cortisol + Testosteron · nur 14,96 €/Monat |
| **Vitamin D3** | 🔴 Ja — aber du hast es zuhause · ok |
| **Whey Protein 2. Portion** | Durch 2× Protein im Warenkorb gedeckt |

---

## ✅ OPTIMIERTER WARENKORB

| Produkt | Intervall | Preis |
|---|---|---|
| Whey Protein Unflavored | Monatlich | 39,71 € |
| ~~Whey Protein Chocolate~~ | ~~raus~~ | ~~-39,71 €~~ |
| ~~Collagen Peptides~~ | ~~raus~~ | ~~-34,46 €~~ |
| Kreatin | **3-monatlich** | 26,21 € (~8,74 €/Mo) |
| Omega-3 | Monatlich | 26,21 € |
| Magnesium L-Threonat | Monatlich | 32,96 € |
| Zinc | Monatlich | — |
| L-Theanin | 2-monatlich ✅ | 26,21 € |
| Apigenin | 2-monatlich ✅ | 15,71 € |
| Multivitamin | Monatlich | 35,96 € |
| **Tongkat Ali hinzufügen** | Monatlich | ~14,96 € |
| **Gesamt optimiert** | | **~ca. 200–210 €/Monat** |

---

## 💡 WICHTIGE BEOBACHTUNG

L-Theanin und Apigenin sind auf **2-monatliche Lieferung** eingestellt — das ist clever und richtig, da 60 Kapseln bei täglicher Einnahme 2 Monate reichen.

**Aber:** Magnesium L-Threonat separat + L-Theanin + Apigenin ist eigentlich das **Nightly Sleep Pack** — check ob das als Bundle günstiger ist als die 3 einzeln.

**Nächster Schritt:** Chocolate rausnehmen · Collagen rausnehmen · Kreatin auf 3 Monate · Tongkat Ali hinzufügen → dann bestellen.

---

**Du:**

https://www.livemomentous.com/collections/bundles prüfe

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Perfekt — ich habe alle verfügbaren Bundles. Hier ist die vollständige Übersicht und was für dich relevant ist:

---

## 📦 ALLE MOMENTOUS BUNDLES — PRÜFUNG FÜR DICH

---

### 🔴 1. Nightly Sleep Stack — RELEVANT
Magnesium L-Threonat + Apigenin + L-Theanin — die drei Schlaf-Supplements kombiniert in einem Bundle.

**Du hast diese 3 bereits einzeln im Warenkorb:**
| Einzeln in deinem Warenkorb | Preis |
|---|---|
| Magnesium L-Threonat | 32,96 € |
| Apigenin | 15,71 € (2-monatlich) |
| L-Theanin | 26,21 € (2-monatlich) |

> ⚠️ Leider aktuell **ausverkauft** — aber prüfe ob es wieder verfügbar ist. Als Bundle wäre es günstiger als einzeln.

---

### 🔴 2. Male Hormone Support Stack — SEHR RELEVANT FÜR DICH
Tongkat Ali + Zink kombiniert — für natürliche Testosteron-Unterstützung, Energie und männliche Vitalität. Drittgeprüft auf Reinheit.

Du hast **Zink bereits im Warenkorb** — Tongkat Ali fehlt noch. Dieses Bundle wäre günstiger als beide einzeln.

**Empfehlung: Zink aus Warenkorb raus → Male Hormone Stack rein.**

---

### 🟠 3. Complete Sleep Stack — UPGRADE OPTION
Magnesium L-Threonat + L-Theanin + Apigenin + Myo-Inositol (900mg) — Inositol 3–4× pro Woche zusätzlich für tieferen Schlaf und Serotonin-Produktion.

Das ist der Nightly Sleep Stack + Inositol. Für dich sinnvoll wenn du tiefen Schlaf maximieren willst — Myo-Inositol ist ein echter Bonus für Schlafqualität.

---

### 🟠 4. Brain, Body & Sleep Stack — INTERESSANT
Omega-3 + Magnesium L-Threonat + Tongkat Ali — Omega-3 für Kognition und Entzündung, Magnesium für Tiefschlaf, Tongkat Ali für Cortisol-Regulation und Testosteron.

Du hast Omega-3 und Magnesium bereits — aber Tongkat Ali fehlt. Nicht ideal da Dopplungen entstehen.

---

### 🟡 5. Complete Expert Stack — VOLLSTÄNDIG ABER AUSVERKAUFT
Enthält: Omega-3 · Magnesium · Apigenin · Inositol · L-Theanin · Tongkat Ali · Fadogia Agrestis · Zink · Alpha-GPC · Tyrosin · Kreatin · Acetyl-L-Carnitin — ausverkauft.

---

## ✅ MEINE KONKRETE EMPFEHLUNG

**So optimierst du deinen Warenkorb mit Bundles:**

| Aktion | Was | Ersparnis |
|---|---|---|
| **Zink raus** aus Warenkorb | Einzeln teurer | — |
| **Male Hormone Stack rein** | Tongkat Ali + Zink günstiger | ~5 € |
| **Nightly Sleep Stack prüfen** | Mag + Apigenin + L-Theanin | ~5–8 € wenn verfügbar |
| **Complete Sleep Stack** statt einzeln | + Inositol als Bonus | Sinnvoll |

---

## 🛒 DEIN OPTIMALER FINALER WARENKORB

| Produkt | Intervall | ca. Preis |
|---|---|---|
| **Whey Protein Isolat Unflavored** | Monatlich | ~40 € |
| ~~Whey Protein Chocolate~~ | ~~raus~~ | — |
| ~~Collagen Peptides~~ | ~~raus~~ | — |
| **Kreatin** | **3-monatlich** | ~26 € (~9 €/Mo) |
| **Omega-3** | Monatlich | ~26 € |
| **Complete Sleep Stack** (Mag + Apigenin + L-Theanin + Inositol) | Monatlich | ~45 € |
| ~~Magnesium einzeln~~ | ~~raus~~ | — |
| ~~Apigenin einzeln~~ | ~~raus~~ | — |
| ~~L-Theanin einzeln~~ | ~~raus~~ | — |
| **Male Hormone Stack** (Tongkat Ali + Zink) | Monatlich | ~25 € |
| ~~Zink einzeln~~ | ~~raus~~ | — |
| **Multivitamin** | Monatlich | ~36 € |
| **Gesamt** | | **~202 € /Monat** |

**Du sparst ~90 € gegenüber deinem aktuellen Warenkorb (289 €) — und bekommst mehr (Inositol + Tongkat Ali).**

---

**Du:**

wenn ich expert stack nehme habe ich dann alels

---

**Claude:**

Kurze Erinnerung aus unserer Analyse:

**Complete Expert Stack ist aktuell ausverkauft** — das war das Problem.

Aber angenommen er wird wieder verfügbar — lass mich prüfen was drin ist vs. was du brauchst:

---

## Expert Stack — Hast du dann alles?

### ✅ Was im Expert Stack enthalten ist:
Omega-3 · Magnesium L-Threonat · Apigenin · Inositol · L-Theanin · Tongkat Ali · Fadogia Agrestis · Zink · Alpha-GPC · Tyrosin · Kreatin · Acetyl-L-Carnitin

---

## Vergleich mit deinem kompletten Bedarf:

| Supplement | Expert Stack | Status |
|---|---|---|
| **Omega-3** | ✅ | Abgedeckt |
| **Magnesium L-Threonat** | ✅ | Abgedeckt |
| **Apigenin** | ✅ | Abgedeckt |
| **L-Theanin** | ✅ | Abgedeckt |
| **Inositol** | ✅ | Bonus |
| **Tongkat Ali** | ✅ | Abgedeckt |
| **Zink** | ✅ | Abgedeckt |
| **Alpha-GPC** | ✅ | Abgedeckt |
| **L-Tyrosin** | ✅ | Abgedeckt |
| **Kreatin** | ✅ | Abgedeckt |
| **Acetyl-L-Carnitin** | ✅ | Bonus |
| **Fadogia Agrestis** | ✅ | Bonus Testosteron |
| **Whey Protein** | ❌ | Fehlt |
| **Vitamin D3** | ❌ | Zuhause ✅ |
| **Vitamin K2** | ❌ | Zuhause ✅ |
| **Multivitamin** | ❌ | Fehlt |

---

## ✅ FAZIT

**Fast alles** — nur 2 Dinge separat:

| Was fehlt | Lösung | Preis |
|---|---|---|
| **Whey Protein Isolat** | Momentous separat · Unflavored | ~40 €/Monat |
| **Multivitamin** | Momentous Essential Multi separat | ~36 €/Monat |
| **D3 + K2** | ✅ Zuhause vorhanden | 0 € |

---

## 💰 GESAMTKOSTEN wenn Expert Stack wieder verfügbar:

| Produkt | Preis Abo |
|---|---|
| **Complete Expert Stack** | ~196 € (25% off) |
| **Whey Protein Isolat** | ~40 € |
| **Multivitamin** | ~36 € |
| **Gesamt** | **~272 €/Monat** |

Das ist günstiger als alles einzeln — und du hast **100% deines Protokolls abgedeckt.**

**Empfehlung:** Auf den Expert Stack warten bis er wieder verfügbar ist + Protein + Multivitamin separat dazu. Das ist die einfachste und vollständigste Lösung.

---

**Du:**

ok habe ich in den warenkorb hinzugefügt

ist das nach hubermans und rhonda

---

**Claude:**

Fast — aber nicht 100%. Lass mich schnell prüfen was noch fehlt:

---

## ✅ DEIN STACK vs. HUBERMAN & RHONDA PATRICK STANDARD

| Supplement | Dein Stack | Huberman | Rhonda Patrick |
|---|---|---|---|
| **Omega-3** | ✅ Expert Stack | ✅ | ✅ |
| **Magnesium L-Threonat** | ✅ Expert Stack | ✅ | ✅ |
| **Apigenin** | ✅ Expert Stack | ✅ | — |
| **L-Theanin** | ✅ Expert Stack | ✅ | — |
| **Kreatin** | ✅ Expert Stack | ✅ | ✅ |
| **Alpha-GPC** | ✅ Expert Stack | ✅ | — |
| **L-Tyrosin** | ✅ Expert Stack | ✅ | — |
| **Tongkat Ali** | ✅ Expert Stack | ✅ | — |
| **Zink** | ✅ Expert Stack | ✅ | ✅ |
| **Inositol** | ✅ Expert Stack | ✅ | — |
| **Acetyl-L-Carnitin** | ✅ Expert Stack | 🟡 | — |
| **Whey Protein Isolat** | ✅ Separat | ✅ | ✅ |
| **Multivitamin** | ✅ Separat | ✅ | ✅ |
| **Vitamin D3** | ✅ Zuhause | ✅ | ✅ |
| **Vitamin K2** | ✅ Zuhause | ✅ | ✅ |
| **Sulforaphan** | ❌ Fehlt | — | 🔴 Nr.1 |
| **NMN/NR** | ❌ Fehlt | 🟡 ab 35+ | 🟡 |

---

## 🔴 WAS NOCH FEHLT

### 1. Sulforaphan — Rhonda Patricks Nr. 1 Supplement
Das einzige wirklich fehlende Supplement aus Patricks Protokoll. Nicht bei Momentous erhältlich.

**Lösung:** Sunday Natural Sulforaphan (sunday.de) · ~20–25 €/Monat

### 2. NMN — optional
Huberman nimmt es aber erst ab 35 Jahren relevant. Du bist 32 — **noch nicht nötig.**

---

## ✅ FAZIT

**Zu 95% nach Huberman & Rhonda Patrick Standard** — mit einem einzigen Zusatz komplett:

| Was | Wo | Preis |
|---|---|---|
| **Sulforaphan** | sunday.de | ~22 €/Monat |

Dann bist du **100% nach beiden Protokollen** abgedeckt — besser als die meisten Menschen die diese Protokolle verfolgen.

**Nächster Schritt:** Checkout bei Momentous abschließen → Sulforaphan bei Sunday Natural bestellen → fertig.

---

**Du:**

finde mir einen Rabattcode

---

**Claude:**

```
This block is not supported on your current device yet.
```

Hier sind alle verfügbaren Rabatte für Sunday Natural:

---

## 🏷️ SUNDAY NATURAL — RABATTCODES MAI 2026

### ✅ Beste Optionen:

| Rabatt | Wie | Code |
|---|---|---|
| **10% Neukunden** | Newsletter abonnieren auf sunday.de | Per E-Mail nach Anmeldung |
| **10% Influencer-Codes** | Mehrere Codes zuletzt genutzt am 24.05.2026 — noch aktiv | Ausprobieren: **TAN8...** · **NINA...** · **LECA...** |
| **Bis 20% auf Bundles** | Automatisch ohne Code auf Sets und Bundles — wird direkt im Shop angezeigt | Kein Code nötig |
| **Kostenloser Versand** | Ab 49–69 € Bestellwert automatisch | Kein Code nötig |

---

## 💡 SO BEKOMMST DU DEN BESTEN RABATT

**Schritt 1:** Newsletter auf sunday.de abonnieren → 10% Willkommenscode per E-Mail

**Schritt 2:** Sulforaphan in den Warenkorb → über 49 € = kostenloser Versand

**Schritt 3:** Code beim Checkout eingeben

---

## ⚠️ HINWEIS

Die vollständigen Influencer-Codes sind auf Gutschein-Seiten hinter einem Klick versteckt. Die sicherste Methode ist der **Newsletter** — der Code kommt garantiert und ist offiziell gültig.

**sunday.de → Newsletter abonnieren → 10% Code sichern → Sulforaphan bestellen.**

---

**Du:**

für momentous

---

**Claude:**

```
This block is not supported on your current device yet.
```

Hier sind alle aktuell verfügbaren Rabattcodes:

---

## 🏷️ MOMENTOUS RABATTCODES — MAI 2026

### ✅ Beste & aktuell bestätigte Codes:

| Code | Rabatt | Status | Zuletzt geprüft |
|---|---|---|---|
| **GALPIN** | 10–15% | Am 30.12.2025 bestätigt funktionierend | Ausprobieren |
| **RICHROLL** | 10–15% | Aktuell in Top-5 der meistgenutzten Codes | ✅ Ausprobieren |
| **THEDINK** | 10–15% | Höchste Erfolgsrate in den letzten 7 Tagen | ✅ Ausprobieren |
| **Subscribe & Save** | **25%** | Automatisch · kein Code nötig · erste + alle Folgebestellungen | ✅ Garantiert |
| **Newsletter** | 15% | Erste Bestellung für neue Abonnenten | ✅ Nach Anmeldung |

---

### 💡 MAXIMALE ERSPARNIS — So gehst du vor:

**Schritt 1:** Newsletter auf livemomentous.com abonnieren → **15% Code** per E-Mail

**Schritt 2:** Subscribe & Save aktivieren → **25% automatisch**

**Schritt 3:** Codes **RICHROLL** oder **THEDINK** beim Checkout ausprobieren

> ⚠️ Nur ein Code pro Bestellung möglich — wähle den mit der höchsten Ersparnis. Subscribe & Save (25%) schlägt meistens alle anderen Codes.

---

### 🎖️ SPECIAL — 20% für bestimmte Berufsgruppen

Militär · Ersthelfer · Krankenpfleger · Lehrer · Regierungsangestellte erhalten 20% über ID.me Verifizierung beim Checkout.

---

**Bei deiner Bestellung von ~272 €/Monat spart Subscribe & Save (25%) bereits ~90 € — das ist dein bester Deal.**

---

**Du:**

Untersuche und ergänze hier

---

**Claude:**

Das ist ein professioneller 3D-Körperscan von heute Morgen — sehr wertvolle Daten. Lass mich alles analysieren und mit deinen Zielen abgleichen:

---

## 📊 DEIN 3D-KÖRPERSCAN — VOLLSTÄNDIGE ANALYSE
### Scaneca · Labor Berlin · 29.05.2026 · 08:25

---

## 🔢 KÖRPERWERTE — EHRLICHE BEWERTUNG

| Parameter | Dein Wert | Normalbereich | Status | Bewertung |
|---|---|---|---|---|
| **Gewicht** | 96,7 kg | 66–88 kg | 🔴 Über | Ziel: 85–88 kg |
| **Körperfett** | **20,3%** | unter 23% | ✅ Im Bereich | Ziel: 15–16% |
| **Magermasse** | **77,1 kg** | 56–83 kg | ✅ Gut | Sehr solide Basis |
| **FFMI** | **21,3** | 19–24 | ✅ Gut | Athletisch normal |
| **BMI** | 27,4 | 18,5–25 | 🔴 Über | Wenig aussagekräftig |
| **Taille/Hüfte** | **0,92** | unter 0,86 | 🔴 Erhöht | Bauchfett-Risiko |
| **Taille/Größe** | **0,52** | 0,40–0,50 | 🔴 Über | Ziel: unter 0,50 |
| **Grundumsatz** | **2.113 kcal** | — | ℹ️ | Basis für Kalorien |

---

## 📏 UMFÄNGE — VERGLEICH MIT UNSEREN ZIELEN

| Messstelle | Heute (Scan) | Vorherige Schätzung | Differenz | Ziel 6 Monate |
|---|---|---|---|---|
| **Taille** | **97,2 cm** | 108 cm | **−10,8 cm** ✅ | 88–90 cm |
| **Bauch** | **101,4 cm** | — | Neu | unter 94 cm |
| **Hüfte** | **105,5 cm** | — | Neu | 98–100 cm |
| **Brust** | **116,7 cm** | 123 cm | −6,3 cm | 122–125 cm ↑ |
| **Schulter** | **120,0 cm** | 120 cm | ✅ Exakt | 124–126 cm ↑ |
| **Oberarm R** | **36,3 cm** | — | Neu | 40–42 cm ↑ |
| **Oberschenkel R** | **59,9 cm** | 60 cm | ✅ Exakt | 64–66 cm ↑ |

> ⚠️ Wichtige Korrektur: Deine Taille ist 97,2 cm — nicht 108 cm wie wir vorher geschätzt hatten. Das ist bereits deutlich besser als angenommen. Ziel 88–90 cm ist realistisch in 3–4 Monaten.

---

## 🎯 REVIDIERTE ZIELE — BASIEREND AUF ECHTEN DATEN

### Körperfett: 20,3% → 15%
Du musst **ca. 5,3% Körperfett abbauen** — das sind bei 77,1 kg Magermasse und 96,7 kg Gesamtgewicht:

| Berechnung | Wert |
|---|---|
| Aktuelles Fettgewicht | 96,7 × 0,203 = **19,6 kg Fett** |
| Ziel-Fettgewicht (15%) | 77,1 ÷ 0,85 × 0,15 = **13,6 kg Fett** |
| Abzubauendes Fett | **~6 kg reines Fett** |
| Bei 500 kcal Defizit | **~3 Monate** |
| Bei 300 kcal Defizit | **~5 Monate** |

---

## 🏋️ MUSKEL-ANALYSE — FFMI 21,3

**FFMI (Fat-Free Mass Index) 21,3 ist solide** — aber hier liegt dein größtes Potenzial:

| FFMI | Bedeutung |
|---|---|
| 18–20 | Unterdurchschnittlich |
| 20–22 | Durchschnittlich normal |
| **21,3 — Du** | **Guter Ausgangspunkt** |
| 22–24 | Athletisch |
| 25+ | Sehr muskulös (natürliches Maximum ~25–26) |

Mit konsequentem Training und deinem Protein-Stack kannst du FFMI auf **23–24** bringen — das ist der athletische Bereich.

---

## ⚖️ BALANCE & HALTUNG — WICHTIGE BEFUNDE

| Befund | Was es bedeutet | Was tun |
|---|---|---|
| **Körperschwerpunkt nach rechts** | Rechtes Bein trägt mehr Last | Einbeinige Übungen einbauen |
| **Linke Schulter 0,6 cm höher** | Minimale Asymmetrie | Normal — kein Handlungsbedarf |
| **Rechter Arm stärker** | R: +0,6 cm Oberarm | Dominante Seite — normal |
| **Rechtes Bein mehr Volumen** | R: +1,3 cm Oberschenkel | Dominante Seite — normal |
| **Kopf-Vorneigung 30°** | Vorwärtsgeneigter Kopf | Nackentraining — bereits im Plan ✅ |

---

## 🔴 DER WICHTIGSTE BEFUND — KOPF-VORNEIGUNG

Schulterwinkel 30,5° und Kopfabstand zum Lot 19,9 cm — das ist eine ausgeprägte **Forward Head Posture**. Das entsteht durch langes Sitzen am Computer.

**Was das verursacht:**
- Nacken- und Schulterschmerzen langfristig
- Atemkapazität reduziert
- Sieht optisch schlechter aus

**Was du bereits in deinem Plan hast:** Nackentraining Mittwoch und Samstag ✅

**Zusätzlich täglich:** Chin Tucks — Kinn 10× täglich nach hinten ziehen · 3 Sätze · kostet 2 Minuten.

---

## 📊 REVIDIERTER ERNÄHRUNGS-PLAN — BASIEREND AUF ECHTEM GRUNDUMSATZ

Der Scan zeigt **Grundumsatz 2.113 kcal** — fast identisch mit unserer Berechnung (2.140 kcal). Das bestätigt alles.

| | Scan-Wert | Unser Plan | Status |
|---|---|---|---|
| Grundumsatz | 2.113 kcal | 2.140 kcal | ✅ Bestätigt |
| TDEE (×1,725) | 3.645 kcal | 3.692 kcal | ✅ Bestätigt |
| Zielkalorien (−500) | 3.145 kcal | 3.192 kcal | ✅ Bestätigt |

**Dein Ernährungsplan bleibt unverändert — die Daten bestätigen ihn.**

---

## ✅ ZUSAMMENFASSUNG — WAS DU JETZT WEISST

| | Vorher (Schätzung) | Jetzt (Scan) | Bewertung |
|---|---|---|---|
| Körperfett | ~24% | **20,3%** | Besser als gedacht ✅ |
| Taille | ~108 cm | **97,2 cm** | Deutlich besser ✅ |
| Magermasse | Unbekannt | **77,1 kg** | Sehr gut für Ziele ✅ |
| Grundumsatz | 2.140 kcal | **2.113 kcal** | Bestätigt ✅ |
| Ziel KFA 15% | 6 Monate | **3–4 Monate** | Schneller erreichbar ✅ |

---

## 🎯 ANGEPASSTE ZEITLINIE

| Monat | Gewicht | Taille | KFA | Meilenstein |
|---|---|---|---|---|
| **Heute** | 96,7 kg | 97,2 cm | 20,3% | Scan-Baseline ✅ |
| **Monat 1** | 94,5 kg | 94,5 cm | 18,5% | Taille unter 95 cm |
| **Monat 2** | 92,5 kg | 92,0 cm | 17,0% | Taille unter 93 cm |
| **Monat 3** | 90,5 kg | 90,0 cm | 15,5% | Ziel fast erreicht |
| **Monat 4** | 89,0 kg | 88,5 cm | 15,0% | ✅ Ziel erreicht |

**Nächster Schritt:** Diese Werte als Woche-1-Baseline in dein Körper-Tracking-Blatt der Excel-Datei eintragen — und in 4 Wochen neu scannen lassen.

---

**Du:**

Ich möchte es so schnell wie möglich erreichen und effektiv

---

**Claude:**

Direkt und ehrlich — hier ist der schnellste evidenzbasierte Weg:

---

## ⚡ SCHNELLSTER WEG ZUM ZIEL
### Von 20,3% auf 15% KFA · 97,2 cm auf 88 cm Taille · in 10–12 Wochen

---

## 🔢 DIE MATHEMATIK

| | Wert |
|---|---|
| Abzubauendes Fett | 6 kg |
| Max. sicherer Fettabbau/Woche | 700–800g |
| Benötigte Zeit minimal | **8–10 Wochen** |
| Realistisch mit Muskelerhalt | **10–12 Wochen** |

> Schneller als 10 Wochen = Muskelabbau. Das willst du nicht — dann verlierst du deine 77,1 kg Magermasse.

---

## 🔴 DIE 5 HEBEL — IN REIHENFOLGE DER WIRKUNG

---

### Hebel 1 — Kaloriendefizit maximieren (größte Wirkung)

**Zielkalorien: 2.800 kcal täglich**

Das ist aggressiv aber sicher — 845 kcal unter TDEE:

| | Wert |
|---|---|
| TDEE (bestätigt durch Scan) | 3.645 kcal |
| Defizit | 845 kcal |
| Fettabbau/Woche | ~800g |
| Protein | **220g täglich — nicht verhandelbar** |
| Kohlenhydrate | 270g |
| Fett | 70g |

**Mahlzeiten angepasst auf 2.800 kcal:**

| Mahlzeit | Was | Kcal |
|---|---|---|
| Shake 07:40 | Whey 50g + Kreatin | 200 |
| Frühstück 08:30 | 500g Quark + 150g Beeren + 50g Haferflocken + 15 Mandeln | 620 |
| Mittag 13:00 | 150g Hähnchen + 150g Reis + 300g Gemüse + 1 EL Öl | 620 |
| Abend 19:30 | 200g Hähnchen/Thunfisch + 200g Reis + 300g Gemüse + ½ Avocado | 720 |
| Protein Ice Cafe | Doppelte Portion | 234 |
| Mozzarella | 100g Light | 140 |
| **Gesamt** | | **~2.534 kcal** |

> Feinjustierung: 50g Reis extra oder 100g Quark extra um auf 2.800 zu kommen.

---

### Hebel 2 — Training optimieren (zweitgrößte Wirkung)

**HIIT 2× statt 1× pro Woche:**

| Tag | Training | Änderung |
|---|---|---|
| Montag | Beine | ✅ bleibt |
| Dienstag | 🆕 HIIT (20 Min) + Sauna | NEU — statt nur Sauna |
| Mittwoch | Oberkörper Brust-Fokus | ✅ bleibt |
| Donnerstag | Zone-2 + Hund | ✅ bleibt |
| Freitag | HIIT (20 Min) | ✅ bleibt |
| Samstag | Arme + Schultern | ✅ bleibt |
| Sonntag | Zone-2 langer Spaziergang | ✅ bleibt |

**Warum Dienstag HIIT hinzufügen:** HIIT erhöht den Nachbrenneffekt (EPOC) — du verbrennst 24–48h nach dem Training mehr Kalorien. 2× HIIT/Woche = ~400 kcal extra Verbrauch wöchentlich.

---

### Hebel 3 — Cortisol weiter senken (Bauchfett-spezifisch)

Dein Taille/Hüfte-Verhältnis 0,92 zeigt viszerales Fett — das ist reines Cortisol-Fett. Drei Sofortmaßnahmen:

| Maßnahme | Wann | Wirkung |
|---|---|---|
| **Ashwagandha 600mg** | Morgens mit Mahlzeit | Cortisol ↓ 20–30% in 8 Wochen |
| **NSDR täglich** | 20:00 Uhr | Cortisol-Reset täglich |
| **Schlafen 20:30** | Konsequent | Testosteron ↑ · Cortisol ↓ |

---

### Hebel 4 — Fasten verlängern (Insulin senken)

Aktuell isst du von 07:40–19:30 = **11,8h Fenster**.

**Optimiert für maximalen Fettabbau:**
- Erste Mahlzeit: **09:00** (Shake weiter im Auto · Frühstück erst um 09:00)
- Letzte Mahlzeit: **19:00**
- Fastenfenster: **14 Stunden**

Das senkt Insulin für 14h täglich — in dieser Zeit verbrennt dein Körper ausschließlich Fett.

---

### Hebel 5 — Zone-2 erhöhen (Fettverbrennung optimieren)

Dein Hund morgens (60 Min) + abends (60 Min) = bereits 120 Min Zone-2 täglich. Das ist außergewöhnlich gut.

**Donnerstag zusätzlich:** 30 Min Radfahren nach Mittagshund = Zone-2 auf 150+ Min an diesem Tag.

**Wochentotal Zone-2:** ~250–280 Min — deutlich über Hubermans Ziel von 180–200 Min.

---

## 📅 DEIN 10-WOCHEN SPRINT-PLAN

| Woche | Fokus | Erwartet |
|---|---|---|
| **1–2** | Kalorien auf 2.800 · Fasten 14h · Cortisol-Protokoll | −1,0–1,5 kg |
| **3–4** | HIIT 2× · Ashwagandha einführen · Scan Woche 4 | −1,5 kg |
| **5–6** | Progressive Überladung Brust + Arme · Diät stabil | −1,5 kg |
| **7–8** | Letzte aggressive Phase · alles konsequent | −1,0 kg |
| **9–10** | Feintuning · Muskeln zeigen sich · Scan Woche 10 | −0,5–1,0 kg |
| **Gesamt** | | **−6–7 kg Fett** |

---

## 📊 ZIELWERTE IN 10 WOCHEN

| Messung | Heute | Ziel Woche 10 |
|---|---|---|
| Gewicht | 96,7 kg | **89–90 kg** |
| Körperfett | 20,3% | **15,0%** |
| Taille | 97,2 cm | **88–90 cm** |
| Bauch | 101,4 cm | **92–94 cm** |
| Magermasse | 77,1 kg | **76–77 kg** (erhalten) |
| FFMI | 21,3 | **21,5–22** |
| Taille/Hüfte | 0,92 | **unter 0,86** |

---

## ✅ SOFORT-AKTIONSPLAN — DIESE WOCHE

| Tag | Aktion |
|---|---|
| **Heute** | Ashwagandha bei Sunday Natural bestellen |
| **Heute** | Kalorien auf 2.800 anpassen — Haferflocken auf 50g · Mandeln auf 15 Stück |
| **Morgen** | Erstmals um 05:00 aufstehen · Training 06:20 |
| **Dienstag** | HIIT statt nur Sauna |
| **Täglich** | Fasten bis 09:00 · Letztes Essen 19:00 |
| **In 4 Wochen** | Neuer Scaneca-Scan — Fortschritt messen |

---

> **Die wichtigste Erkenntnis aus deinem Scan:** Du hast bereits 77,1 kg Magermasse — das ist eine ausgezeichnete Basis. Du musst nur das Fett darüber abbauen. Das Fundament ist bereits da — jetzt freigraben.

**Nächster Schritt:** Soll ich die angepassten 2.800 kcal Mahlzeiten als aktualisiertes Excel-Blatt speichern?

---

**Du:**

Ja bitte anpassen

Aktuell trainiere ich 4 tage 

Brust Rücken Beine Arme soll ich das weiter machen oder was ist der beste Trainingsplatz für mich 

Prüfe auch Bryan Johnson’s

---

**Claude:**

Lass mich erst Bryan Johnson prüfen, dann baue ich alles zusammen:
```
This block is not supported on your current device yet.
```

Jetzt habe ich alles — Bryan Johnson, Huberman, dein Scan und deine aktuelle Routine. Lass mich alles zusammenbauen:

---

## 🏋️ VERGLEICH — 3 ANSÄTZE FÜR DICH

### Was Bryan Johnson macht:
Täglich 1 Stunde · 25 Übungen · 3× HIIT pro Woche · 4,5h Zone-2 pro Woche · Ziel ist ausschließlich Longevity und Anti-Aging — kein Muskelaufbau, kein Bodybuilding.

**Für dich nicht ideal** — dein Ziel ist Fett abbauen + Muskeln aufbauen. Johnson optimiert für Longevity, nicht für Körperkomposition.

---

## 🏆 DEIN OPTIMALER TRAININGSPLAN
### Kombination: Huberman + Bryan Johnson + deine Ziele

**Dein aktueller 4-Tage-Split (Brust/Rücken/Beine/Arme) ist solide — aber nicht optimal für dein Ziel.** Das Problem: Kein HIIT, kein Zone-2, keine Frequenz-Optimierung.

**Beste Lösung für dich:** Auf 6 Tage erweitern mit klarem Fokus.

---

## 📅 DEIN NEUER 6-TAGE TRAININGSPLAN

| Tag | Training | Fokus | Dauer |
|---|---|---|---|
| **Mo** | 💪 Obere Brust + Trizeps | Schrägbank · Dips · Kabel | 50 Min |
| **Di** | ⚡ HIIT + Sauna | 8–12 Runden · Assault Bike | 30 Min |
| **Mi** | 🦵 Beine + Hintern | Hack Squats · Leg Press · Curls | 50 Min |
| **Do** | 💪 Rücken + Bizeps | Klimmzüge · Rudern · Curls | 50 Min |
| **Fr** | ⚡ HIIT + Sauna | 8–12 Runden · Assault Bike | 30 Min |
| **Sa** | 💪 Schultern + Arme | Seitheben · Trizeps · Nacken | 50 Min |
| **So** | 🏃 Zone-2 | Langer Spaziergang + Hund | 75 Min |

---

### Warum dieser Split besser ist als Brust/Rücken/Beine/Arme:

| | Dein alter 4-Tage Split | Neuer 6-Tage Split |
|---|---|---|
| **HIIT** | ❌ Kein | ✅ 2× pro Woche |
| **Muskelfrequenz** | 1× pro Woche | 1–2× pro Woche |
| **Obere Brust Fokus** | 🟡 Gemischt | ✅ Eigener Tag |
| **Zone-2** | ❌ Kein | ✅ Sonntag + Hund täglich |
| **Fettabbau** | Langsam | Deutlich schneller |
| **Bryan Johnson Element** | ❌ | ✅ Mobilität + HIIT täglich |

---

### Montag — Obere Brust + Trizeps (dein wichtigster Tag)

| # | Übung | Sätze | Wdh | Fokus |
|---|---|---|---|---|
| 1 | Schrägbankdrücken 30° (Langhantel) | 4 | 6–8 | Obere Brust — Hauptübung |
| 2 | Schrägbank Kurzhantel Flyes | 3 | 10–12 | Obere Brust Dehnung |
| 3 | Kabel Crossover (hoch→unten) | 3 | 12–15 | Obere Brust Isolation |
| 4 | Trizeps Dips mit Gewicht | 4 | 6–10 | Trizeps Masse |
| 5 | Skull Crushers | 3 | 8–10 | Langer Trizepskopf |
| 6 | Kabel Pushdown | 3 | 12–15 | Trizeps Definition |
| 7 | Nackentraining | 2 | 15 | Haltung + Prävention |

---

### Mittwoch — Beine (Bryan Johnson Prinzip: Beine = Longevity)

| # | Übung | Sätze | Wdh |
|---|---|---|---|
| 1 | Hack Squats | 4 | 8–10 |
| 2 | Leg Press | 3 | 10–12 |
| 3 | Leg Curls (liegend) | 3 | 10–12 |
| 4 | Calf Raises (schwer bis Versagen) | 3 | 6–10 |
| 5 | Tibialis Raises | 2 | 15 |
| 6 | Rückwärtsgehen (Laufband) | 1 | 5 Min |

---

### Donnerstag — Rücken + Bizeps

| # | Übung | Sätze | Wdh |
|---|---|---|---|
| 1 | Klimmzüge (breiter Griff) | 4 | max |
| 2 | Langhantelrudern | 3 | 8–10 |
| 3 | Kabelrudern eng | 3 | 10–12 |
| 4 | Lat Pulldown | 3 | 10–12 |
| 5 | Bizepscurls (Kurzhantel) | 3 | 10–12 |
| 6 | Hammer Curl | 3 | 10–12 |

---

### Samstag — Schultern + Arme (leichter Tag)

| # | Übung | Sätze | Wdh |
|---|---|---|---|
| 1 | Schulterdrücken (Maschine) | 3 | 10–12 |
| 2 | Seitheben (Kabel) | 3 | 12–15 |
| 3 | Face Pulls | 3 | 15 |
| 4 | Overhead Trizeps Extension | 3 | 10–12 |
| 5 | Concentration Curl | 3 | 12 |
| 6 | Waden (2. Mal) | 2 | 12–15 |

---

### Bryan Johnson Element — täglich 10 Min Mobilität

Johnson beginnt jede Session mit 10 Minuten dynamischer Mobilität: Hüft- und Schulterübungen wie Wall Slides, Arm Circles, Thread the Needle und Hip CARs.

**Für dich täglich vor dem Training (5 Min):**
- 10× Arm Circles vorwärts + rückwärts
- 10× Hip CARs pro Seite
- 10× Chin Tucks (Kopfvorneigung korrigieren — dein Scan zeigt 30°)
- 10× Thoracic Rotations

---

## 🍽️ ERNÄHRUNGSPLAN — 2.800 KCAL ANGEPASST

| Mahlzeit | Was | Gramm | Kcal | Protein |
|---|---|---|---|---|
| **07:40 Shake im Auto** | Whey Isolat + Kreatin | 50g + 5g | 200 | 45g |
| **09:00 Frühstück** | Magerquark + Beeren + Haferflocken 50g + 15 Mandeln + Flohsamen + Chia | 500+150+50+20+8+10g | 620 | 58g |
| **13:00 Mittag** | Hähnchen/Thunfisch + Reis + Gemüse + Mozzarella Light + 1 EL Öl | 150+150+300+80+10g | 620 | 58g |
| **Nachmittag** | Protein Ice Cafe (doppelt) | 60g | 234 | 45g |
| **19:00 Abend** | Hähnchen/Thunfisch + Reis + Gemüse + ½ Avocado | 200+180+300+100g | 720 | 52g |
| **Gesamt** | | | **~2.794 kcal** | **~218g** |

✅ Kalorien: 2.794 (~2.800 Ziel)
✅ Protein: 218g (Ziel: 220g)
🟡 Carbs: ~265g (Ziel: 270g)
✅ Fett: ~72g (Ziel: 70g)

---

Jetzt baue ich das als Excel-Blatt:
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Hier ist dein kompletter optimierter Plan — 4 Blätter:

| Blatt | Inhalt |
|---|---|
| **Scan Baseline** | Alle Scan-Werte · Ziele 10 Wochen · Haltungsbefunde |
| **Trainingsplan Optimiert** | Neuer 6-Tage Split · alle Übungen mit Technik · Bryan Johnson Elemente |
| **Ernährung 2.800 kcal** | Angepasste Makros · Mahlzeiten nach Gramm · 10-Wochen Tracker |
| **Huberman vs Johnson** | Vollständiger Vergleich · was du übernimmst |

---

## Deine 3 wichtigsten Änderungen ab heute:

**1. Trainingsplan:** Von 4 auf 6 Tage · HIIT jetzt Dienstag UND Freitag · Obere Brust bekommt eigenen Montags-Tag

**2. Kalorien:** Von 3.090 auf **2.800 kcal** · Defizit von 845 kcal statt 350 · **2× schnellerer Fettabbau**

**3. Fasten:** Von 11,3h auf **14h täglich** · Erste Mahlzeit erst 09:00 · Letzte Mahlzeit 19:00

**In 10 Wochen erwartet:** 96,7 → 89–90 kg · Taille 97,2 → 88–90 cm · KFA 20,3 → 15%

---

**Du:**

Ist es gut den kefir zu trinken

---

**Du:**

Ist es gut den kefir zu trinken

---

**Claude:**

Das ist ein **ja! Kefir** — lass mich die Nährwerte direkt analysieren:

---

## Ja! Kefir 500g — Analyse

| Nährwert | pro 100g | pro Portion (500g) |
|---|---|---|
| Kalorien | 45 kcal | 226 kcal |
| Fett | 1,5g | 7,5g |
| Gesättigte Fettsäuren | 1,0g | 5,0g |
| Kohlenhydrate | 4,1g | 21g |
| Zucker | 4,1g | 21g |
| Ballaststoffe | 0g | 0g |
| **Eiweiß** | **3,2g** | **16g** |

---

## ✅ Gut für dich — mit einer Einschränkung

**Was gut ist:**
- 16g Protein für 226 kcal — solides Verhältnis
- Probiotika — Darmgesundheit · Immunsystem
- Passt in dein Kalorienziel

**Was zu beachten:**
- 21g Zucker (Laktose) — natürlich aber bei Insulinsensitivität relevant
- Weniger Protein als dein Magerquark (500g Quark = 55g Protein vs. 16g hier)
- Kein Ballaststoffgehalt

---

## Vergleich mit deinem Plan

| | Kefir 500g | Magerquark 500g |
|---|---|---|
| Protein | 16g | 55g |
| Kalorien | 226 kcal | 290 kcal |
| Zucker | 21g | 16g |
| Probiotika | ✅ | 🟡 weniger |

---

## ✅ Empfehlung

**Ja — aber als Ergänzung, nicht als Ersatz für deinen Quark.**

Ideal als **Pre-Workout Drink** oder **Snack zwischen den Mahlzeiten** — nicht als Frühstücksersatz, da zu wenig Protein für dein 220g Tagesziel.

Oder: **250g Kefir + 250g Quark** kombinieren — dann hast du Probiotika + hohes Protein.

---

**Claude:**

Gleiche Packung, anderes Foto — gleiche Analyse gilt. Schöner Hund übrigens! 🐕

---

## Kurze Antwort: Ja, trinken — aber mit Kontext

**500g Kefir = 16g Protein · 226 kcal · 21g Zucker (Laktose)**

Für dein Protokoll:

| Szenario | Empfehlung |
|---|---|
| **Als Frühstücksersatz** | ❌ Zu wenig Protein (nur 16g statt 64g Ziel) |
| **Zusätzlich zum Quark** | ✅ Probiotika + extra Protein |
| **Als Snack zwischen Mahlzeiten** | ✅ Passt gut |
| **Nach dem Training** | 🟡 Ok aber Whey Shake ist besser |
| **Abends** | ✅ Casein-ähnlich · langsame Aufnahme |

---

## Beste Nutzung für dich

**Kefir nicht statt Quark — sondern zusätzlich:**

Morgen-Option: 300g Quark + 200g Kefir = 41g Protein · bessere Probiotika · gleiche Kalorien wie 500g Quark.

Oder einfach so trinken wenn du Hunger hast — 226 kcal und 16g Protein sind kein schlechter Snack.

---

