---
date: 2026-05-08
tags: [claude]
---

# Zeitschätzung für 31 km Lauf

**Du:**

Wie lange brauche ich für 31 km Lauf

---

**Claude:**

Bei welchem Tempo läufst du normalerweise — oder soll ich dir eine Schätzung basierend auf deinem Fitness-Level geben?

---

**Du:**

Ja bitte ich muss morgen um 10 Uhr im Garten von den Eltern von laufe sein daher wollte ich hin laufen danach beim Kompost helfen

---

**Claude:**

Kurze Rückfrage: Was ist dein ungefähres Lauftempo — eher Anfänger (7–8 min/km), ambitioniert (5–6 min/km), oder irgendwo dazwischen?

---

**Du:**

Dazwischen

---

**Claude:**

Bei ~6:30 min/km brauchst du für 31 km etwa **3:20–3:30 Stunden**.

Für 10:00 Uhr Ankunft → **Abfahrt spätestens 06:30 Uhr**.

Einkalkulieren:
- 10–15 Min Aufwärmen/Start
- Evtl. kurze Pausen unterwegs

**Empfehlung:** Starte um **06:15 Uhr** — dann bist du entspannt pünktlich da und hast noch Luft, dich kurz frisch zu machen bevor du beim Kompost anpackst.

Soll ich das als Wecker-Erinnerung setzen?

---

**Du:**

Ich brauche 5:30-6:00 min

---

**Claude:**

Bei 5:45 min/km brauchst du für 31 km etwa **2:58–3:05 Stunden**.

Für 10:00 Uhr Ankunft → **Abfahrt spätestens 06:55 Uhr**.

Mit Puffer → Start um **06:45 Uhr**.

Soll ich dir einen Wecker oder eine Erinnerung für morgen früh setzen?

---

**Du:**

Ist das realistisch oder zu Ambitioniert

---

**Claude:**

Für jemanden mit deinem Trainingsstand (6x/Woche Gym + regelmäßige Zone-2 Walks) ist die Ausdauerbasis solide — aber 31 km am Stück ist eine andere Kategorie als deine üblichen Einheiten.

**Ehrliche Einschätzung:**

- 5:30–6:00 min/km über 31 km ist **ambitioniert bis sehr ambitioniert** — das entspricht fast einem Halbmarathon-Tempo über mehr als die doppelte Distanz
- Realistisch könntest du die zweite Hälfte auf **6:30–7:00 min/km** einbrechen
- Gesamtzeit eher **3:15–3:30h** → Abfahrt **06:30 Uhr**

**Meine Empfehlung:**
Starte bei 6:00 min/km und lass dein Gefühl entscheiden. Plane aber mit **06:30 Uhr Abfahrt** — lieber zu früh da als zu spät und ausgepumpt vorm Kompost-Einsatz.

Wecker für 06:00 Uhr setzen?

---

