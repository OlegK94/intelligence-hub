---
date: 2026-04-20
tags: [claude]
---

# Apple Fotos systematisch aufräumen

**Du:**

Wie kann man Apple Fotos am besten ausmisten und aufräumen?

Man hat immer viel Fotos oder Screenshots die man nicht Brauch die vom Apple System nicktt zu erkannt werden

---

**Claude:**

# Apple Fotos aufräumen – systematisch & effizient

## Das Grundproblem verstehen

Apple Photos erkennt Duplikate und unscharfe Bilder teilweise, aber **Screenshots, irrelevante Downloads und "Ballast-Fotos"** fallen durchs Raster. Das musst du aktiv angehen.

---

## Die beste Strategie: Hybrid-Ansatz

### 1. Apple-Bordmittel zuerst (kostenlos)

In der Fotos-App gibt es unter **„Dienstprogramme"** (linke Sidebar):

- **Duplikate** → automatisch erkannt, mit einem Klick zusammenführen
- **Für dich** → zeigt unerwünschte Screenshots oft in eigenen Alben

### 2. Smart Albums als Filter nutzen

Erstelle in Fotos eigene Alben mit Filtern:
- Medientyp = **Screenshot** → alle auf einmal sichten & löschen
- Medientyp = **Bildschirmaufnahme**

### 3. Drittanbieter-Tools (der eigentliche Gamechanger)

| Tool | Stärke | Preis |
|------|--------|-------|
| **Gemini 2** | Duplikate + ähnliche Fotos, sehr smart | ~€10/Jahr |
| **CleanMaster Photos** | Massenlöschung nach Kategorie | kostenlos/IAP |
| **Slidebox** | Tinder-Style durchswipen | kostenlos |
| **Unfolder** | Ähnliche Gruppen clustern | einmalig ~€5 |

**Empfehlung: Gemini 2** – erkennt auch "fast-gleiche" Fotos (z.B. 12 Bursts vom selben Moment).

---

## Mein empfohlener Workflow

```
1. Screenshots-Album leeren         → 10 Min
2. Duplikate via Apple mergen       → 5 Min  
3. Gemini 2 durchlaufen lassen      → 30–60 Min
4. "Zuletzt gelöscht" leeren        → sofort
```

**Wichtig:** Erst nach dem Leeren des "Zuletzt gelöscht"-Ordners wird wirklich Speicher frei.

---

## Langfristig sauber bleiben

- **Screenshots** direkt nach Gebrauch löschen (Gewohnheit)
- iCloud-Mediathek aktivieren → sync über alle Geräte, nur einmal aufräumen
- Einmal im Quartal: Gemini-Scan

---

**Nächster Schritt:** Wie groß ist deine Bibliothek ungefähr (Anzahl Fotos)? Dann kann ich den Aufwand realistisch einschätzen und ggf. einen gezielteren Ansatz empfehlen.

---

