---
date: 2026-06-07
tags: [claude]
---

# Hyrox-Vorbereitung: Analyse und Optimierungshebel

**Du:**

Hier sind meine aktuellen Körperdaten aus dem letzten 
Scan (29.05.2026): 96.7 kg, 20.3% KF, Lean Mass 77.1 kg, 
Taille-Hüfte 0.92. Hyrox-Vorbereitung läuft. 
Analysiere meinen aktuellen Stand und sag mir ehrlich 
was die drei größten Hebel für meine Ziele sind.

---

**Claude:**

Let me analyze Oleg's full scan data and provide a sharp, honest assessment. Let me go through everything carefully.

**Body Composition:**
- 96.7 kg, 188 cm, 32 years old
- 20.3% body fat = ~19.6 kg fat mass
- Lean Mass: 77.1 kg
- FFMI: 21.3 (decent, within normal range 19-24)
- BMI: 27.4 (overweight category)
- Basal Metabolic Rate: 2,113 kcal
- Current intake: ~2,800 kcal, ~220g protein
- Waist-to-hip ratio is 0.92, which is elevated compared to the healthy target of under 0.86, and his waist-to-height ratio of 0.52 is slightly above the optimal 0.40-0.50 range—both suggesting excess visceral fat despite decent overall body composition metrics. His posture shows significant forward head positioning at around 30 degrees, which is something we'll need to address.

Looking at his structural alignment, there's a notable rightward shift in his center of gravity with asymmetries throughout—his left shoulder sits 0.6 cm higher than the right, and his left hip shows a more pronounced offset from the midline compared to the right. His right side is consistently dominant across all measurements, with the right leg nearly a liter heavier than the left and the right arm measuring 0.5-1.5 cm larger at most points, which correlates with the 53-47 weight distribution favoring his right side.

The visceral fat accumulation is his primary metabolic concern—his waist-to-hip ratio of 0.92 exceeds the healthy threshold of 0.86, and with his abdomen measuring 101.4 cm against a waist of 97.2 cm, the fat is concentrated centrally, which carries the highest metabolic risk. To reach a healthier ratio, he'd need to reduce his waist circumference by roughly 6.5 cm, which would require losing approximately 4-5 kg of fat.

For Hyrox performance, his aerobic capacity is the limiting factor, and his body composition explains why—carrying nearly 20 kg of excess fat through eight 1-kilometer runs and functional stations adds significant dead weight that directly impairs his VO2max. Every kilogram of fat loss will meaningfully improve his running efficiency across those segments.

The forward head posture at 30 degrees is biomechanically problematic, creating roughly 18-27 kg of effective compressive force on his cervical spine despite his head weighing only about 5 kg normally. This postural deviation compromises his breathing mechanics and likely contributes to his aerobic limitations.

His waist-to-hip ratio of 0.92 indicates visceral fat is the primary concern, not subcutaneous fat. While he's already in a caloric deficit at 2,800 kcal relative to his estimated TDEE of 3,200-3,500 kcal, visceral fat responds to specific metabolic interventions beyond simple calorie restriction.

For Zone 2 training, the aerobic capacity limitation is the real bottleneck in Hyrox performance—at 96.7 kg, every kilometer of running carries significantly more metabolic cost than it would at a lighter body weight, making the aerobic base the critical limiting factor to address.

The forward head posture and asymmetry are performance and injury concerns, not just postural issues. The 30° forward head position restricts thoracic extension and shoulder flexion, which directly undermines rowing power transfer and breathing efficiency under load. Combined with the 53/47 strength split and the 4.6 cm hip asymmetry, this creates a problematic injury risk pattern.

A targeted 10-15 minute daily protocol addressing deep neck flexors, thoracic extension, and hip asymmetry will compound into significant Hyrox performance gains. The harder truth is that the 20.3% body fat with central/visceral distribution—evidenced by the abdomen measurement exceeding the waist measurement—is the real metabolic and longevity concern, and the current caloric intake may need reassessment.

The FFMI of 21.3 is respectable but the upper body development goal takes a backseat to fat loss; meaningful muscle definition and aerobic improvements won't materialize at this body composition. The real priorities are visceral fat reduction to shift the waist-to-hip ratio from 0.92 toward 0.86, building a solid Zone 2 aerobic base for both Hyrox performance and metabolic acceleration, and correcting the postural issues that are currently limiting performance ceiling and injury resilience.

What's crucial here is recognizing these three aren't separate problems—Zone 2 training is the master intervention that simultaneously addresses all of them. Fat loss improves aerobic capacity, better posture enhances breathing mechanics which boosts aerobic function, and Zone 2 work mobilizes visceral fat while building the aerobic foundation. I'll structure the response around these three interconnected levers without the wellness noise.## Ehrliche Bewertung: Stand 29.05.2026

Starke Grundlage. 77.1 kg Lean Mass bei FFMI 21.3 ist solide. 220g Protein täglich ist richtig. Aber drei Dinge blockieren dich konkret — und alle drei hängen zusammen.

---

**Hebel 1: Viszerales Fett ist dein primäres Longevity-Problem**

Der WHR von 0.92 sagt mehr als die 20.3% KF. Dein Bauchumfang (101.4 cm) liegt *über* der Taille (97.2 cm) — das ist keine periphere Fettverteilung, das ist metabolisch aktives viszerales Fett. Der Normalbereich der Scaneca-Skala endet bei 0.86 — du liegst 7% drüber.

Was du brauchst, um auf 0.86 zu kommen: Taille von 97.2 auf ~90.7 cm. Das sind ~6.5 cm Taillenumfang, realistisch 6–8 kg netto Fettmasse. Bei deiner Lean Mass und Proteinzufuhr machbar ohne nennenswerten Muskelverlust.

Die unbequeme Wahrheit: Bei 2,800 kcal und deinem Grundumsatz von 2,113 kcal ist dein Defizit kleiner als du wahrscheinlich denkst. Wenn dein TDEE bei Hyrox-Belastung ~3,200 kcal liegt, bist du bei ~400 kcal Defizit — das ist korrekt, aber viszerales Fett reagiert *spezifisch* auf Zone 2 Intensität und Insulinsensitivität. Kohlenhydratqualität und -timing sind hier relevanter als die reine Kalorienbilanz.

---

**Hebel 2: Aerobe Basis fehlt — das ist strukturell, nicht trainingsbedingt**

Du nennst aerobe Kapazität selbst als Hauptlimiter. Der Scan erklärt einen Teil davon: 30° Kopfvorneigung komprimiert den thorakalen Einlass und limitiert Zwerchfellexkursion. Unter Belastung — besonders Rudern und Ski Erg — überaktivierst du Skaleni und SCM als Atemhilfsmuskulatur statt primär über das Zwerchfell zu atmen. Das kostet aerobe Effizienz, bevor du überhaupt ins metabolische Limit kommst.

Das zweite Problem: Hyrox-Athleten verbringen zu viel Zeit im Graubereich (70–85% HFmax) und zu wenig in echtem Zone 2 (<75% HFmax, Nasenatemkapazität). Zone 2 ist der einzige Reiz, der Mitochondriendichte in Typ-1-Fasern strukturell erhöht — das ist was dein Limiter wirklich braucht.

Zone 2 macht gleichzeitig Hebel 1 effizienter: FFA-Oxidation läuft in Zone 2, viszerales Fett mobilisiert bevorzugt bei niedrig-mittelintensiver aerober Arbeit über sustainte Zeit.

---

**Hebel 3: Die Rechts-Asymmetrie wird dich in der Hyrox-Vorbereitung einholen**

Das ist der blinde Fleck in deinem Profil. 53% Körperlast rechts, linkes Hüftgelenk sitzt 4.6 cm weiter vom Lot als rechts (R: 6.1 cm, L: 10.7 cm) — das ist eine ausgeprägte laterale Beckenverschiebung nach links bei rechtsseitigem Schwerpunkt. In Kombination mit der 30° Kopfvorneigung ergibt das eine Belastungskette: rechter Fuß → rechtes Knie → rechte Hüfte trägt die Hauptlast, während links kompensiert.

Bei steigendem Hyrox-Volumen (8× 1km Laufen bei 96+ kg) ist das ein strukturierter Weg zu Knie- oder IT-Band-Problemen links — klassisches Überkompensationsmuster. Nicht wenn, sondern wann.

---

## Was das bedeutet: Prioritätenreihenfolge

Alle drei Hebel haben einen gemeinsamen Kern: **Zone 2 + Posturkorrektur** ist das Primärprotokoll — beides adressiert aerobe Basis, visz. Fettmobilisierung und entlastet die Asymmetrie.

Konkret:
- **Ernährung:** Defizit auf ~500 kcal erhöhen (→ 2,300 kcal), Protein bleibt bei 220g, Kohlenhydrate timing-optimiert (peritraining), Verzicht auf flüssige Kalorien und Raffiniertes konsequent umsetzen
- **Zone 2:** 3–4×/Woche, 45–60 min, strikte Nasenatemkontrolle als Intensitätslimiter — Ruder-Erg ist Priorität wegen Hyrox-Spezifität
- **Haltungsprotokoll:** Täglich 10 min tiefer Nackenflexoren + thorakale Extension + einseitige Hüftstabilisierung links — das ist kein Wellness-Add-on, das ist Verletzungsprävention und Leistungsfreischaltung

---

**Nächster Schritt:** Ich baue dir das konkrete Wochenprotokoll — Trainingsstruktur, Ernährungstiming und das tägliche 10-min-Haltungsprotokoll als sofort ausführbares Dokument. Willst du das auf Basis deines aktuellen Wochenplans (Trainingstage, Sitzzeit, Schlafroutine)?

---

