---
date: 2026-04-08
tags: [claude]
---

# Fashion Brand Gründung mit Marktanalyse

**Du:**

Schreibe meinen Prompt für mein vorhaben


Denke wie ein Investor und löse ein konkretes Problem

Ziel ist es eine Fashion Brand zu gründen die ein Problem löst wie bsp. das ich beschrieben habe


Prüfe den gesamten weltweiten Markt und mach dazu eine richtige MArktanalyse prüfe USPs Risiken, Kosten, Vor und Nachteile etc.

Mach eine Projektbeschreibung am Ende

Prüfe ob noch weitere Punkte bedacht werden sollten

---

**Claude:**

```
This block is not supported on your current device yet.
```

Bevor ich den Prompt schreibe — eine kurze Frage, damit er präzise auf dein Vorhaben zugeschnitten ist:
```
This block is not supported on your current device yet.
```

---

**Du:**

F: Was ist das konkrete Problem, das deine Fashion Brand lösen soll?
A: Fehlende Premium-Basics für Männer (Fit, Qualität, Ästhetik)

F: Wie soll der Prompt ausgegeben werden?
A: Als interaktives HTML-Artifact (schön formatiert, kopierbar)

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Der Prompt ist fertig — du kannst entweder alle vier Blöcke zusammen oder einzelne Abschnitte kopieren.

Ein paar Hinweise zur Nutzung:

Starte am besten in einem neuen, leeren Chat damit, damit die Analyse ohne Vorkontext erfolgt. Der Prompt ist bewusst so formuliert, dass er dich als Gründer herausfordert — die Investor-Rolle erzwingt ehrliche, datenbasierte Antworten statt Bestätigungsschleifen.

Was der Prompt abdeckt: Marktgröße & Wachstum, Wettbewerber-Benchmarks, Unit Economics, Startkapital-Kalkulation, Risikoanalyse und am Ende ein vollständiges Investor Memo — also alles, was du für eine ernst gemeinte Entscheidungsgrundlage brauchst.

Wenn du die Analyse dann hast, können wir die relevantesten Teile direkt in deine ARYS Brandstrategie einarbeiten.

---

**Du:**

Das Problem muss geprüft werden es isst aktuell noch eine Theorie die ich denke das es so ist da ich mit vielen spreche und es selbst teste

Preis soll nicht 60€ übersteigen klares minimalistisches Design aber auch shirts mit auffälligen designs könenn dabei sein

---

**Claude:**

Guter Punkt — eine unvalidierte Theorie als Fundament für eine Brand zu bauen ist eines der häufigsten Fehler bei Gründungen. Lass uns das sauber angehen.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Ich habe den ursprünglichen Prompt in drei Phasen aufgeteilt, weil das der ehrlichere und sicherere Weg ist.

Die Logik dahinter: Ein Investor würde dir in Phase 3 die Frage stellen "Wie viele echte Menschen haben dir das bestätigt?" — und wenn die Antwort "ein paar Freunde und ich selbst" ist, ist das Gespräch vorbei. Also erst das Fundament gießen.

Was du konkret jetzt tun kannst, ohne einen Cent auszugeben:

Starte mit Phase 1 — lass das Modell deine Hypothese auseinandernehmen und dir die unbequemen Gegenfragen stellen. Dann geh mit dem Interview-Leitfaden aus Phase 2 in echte Gespräche — nicht mit Freunden, sondern mit Fremden (Reddit, Instagram DMs, Berliner Streetwear-Communities). Und bau parallel einen minimalen Smoke-Test: eine Landing Page mit Waitlist, kein Produkt, nur die Idee.

Erst wenn du 15+ echte Signale hast, fütterst du Phase 3 — dann wird die Marktanalyse auch wirklich wertvoll, weil sie auf echten Daten sitzt.

---

