---
date: 2026-04-11
tags: [claude]
---

# Optimale Claude-Konfiguration

**Du:**

Ich möchte das du dich auf das beste Claude Set up konfigurierst

---

**Claude:**

```
This block is not supported on your current device yet.
```

Gute Frage — lass mich kurz klären, was du meinst, damit ich dir wirklich helfen kann.

"Das beste Claude Setup" kann verschiedene Dinge bedeuten:

**Option 1 — Claude.ai optimieren** (dieses Interface hier)
Features aktivieren, Einstellungen anpassen, User Preferences setzen — z.B. damit ich immer auf Deutsch antworte, dein ARYS-Kontext automatisch berücksichtigt wird, bestimmte Formate bevorzugt werden usw.

**Option 2 — System Prompt / Custom Instructions schreiben**
Ich schreibe dir einen maßgeschneiderten System Prompt, der mich für deine spezifischen Workflows (ARYS Brand, Fitness, Legal etc.) konfiguriert.

**Option 3 — Claude API Setup**
Technisches Setup für Entwickler — Modellauswahl, Parameter-Tuning, Tool Use usw.

**Option 4 — Claude Code**
Konfiguration für das CLI-Tool zum Coden.

Was hast du im Sinn?

---

**Du:**

Ich möchte das wir bei edem prompt den ich eingebe das richtige verfahren nutzt um das maximale ergebniss rauszuholen mit Kontext rolle etc

---

**Claude:**

Verstanden. Du willst, dass ich bei jedem deiner Prompts automatisch das optimale Framework anwende — Rolle, Kontext, Format, Chain-of-Thought etc. — ohne dass du das jedes Mal manuell spezifizieren musst.

Dafür schreibe ich dir einen **User Preferences Text**, den du einmalig in den Claude.ai Einstellungen hinterlegst. Dann gilt er für alle zukünftigen Gespräche.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Hier ist das komplette Setup — ein visuelles Reference Card und der fertige Text für deine User Preferences.
```
This block is not supported on your current device yet.
```

---

Jetzt der Text, den du direkt in **Claude.ai → Settings → User Preferences** einfügst:

---

**User Preferences für Claude:**

> Ich bin Oleg, Gründer der Premium-Lifestyle-Brand ARYS (Berlin, Kazakh roots). ARYS ist ein Multi-Vertikal-Ökosystem: Apparel, Café, Bar, Music Label (ARYS Records), Community Events — positioniert nach dem Modell von Aimé Leon Dore. Brand-Palette: Schwarz / Weiß / Gold. Schriften: Cormorant Garamond (Display), DM Mono (Body).
>
> **Verarbeitungsframework für jeden meiner Prompts:**
> 1. **Intent analysieren** — Aufgabentyp, Komplexität und gewünschten Output-Typ bestimmen, bevor geantwortet wird.
> 2. **Rolle einnehmen** — Die passende Expertenrolle wählen (z.B. Brand Strategist, Creative Director, Legal Researcher, Fitness Coach) und aus dieser Perspektive antworten.
> 3. **Reasoning-Tiefe kalibrieren** — Bei einfachen Tasks direkt antworten. Bei komplexen Themen schrittweise denken, Optionen abwägen und die Entscheidungslogik sichtbar machen.
> 4. **ARYS-Kontext einbeziehen** — Wenn relevant, Brand-Werte, Positionierung und Ästhetik in die Antwort einfließen lassen ohne dass ich es jedes Mal erklären muss.
> 5. **Format dem Zweck anpassen** — Vollständige, renderfähige Deliverables bevorzugen. Keine halben Antworten. Nächsten sinnvollen Schritt vorschlagen.
>
> **Stil:** Präzise, direkt, ohne Füllwörter. Deutsch oder Englisch je nach meiner Eingabe. Iterativ und output-driven.

---

**So aktivierst du es:** Settings → "User Preferences" oder "Custom Instructions" → Text einfügen → Speichern.

Ab dann läuft das Framework bei jedem Gespräch automatisch im Hintergrund — ohne dass du Role, Kontext oder Format manuell spezifizieren musst.

---

**Du:**

Lass arys raus und nutze es neutral

---

**Claude:**

```
This block is not supported on your current device yet.
```

Klaro. Hier der neutrale Version — kein ARYS, kein persönlicher Kontext, universell einsetzbar:

---

**User Preferences für Claude:**

> **Verarbeitungsframework für jeden Prompt:**
>
> 1. **Intent analysieren** — Aufgabentyp, Komplexität und gewünschten Output-Typ bestimmen, bevor geantwortet wird.
> 2. **Rolle einnehmen** — Die passende Expertenrolle wählen (z.B. Strategist, Analyst, Creative Director, Engineer, Researcher) und konsequent aus dieser Perspektive antworten.
> 3. **Reasoning-Tiefe kalibrieren** — Bei einfachen Tasks direkt antworten. Bei komplexen Themen schrittweise denken, Optionen abwägen, Entscheidungslogik transparent machen.
> 4. **Format dem Zweck anpassen** — Vollständige, sofort verwendbare Deliverables bevorzugen. Keine halben Antworten. Am Ende den sinnvollsten nächsten Schritt vorschlagen.
> 5. **Sprache anpassen** — Deutsch oder Englisch je nach meiner Eingabe. Präzise, direkt, ohne Füllwörter und ohne unnötige Absicherungen.

---

Kurz und wirkungsvoll. Funktioniert für jeden Use Case — Business, Kreatives, Tech, Research, alles.

---

**Du:**

Wie arbeiten Profis mit Claude bevor sie starten

---

**Claude:**

Gute Frage — hier die wichtigsten Praktiken, die erfahrene Claude-Nutzer anwenden, bevor sie in einen Task einsteigen:

---

**1. Kontext zuerst, Frage danach**

Statt direkt zu fragen, geben Profis zuerst den Rahmen: Wer sie sind, was das Ziel ist, für wen der Output gedacht ist. Claude kann nur so gut antworten wie der Kontext es erlaubt.

*Schlecht:* „Schreib mir eine E-Mail."
*Gut:* „Ich bin Produktmanager, schreibe an einen skeptischen CFO, Ziel ist Budget-Freigabe für Q3."

---

**2. Rolle explizit zuweisen**

„Du bist ein erfahrener M&A-Anwalt" liefert strukturell bessere Antworten als ohne Rollenzuweisung — weil es den Reasoning-Frame setzt, nicht nur den Ton.

---

**3. Output-Format spezifizieren**

Profis sagen im Voraus, was sie wollen: Fließtext, Stichpunkte, Tabelle, Code, Entscheidungsmatrix. Das spart Iterationsschleifen.

---

**4. Constraints nennen**

Länge, Sprache, was weggelassen werden soll, welche Annahmen gelten. Je enger der Rahmen, desto präziser das Ergebnis.

---

**5. Mit einem Briefing-Prompt starten**

Viele Profis schicken zuerst nur den Kontext — ohne direkte Aufgabe — und bitten Claude, Rückfragen zu stellen bevor es losgeht. Das deckt blinde Flecken auf.

*„Hier ist mein Projekt: [Kontext]. Bevor du anfängst — welche Informationen brauchst du noch für ein optimales Ergebnis?"*

---

**6. Iterativ arbeiten, nicht alles auf einmal**

Statt einen Mega-Prompt zu schreiben, arbeiten sie in Schritten: erst Struktur, dann Inhalt, dann Verfeinerung. Claude als Denkpartner, nicht als Automat.

---

**7. Beispiele mitgeben**

„Im Stil von X", „so wie dieses Beispiel [einfügen]" ist oft präziser als lange Beschreibungen. Ein gutes Beispiel sagt mehr als 200 Wörter Erklärung.

---

Das Kernprinzip dahinter: **Claude ist kein Suchfeld, sondern ein Gesprächspartner.** Wer das verinnerlicht, bekommt qualitativ andere Ergebnisse.

Willst du daraus ein persönliches Starter-Template bauen, das du vor jedem größeren Task nutzt?

---

**Du:**

Lass uns das genau so einrichten

---

**Claude:**

Lass uns kurz eingrenzen, damit das Template wirklich zu dir passt:
```
This block is not supported on your current device yet.
```

---

**Du:**

F: Für welche Bereiche nutzt du Claude hauptsächlich? (Wähle alle zutreffenden aus)
A: Texte & Kommunikation, Research & Analyse, Strategie & Business, Creative & Brand, Tech & Code

F: Wie willst du starten — soll Claude zuerst Rückfragen stellen oder direkt loslegen?
A: Erst Rückfragen, dann Output

F: Welche Sprache bevorzugst du im Output?
A: Immer Deutsch

---

**Claude:**

Perfekt — alle Bereiche, Rückfragen zuerst, immer Deutsch. Hier dein fertiges Starter-Template:

---

**Starter-Template — vor jedem größeren Task:**

> **Kontext:** [Wer du bist / welche Rolle du gerade einnimmst]
> **Ziel:** [Was am Ende entstehen soll]
> **Zielgruppe:** [Für wen ist der Output gedacht]
> **Constraints:** [Länge, Ton, was weggelassen werden soll]
> **Beispiel/Referenz:** [Optional — Stil, Format, Vorlage]
>
> Bevor du anfängst: Welche Informationen fehlen dir noch für ein optimales Ergebnis?

---

Und hier die **5 Rollenframes** nach deinen Bereichen — die du je nach Task vorne anhängst:

| Bereich | Rollenframe |
|---|---|
| Strategie & Business | „Du bist ein erfahrener Unternehmensberater mit McKinsey-Hintergrund." |
| Creative & Brand | „Du bist Creative Director einer internationalen Designagentur." |
| Tech & Code | „Du bist Senior Software Architect mit Fokus auf skalierbare Systeme." |
| Research & Analyse | „Du bist Research Analyst — präzise, quellenbasiert, keine Annahmen ohne Belege." |
| Texte & Kommunikation | „Du bist erfahrener Copywriter — prägnant, wirkungsstark, zielgruppengenau." |

---

**Wie es in der Praxis aussieht:**

> *„Du bist Creative Director einer internationalen Designagentur.*
> **Kontext:** Ich entwickle eine neue Produktlinie für eine Premium-Lifestyle-Brand.
> **Ziel:** Positionierungstext für die Landingpage.
> **Zielgruppe:** Urban, 25–40, kaufkräftig, designaffin.
> **Constraints:** Max. 150 Wörter, kein Marketing-Sprech, kein „innovativ".
> Bevor du anfängst: Welche Infos fehlen dir noch?"*

---

Willst du, dass ich das als User Preference Text formuliere, den du einmalig in Claude.ai hinterlegst — damit du das Template nicht jedes Mal neu tippen musst?

---

**Du:**

Ja wenn das das beste Set Up ist

---

**Claude:**

Es ist ein sehr gutes Setup — mit einer wichtigen Einschränkung:

**User Preferences** sind für dauerhafte Persönlichkeits- und Stilpräferenzen gedacht. Das Starter-Template funktioniert dort, aber der eigentliche Hebel liegt darin, dass du es **aktiv pro Task ausfüllst** — sonst fehlt Claude der spezifische Kontext, der den Unterschied macht.

Das beste Setup ist also **beides kombiniert:**

- **User Preferences** → setzt den Grundrahmen permanent
- **Starter-Template** → füllst du kurz aus wenn der Task es braucht

---

Hier der fertige Text für **Settings → User Preferences:**

---

> Antworte immer auf Deutsch, unabhängig von der Sprache meines Inputs.
>
> Analysiere vor jeder Antwort still: Aufgabentyp, Komplexität, optimale Expertenrolle und passendes Output-Format. Nimm die entsprechende Rolle ein ohne sie zu benennen.
>
> Bei komplexen oder mehrdeutigen Aufgaben: Stelle zuerst gezielte Rückfragen bevor du mit dem Output beginnst. Bei einfachen, klaren Tasks antworte direkt.
>
> Bevorzuge vollständige, sofort verwendbare Deliverables. Kein Fülltext, keine unnötigen Absicherungen. Schlage am Ende den sinnvollsten nächsten Schritt vor.
>
> Meine Hauptbereiche: Strategie & Business, Creative & Brand, Tech & Code, Research & Analyse, Texte & Kommunikation.

---

Und das **Starter-Template** speicherst du dir lokal — z.B. als Notiz oder Text-Snippet — und fügst es bei größeren Tasks vorne ein. 30 Sekunden Aufwand, deutlich besserer Output.

Soll ich dir das Template noch als schnell abrufbares Format aufbereiten — z.B. als minimalistische HTML-Seite die du lokal öffnen kannst?

---

**Du:**

weiter

---

**Claude:**

Ich brauche kurz mehr Kontext — was meinst du mit „weiter"?

- **Nächster Setup-Schritt** — z.B. das Starter-Template als lokale HTML-Seite bauen?
- **Weitere Profi-Praktiken** — was erfahrene Nutzer darüber hinaus machen?
- **Etwas anderes** — du hast noch einen Task im Kopf?

---

**Du:**

Nächster Schritt oder sind wir fertig

---

**Claude:**

Wir sind zu ~80% fertig. Was noch fehlt:

**Offen:**
1. **Starter-Template lokal verfügbar machen** — als HTML-Seite oder Text-Snippet, damit du es in 2 Sekunden abrufst und nicht jedes Mal neu tippst
2. **User Preferences aktivieren** — hast du den Text bereits in Claude.ai eingefügt?

---

Wenn beides erledigt ist, hast du ein vollständiges System:

- Permanenter Grundrahmen via User Preferences
- Schnell abrufbares Starter-Template für komplexe Tasks
- Klare Rollenframes für alle 5 Bereiche

Willst du, dass ich das Template als saubere HTML-Seite baue — öffnen, ausfüllen, kopieren, fertig?

---

**Du:**

erledigt

Welche Rollen soll ich als Privatperson wählen wenn ich Privat als Senior Account Executive arbeite bei Doctolib 

nebenbei eine Firma aufbauen möchte bsp. Fashion

---

**Claude:**

Gute Ausgangslage — drei verschiedene Kontexte, drei verschiedene Rollensets.

---

**Für deinen Job bei Doctolib**

| Situation | Rollenframe |
|---|---|
| Deals vorbereiten / Argumentation | Erfahrener B2B Sales Strategist mit Enterprise-Fokus |
| E-Mails / Kommunikation | Senior Copywriter für professionelle Geschäftskommunikation |
| Einwände / Verhandlung | Verhandlungsexperte mit Consultingbackground |
| Markt / Wettbewerb | Research Analyst mit Healthcare-Fokus |

---

**Für dein Fashion-Business**

| Situation | Rollenframe |
|---|---|
| Brand & Positionierung | Creative Director einer internationalen Modemarke |
| Businessplan / Finanzen | Unternehmensberater mit Startup- und Fashion-Erfahrung |
| Produkt & Hersteller | Supply Chain Experte für Fashion & Apparel |
| Content & Social | Fashion-fokussierter Creative Strategist |
| Legal / Verträge | Wirtschaftsanwalt mit Startup-Erfahrung |

---

**Privat**

| Situation | Rollenframe |
|---|---|
| Karriereentscheidungen | Executive Coach mit Fokus auf Ambitionierte in Doppelrolle |
| Finanzen / Investment | unabhängiger Finanzberater, konservativ und faktenbasiert |
| Gesundheit / Fitness | Sports & Performance Coach |

---

**Mein Vorschlag:** Ergänze deine User Preferences um eine Zeile:

> *„Ich arbeite hauptberuflich als Senior Account Executive im B2B SaaS (Healthcare) und baue nebenbei eine Fashion-Brand auf. Wähle Rollen entsprechend diesem Kontext."*

Dann muss ich den Rahmen nicht jedes Mal neu ableiten.

Soll ich die User Preferences direkt mit diesem Zusatz neu formulieren — als fertigen Text zum Einfügen?

---

**Du:**

Doctolib aufgaben raushalten da ich sie auf meinem Arbeitslaptop mache den Rest würde ich sonst zum aktuellen set up sinnvoll ergänzen

---

**Claude:**

Passt. Hier der aktualisierte **User Preferences Text** — dein bisheriger Rahmen plus die neuen Kontexte:

---

> Antworte immer auf Deutsch, unabhängig von der Sprache meines Inputs.
>
> Analysiere vor jeder Antwort still: Aufgabentyp, Komplexität, optimale Expertenrolle und passendes Output-Format. Nimm die entsprechende Rolle ein ohne sie zu benennen.
>
> Bei komplexen oder mehrdeutigen Aufgaben: Stelle zuerst gezielte Rückfragen bevor du mit dem Output beginnst. Bei einfachen, klaren Tasks antworte direkt.
>
> Bevorzuge vollständige, sofort verwendbare Deliverables. Kein Fülltext, keine unnötigen Absicherungen. Schlage am Ende den sinnvollsten nächsten Schritt vor.
>
> Meine Hauptbereiche: Strategie & Business, Creative & Brand, Tech & Code, Research & Analyse, Texte & Kommunikation.
>
> Persönlicher Kontext: Ich baue nebenbei eine Fashion-Brand auf. Wähle Rollen entsprechend — z.B. Creative Director, Brand Strategist, Supply Chain Experte, Wirtschaftsanwalt oder Fashion-fokussierter Creative Strategist — je nach Aufgabe.
>
> Für private Themen: Denke als Executive Coach, Finanzberater oder Performance Coach — je nach Kontext.

---

Einfach den alten Text in den Settings ersetzen. Das war's — Setup ist damit vollständig.

---

**Du:**

Macht es sind alle Rollen als Chief Rollen aufzusetzen?

---

**Claude:**

Kurze Antwort: **Nein — kontraproduktiv.**

**Warum:**

Chief-Rollen (CEO, CMO, CFO etc.) sind Generalistenrollen. Sie denken in Verantwortung, Überblick und Entscheidung — nicht in Tiefe und Handwerk.

Wenn du einen konkreten Output willst — einen Vertragstext, eine Positionierung, eine Finanzanalyse — brauchst du den Spezialisten, nicht den Chef.

---

**Die Faustregel:**

| Wenn du willst... | Nimm... |
|---|---|
| Strategie, Richtungsentscheidung | Chief-Rolle sinnvoll |
| Konkreten Output, Handwerk | Spezialisten-Rolle |
| Beides kombiniert | „Du bist CMO mit tiefem Brand-Handwerk" |

---

**Beispiel:**

- „Du bist CMO" → gibt dir Strategie-Denken, aber generische Copy
- „Du bist Senior Copywriter für Fashion-Brands" → gibt dir präzisen, verwendbaren Text

Die Rollen im aktuellen Setup sind bereits optimal kalibriert. Ich würde nichts ändern.

---

**Du:**

Baue das sinnvollste set Up auf

---

**Claude:**

```
This block is not supported on your current device yet.
```

Hier ist das vollständige, fertige Setup — alles an einem Ort:
```
This block is not supported on your current device yet.
```

Das ist dein komplettes Setup — vier Tabs, alles an einem Ort:

- **User Preferences** → Text kopieren, einmalig in Claude.ai einfügen, fertig
- **Rollen** → Nachschlagewerk für alle Kontexte
- **Starter-Template** → ausfüllen und direkt als Session starten
- **Anleitung** → wie alles zusammenspielt

Einziger offener Schritt: User Preferences in Claude.ai hinterlegen falls noch nicht erledigt.

---

**Du:**

Ich möchte jetzt mit dem Starter-Template arbeiten. Stelle mir zuerst gezielte Rückfragen bevor du anfängst.

---

**Claude:**

Bevor wir starten — füll kurz die wichtigsten Felder aus:
```
This block is not supported on your current device yet.
```

---

**Du:**

[User dismissed — do not proceed, wait for next instruction]

---

**Claude:**

Alles klar — ich warte auf deinen nächsten Input.

---

**Du:**

Ich möchte jetzt mit dem Starter-Template arbeiten. Stelle mir zuerst gezielte Rückfragen bevor du anfängst.

---

**Claude:**

Worum geht es — beschreib kurz den Task in einem Satz, dann stelle ich die richtigen Rückfragen.

---

**Du:**

Wie starte ich das Starter Template im neuen Chat am schnellsten

---

**Claude:**

Zwei Optionen — je nach Arbeitsweise:

**Option 1 — Fester Eröffnungssatz (schnellste)**

Speicher diesen Satz als Text-Snippet (Notiz, Textexpander, Apple Shortcuts):

> „Neuer Task. Stelle mir zuerst gezielte Rückfragen zu Kontext, Ziel, Zielgruppe und Constraints — bevor du anfängst."

Einmal einfügen, Claude fragt den Rest ab.

---

**Option 2 — Projekt in Claude.ai anlegen**

Unter claude.ai → Projects kannst du ein Projekt erstellen mit einem festen System Prompt. Dort hinterlegst du einmalig das vollständige Template-Framework. Jeder neue Chat im Projekt startet automatisch damit — ohne dass du irgendetwas einfügen musst.

---

**Empfehlung:** Option 2 ist das sauberste Setup für wiederkehrende Arbeit. Option 1 für alles was außerhalb eines Projekts läuft.

Willst du, dass ich den Project System Prompt dafür direkt aufsetze?

---

**Du:**

ok gib mir bitte das Template framework dafür

---

**Claude:**

Hier der fertige **Project System Prompt** — direkt einfügbar:

---

> Du bist mein persönlicher Experten-Assistent. Folgende Regeln gelten für jeden Task in diesem Projekt:
>
> **Sprache:** Antworte immer auf Deutsch, unabhängig von der Sprache meines Inputs.
>
> **Vor jedem Task:** Stelle mir gezielte Rückfragen zu den fehlenden Feldern — aber nur die, die du wirklich brauchst:
> - Kontext: Wer bin ich in dieser Situation / was ist der Hintergrund?
> - Ziel: Was soll am Ende entstehen?
> - Zielgruppe: Für wen ist der Output?
> - Constraints: Länge, Ton, was weggelassen werden soll?
> - Referenz: Gibt es ein Beispiel oder einen Stil den ich anstrebe?
>
> Wenn einzelne Felder aus dem Kontext klar sind, frag nicht danach. Stelle maximal 3 gezielte Fragen.
>
> **Rolle:** Analysiere still welche Expertenrolle optimal passt und nimm sie ein ohne sie zu benennen. Meine Bereiche: Fashion-Brand (Brand Strategist, Creative Director, Supply Chain, Fashion Copywriter, Wirtschaftsanwalt), Strategie & Business, Creative & Brand, Tech & Code, Research & Analyse, Texte & Kommunikation, Privat (Executive Coach, Finanzberater, Performance Coach).
>
> **Output:** Vollständige, sofort verwendbare Deliverables. Kein Fülltext, keine unnötigen Absicherungen. Am Ende den sinnvollsten nächsten Schritt vorschlagen.

---

**So richtest du es ein:**

Claude.ai → linke Sidebar → **Projects** → **New Project** → oben rechts **Project Instructions** → Text einfügen → Speichern.

Ab dann startet jeder Chat in diesem Projekt automatisch mit dem Framework — du schreibst einfach deinen Task rein, Claude fragt den Rest.

---

**Du:**

Muss ich es in Proekte immer starten oder geht es auch über chat

---

**Claude:**

Beides geht — hier der Unterschied:

**Projekte**
Kontext ist dauerhaft gespeichert. Jeder neue Chat startet automatisch mit deinem Framework. Ideal für wiederkehrende Themenbereiche wie Fashion-Brand oder Strategie.

**Normaler Chat**
Kein dauerhafter Kontext. Du müsstest den System Prompt jedes Mal manuell einfügen — oder den einen Eröffnungssatz von vorhin nutzen.

---

**Empfehlung für dich:**

Leg dir 2-3 Projekte an, thematisch getrennt:

| Projekt | Wofür |
|---|---|
| Fashion Brand | Alles rund um den Markenaufbau |
| Strategie & Leben | Business, Finanzen, Private Entscheidungen |
| Creative & Copy | Texte, Kampagnen, Content |

Normaler Chat bleibt für schnelle Einzel-Fragen ohne Template-Bedarf.

So hast du das beste aus beiden Welten — strukturiertes Arbeiten in Projekten, schnelle Antworten im Chat.

---

**Du:**

ok lets do

---

**Claude:**

Los geht's. Drei Schritte:

**1. Projekt anlegen**
Claude.ai → linke Sidebar → **New Project** → Name eingeben, z.B. „Fashion Brand"

**2. System Prompt einfügen**
Im Projekt oben rechts → **Project Instructions** → den Text von vorhin einfügen → Speichern

**3. Wiederholen** für „Strategie & Leben" und „Creative & Copy"

---

Sobald ein Projekt steht — einfach neuen Chat darin öffnen, Task reinschreiben, Claude fragt den Rest.

Sag Bescheid wenn du hängst oder wir direkt mit dem ersten Task starten sollen.

---

**Du:**

Lass uns diese drei aufsetzen muss ich dafür das selbe template nutzen?

---

**Claude:**

Nein — jedes Projekt bekommt ein leicht angepasstes Template. Gleiche Struktur, aber Rolle und Fokus sind unterschiedlich kalibriert.

Hier alle drei fertig:

---

**Projekt 1 — Fashion Brand**

> Du bist mein Experten-Team für den Aufbau meiner Fashion-Brand. Antworte immer auf Deutsch.
>
> Vor jedem Task: Stelle gezielte Rückfragen zu Kontext, Ziel, Zielgruppe und Constraints — maximal 3, nur was wirklich fehlt.
>
> Wähle die passende Rolle still: Brand Strategist, Creative Director, Supply Chain Experte, Fashion Copywriter, Wirtschaftsanwalt oder Startup-Finanzberater — je nach Aufgabe.
>
> Output: Vollständige, sofort verwendbare Deliverables. Kein Fülltext. Nächsten Schritt am Ende vorschlagen.

---

**Projekt 2 — Strategie & Leben**

> Du bist mein strategischer Sparringspartner für Business- und Privatentscheidungen. Antworte immer auf Deutsch.
>
> Vor jedem Task: Stelle gezielte Rückfragen zu Kontext, Ziel und Constraints — maximal 3, nur was wirklich fehlt.
>
> Wähle die passende Rolle still: Unternehmensberater, Executive Coach, unabhängiger Finanzberater oder Performance Coach — je nach Aufgabe.
>
> Output: Klare Entscheidungsgrundlagen, Analysen oder Handlungsempfehlungen. Kein Fülltext. Nächsten Schritt am Ende vorschlagen.

---

**Projekt 3 — Creative & Copy**

> Du bist mein Creative Partner für Texte, Kampagnen und Content. Antworte immer auf Deutsch.
>
> Vor jedem Task: Stelle gezielte Rückfragen zu Kontext, Ziel, Zielgruppe, Ton und Constraints — maximal 3, nur was wirklich fehlt.
>
> Wähle die passende Rolle still: Fashion Copywriter, Creative Strategist, Content Director oder Texter für Premium-Brands — je nach Aufgabe.
>
> Output: Fertige, sofort verwendbare Texte und Konzepte. Kein Fülltext. Nächsten Schritt am Ende vorschlagen.

---

Jeden Text einfach in die **Project Instructions** des jeweiligen Projekts einfügen — fertig. Drei Minuten Arbeit insgesamt.

---

**Du:**

Welche Proekte setzen Profis auf

---

**Claude:**

Kommt stark auf den Kontext an — aber hier die Muster die sich bewähren:

**Prinzip:** Ein Projekt pro Lebens- oder Arbeitsbereich mit eigenem Kontext, eigener Rolle, eigenen Dateien.

---

**Für jemanden in deiner Situation**

| Projekt | Zweck |
|---|---|
| Fashion Brand | Markenaufbau, Produktion, Strategie, Legal |
| Creative & Copy | Texte, Kampagnen, Content, Social |
| Strategie & Leben | Business-Entscheidungen, Finanzen, Privates |
| Research | Markt, Wettbewerb, Trends — mit hochgeladenen Dokumenten |

Das sind die vier die für dich Sinn ergeben. Mehr wäre Overengineering.

---

**Was Profis zusätzlich machen**

Dokumente ins Projekt hochladen — z.B. Brandbook, Businessplan, Verträge. Claude liest sie automatisch mit und muss nicht jedes Mal neu gebrieft werden.

Ein Projekt als „Inbox" nutzen — schnelle Ideen, Notizen, Drafts die noch keinem Bereich zugeordnet sind.

---

**Was nicht funktioniert**

Zu viele Projekte anlegen. Ab 6-7 verlierst du den Überblick welches Projekt welchen Kontext hat — und der Vorteil geht verloren.

---

Für dich sind die drei die wir gerade aufgesetzt haben plus eventuell ein viertes für Research das Optimum. Willst du den Research-Prompt auch noch haben?

---

**Du:**

Lass uns die besten Projekte anlegen

---

**Claude:**

Für deine Situation sind es genau diese vier:
```
This block is not supported on your current device yet.
```

---

**Du:**

F: Welche Projekte sollen wir aufsetzen?
A: Fashion Brand, Creative & Copy, Strategie & Leben, Research

---

**Claude:**

Hier alle vier fertigen Project Instructions — direkt einfügbar:

---

**Projekt 1 — Fashion Brand**

> Du bist mein Experten-Team für den Aufbau meiner Fashion-Brand. Antworte immer auf Deutsch.
>
> Vor jedem Task: Stelle gezielte Rückfragen zu Kontext, Ziel, Zielgruppe und Constraints — maximal 3, nur was wirklich fehlt.
>
> Wähle die passende Rolle still: Brand Strategist, Creative Director, Supply Chain Experte, Fashion Copywriter, Wirtschaftsanwalt oder Startup-Finanzberater — je nach Aufgabe.
>
> Output: Vollständige, sofort verwendbare Deliverables. Kein Fülltext. Nächsten Schritt am Ende vorschlagen.

---

**Projekt 2 — Creative & Copy**

> Du bist mein Creative Partner für Texte, Kampagnen und Content. Antworte immer auf Deutsch.
>
> Vor jedem Task: Stelle gezielte Rückfragen zu Kontext, Ziel, Zielgruppe, Ton und Constraints — maximal 3, nur was wirklich fehlt.
>
> Wähle die passende Rolle still: Fashion Copywriter, Creative Strategist, Content Director oder Texter für Premium-Brands — je nach Aufgabe.
>
> Output: Fertige, sofort verwendbare Texte und Konzepte. Kein Fülltext. Nächsten Schritt am Ende vorschlagen.

---

**Projekt 3 — Strategie & Leben**

> Du bist mein strategischer Sparringspartner für Business- und Privatentscheidungen. Antworte immer auf Deutsch.
>
> Vor jedem Task: Stelle gezielte Rückfragen zu Kontext, Ziel und Constraints — maximal 3, nur was wirklich fehlt.
>
> Wähle die passende Rolle still: Unternehmensberater, Executive Coach, unabhängiger Finanzberater oder Performance Coach — je nach Aufgabe.
>
> Output: Klare Entscheidungsgrundlagen, Analysen oder Handlungsempfehlungen. Kein Fülltext. Nächsten Schritt am Ende vorschlagen.

---

**Projekt 4 — Research**

> Du bist mein Research Analyst. Antworte immer auf Deutsch.
>
> Vor jedem Task: Stelle gezielte Rückfragen zu Thema, Tiefe, Verwendungszweck und gewünschtem Format — maximal 3, nur was wirklich fehlt.
>
> Arbeite quellenbasiert, präzise und ohne Annahmen ohne Belege. Nutze Web Search wenn aktuelle Daten nötig sind. Lade ich Dokumente hoch, arbeite damit als primäre Quelle.
>
> Output: Strukturierte Analysen, Marktüberblicke oder Entscheidungsgrundlagen. Kein Fülltext. Nächsten Schritt am Ende vorschlagen.

---

**Einrichtung in 5 Minuten:**

1. Claude.ai → linke Sidebar → **New Project**
2. Name eingeben
3. **Project Instructions** → jeweiligen Text einfügen → Speichern
4. Wiederholen für alle vier

Danach kannst du optional relevante Dokumente ins jeweilige Projekt hochladen — Brandbook in Fashion Brand, Businessplan in Strategie & Leben etc. Claude liest sie automatisch mit.

---

**Du:**

Brauche ich für die Projekte das Starte Template?

---

**Claude:**

Nein — die Projekte ersetzen das Starter-Template.

Die Project Instructions übernehmen automatisch was das Template manuell macht: Rolle, Rückfragen, Output-Format. Du schreibst einfach deinen Task rein — Claude fragt den Rest ab.

**Wann das Starter-Template noch sinnvoll ist:**

Nur im normalen Chat außerhalb der Projekte, wenn du einen komplexen Task ohne Projekt-Kontext hast.

Für alles innerhalb der vier Projekte brauchst du es nicht mehr.

---

**Du:**

Kann man es mit User Preferens ergänzen ?

---

**Claude:**

Ja — und das ist sogar das optimale Setup.

Die beiden Ebenen ergänzen sich perfekt:

| Ebene | Wofür |
|---|---|
| **User Preferences** | Globale Regeln — gelten überall, immer |
| **Project Instructions** | Projektspezifische Rolle & Fokus |

User Preferences setzen den Grundcharakter — Sprache, Denkweise, Output-Stil. Project Instructions verfeinern ihn für den jeweiligen Kontext.

---

**Konkret für dich:**

Die User Preferences die wir aufgesetzt haben bleiben so wie sie sind. Die Project Instructions bauen darauf auf — du musst in den Projekten also nicht mehr wiederholen was bereits global gilt wie z.B. „Antworte auf Deutsch" oder „kein Fülltext".

Das heißt die Project Instructions können wir noch etwas schlanker machen — nur das Projektspezifische bleibt drin.

Soll ich die vier Projekt-Prompts entsprechend verschlanken?

---

**Du:**

Was wäre für mich perfekt im vergleich z uprofis bei User preference ich brauche hier das beste set up und zeitgemäßt immer moderniesierend

---

**Claude:**

Gute Frage — lass mich ehrlich sein:

**Was du bereits hast ist auf Profi-Niveau.** Die meisten Nutzer haben gar keine User Preferences. Du hast bereits: Sprache, Rollenlogik, Rückfragen-Verhalten, Output-Format, Kontexte.

**Was Profis zusätzlich machen — und was für dich relevant ist:**

---

**1. Denkstil definieren**
Nicht nur was Claude produzieren soll, sondern wie es denken soll. Z.B. „Denke immer in First Principles — hinterfrage Annahmen bevor du antwortest."

**2. Feedback-Loop einbauen**
„Wenn mein Prompt unklar ist, sage es direkt — optimiere ihn nicht stillschweigend."

**3. Qualitätsstandard setzen**
„Liefere nur was du selbst als Senior-Experte unterschreiben würdest. Kein Mittelmaß."

**4. Persönlichen Arbeitsstil spiegeln**
„Ich denke iterativ und output-driven. Fang klein an, verfeinere auf Nachfrage."

---

Hier dein **aktualisierter, moderner User Preferences Text:**

---

> Antworte immer auf Deutsch, unabhängig von der Sprache meines Inputs.
>
> Analysiere vor jeder Antwort still: Aufgabentyp, Komplexität, optimale Expertenrolle und passendes Output-Format. Nimm die entsprechende Rolle ein ohne sie zu benennen.
>
> Denke in First Principles — hinterfrage Annahmen, bevor du antwortest. Liefere nur was du als Senior-Experte selbst unterschreiben würdest. Kein Mittelmaß.
>
> Bei komplexen oder mehrdeutigen Aufgaben: Stelle zuerst gezielte Rückfragen — maximal 3. Wenn mein Prompt unklar ist, sag es direkt statt ihn stillschweigend zu optimieren. Bei einfachen Tasks antworte direkt.
>
> Ich denke iterativ und output-driven. Fang präzise an, verfeinere auf Nachfrage. Bevorzuge vollständige, sofort verwendbare Deliverables. Kein Fülltext, keine unnötigen Absicherungen. Schlage am Ende den sinnvollsten nächsten Schritt vor.
>
> Meine Hauptbereiche: Strategie & Business, Creative & Brand, Tech & Code, Research & Analyse, Texte & Kommunikation.
>
> Persönlicher Kontext: Ich baue nebenbei eine Fashion-Brand auf. Wähle Spezialistenrollen entsprechend — z.B. Brand Strategist, Creative Director für Mode, Supply Chain Experte, Wirtschaftsanwalt oder Fashion Copywriter.
>
> Für private Themen: Denke als Executive Coach, unabhängiger Finanzberater oder Performance Coach — je nach Kontext.

---

Das ist der aktuelle Best-Practice Stand. Einfach den alten Text in den Settings ersetzen.

---

**Du:**

brauche ich jetzt noch im Chat das Starter Template

---

**Claude:**

Nein — nicht mehr.

Du hast jetzt drei Ebenen die alles abdecken:

| Ebene | Deckt ab |
|---|---|
| User Preferences | Globaler Rahmen — immer aktiv |
| Project Instructions | Projektspezifische Rolle & Rückfragen |
| Normaler Chat | User Preferences greifen automatisch |

Das Starter-Template war der Workaround bevor du Projekte und starke User Preferences hattest. Jetzt ist es überholt.

**Einziger Restfall:** Wenn du im normalen Chat einen sehr spezifischen Kontext hast den Claude nicht ableiten kann — dann reicht ein einzelner Satz wie „Ich bin in Situation X, Ziel ist Y" als Einstieg. Kein Template nötig.

Du bist fertig eingerichtet.

---

**Du:**

Muss ich etwas noch beachten wenn ich im Chat starte

---

**Claude:**

Nur drei Dinge:

**1. Kontext den Claude nicht kennt — kurz nennen**
Namen, spezifische Projekte, neue Situationen die nicht in deinen Preferences stehen. Ein Satz reicht.

**2. Bei sehr komplexen Tasks — Ziel voranstellen**
„Ich möchte X erreichen. Was brauchst du noch?" — Claude übernimmt den Rest.

**3. Projekte für Tiefenarbeit, Chat für Schnelles**
Einzel-Fragen, schnelle Recherchen, spontane Ideen → normaler Chat. Alles mit Kontext, Aufbau, Iterationen → Projekt.

Das war's. Alles andere läuft automatisch.

---

**Du:**

Ich suche oft und formuleire oft was nutze ich dazu am besten

---

**Claude:**

Du beschreibst zwei verschiedene Verhaltensweisen — dafür gibt es zwei verschiedene Lösungen:

---

**Wenn du oft suchst**

Nutze direkt die **Search-Funktion in Claude** — oben im Interface. Durchsucht deine bisherigen Chats. Schneller als einen neuen Chat zu öffnen und neu zu fragen.

Noch besser: Aktiviere **„Search and reference past chats"** in den Settings — dann kann Claude automatisch auf frühere Gespräche zugreifen ohne dass du danach suchen musst.

---

**Wenn du oft formulierst — immer wieder ähnliche Prompts**

Leg dir ein **Text-Snippet-Tool** zu. Einmal speichern, überall per Kürzel einfügen:

| Tool | Platform |
|---|---|
| **Raycast** | Mac — kostenlos, sehr schnell |
| **Alfred** | Mac — mächtiger, kostenpflichtig |
| **TextExpander** | Mac & Windows |
| **Espanso** | Mac, Windows, Linux — kostenlos |

Beispiel: Du tippst `;brief` → es erscheint automatisch dein Briefing-Template.

---

**Für dich konkret:**

Raycast auf Mac einrichten, häufige Prompt-Strukturen als Snippets speichern. Kombination aus Past-Chats-Search in Claude und Snippets für Formulierungen — das ist der effizienteste Stack.

Nutzt du Mac oder Windows?

---

**Du:**

Welches ist das beste und modernste tool

---

**Claude:**

**Raycast** — keine Diskussion.

Es ist der aktuelle Standard unter Profis und Developern auf Mac. Kostenlos, blitzschnell, und ersetzt gleichzeitig Spotlight.

---

**Was du konkret damit machst:**

Snippets anlegen — du tippst ein Kürzel, der vollständige Prompt erscheint sofort. Beispiel:

| Kürzel | Expandiert zu |
|---|---|
| `;brief` | Dein Briefing-Template |
| `;fashion` | Fashion Brand Kontext-Einstieg |
| `;research` | Research-Anfrage Struktur |
| `;check` | „Prüfe das kritisch und nenn mir Schwachstellen" |

Dazu bekommst du Claude direkt in Raycast — ohne Browser zu öffnen.

---

**Einrichtung:**

1. raycast.com → Download → installieren
2. Snippets → New Snippet → Kürzel + Text definieren
3. Überall auf dem System verfügbar — in jedem Textfeld

---

**Einziger Haken:** Nur Mac. Auf Windows wäre die Alternative **PowerToys** von Microsoft — funktional, aber deutlich weniger elegant.

Nutzt du Mac?

---

**Du:**

ist raycast sicher und welches andere tool ist evtl besser

Datenschutz preis etc

---

**Claude:**

```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Hier der ehrliche Vergleich — basierend auf aktuellen Daten:

---

**Datenschutz — was wirklich passiert:**

Raycast ist eine local-first Anwendung — Daten werden in einer lokalen, verschlüsselten Datenbank gespeichert. Verbindungen zu Drittanbieter-APIs laufen direkt, nicht über Raycast-Server.

Cloud Sync ist optional. Wenn aktiviert, werden Snippets verschlüsselt gespeichert. KI-Features laufen nur wenn du sie explizit aufrufst — kein Hintergrund-Monitoring.

Für reine Snippets ohne AI-Features: vollständig lokal, kein Datenschutzproblem.

---

**Der direkte Vergleich:**

| Tool | Preis | Datenschutz | Platform | Für wen |
|---|---|---|---|---|
| **Raycast** | Kostenlos | Lokal + optional Cloud | Mac (Windows Beta) | Alle Mac-Nutzer |
| **Espanso** | Kostenlos, Open Source | 100% lokal, kein Account | Mac, Win, Linux | Technisch affin |
| **TextExpander** | ~40€/Jahr | Cloud-basiert | Mac, Win, iOS | Teams |
| **TypeSnap** | 17,99€ einmalig | 100% lokal | Nur Mac | Dediziertes Tool |

---

**Meine ehrliche Einschätzung für dich:**

Wenn du Raycast bereits als Mac-Launcher nutzt, gibt es keinen Grund etwas anderes zu installieren. Wenn du merkst dass du Formatierungen, Fill-in-Felder oder Organisation brauchst — dann lohnt sich ein dediziertes Tool.

**Empfehlung: Raycast als Einstieg.** Kostenlos, sicher, reicht für deinen Use Case völlig aus. Falls du irgendwann komplexere Snippet-Strukturen brauchst — dann TypeSnap als Einmalkauf, kein Abo.

Nutzt du Mac oder Windows?

---

**Du:**

welche Snippets sollte ich einstellen in verbidnung mit claude und alles andere

---

**Claude:**

Gute Frage — lass mich kurz deinen Kontext abfragen damit die Snippets wirklich zu dir passen:
```
This block is not supported on your current device yet.
```

---

**Du:**

F: Für welche Bereiche willst du Snippets einrichten?
A: Claude & KI Prompts

F: Was nervt dich am meisten beim täglichen Arbeiten?
A: Ich tippe vieles immer wieder

---

**Claude:**

Hier dein komplettes Snippet-Set für Claude — direkt einsatzbereit:

---

**Kategorie 1 — Gesprächsstart**

| Kürzel | Expandiert zu |
|---|---|
| `;start` | Neuer Task. Stelle mir zuerst gezielte Rückfragen zu Kontext, Ziel, Zielgruppe und Constraints — bevor du anfängst. |
| `;rolle` | Du bist [ROLLE]. Bevor du anfängst: Welche Informationen fehlen dir noch für ein optimales Ergebnis? |
| `;brief` | Kontext: []\nZiel: []\nZielgruppe: []\nConstraints: []\nReferenz: [] |

---

**Kategorie 2 — Qualitätskontrolle**

| Kürzel | Expandiert zu |
|---|---|
| `;check` | Prüfe das kritisch. Nenn mir drei Schwachstellen und wie du sie beheben würdest. |
| `;besser` | Verbessere das — schärfer, präziser, weniger Füllwörter. Gleiche Länge. |
| `;expert` | Antworte so wie ein Senior-Experte der das selbst unterschreiben würde. Kein Mittelmaß. |
| `;alts` | Gib mir drei alternative Versionen — unterschiedliche Richtungen, nicht nur unterschiedliche Formulierungen. |

---

**Kategorie 3 — Output-Steuerung**

| Kürzel | Expandiert zu |
|---|---|
| `;kurz` | Fasse das in maximal 3 Sätzen zusammen. Nur das Wesentliche. |
| `;liste` | Strukturiere das als klare, priorisierte Liste. Keine Erklärungen — nur die Punkte. |
| `;tabelle` | Stell das als übersichtliche Tabelle dar. |
| `;next` | Was ist der sinnvollste nächste Schritt? Nur einer — der wichtigste. |

---

**Kategorie 4 — Iteration**

| Kürzel | Expandiert zu |
|---|---|
| `;mehr` | Geh tiefer. Mehr Detail, mehr Substanz — gleiche Richtung. |
| `;anders` | Anderer Ansatz. Gleiche Aufgabe, komplett andere Perspektive. |
| `;formal` | Formuliere das formeller und professioneller — ohne den Inhalt zu verändern. |
| `;casual` | Formuliere das lockerer und direkter — ohne den Inhalt zu verändern. |

---

**Kategorie 5 — Fashion Brand spezifisch**

| Kürzel | Expandiert zu |
|---|---|
| `;brand` | Du bist Brand Strategist für eine Premium Fashion Brand. Kontext: []\nZiel: [] |
| `;copy` | Du bist Fashion Copywriter für eine Premium-Brand. Ton: minimalistisch, selbstbewusst, keine Adjektiv-Inflation. Schreib: [] |
| `;supply` | Du bist Supply Chain Experte für Apparel. Analysiere: [] |

---

**Einrichtung in Raycast:**

1. Raycast öffnen → `Snippets` tippen → Enter
2. `+` → Name, Kürzel und Text eingeben
3. Fertig — funktioniert in jedem Textfeld systemweit

Willst du, dass ich die Snippets noch nach Priorität sortiere — also welche du zuerst einrichten solltest?

---

**Du:**

brauche ich alle oder iummer nur einer pro Kategorie

---

**Claude:**

Nur die die du wirklich nutzt — Qualität vor Quantität.

**Die 5 die du unbedingt brauchst — starte damit:**

| Kürzel | Wann |
|---|---|
| `;start` | Jeder neue komplexe Task |
| `;check` | Wenn du unsicher bist ob der Output gut ist |
| `;besser` | Wenn der Output okay ist aber nicht great |
| `;kurz` | Wenn du eine schnelle Zusammenfassung brauchst |
| `;anders` | Wenn du in einer Richtung feststeckst |

---

**Die Regel dahinter:**

Pro Kategorie reicht ein Snippet für den Anfang. Du merkst nach 1-2 Wochen welche du nie benutzt — die löschst du. Und welche dir fehlen — die ergänzt du dann.

Fang mit diesen 5 an. Alles andere kommt on demand.

---

**Du:**

schreibe mir die besten weltweit auf lege sie fertig bereit zum einfügemn

---

**Claude:**

Lass mich kurz recherchieren was Profis weltweit tatsächlich nutzen:
```
This block is not supported on your current device yet.
```

Gut — ich habe recherchiert was weltweit tatsächlich funktioniert, kombiniert mit Anthropics eigenen Best Practices. Hier das fertige, kuratierte Snippet-Set:
```
This block is not supported on your current device yet.
```

20 Snippets in 5 Kategorien — alle direkt kopierbar.

**Die 6 Must-haves zuerst einrichten** — die mit dem grünen Label. Das sind die die du täglich brauchst: `;start`, `;brief`, `;expert`, `;check`, `;first`, `;kurz`, `;next`, `;anders`.

Den Rest ergänzt du on demand wenn du merkst dass du ihn brauchst.

---

**Du:**

Gibt es sowas nicht bei apple auch

---

**Claude:**

Ja — heißt **Text Replacement** und ist direkt in macOS eingebaut.

**Wo:** Systemeinstellungen → Tastatur → Text Replacement

**Wie:** Kürzel eingeben (z.B. `;start`) → langer Text daneben → fertig. Funktioniert systemweit überall wo du tippst.

---

**Der ehrliche Vergleich:**

| | Apple Text Replacement | Raycast Snippets |
|---|---|---|
| Preis | Kostenlos, built-in | Kostenlos |
| Setup | 2 Minuten | 5 Minuten |
| iCloud Sync | Automatisch — Mac, iPhone, iPad | Nur Mac |
| Zuverlässigkeit | Funktioniert nicht in Chrome & vielen Apps | Funktioniert überall |
| Länge | Begrenzt | Unbegrenzt |

---

**Meine Empfehlung für dich:**

Wenn du auch vom iPhone aus promptest — Apple Text Replacement. Die Snippets funktionieren dann auf allen deinen Geräten automatisch via iCloud.

Wenn du hauptsächlich am Mac arbeitest — Raycast ist zuverlässiger, besonders in Chrome und anderen Drittanbieter-Apps.

Nutzt du Claude auch vom iPhone?

---

**Du:**

ich prompte aus mac und i phone

---

**Claude:**

Dann ist die Lösung klar: **beide kombinieren.**

---

**Setup:**

**Apple Text Replacement** → für alle Snippets die du auch vom iPhone nutzt. Einmal eingeben in Systemeinstellungen → via iCloud automatisch auf Mac und iPhone verfügbar.

**Raycast** → bleibt auf dem Mac als Launcher, Suche und alles andere. Für Snippets nicht nötig wenn Apple Text Replacement läuft.

---

**Einrichtung in 5 Minuten:**

Mac → Systemeinstellungen → Tastatur → Text Replacement → `+` → Kürzel + Text eingeben → wiederholen für alle Snippets.

iPhone synchronisiert automatisch via iCloud — nichts weiter zu tun.

---

**Eine Einschränkung:** Apple Text Replacement funktioniert auf dem Mac nicht in Chrome. Wenn du Claude im Chrome-Browser nutzt, greift es dort nicht.

Nutzt du Claude im Safari oder Chrome auf dem Mac?

---

**Du:**

ich nutze chrome nie

---

**Claude:**

Dann brauchst du Raycast nicht für Snippets.

**Dein optimales Setup:**

Apple Text Replacement — einmal einrichten, läuft automatisch auf Mac und iPhone via iCloud. Fertig.

Geh jetzt in Systemeinstellungen → Tastatur → Text Replacement und füge die Must-haves ein. Fang mit diesen sechs an:

| Kürzel | Name |
|---|---|
| `;start` | Universeller Task-Einstieg |
| `;brief` | Briefing-Template |
| `;expert` | Senior-Level Qualität |
| `;check` | Kritische Prüfung |
| `;first` | First Principles |
| `;anders` | Andere Perspektive |

Die Texte dazu hast du im Widget oben — einfach kopieren und einfügen. 10 Minuten Arbeit, dann läuft es auf allen deinen Apple-Geräten.

---

**Du:**

lege alle vor damit ich sie einsetzen kann

---

**Claude:**

Hier alle 20 Snippets — fertig zum Einfügen in Apple Text Replacement:
```
This block is not supported on your current device yet.
```

Alle 20 bereit. Einfach Text kopieren → in Apple Text Replacement einfügen → fertig.

**Reihenfolge:** Fang mit den Must-haves an — die ersten 7 reichen für den Alltag komplett. Den Rest ergänzt du wenn du ihn brauchst.

---

**Du:**

Verwenden profis alle diese?

---

**Claude:**

Nein — Profis nutzen typischerweise 5-7 davon täglich. Der Rest ist Situationsabhängig.

**Was wirklich täglich genutzt wird:**

| Snippet | Nutzungsfrequenz |
|---|---|
| `;start` | Fast jeden Task |
| `;check` | Sehr oft — Output-Qualität sichern |
| `;expert` | Oft — besonders bei wichtigen Deliverables |
| `;kurz` | Oft — wenn Antwort zu lang |
| `;anders` | Regelmäßig — wenn Richtung nicht stimmt |
| `;first` | Bei komplexen Entscheidungen |
| `;next` | Am Ende jedes Tasks |

**Was Profis zusätzlich machen was wir noch nicht haben:**

Eigene kontextspezifische Snippets — z.B. einen Einstieg der genau ihren Beruf oder ihr Projekt beschreibt. Das ist mächtiger als generische Prompts.

Für dich konkret wäre z.B. ein `;fashion` Snippet wertvoller als `;steelman` — weil du ihn täglich nutzen würdest.

**Die ehrliche Antwort:** Starte mit den 7 oben. Nach zwei Wochen weißt du genau welche du wirklich brauchst — und welche du nie angefasst hast.

---

**Du:**

ich will auch max 10

---

**Claude:**

Die besten 10 — kuratiert für deinen Alltag:

| # | Kürzel | Wofür |
|---|---|---|
| 1 | `;start` | Jeder neue komplexe Task |
| 2 | `;check` | Output kritisch prüfen |
| 3 | `;expert` | Senior-Level Qualität einfordern |
| 4 | `;first` | Komplexe Entscheidungen durchdenken |
| 5 | `;kurz` | Antwort verdichten |
| 6 | `;anders` | Andere Richtung einschlagen |
| 7 | `;next` | Nächsten Schritt klären |
| 8 | `;blind` | Blinde Flecken aufdecken |
| 9 | `;brief` | Vollständiges Briefing strukturieren |
| 10 | `;besser` | Output schärfen |

---

**Raus geflogen:** `;rolle`, `;devil`, `;steelman`, `;invert`, `;tabelle`, `;tldr`, `;mehr`, `;alts`, `;formal`, `;casual`

Zu situationsspezifisch — die tippst du schneller direkt als du das Kürzel erinnerst.

Richte genau diese 10 ein — fertig.

---

**Du:**

schreib mir alle für text replacement runter

---

**Claude:**

Hier alle 10 — direkt zum Abtippen in Text Replacement:

---

**1**
Ersetzen: `;start`
Mit: `Neuer Task. Stelle mir zuerst gezielte Rückfragen zu Kontext, Ziel, Zielgruppe und Constraints — maximal 3, nur was wirklich fehlt. Dann starte.`

---

**2**
Ersetzen: `;check`
Mit: `Prüfe das kritisch. Nenn mir die drei größten Schwachstellen und wie du sie konkret beheben würdest.`

---

**3**
Ersetzen: `;expert`
Mit: `Antworte so wie ein Senior-Experte der das selbst unterschreiben würde. Kein Mittelmaß, keine sicheren Allgemeinaussagen. Nur was wirklich substanziell ist.`

---

**4**
Ersetzen: `;first`
Mit: `Analysiere das mit First-Principles-Denken. Hinterfrage alle Annahmen, geh auf die fundamentalsten Wahrheiten zurück und bau die Antwort von dort auf.`

---

**5**
Ersetzen: `;kurz`
Mit: `Fasse das in maximal 3 Sätzen zusammen. Nur das Wesentliche — kein Kontext, keine Erklärungen.`

---

**6**
Ersetzen: `;anders`
Mit: `Anderer Ansatz. Gleiche Aufgabe — komplett andere Perspektive, andere Struktur, andere Richtung. Nicht nur anders formuliert.`

---

**7**
Ersetzen: `;next`
Mit: `Was ist der eine sinnvollste nächste Schritt? Nur einer — der wichtigste. Keine Liste.`

---

**8**
Ersetzen: `;blind`
Mit: `Was übersehe ich hier? Welche Annahmen treffe ich unbewusst? Nenn mir die drei größten blinden Flecken in meinem Denken dazu.`

---

**9**
Ersetzen: `;brief`
Mit: `Kontext: []
Ziel: []
Zielgruppe: []
Constraints: []
Referenz: []

Bevor du anfängst: Welche Informationen fehlen dir noch?`

---

**10**
Ersetzen: `;besser`
Mit: `Verbessere das — schärfer, präziser, weniger Füllwörter. Gleiche Länge, deutlich höhere Qualität.`

---

Einfach nacheinander in Systemeinstellungen → Tastatur → Text Replacement eingeben. 10 Minuten — dann läuft es auf Mac und iPhone.

---

**Du:**

hab alles eingefügt

Müssen wir noch etwas konfigurieren um besser zu sein prüfe alle profi einstellungen und claude empfehlungen aber auch das aktuelle set up plugins skills etc

---

**Claude:**

Lass mich zuerst recherchieren was aktuell möglich ist:
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Gut — hier die vollständige Bestandsaufnahme was existiert, was du davon brauchst, und was noch fehlt:
```
This block is not supported on your current device yet.
```

**Die drei wichtigsten nächsten Schritte:**

**1. Settings aktivieren** — das ist das Dringlichste. Claude.ai → Settings → alle Features einschalten die im Audit als "Offen" markiert sind. 10 Minuten.

**2. Dokumente in Projekte hochladen** — das ist der größte Hebel den die meisten übersehen. Lade alle relevanten Hintergrunddokumente einmalig in ein Projekt — jeder Chat darin hat dann automatisch Zugriff darauf, ohne dass du Claude jedes Mal neu briefen musst.

**3. Deep Research** — verfügbar auf Pro — für komplexe Recherchen deutlich mächtiger als normale Web Search.

Willst du mit Schritt 1 — den Settings — direkt starten?

---

**Du:**

Schalte alles an und erledige

---

**Claude:**

Das kann ich leider nicht direkt für dich erledigen — ich habe keinen Zugriff auf deine Claude.ai Settings.

Aber hier der schnellste Weg — alles in unter 5 Minuten:

---

**Claude.ai → Settings → Features**

Schalte diese ein:

1. Generate memory from chat history
2. Search and reference past chats
3. Artifacts
4. AI-powered artifacts
5. Inline visualizations
6. Cloud code execution and file creation
7. Web Search

---

**Wo genau:**

claude.ai → oben rechts dein Profilbild → Settings → im linken Menü "Features" oder "Capabilities"

---

Sobald das erledigt ist — sag Bescheid. Dann gehen wir direkt zu Schritt 2: die richtigen Dokumente in deine Projekte hochladen.

---

**Du:**

Haben wir diese Settings nicht schon aktiviert?

---

**Claude:**

Du hast recht — teilweise. Lass mich ehrlich sein was ich weiß und was nicht:

**Sicher erledigt:**
- User Preferences ✓
- 4 Projekte ✓
- 10 Snippets ✓

**Nicht sicher:**
Die Settings wie Memory, Artifacts, Web Search — die haben wir in diesem Chat besprochen aber nie explizit bestätigt dass du sie aktiviert hast.

---

Schnellster Check: Geh einmal in Claude.ai → Settings → Features und schau ob die 7 Toggles an sind. Dauert 30 Sekunden.

Was siehst du dort?

---

**Du:**

Wo finde ich die

---

**Claude:**

Claude.ai → oben rechts dein **Profilbild** → **Settings** → linke Sidebar → **Features**

Dort siehst du alle Toggles auf einen Blick.

---

**Du:**

ich hab claude auf deutsch

---

**Claude:**

Dann: Claude.ai → oben rechts dein **Profilbild** → **Einstellungen** → linke Sidebar → **Funktionen**

Was siehst du dort?

---

**Du:**

alles an

---

**Claude:**

Perfekt — dann ist dein Setup zu 100% vollständig.

**Was du jetzt hast:**

- User Preferences ✓
- 4 Projekte mit Project Instructions ✓
- 10 Snippets auf Mac & iPhone ✓
- Alle Features aktiviert ✓

**Einziger offener Punkt:** Dokumente in die Projekte hochladen — Brandbook, Recherchen, Referenzmaterial. Das ist der letzte große Hebel.

Willst du damit starten oder hast du gerade keinen relevanten Content dafür?

---

**Du:**

Ich importiere später alles aus Claude Privat und Chat GPT fürher

---

**Claude:**

Perfekt — dann ist das Setup abgeschlossen.

Wenn du importierst, denk daran: relevante Dokumente, Texte und Referenzmaterial direkt in das jeweilige Projekt hochladen — nicht in den allgemeinen Chat. So hat Claude den Kontext dauerhaft ohne dass du jedes Mal neu briefst.

Was ist dein nächster Task?

---

**Du:**

Lass usn unser Set up testen

---

**Claude:**

Gerne — such dir einen echten Task aus deinem Alltag aus, den du gerade wirklich brauchst. Kein Testprompt — echte Aufgabe.

Welches Projekt starten wir mit — Fashion Brand, Creative & Copy, Strategie & Leben oder Research?

---

**Du:**

Leben

---

**Claude:**

Starte einen neuen Chat im Projekt **Strategie & Leben** — schreib dort deinen Task rein.

Dann sehen wir live ob das Setup funktioniert wie es soll.

---

**Du:**

;brief

---

**Claude:**

Das Snippet funktioniert — jetzt füll es aus:

**Kontext:** []
**Ziel:** []
**Zielgruppe:** []
**Constraints:** []
**Referenz:** []

Bevor du anfängst: Welche Informationen fehlen dir noch?

---

**Du:**

Wie kann ich in apple text replacement eine liste an snippets öffnen und aussuchen im alltag weil ich sie nicht alle im kopf kenne

---

**Claude:**

Das geht mit Apple Text Replacement nicht — es gibt keine Such- oder Übersichtsfunktion beim Tippen.

**Deine Optionen:**

**Option 1 — Raycast doch installieren**
Dort kannst du alle Snippets durchsuchen. Tippe den Raycast-Shortcut → „Snippets" → du siehst alle auf einen Blick und kannst suchen. Das ist der eigentliche Vorteil von Raycast gegenüber Apple Text Replacement.

**Option 2 — Spickzettel**
Ein simples Notiz-Widget auf dem Homescreen oder in der Notizen-App mit allen 10 Kürzeln und ihrer Bedeutung. 30 Sekunden nachschlagen.

**Option 3 — Nur 5 nutzen**
Die die du wirklich täglich brauchst merkst du dir nach einer Woche automatisch. Den Rest brauchst du seltener als du denkst.

---

**Ehrliche Empfehlung:** Raycast installieren — nur für die Snippet-Suche. Apple Text Replacement behältst du für iPhone. Beides parallel läuft problemlos und ergänzt sich perfekt.

---

**Du:**

Die besten 10 — kuratiert für deinen Alltag:
#KürzelWofür1`;start`Jeder neue komplexe Task2`;check`Output kritisch prüfen3`;expert`Senior-Level Qualität einfordern4`;first`Komplexe Entscheidungen durchdenken5`;kurz`Antwort verdichten6`;anders`Andere Richtung einschlagen7`;next`Nächsten Schritt klären8`;blind`Blinde Flecken aufdecken9`;brief`Vollständiges Briefing strukturieren10`;besser`Output schärfen


erstelle eine Notiz für apple notizen als erinnerung

---

**Claude:**

Hier die fertige Notiz — direkt kopieren und in Apple Notizen einfügen:

---

```
CLAUDE SNIPPETS

;start    → Neuer Task starten
;brief    → Briefing strukturieren
;expert   → Senior-Level Qualität
;check    → Output kritisch prüfen
;first    → First Principles Analyse
;kurz     → Antwort verdichten
;anders   → Andere Richtung
;next     → Nächsten Schritt
;blind    → Blinde Flecken aufdecken
;besser   → Output schärfen
```

---

**Tipp:** In Apple Notizen als **Pinned Note** ganz oben anpinnen — dann ist sie immer sofort sichtbar. Auf iPhone als Widget auf den Homescreen.

---

**Du:**

mit kurzer beschreibung

---

**Claude:**

```
CLAUDE SNIPPETS

;start    → Neuer Task — Claude stellt zuerst Rückfragen
;brief    → Briefing ausfüllen — Kontext, Ziel, Constraints
;expert   → Senior-Level Qualität einfordern — kein Mittelmaß
;check    → Output kritisch prüfen — 3 Schwachstellen nennen
;first    → First Principles — Annahmen hinterfragen, von Grund auf
;kurz     → Max. 3 Sätze — nur das Wesentliche
;anders   → Komplett andere Perspektive — nicht nur anders formuliert
;next     → Einen nächsten Schritt — nur den wichtigsten
;blind    → Blinde Flecken — was übersehe ich unbewusst?
;besser   → Schärfer, präziser, weniger Füllwörter — gleiche Länge
```

---

Kopieren → Apple Notizen → oben anpinnen. Fertig.

---

**Du:**

snippet start funktioniert nicht im neuen chat

---

**Claude:**

Das ist normal — Apple Text Replacement funktioniert nicht in der Claude iOS App oder im Safari/Browser-Eingabefeld zuverlässig.

**Warum:** Apple Text Replacement greift nur in nativen iOS/macOS Textfeldern. Viele Apps blockieren es.

**Lösung — zwei Optionen:**

**Option 1 — Manuell tippen beim ersten Mal**
Nur `;start` funktioniert nicht — die anderen kürzeren Snippets wahrscheinlich schon. Test: probiere `;kurz` oder `;check`.

**Option 2 — Raycast auf Mac**
Auf dem Mac funktioniert Raycast in jedem Textfeld zuverlässig — auch in Claude. Für iPhone bleibt das Problem bestehen.

**Option 3 — Tastatur-Shortcut auf iPhone**
iPhone → Einstellungen → Allgemein → Tastatur → Textersetzung. Dort direkt in den iOS Einstellungen eingeben statt über Mac Sync — manchmal zuverlässiger.

---

Teste kurz: Funktionieren die anderen Snippets wie `;kurz` oder `;check` in Claude?

---

**Du:**

er fügt es ein aber du verstehst den kontext nicht

hier 

Neuer Task. Stelle mir zuerst gezielte Rückfragen zu Kontext, Ziel, Zielgruppe und Constraints — maximal 3, nur was wirklich fehlt. Dann starte.
Analysiere vor jeder Antwort still: Aufgabentyp, Komplexität, optimale Expertenrolle und passendes Output-Format. Nimm die entsprechende Rolle ein ohne sie zu benennen.
Denke in First Principles — hinterfrage Annahmen, bevor du antwortest. Liefere nur was du als Senior-Experte selbst unterschreiben würdest. Kein Mittelmaß.
Bei komplexen oder mehrdeutigen Aufgaben: Stelle zuerst gezielte Rückfragen — maximal 3. Wenn mein Prompt unklar ist, sag es direkt statt ihn stillschweigend zu optimieren. Bei einfachen Tasks antworte direkt.
Ich denke iterativ und output-driven. Fang präzise an, verfeinere auf Nachfrage. Bevorzuge vollständige, sofort verwendbare Deliverables. Kein Fülltext, keine unnötigen Absicherungen. Schlage am Ende den sinnvollsten nächsten Schritt vor.
Meine Hauptbereiche: Strategie & Business, Creative & Brand, Tech & Code, Research & Analyse, Texte & Kommunikation.
Persönlicher Kontext: Ich baue nebenbei eine Fashion-Brand auf. Wähle Spezialistenrollen entsprechend — z.B. Brand Strategist, Creative Director für Mode, Supply Chain Experte, Wirtschaftsanwalt oder Fashion Copywriter.
Für private Themen: Denke als Executive Coach, unabhängiger Finanzberater oder Performance Coach — je nach Kontext.

---

**Claude:**

Ich verstehe das Problem. Das `;start` Snippet enthält deinen kompletten User Preferences Text — das ist falsch.

**Was passiert:** Claude sieht einen riesigen Kontext-Block ohne konkreten Task und weiß nicht womit es anfangen soll.

**Die Lösung:** Das `;start` Snippet muss kurz und klar sein — nur die Anweisung für den Task-Einstieg, nicht deine gesamten Preferences.

---

**Ersetze `;start` in Apple Text Replacement mit diesem kurzen Text:**

```
Neuer Task. Stelle mir gezielte Rückfragen zu Kontext, Ziel und Constraints — maximal 3. Dann starte.
```

Das reicht vollständig — deine User Preferences laufen bereits im Hintergrund und Claude kennt den Rest automatisch.

---

**Merkrege:** Snippets ergänzen deine Preferences — sie wiederholen sie nicht.

---

