---
date: 2026-04-06
tags: [claude]
---

# Apple Music Bibliothek organisieren

**Du:**

Apple Music music richtig sortieren

---

**Claude:**

Was möchtest du genau sortieren? Alben, Songs, Playlists – und nach welchem Kriterium (Datum, Alphabet, Genre, ...)?

---

**Du:**

Ich hab von Spotify zu Apple Music alles umgezogen und möchte Titel in playlisten sortieren und teilweise zusammen legen 

Sortieren mach Genre und Tempo

---

**Claude:**

Das klingt nach etwas manuellem Aufwand – Apple Music hat leider keine automatische Sortierung nach Genre oder Tempo. Hier was du tun kannst:

**Sortieren in Playlists**

In Apple Music kannst du Playlists nur nach diesen Kriterien sortieren: Titel, Interpret, Album, Datum hinzugefügt, Dauer. Genre und Tempo gibt es nicht als Sortieroption.

**Was wirklich hilft**

Die beste Lösung für Genre/Tempo-Sortierung ist ein externes Tool:

- **Soundiiz** – kann Playlists zwischen Diensten verschieben und zusammenführen
- **Marvis Pro** (iOS App, ~4€) – zeigt deine Apple Music Bibliothek nach BPM, Genre, Energie und vielem mehr an und lässt dich daraus neue Playlists erstellen
- **Playlists zusammenlegen** – geht direkt in Apple Music: Playlist öffnen → alle Titel markieren → in eine andere Playlist ziehen

**Für BPM/Tempo speziell**

Wenn du die Musik auch zum DJing nutzt, wäre **rekordbox** oder **djay Pro** sinnvoller – die analysieren BPM automatisch und lassen dich Playlists entsprechend bauen, die sich dann mit Apple Music syncen lassen.

Wie viele Playlists hast du ungefähr umgezogen?

---

