---
date: 2026-05-30
tags: [claude]
---

# Café-Gründung mit Holding-Struktur

**Du:**

Ich möchte ein neues Projekt hier aufsetzen wo ich mein eigenes Cafe aufbauen mchte von grund auf mit meiner bereits vorhanden Holding struktur

schreibe mir den prompt für das Proekt oder prüfe ob ich das Proekt privat und business nutzen sollte

---

**Claude:**

```
This block is not supported on your current device yet.
```

Kurze strategische Einschätzung zuerst, dann der Prompt.

---

## Privat vs. Business Projekt?

**Empfehlung: Business-Projekt** — aber mit privatem Kontext drin.

Das Café ist ein Unternehmensvorhaben mit konkretem wirtschaftlichem Kontext (Holding, Rechtsform, Finanzierung, Standort Berlin). Das gehört in ein eigenes Business-Projekt, getrennt von deinem privaten Kontext. So bleibt der Memory-Scope sauber, du kannst sensible Businessdaten (Zahlen, Verträge, Pitches) isoliert halten, und der Projektprompt kann präzise auf die Café-Domäne fokussieren.

Dein privater Kontext (ARYS, Holding-Struktur, Berliner Lebensumfeld) kann trotzdem im Prompt referenziert werden — als Background, nicht als aktiver Memory-Scope.

---

## Projekt-Prompt

```
Du bist mein strategischer Co-Founder und Sparringspartner für den Aufbau eines Cafés in Berlin.

**Mein Hintergrund**
Ich bin Oleg, Unternehmer in Berlin. Ich baue das Café unter meiner bestehenden Holding-Struktur auf (ok-holding.com), die aus einer Capital UG und einer Wagglz GmbH besteht. Ich denke in Strukturen, arbeite output-driven und iterativ — ich will keine Theorie, sondern sofort verwendbare Deliverables.

**Das Vorhaben**
Ein eigenständiges Café-Konzept in Berlin — von Grund auf aufgebaut. Das Projekt ist noch in der Konzeptphase. Relevante Dimensionen, die wir gemeinsam entwickeln:

- Konzept & Positionierung (Zielgruppe, Atmosphäre, Differenzierung)
- Standortanalyse & Flächenstrategie (Berliner Kiez, Mietrecht, Gewerbeflächen)
- Rechts- & Holdingstruktur (optimale Einbindung ins bestehende Konstrukt: neue GmbH, UG oder Betriebsstätte?)
- Finanzplanung & Business Case (Startup-Kosten, Break-even, Liquidität)
- Betrieb & Prozesse (Konzession, Hygiene, Personal, Lieferanten)
- Brand & Ästhetik (mein visueller Geschmack tendiert zu NYC Preppy-meets-Streetwear, inspiriert von Aimé Leon Dore — das Café soll diesen Spirit haben, ohne eine Fashion-Brand zu sein)

**Wie wir arbeiten**
- Analysiere still: Welche Expertenrolle ist gerade gefragt? (Gastronom, Jurist, Finanzberater, Brand Strategist, Immobilienmakler, Betriebswirt)
- Denke in First Principles — hinterfrage Annahmen, bevor du antwortest
- Keine Absicherungen, kein Fülltext. Nur was ein Senior-Experte selbst unterschreiben würde
- Bei komplexen Fragen: max. 3 gezielte Rückfragen bevor du loslegst
- Schlag am Ende jeder Antwort den sinnvollsten nächsten Schritt vor

**Kontext-Dateien** (werden bei Bedarf hochgeladen)
- Holding-Struktur & bestehende Gesellschaften
- Budgetrahmen
- Inspirationsbilder / Moodboard
```

---

**Nächster Schritt:** Projekt anlegen, diesen Prompt als System-Prompt einfügen — und dann als erstes den Budgetrahmen und 2–3 Inspirationsbilder reinwerfen, damit wir das Konzept direkt greifbar machen können.

---

**Du:**

Ich möchte meinen Firmen dafür verwenden um das bereits investierte geld für meine Start up idee nicht zu verlieren aber auch das Geld sprich verlust als Steuerfrei zu nutzen um gewinne zu erzielen und später zu skalieren oder zu verkaufen

Ich möchte das du wirklich intensiv alles prüfst und realistisch das ganze planst

Nutze experten wissen dazu und Branchen spezifsiche themen

---

**Claude:**

Bevor ich einen belastbaren Plan aufstelle, brauche ich drei konkrete Angaben — sonst arbeite ich mit falschen Annahmen:

**1. Welche Verluste/investiertes Kapital existieren wo genau?**
- In welcher Gesellschaft stecken die Verluste? (Capital UG, Wagglz GmbH, oder beide?)
- Handelt es sich um Verlustvortrag (steuerlich festgestellt) oder nur buchhalterische Verluste?
- Größenordnung: unter 50k€, 50–200k€, über 200k€?

**2. Was ist der aktuelle Status der Gesellschaften?**
- Wagglz GmbH: du hattest sie auf "ruhend" gestellt wegen der Vet-App — ist die noch operativ nutzbar oder bereits abgemeldet?
- Capital UG: aktiv, mit laufenden Einnahmen oder ebenfalls dormant?
- Gibt es bereits einen steuerlich festgestellten Verlustvortrag (§ 10d EStG / KStG)?

**3. Was ist die konkrete Café-Planung?**
- Eigenbetrieb (du als Operator) oder Beteiligung/Investment in jemand anderen?
- Hast du schon einen Budgetrahmen im Kopf für den Aufbau?
- Zeitrahmen: wann soll das Café operativ sein?

Ohne das kann ich dir keinen Plan liefern, hinter dem ich stehe.

---

**Du:**

150k ungefähr in der Wagglz

Ich habe dem Unternehmen ein Gesellschafterdahrlehnen gegeben 

Sie sind beide aktuv habe kein Gewinn und Umsatz 

noch nicht wird aber durch die Jahresabschlüsse 2024, 2025 und 2026 no0ch passieren

Lass es zuerst so planen das ich es alleine bin mit der Mögichkeit das jemand einsteigt

kein Budget bisher so effizient wie möglich und nötig

zeitrahmen auch so schnell wie möglich

---

**Claude:**

Gut. Das ist eine klare Ausgangslage. Ich arbeite das jetzt vollständig durch.

---
```
This block is not supported on your current device yet.
```

Vollständige Analyse läuft. Ich prüfe alles — Steuerrecht, Gesellschaftsrecht, Gastronomierecht, Finanzstruktur und operatives Setup.
```
This block is not supported on your current device yet.
```

Hier ist die vollständige Analyse — kein Mittelmaß, keine Vereinfachungen.

---

## Ausgangslage — was du wirklich hast

Die Wagglz GmbH hat ~150k€ investiertes Kapital, das als Gesellschafterdarlehen strukturiert ist. Das ist steuerrechtlich ein kritischer Unterschied:

Ein Gesellschafterdarlehen ist **kein steuerlicher Verlust**. Es ist eine Forderung des Gesellschafters gegenüber der GmbH. Solange die GmbH dieses Darlehen zurückzahlen kann (oder könnte), entsteht kein abzugsfähiger Verlust — weder auf GmbH-Ebene noch bei dir persönlich. Erst wenn das Darlehen **wertlos** wird (Forderungsverzicht, Insolvenz, oder nachgewiesene Uneinbringlichkeit) entsteht ein steuerlicher Verlust — und dann auch nur unter sehr spezifischen Bedingungen.

Was wahrscheinlich existiert: ein **körperschaftsteuerlicher Verlustvortrag** in der Wagglz GmbH aus den operativen Jahresverlusten (laufende Kosten ohne Umsatz). Das ist der verwendbare Hebel.

---

## Die drei steuerlichen Kernmechanismen — realistisch bewertet

**1. Verlustvortrag (§ 10d KStG) — das ist dein bestes Asset**

Der Verlustvortrag der Wagglz GmbH kann unbegrenzt in die Zukunft vorgetragen werden. Sobald die Wagglz GmbH profitable wird (z.B. durch Weiterbelastung von Dienstleistungen ans Café), werden zukünftige Gewinne bis zur Verlustvortrags-Höhe nicht besteuert. Das funktioniert aber nur **innerhalb derselben Gesellschaft** — der Verlust der Wagglz nützt der Café GmbH direkt nichts, solange keine steuerliche Organschaft besteht.

**Mindestbesteuerungsregel beachten**: Ab 1 Mio€ Gewinn pro Jahr kann nur noch 60% des Gewinns durch Verlustvorträge neutralisiert werden. Bei deiner Größenordnung irrelevant.

**2. Steuerliche Organschaft (§§ 14–19 KStG) — das ist der eigentliche Hebel**

Eine Organschaft zwischen Wagglz GmbH (Organträgerin) und Café GmbH (Organgesellschaft) würde bedeuten: Gewinne des Cafés werden direkt der Wagglz zugerechnet — und dort gegen den Verlustvortrag verrechnet. **Ergebnis: das Café zahlt de facto keine Körperschaftsteuer, bis der Verlust aufgebraucht ist.**

Voraussetzungen sind jedoch streng:
- Wagglz GmbH muss zu mehr als 50% an der Café GmbH beteiligt sein
- Es muss ein **Gewinnabführungsvertrag** (GAV) abgeschlossen werden
- Der GAV muss **mindestens 5 Jahre** laufen und tatsächlich durchgeführt werden
- Die Organschaft muss beim Finanzamt angemeldet werden
- Erster vollständiger Organschaftsjahrgang zählt ab dem Jahr des GAV-Abschlusses

Das bedeutet konkret: Wenn du den GAV Anfang 2026 abschließt, greift die Organschaft für 2026 voll. Du musst dann bis mindestens Ende 2030 durchhalten — oder du zahlst rückwirkend Steuern nach.

**3. Gewinnausschüttung aufwärts (§ 8b KStG) — der Exit-Hebel**

Wenn die Café GmbH später Gewinne macht und diese an die Holding ausschüttet, sind 95% davon bei der Holding **steuerfrei**. Nur 5% gelten als nicht abzugsfähige Betriebsausgaben (effektive Steuer ca. 1,5%). Beim Verkauf der Café GmbH-Anteile durch die Holding: ebenfalls 95% des Veräußerungsgewinns steuerfrei. Das ist der stärkste Exit-Vorteil einer Holdingstruktur.

---

## Die optimale Gesellschaftsstruktur für das Café

**Empfehlung: Café GmbH als 100%-Tochter der Wagglz GmbH**, nicht der Holding direkt.

Warum Wagglz und nicht Holding? Weil nur so die Organschaft funktioniert und der Verlustvortrag genutzt werden kann. Die Kette wäre dann: Café GmbH (Betrieb) → Gewinnabführung → Wagglz GmbH (Verlustverrechnung) → Gewinnausschüttung → Holding (steuerfrei nach § 8b KStG).

**Gründungskosten der Café GmbH**: Mindeststammkapital 25.000€ (davon 12.500€ bei Gründung einzuzahlen). Notarkosten ca. 800–1.200€. Handelsregistereintragung ca. 150€. Alternativ: UG mit 1€ Stammkapital — aber für Gastronomie nicht empfehlenswert, da Lieferanten und Vermieter oft auf GmbH bestehen.

**Wichtig zur Wagglz**: Der "ruhend"-Status muss aufgehoben werden, falls sie als Organträgerin fungieren soll. Eine ruhende Gesellschaft kann keine aktive Organschaft führen. Prüfe mit deinem Steuerberater, ob der ruhende Status buchhalterisch/steuerlich korrekt deklariert wurde.

---

## Das Gesellschafterdarlehen — was damit passieren sollte

Dein Darlehen von ~150k€ an die Wagglz GmbH hat mehrere Optionen:

**Option A — Darlehen stehen lassen**: Zinsen können vereinbart werden (übliche Marktkonditionen, sonst verdeckte Gewinnausschüttung). Wenn die Wagglz durch die Organschaft Gewinne verrechnet, kann sie das Darlehen schrittweise zurückzahlen — an dich, steuerneutral.

**Option B — Darlehen in Eigenkapital umwandeln**: Du verzichtest auf die Rückzahlung und wandelst es in eine Kapitaleinlage um. Das erhöht den Buchwert der Anteile (relevant für späteren Exit-Besteuerung) aber generiert steuerlich nur dann einen Verlust, wenn die GmbH tatsächlich überschuldet ist.

**Option C — Darlehen als Betriebsmittel für das Café nutzen**: Die Wagglz kann das Darlehenskapital an die Café GmbH weiterdarlehen (Durchleitung). Marktüblicher Zins muss auch hier passen.

**Empfehlung**: Option A oder C — je nachdem wie das Café finanziert wird.

---

## Operativer Aufbau — so schnell und kosteneffizient wie möglich

**Phase 1: Rechtliche Struktur (Monat 1–2)**
Café GmbH gründen, Gewinnabführungsvertrag aufsetzen, Organschaft beim Finanzamt anmelden. Gewerbe anmelden (Gaststättengewerbe ist in Berlin seit 2020 nicht mehr genehmigungspflichtig — nur Anmeldung beim Bezirksamt). Ausnahme: wenn Alkohol ausgeschenkt wird, ist eine Gaststättenerlaubnis nach § 2 GastG nach wie vor erforderlich in einigen Ländern — in Berlin formal nicht mehr für Schankwirtschaft ohne Speisen, aber die Bezirksämter handhaben das unterschiedlich. Prüfen.

**Phase 2: Standort (Monat 1–3 parallel)**
Berlin ist ein Mietermarkt auch für Gewerbe. Realistische Quadratmeterpreise für Café-Flächen (50–100 qm): 25–45€/qm kalt in gefragten Lagen (Mitte, Prenzlauer Berg, Kreuzberg), 15–25€/qm in B-Lagen. Kiezbüros und lokale Makler sind schneller als Immobilienportale. Wichtig: Mietvertrag immer auf die Café GmbH abschließen, nicht auf dich persönlich.

**Phase 3: Mindestinvestition zum Start**
Das absolut notwendige Setup für ein Minimalcafé (Kaffee, einfache Speisen):

Gewerbliche Espressomaschine (gebraucht): 2.000–5.000€. Kaffeemühle: 800–2.000€. Kühlmöbel (gebraucht): 1.500–3.000€. Ladeneinrichtung (Minimal): 5.000–15.000€. Erste Warenlieferung: 2.000–3.000€. Kaution (i.d.R. 3 Monatsmieten): je nach Miete. Behördengebühren, Versicherungen: 1.500–3.000€. Kassensystem (TSE-konform, gesetzlich vorgeschrieben): 500–1.500€.

Realistisches Mindestbudget: 25.000–45.000€ ohne Kaution und erste Mieten.

**Phase 4: Laufende Kosten — Break-even Kalkulation**

Ein kleines Berliner Café (60qm, 2 Mitarbeiter plus du) hat typischerweise folgende Kostenstruktur:
Miete: 2.000–3.500€/Monat. Personal (2 Teilzeit): 2.500–3.500€/Monat. Wareneinsatz (ca. 28–35% des Umsatzes). Nebenkosten, Versicherungen, GEMA: 800–1.200€/Monat. Steuerberater (laufend): 300–500€/Monat.

Gesamtfixkosten: ca. 6.000–9.000€/Monat. Break-even bei ca. 200–280€ Tagesumsatz (6–7 Tage/Woche). Das sind ca. 80–120 Kunden täglich bei 2,50–3,50€ Durchschnittsumsatz — **realistisch für einen gut positionierten Berliner Standort nach 6–12 Monaten Anlaufzeit**.

---

## Investor-Einstieg — so strukturierst du das von Anfang an richtig

Wenn du heute allein startest, aber einen Investor offen lässt, muss die Gesellschaft skalierbar strukturiert sein:

Die Café GmbH sollte von Anfang an einen **Gesellschaftsvertrag mit Anteilsklassen** haben (oder zumindest erweiterbar sein). Beim Einstieg eines Investors nimmt dieser Anteile an der **Café GmbH direkt** — nicht an der Wagglz und nicht an der Holding. Deine Wagglz-Ebene bleibt unberührt. Die Organschaft endet automatisch, sobald ein externer Investor mehr als 50% der Café GmbH hält — das muss vor dem Einstieg sauber geplant werden.

**Typische Investor-Strukturen für diese Größe**: 10–25% für 50.000–150.000€ Investment (Pre-Seed Café). Wandeldarlehen als Einstieg (Investor gibt Darlehen, wandelt bei nächster Runde in Anteile) ist oft einfacher als direkte Beteiligung in früher Phase.

---

## Was du als nächstes konkret tun musst

**Sofort (diese Woche)**:
Steuerberater kontaktieren — speziell einen mit GmbH/Holding-Erfahrung und Gastronomie-Kenntnissen. Lass die Jahresabschlüsse 2023 (falls noch nicht) und 2024 fertigstellen. Ohne festgestellten Verlustvortrag im Steuerbescheid hat die Organschaft keinen Hebel.

**Innerhalb 4 Wochen**:
Standortsuche starten. Klären, ob Wagglz-Status ("ruhend") für Organschaft angepasst werden muss. Businessplan mit realistischen Zahlen — nicht für externe, sondern für dich als Entscheidungsgrundlage.

**Innerhalb 8 Wochen**:
Café GmbH gründen. Gewinnabführungsvertrag notariell beurkunden lassen. Mietvertrag verhandeln (nur auf GmbH abschließen).

---

**Kritischer Hinweis**: Diese Analyse ersetzt keinen Steuerberater. Die Organschaft ist eines der komplexesten Konstrukte im deutschen Steuerrecht — ein Fehler bei der Durchführung (z.B. GAV nicht korrekt vollzogen) kann zur rückwirkenden Aberkennung führen. Die Konzeption hier ist korrekt, die Umsetzung muss ein auf Holding-Strukturen spezialisierter Steuerberater begleiten. Kosten dafür: ca. 2.000–4.000€ einmalig für Strukturberatung — die günstigste Investition des gesamten Projekts.

**Nächster Schritt**: Soll ich dir einen konkreten Businessplan mit Zahlen für das Café ausarbeiten, oder zuerst die steuerliche Struktur detaillierter durchrechnen (Organschaft-Szenarien mit konkreten Zahlen)?

---

**Du:**

Capital UG ist die Dachgesellschaft mit Beteiligung zu 100% darunter Wagglz die wagglz soll zum cafe umgewandelt werden

---

**Claude:**

Wichtige Korrektur — danke, das ändert die Struktur wesentlich.

Kurze Rückfrage bevor ich alles neu aufbaue:

**Was ist der aktuelle Unternehmensgegenstand der Wagglz GmbH im Handelsregister?**

Der Grund: Eine GmbH kann zwar den Geschäftszweck ändern (Satzungsänderung, Notartermin, ~800€), aber wenn der bisherige Gegenstand sehr spezifisch ist (z.B. "Entwicklung veterinärmedizinischer Software"), braucht es eine formelle Satzungsänderung mit Handelsregistereintragung — das dauert 4–8 Wochen.

Wenn der Gegenstand bereits breit formuliert ist (z.B. "Erbringung von Dienstleistungen aller Art" o.ä.), kannst du das Café **sofort operativ** unter der Wagglz starten, ohne Notar.

Weißt du das auswendig, oder soll ich dir sagen wie du es schnell prüfen kannst?

---

**Du:**

ja das muss aufjedenfall durchgeführt werden daher planen wir jetzt hier alles 

aktuell
Zentralisierte und digitale Vermittlungsplattform, die Hundebesitzern, Katzenbesitzern und Kleintieren eine Vielzahl von Dienstleistungen und Produkten vermittelt, darunter professioneller Gassiservice, individuelles Hundetraining, Tierarzt Service, Versicherungen, Bildungsbereich, Community und einen Online-Shop für Hochwertiges Hundefutter und Zubehör.

---

**Claude:**

Perfekt. Jetzt habe ich alles was ich brauche. Vollständiger Masterplan.
```
This block is not supported on your current device yet.
```

---

## Der entscheidende strategische Vorteil dieser Struktur

Weil die Wagglz GmbH **direkt** zur Café GmbH umgewandelt wird und die Capital UG 100% hält, brauchst du **keine Organschaft und keinen Gewinnabführungsvertrag**. Der Verlustvortrag ist bereits in der Gesellschaft — die zukünftigen Café-Gewinne verrechnen sich automatisch damit. Das ist der sauberste und günstigste Weg.

---

## Schritt 1: Satzungsänderung — alles was du wissen musst

**Was genau geändert werden muss:**

Der aktuelle Unternehmensgegenstand (Tierdienstleistungsplattform) wird vollständig ersetzt. Neuer Gegenstand, der sowohl das Café absichert als auch spätere Skalierung und Investoreneinstieg ermöglicht:

> *„Betrieb von Gastronomie- und Cafébetrieben, insbesondere von Cafés, Bars und Bistros; Handel mit Lebens- und Genussmitteln; Erbringung von Event- und Veranstaltungsdienstleistungen; Betrieb von Einzelhandelsgeschäften; sowie alle damit zusammenhängenden Tätigkeiten einschließlich der Beteiligung an anderen Unternehmen."*

Der breite Zuschnitt ist Absicht — er lässt Raum für das ARYS-Konzept (Café + Brand + Events + Records) ohne weitere Satzungsänderungen.

**Was der Notar macht und was es kostet:**

Notarielle Beurkundung der Satzungsänderung: ca. 400–700€ je nach Stammkapital der Wagglz. Handelsregistereintragung beim Amtsgericht: ca. 70–150€. Bearbeitungszeit Handelsregister Berlin: aktuell 4–8 Wochen. Name bleibt zunächst "Wagglz GmbH" — Namensänderung zu "Café [Name] GmbH" kostet nochmal ~200–300€ extra und ist optional, aber empfehlenswert sobald du einen Café-Namen hast.

**Dokumente die du zum Notar mitbringen musst:**

Aktueller Gesellschaftsvertrag der Wagglz GmbH (aus dem Handelsregister abrufbar unter handelsregister.de, kostenlos), gültiger Personalausweis, Gesellschafterbeschluss (kann der Notar vorbereiten), HR-Auszug (aktuell, nicht älter als 3 Monate).

**Critical point zum Verlustvortrag:** Die Satzungsänderung ist steuerrechtlich neutral — der Verlustvortrag überlebt sie vollständig. Er ist an die Körperschaft gebunden, nicht an den Unternehmensgegenstand. Was ihn vernichten würde: ein Gesellschafterwechsel von mehr als 50% (§ 8c KStG, Mantelkaufsregelung). Da Capital UG weiter 100% hält, passiert das nicht. Solange du keinen Investor reinholst der mehr als 50% übernimmt, ist der Verlustvortrag sicher.

---

## Schritt 2: Behörden und Anmeldungen parallel zur HR-Eintragung

**Gewerbeanmeldung Café:** Bezirksamt Berlin (Ordnungsamt), ca. 26€, Bearbeitungszeit 1–2 Wochen. Gaststättengewerbe ist in Berlin seit 2020 anzeigepflichtig aber nicht mehr genehmigungspflichtig — außer bei Alkoholausschank nach 22 Uhr (dann Sperrzeitbefreiung beim Bezirksamt beantragen).

**Finanzamt:** Neue Steuernummer für den geänderten Betriebszweck beantragen (Fragebogen zur steuerlichen Erfassung). USt-ID bleibt in der Regel bestehen.

**Pflichtversicherungen für Gastronomie:** Betriebshaftpflicht (ca. 300–600€/Jahr), Inventarversicherung, Berufsgenossenschaft Nahrungsmittel und Gastgewerbe (BGN) — Anmeldung innerhalb einer Woche nach Betriebsaufnahme, Pflicht. Glasversicherung optional aber empfehlenswert.

**TSE-Kassenpflicht:** Seit 2021 gesetzlich vorgeschrieben. Jede Kasse muss eine zertifizierte technische Sicherheitseinrichtung haben. Günstige Lösung: SumUp oder orderbird (beide TSE-konform, monatlich ca. 30–60€, kein großes Investvolumen).

**GEMA:** Wenn du Musik abspielst (auch Spotify im Café), bist du GEMA-pflichtig. Jahresgebühr für kleine Cafés: ca. 200–500€.

**Lebensmittelhygiene:** Anmeldung beim zuständigen Veterinär- und Lebensmittelaufsichtsamt (kostenfrei, Pflicht vor Eröffnung). Mindestens eine Person im Betrieb muss einen Hygienepass haben (IHK-Kurs, ca. 50–80€, halber Tag).

---

## Schritt 3: Das Gesellschafterdarlehen — jetzt richtig strukturieren

Deine ~150k€ als Gesellschafterdarlehen in der Wagglz sind der Hebel für die Café-Finanzierung. Du hast zwei saubere Wege:

**Weg A — Darlehen für Café-Investitionen nutzen:** Das Darlehenskapital bleibt in der GmbH und wird direkt für den Café-Aufbau verwendet (Miete, Ausbau, Erstausstattung). Die GmbH schuldet dir das Geld weiterhin. Wenn das Café profitabel wird, zahlt die GmbH dir das Darlehen zurück — das ist für dich steuerneutral (Rückzahlung eines Darlehens ist kein Einkommen). Zinsen kannst du vereinbaren (Fremdvergleichsmaßstab ca. 4–6% aktuell), dann fließen Zinsen als Betriebsausgabe raus und zu dir als Zinseinnahmen. Schlank, effizient.

**Weg B — Darlehen in Eigenkapital umwandeln:** Du verzichtest auf Rückzahlung, das wird Eigenkapital. Erhöht die Eigenkapitalbasis (gut für Mietvertrag-Verhandlungen und Lieferantenbonität), aber du verlierst den Rückzahlungsanspruch. Nur sinnvoll wenn du das Geld definitiv nicht zurückbrauchst.

**Empfehlung Weg A** — maximale Flexibilität, du behältst den Rückzahlungsanspruch, und das Café hat sofort Betriebskapital.

---

## Schritt 4: Standort Berlin — realistisch und schnell

Für ein erstes Café mit dem von dir beschriebenen Stil (ALD-inspiriert, Premium-Streetwear-Vibe) passen folgende Berliner Kieze mit realistischen Mietpreisen:

**Neukölln (Reuterstraße/Weserstraße):** 18–28€/qm, starke Laufkundschaft, junges Publikum, hohe Gastronomiedichte aber noch Lücken für Konzeptcafés. Schnellste Flächen verfügbar.

**Wedding (Müllerstraße/Gerichtstraße):** 15–22€/qm, stark im Kommen, noch günstig, passt zu authentischem Brand-Aufbau ohne Touristeneffekt.

**Friedrichshain (Simon-Dach-Kiez):** 25–38€/qm, höhere Miete aber sehr hohe Frequenz, gut für schnellen Break-even.

**Xhain/Kreuzberg (Bergmannstraße):** 30–45€/qm, Premium-Lage, höchstes Risiko aber höchste Markenstrahlkraft.

Mein Rat für deine Situation (Kapital begrenzt, schnell profitabel werden): **Neukölln oder Wedding** für den Start. Markenaufbau funktioniert heute über Instagram, nicht über die Adresse.

Fläche findest du am schnellsten nicht über ImmobilienScout, sondern: Direkt in Kieze laufen und Leerstände fotografieren, Gewerbemakler wie Lührmann oder Comfort Berlin anschreiben, Facebook-Gruppen "Gewerbe Berlin mieten/kaufen", und das Netzwerk der IHK Berlin (kostenlose Beratung für Existenzgründer).

---

## Das Gesellschafterdarlehen als Sicherheit beim Mietvertrag

Gewerbevermieter in Berlin verlangen fast immer: drei Monatsmieten Kaution, Bonitätsnachweis der GmbH (neu gegründet = kein Track Record), und oft persönliche Bürgschaft des Gesellschafters. Das Darlehen in der GmbH stärkt die Bilanz — lass deinen Steuerberater eine saubere Eröffnungsbilanz erstellen, die zeigt dass die GmbH mit dem Darlehenskapital gut ausgestattet ist. Das ist dein stärkstes Argument gegenüber dem Vermieter.

---

## Was es kostet — konkrete Zahlen

| Position | Einmalig | Monatlich |
|---|---|---|
| Satzungsänderung Notar + HR | 700–1.200€ | — |
| Gewerbeanmeldung | 26€ | — |
| Hygienepass | 80€ | — |
| Steuerberater Strukturberatung | 2.000–3.500€ | 350–500€ |
| Espressomaschine (gebraucht) | 2.500–5.000€ | — |
| Kaffeemühle | 800–1.500€ | — |
| Mobiliar/Ausbau (Minimal) | 8.000–20.000€ | — |
| Kassensystem (TSE) | 500–1.000€ | 30–60€ |
| Erstwarenbestand | 2.000–3.000€ | — |
| Versicherungen | 800€ | 80€ |
| BGN + GEMA | — | 50–80€ |
| Kaution (3 Monate) | 6.000–12.000€ | — |
| **Gesamt ohne Miete** | **~25.000–48.000€** | **~510–720€** |

Von deinen ~150k€ Darlehenskapital brauchst du also ca. 25–50k€ für den Aufbau. Der Rest bleibt als Puffer — und das ist bei Gastronomie existenziell wichtig: Die meisten Cafés scheitern nicht wegen des Konzepts, sondern wegen fehlender Liquidität in Monat 4–8 vor dem Break-even.

---

**Nächster Schritt:** Soll ich dir jetzt den konkreten Notar-Briefing-Text für die Satzungsänderung ausarbeiten, oder zuerst den Businessplan mit Break-even-Kalkulation für dein spezifisches Konzept?

---

**Du:**

Das Darlehnen wurde bereits schon ausgegeben da ich das davor in das Start up zum aufbau verwendet habe  

Daher muss ich neu investieren

ICh würde gern darauf erstmal verzichten damit es in der Firma bleibt und irgendwann gewinne abgibt

Rückzahlungsanspruch behalten



Plane den Promt bitte damit ich hier ein Projektordner anlegen kann bzw kannst du auch eins anlegen

---

**Claude:**

Kurze Klarstellung damit ich den Prompt präzise baue:

Das Darlehen wurde ausgegeben (für den Startup-Aufbau), ist also bereits **verbraucht** — die GmbH hat das Geld nicht mehr als Cash, sondern als Verluste/Assets aus dem Vetprojekt verbucht. Du verzichtest auf Rückzahlung damit der Anspruch formal bleibt, aber erwartest das Geld erst zurück wenn das Café Gewinne macht. Korrekt so?

Und zur Projektstruktur — ich lege es direkt an. Einen Moment.

---

**Du:**

Genau, mit Rückzahlungsanspruch

---

**Claude:**

Gut. Ich lege das Projekt jetzt direkt an.
```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```


```
This block is not supported on your current device yet.
```

Gespeichert. Hier ist der fertige Projekt-Prompt — direkt verwendbar:

---

## Projekt-Prompt: Café Berlin

```
# Kontext

Ich bin Oleg, Unternehmer in Berlin. Ich baue ein Café auf, das unter meiner 
bestehenden Holding-Struktur operiert:

Capital UG (Dachgesellschaft, 100% Anteilseigner)
└── Wagglz GmbH (wird zur Café-Betriebsgesellschaft umgewandelt)

## Finanzielle Ausgangslage

- ~150.000 € Gesellschafterdarlehen in der Wagglz GmbH bereits verbraucht 
  (in den Startup-Aufbau der ursprünglichen Plattform investiert)
- Rückzahlungsanspruch bleibt formal bestehen — kein Verzicht
- Verlustvortrag ~150.000 € in der Wagglz GmbH vorhanden (§ 10d KStG)
- Ziel: Café-Gewinne gegen diesen Verlustvortrag verrechnen → steuerfrei 
  bis Vortrag aufgebraucht
- Neues Eigenkapital muss frisch investiert werden (Höhe noch offen)
- Kein externes Budget bisher — so kapitaleffizient wie möglich aufbauen

## Status der Wagglz GmbH

- Aktueller Unternehmensgegenstand: Tierdienstleistungsplattform (Hunde, 
  Katzen, Kleintiere)
- Satzungsänderung auf Café-Betrieb steht aus (Notar noch nicht beauftragt)
- Beide Gesellschaften aktiv, kein Umsatz, keine Gewinne
- Jahresabschlüsse 2024/2025/2026 werden noch erstellt

## Das Café

- Eigenständiges Café-Konzept in Berlin, von Grund auf aufgebaut
- Ästhetik und Positionierung: ALD-inspiriert (Aimé Leon Dore), 
  NYC Preppy-meets-Streetwear — Premium ohne Arroganz, Community-Gefühl
- Alleinbetrieb zu Beginn, Investor-Einstieg und Skalierung offen gehalten
- Mittelfristiges Ziel: Verkauf oder Skalierung über Holding (§ 8b KStG)

## Arbeitsbereiche in diesem Projekt

1. Rechtliches & Struktur — Satzungsänderung, Handelsregister, Behörden
2. Steuer & Finanzen — Verlustverrechnung, Darlehen, Kapitalplanung
3. Standort & Immobilien — Berliner Kieze, Mietvertrag, Verhandlung
4. Konzept & Brand — Positionierung, Ästhetik, Differenzierung
5. Betrieb & Prozesse — Ausstattung, Personal, Lieferanten, Hygiene
6. Investor & Exit — Beteiligungsstruktur, Vorbereitung Verkauf

## Wie wir arbeiten

- Analysiere still welche Expertenrolle gerade gefragt ist (Steuerberater, 
  Gastronom, Immobilienmakler, Brand Strategist, Jurist, Finanzplaner)
- First Principles — Annahmen hinterfragen bevor du antwortest
- Nur was ein Senior-Experte selbst unterschreiben würde
- Vollständige, sofort verwendbare Deliverables
- Bei Unklarheit: max. 2 gezielte Rückfragen
- Jede Antwort endet mit dem sinnvollsten nächsten Schritt
- Sprache: Deutsch
```

---

**So anwenden:** Neues Projekt in Claude anlegen → diesen Text als Projektanweisung einfügen → fertig. Alle zukünftigen Gespräche im Projekt haben diesen vollständigen Kontext automatisch.

**Nächster Schritt:** Soll ich direkt den **Notar-Briefing-Text für die Satzungsänderung** ausarbeiten — so dass du diesen Text einem Berliner Notar schicken kannst und er alles Nötige hat?

---

**Du:**

Genau, mit Rückzahlungsanspruch

---

**Claude:**

Das war eine Doppelnachricht — du hast das bereits bestätigt, ich habe es gespeichert und eingebaut.

Der Rückzahlungsanspruch ist im Projekt-Prompt und im Memory korrekt verankert.

Soll ich jetzt den Notar-Briefing-Text für die Satzungsänderung ausarbeiten?

---

**Du:**

fehlt uns noch was im prompt?

---

**Claude:**

Gute Frage. Ich gehe den Prompt gegen das durch was wir besprochen haben:

**Was drin ist:** Struktur, Darlehen, Verlustvortrag, Satzungsänderung, Ästhetik, Arbeitsbereiche, Arbeitsweise. Solide.

**Was fehlt oder unscharf ist:**

1. **Dein persönliches Zeitbudget** — Baust du das Café als Hauptprojekt oder parallel zum Job? Das bestimmt ob wir auf Eigenoperator oder Manager-Modell planen.

2. **Café-Typ** — Specialty Coffee only, Speisekarte, Alkohol, Abendgeschäft? Das hat direkte Auswirkungen auf Lizenz, Ausstattung, Kalkulation und Zielgruppe. Noch völlig offen.

3. **Zielgröße der Fläche** — 40qm Kiosk-Format, 80qm klassisches Café, 150qm mit Eventfläche? Das definiert den Kapitalbedarf komplett.

4. **Investor-Präferenz** — Stiller Gesellschafter, aktiver Co-Founder, oder institutionelles Kapital? Macht einen großen Unterschied bei der Vertragsstruktur.

5. **ARYS-Verbindung** — Ist das Café ein eigenständiges Projekt oder langfristig Teil der ARYS-Brand? Das sollte im Prompt klar sein, weil es die Markenentscheidungen komplett verändert.

Die ersten drei sind für die operative Planung kritisch — ohne sie können wir keinen belastbaren Businessplan und keine Standortstrategie entwickeln. Sollen wir die jetzt klären und dann den Prompt finalisieren?

---

**Du:**

1. aktuell parallel zum Job kann aber zum Hauptprojekt werden sobald es losgeht aktuell arbeite ich noch als Senior Account Executive bei Doctolib 
2. Speciality Coffe mit alkohol abendgeschäft ab und zu dj online shop (crossiaint kuchen sandwiches etc. optional )
3. so effizient wie möglich das es sich finanziell schnell rentiert orientiere dich evtl an Lap coffee
4. aktiver Co founder und später mögliche stiller gesellschafter
5. eigenständiges Projekt arys kann getrennt wwerden

---

**Claude:**

Perfekt. Jetzt ist der Kontext vollständig. Prompt wird finalisiert.
```
This block is not supported on your current device yet.
```

Gut. LAP ist ein reines To-go-Volumenmodell mit Vollautomaten und Investor-Backing — das ist nicht dein Modell. Was du beschreibst ist das Gegenteil: Specialty, Abendgeschäft, Alkohol, DJ, Community. Die richtige Referenz für dich ist eher **Bonanza Coffee**, **Father Carpenter** oder **Café CK** — kleines Format, hohes Handwerk, klare Identität, Abend-Erweiterung.

Jetzt der finale Prompt:

---

```
# Café Berlin — Projekt-Kontext

## Holding-Struktur

Capital UG (Dachgesellschaft, 100% Anteilseigner)
└── Wagglz GmbH → wird zur Café-Betriebsgesellschaft umgewandelt

## Finanzielle Ausgangslage

- ~150.000 € Gesellschafterdarlehen bereits verbraucht (in ursprünglichen 
  Startup-Aufbau investiert, kein Cash mehr in der GmbH)
- Rückzahlungsanspruch bleibt formal bestehen — kein Forderungsverzicht
- Verlustvortrag ~150.000 € in der Wagglz GmbH (§ 10d KStG) — wird gegen 
  zukünftige Café-Gewinne verrechnet → de facto steuerfreie Anfangsgewinne
- Neues Eigenkapital muss frisch eingebracht werden — Höhe richtet sich nach 
  minimalem, rentablem Setup
- Kein externes Budget bisher — Kapitaleffizienz ist oberstes Gebot

## Status der Wagglz GmbH

- Unternehmensgegenstand aktuell: Tierdienstleistungsplattform (Hunde, Katzen, 
  Kleintiere — digitale Vermittlung)
- Satzungsänderung auf Café-Betrieb steht aus (Notar noch nicht beauftragt)
- Beide Gesellschaften aktiv, kein Umsatz, keine Gewinne
- Jahresabschlüsse 2024/2025/2026 werden noch erstellt

## Das Café — Konzept

Eigenständiges Projekt (getrennt von ARYS Fashion Brand).

Positionierung: Specialty Coffee als Hauptanker, Alkohol und gelegentliches 
Abendprogramm (DJ), kleines Food-Angebot (Croissants, Kuchen, Sandwiches), 
Online-Shop als zusätzlicher Kanal. Kein LAP-Modell (kein Volumen-To-go, 
keine Vollautomaten) — Handwerk, Identität, Community.

Ästhetik: ALD-inspiriert (Aimé Leon Dore), NYC Preppy-meets-Streetwear. 
Premium ohne Arroganz. Fläche so effizient wie möglich — schneller Break-even 
vor Skalierung.

Referenz-Benchmarks: Bonanza Coffee, Father Carpenter, Café CK Berlin.

## Mein Setup

- Aktuell: Senior Account Executive bei Doctolib (Vollzeit), Café läuft parallel
- Sobald Café operativ und stabil: Hauptfokus möglich
- Start: Alleinbetrieb mit operativem Manager oder Teilzeitkraft
- Co-Founder-Einstieg möglich und gewünscht (aktiv, mit Equity)
- Spätere stille Beteiligung externer Investoren offen gehalten
- Mittelfristiges Ziel: Skalierung oder Verkauf über Holding (§ 8b KStG: 
  95% des Veräußerungsgewinns steuerfrei)

## Arbeitsbereiche

1. Rechtliches & Struktur — Satzungsänderung, HR, Behörden, Gaststättenrecht
2. Steuer & Finanzen — Verlustverrechnung, Kapitalbedarf, Darlehensstruktur
3. Standort & Immobilien — Berliner Kieze, Flächengröße, Mietverhandlung
4. Konzept & Brand — Positionierung, Ästhetik, Differenzierung, Name
5. Betrieb & Prozesse — Ausstattung, Personal, Lieferanten, Hygiene, Lizenz
6. Online-Shop — Plattform, Sortiment, Integration in Betrieb
7. Co-Founder & Investor — Beteiligungsstruktur, Term Sheet, Vesting
8. Exit & Skalierung — Zweite Location, Verkauf, Franchiseansatz

## Arbeitsweise

- Expertenrolle still wechseln je nach Thema (Steuerberater, Gastronom, 
  Immobilienmakler, Brand Strategist, Jurist, Finanzplaner, Operationsexperte)
- First Principles — Annahmen hinterfragen bevor geantwortet wird
- Nur Deliverables die ein Senior-Experte selbst unterschreiben würde
- Vollständige, sofort verwendbare Outputs
- Bei Unklarheit: max. 2 gezielte Rückfragen
- Jede Antwort endet mit dem sinnvollsten nächsten Schritt
- Sprache: Deutsch
```

---

Das ist der vollständige Prompt. Alles was wir besprochen haben ist drin — keine Lücken mehr.

**Nächster Schritt:** Projekt in Claude anlegen, Prompt einfügen — dann direkt mit dem Notar-Briefing für die Satzungsänderung starten, denn das ist der einzige Schritt der eine externe Partei und Vorlaufzeit braucht. Alles andere kannst du parallel selbst treiben.

---

**Du:**

Welches modell soll ich dazfür nutzen Opus?

---

**Claude:**

Für ein Business-Projekt dieser Komplexität — rechtlich, steuerlich, strategisch, operativ — empfehle ich **Claude Sonnet** (aktuell Sonnet 4.6, das Modell mit dem du gerade sprichst).

**Warum nicht Opus?**

Opus ist das stärkste Modell für extrem komplexe, wissenschaftliche oder hochgradig abstrakte Aufgaben. Für dein Café-Projekt bringt es keinen messbaren Vorteil — die Aufgaben hier sind komplex, aber konkret und praxisorientiert. Sonnet liefert dieselbe Qualität bei deutlich schnelleren Antworten und niedrigeren Kosten wenn du über die API gehst.

**Ausnahme:** Wenn du irgendwann sehr komplexe steuerrechtliche Konstruktionen durchrechnen willst (z.B. detaillierte Organschafts-Szenarien mit mehreren Gesellschaften und Zeitachsen), lohnt es sich, diesen einen Prompt mit Opus zu schicken. Aber als Standard-Modell für das Projekt: Sonnet.

---

**Du:**

ok wie starte ich mit dem ersten prompt im projekt?

---

**Claude:**

So gehst du vor:

**1. Projekt anlegen**
Claude.ai → linke Sidebar → „Neues Projekt" → Name z.B. „Café Berlin"

**2. Prompt einfügen**
Im Projekt auf „Projektanweisungen" oder „Instructions" klicken → den kompletten Prompt aus unserem Gespräch reinkopieren → speichern.

**3. Ersten Chat im Projekt starten**
Neues Gespräch innerhalb des Projekts öffnen — dann mit diesem ersten Prompt einsteigen:

---

```
Wir starten mit Schritt 1.

Erstelle mir einen vollständigen Notar-Briefing-Text für die 
Satzungsänderung der Wagglz GmbH. 

Der Text soll so formuliert sein, dass ich ihn direkt per E-Mail 
an einen Berliner Notar schicken kann — mit allen relevanten 
Informationen damit er sofort loslegen kann:

- Aktueller Unternehmensgegenstand (Tierdienstleistungsplattform)
- Neuer Unternehmensgegenstand (Café-Betrieb, breit formuliert)
- Namensänderung gewünscht (Placeholder für Café-Name)
- Gesellschafterstruktur: Capital UG hält 100%
- Ziel: Verlustvortrag erhalten, keine Anteilsänderung

Außerdem: Liste der Dokumente die ich zum Notartermin mitbringen muss.
```

---

Das ist der logisch erste Schritt — weil die Satzungsänderung externe Vorlaufzeit hat und alles andere davon abhängt.

---

**Du:**

Kannst du hier ein Prompt aufsetzen wo alles abgefragt wird direkt für den ersten Prompt das wir das gesamte projekt aufbauen ohne das ich dauerhaft danach fragen muss

---

**Claude:**

Guter Gedanke. Hier ist ein strukturierter Onboarding-Prompt der alles auf einmal abfragt — einmalig ausfüllen, dann läuft das Projekt von selbst:

---

```
# Projekt-Kickoff: Café Berlin

Bevor wir starten, brauche ich einmalig alle offenen Informationen 
um das Projekt vollständig aufzubauen. Beantworte die folgenden 
Fragen so konkret wie möglich — danach erstelle ich:

1. Vollständigen Projektplan mit Phasen und Meilensteinen
2. Notar-Briefing für die Satzungsänderung
3. Kapitalbedarf-Kalkulation
4. Standort-Kriterien-Profil für Berlin
5. Co-Founder-Profil und Beteiligungsstruktur

---

## BLOCK 1 — Rechtliches & Struktur

1. Wie lautet der exakte eingetragene Name der Wagglz GmbH im 
   Handelsregister? (inkl. Rechtsform-Zusatz)

2. Hast du bereits einen Wunschnamen für das Café? Falls ja: welcher? 
   Falls nein: soll ich Vorschläge machen?

3. Soll die GmbH direkt umbenannt werden (Wagglz GmbH → Café XY GmbH) 
   oder erstmal unter Wagglz GmbH operieren bis der Name feststeht?

4. Gibt es bereits einen Steuerberater der die Wagglz betreut? 
   Falls ja: ist er über das Café-Projekt informiert?

---

## BLOCK 2 — Finanzen & Kapital

5. Wie viel Eigenkapital kannst du realistisch neu einbringen? 
   (Größenordnung reicht: unter 20k / 20–50k / 50–100k / über 100k)

6. Wie läuft das Gesellschafterdarlehen aktuell buchhalterisch? 
   Gibt es einen formellen Darlehensvertrag mit Zinssatz und Laufzeit?

7. Sind die Jahresabschlüsse 2023 und 2024 bereits beim Finanzamt 
   eingereicht? Ist der Verlustvortrag steuerlich festgestellt?

8. Hast du eine monatliche Schmerzgrenze was das Café dich persönlich 
   kosten darf solange es noch nicht profitabel ist?

---

## BLOCK 3 — Konzept & Standort

9. Hast du bereits konkrete Berliner Kieze im Kopf oder bist du 
   völlig offen? (Präferenzen, No-Gos)

10. Fläche: Eher kompakt (40–60qm, Fokus Bar + wenig Sitzplätze) 
    oder klassisches Café-Format (80–120qm mit mehr Sitzplätzen)?

11. Abendgeschäft: Wie oft pro Woche vorgestellt? 
    Fester Konzepttag (z.B. jeden Freitag) oder spontan/saisonal?

12. Online-Shop: Nur Kaffee-Produkte (Bohnen, Merch) oder auch 
    Food (Gebäck versandfertig)? Plattform-Präferenz: Shopify, 
    WooCommerce, oder offen?

---

## BLOCK 4 — Co-Founder & Team

13. Was soll der Co-Founder konkret einbringen? 
    (Kapital / Gastro-Erfahrung / Netzwerk / Operations / alles)

14. Hast du bereits jemanden im Kopf oder suchst du noch?

15. Welche Aufgaben willst du selbst übernehmen solange du noch 
    bei Doctolib bist? (z.B. nur strategisch, oder auch operativ 
    am Wochenende)

16. Wann ist realistisch dein frühestmöglicher Kündigungstermin 
    bei Doctolib falls das Café läuft? (Kündigungsfrist?)

---

## BLOCK 5 — Vision & Exit

17. Zeithorizont: Wann soll das Café spätestens eröffnet sein? 
    (Wunsch vs. realistisch)

18. Skalierung: Eine zweite Location in Berlin, andere Städte, 
    oder Verkauf nach Beweis des Konzepts?

19. Was ist deine persönliche Definition von Erfolg für dieses 
    Projekt in Jahr 1, Jahr 3, Jahr 5?

20. Gibt es Referenz-Cafés (weltweit) die du vom Gefühl her 
    als Ziel siehst — nicht nur LAP, sondern Atmosphäre, 
    Erlebnis, Marke?

---

Sobald du diese Fragen beantwortet hast, baue ich das komplette 
Projekt strukturiert auf — von der Satzungsänderung bis zum 
Exit-Szenario. Einmalig, vollständig, ohne Nachfragen.
```

---

Diesen Prompt als **allererste Nachricht** im neuen Projekt schicken. Die Antworten die du gibst werden zur permanenten Basis für alle weiteren Gespräche im Projekt.

---

**Du:**

Alles was relevant ist um das cafe von 0 auf 100 aufzubauen

Design, interoir, etc

---

**Claude:**

Guter Punkt. Der Prompt war gut aber nicht vollständig. Hier ist die finale Version — wirklich alles drin:

---

```
# Projekt-Kickoff: Café Berlin — Von 0 auf 100

Bevor wir starten, brauche ich einmalig alle offenen Informationen 
um das Projekt vollständig aufzubauen. Beantworte so konkret wie 
möglich — danach erstelle ich einen vollständigen Masterplan der 
das Café von der GmbH-Gründung bis zur Eröffnung abdeckt.

---

## BLOCK 1 — Rechtliches & Struktur

1. Exakter eingetragener Name der Wagglz GmbH im Handelsregister?

2. Hast du bereits einen Wunschnamen für das Café?
   Falls nein: soll ich Vorschläge entwickeln?

3. Sofortige Umbenennung der GmbH oder erstmal unter 
   Wagglz GmbH operieren bis Name feststeht?

4. Steuerberater bereits involviert und über Café informiert?

---

## BLOCK 2 — Finanzen & Kapital

5. Wie viel Eigenkapital kannst du neu einbringen?
   (unter 20k / 20–50k / 50–100k / über 100k)

6. Formeller Darlehensvertrag für die 150k vorhanden? 
   Mit Zinssatz und Laufzeit?

7. Jahresabschlüsse 2023/2024 eingereicht? 
   Verlustvortrag steuerlich festgestellt?

8. Monatliche Schmerzgrenze: Was darf das Café dich persönlich 
   kosten bevor es profitabel ist?

---

## BLOCK 3 — Standort & Fläche

9. Bevorzugte Berliner Kieze? No-Gos?

10. Flächengröße: Kompakt (40–60qm) oder klassisch (80–120qm)?

11. Erdgeschoss Pflicht oder auch UG/1.OG denkbar?

12. Außenfläche / Terrasse gewünscht?

13. Denkmalgeschütztes Gebäude — akzeptabel oder lieber nicht?

---

## BLOCK 4 — Konzept & Betrieb

14. Öffnungszeiten Vorstellung: 
    Morgens ab wann? Abends bis wann? Wie viele Tage/Woche?

15. Abendgeschäft: Fester Konzepttag oder spontan/saisonal?

16. DJ-Abende: Inhouse-Setup (eigene Anlage) oder 
    mobiles Equipment der DJs?

17. Alkohol: Nur Wein/Bier/Naturwein oder auch Cocktails/Bar?

18. Food-Angebot: Nur Backwaren (Croissants, Kuchen) oder 
    auch warme Küche (Sandwiches, Eggs)?

19. Rösterei-Partner schon im Kopf oder offen?
    (Eigenmarke langfristig vorstellbar?)

20. Online-Shop: Nur Kaffee/Merch oder auch Food-Produkte?
    Plattform-Präferenz: Shopify / WooCommerce / offen?

---

## BLOCK 5 — Design & Interior

21. Welche Cafés weltweit inspirieren dich vom Gefühl, 
    Atmosphäre und Interior? (3–5 Referenzen)

22. Materialien: Welche sprechen dich an?
    (Rohbeton / warmes Holz / Marmor / Metall / Terrakotta / Mix)

23. Farbwelt: Eher warm (Beige, Creme, Braun, Olive) oder 
    kühl (Weiß, Grau, Schwarz) oder beides?

24. Beleuchtung: Warmes indirektes Licht oder 
    klares funktionales Licht oder Mix?

25. Sitzkonzept: Hohe Bar-Stühle / niedrige Lounge-Sessel / 
    klassische Stühle und Tische / Mix?

26. Musik-Setup sichtbar als Design-Element 
    (Plattendecks, Vinyl-Wand, Lautsprecher als Objekte)?

27. Pflanzen als Gestaltungselement — ja/nein/wie viel?

28. Eigene Keramik / Tassen-Design gewünscht oder 
    Standard-Gastro-Equipment reicht erstmal?

29. Gibt es ein grobes Vorstellungsbild für das Logo / 
    die visuelle Identität? (Wörter, Gefühle, Referenzen)

30. Soll das Interior skalierbar sein (gleicher Look für 
    spätere Locations) oder bewusst einmalig/handgemacht?

---

## BLOCK 6 — Brand & Marketing

31. Zielgruppe konkret: Wer soll täglich reinkommen?
    (Alter, Lifestyle, Beruf, Mindset)

32. Social Media: Willst du selbst der Gesichter der Brand sein 
    oder lieber anonym im Hintergrund bleiben?

33. Launch-Strategie: Soft-Opening (nur Friends & Network) 
    oder direkt mit Event und Presserummel?

34. Kollaborationen vorstellbar? 
    (Andere Brands, Künstler, Musiker, lokale Designer)

35. Merchandise von Anfang an oder erst nach Etablierung?

---

## BLOCK 7 — Team & Co-Founder

36. Was soll der Co-Founder einbringen?
    (Kapital / Gastro-Erfahrung / Operations / Netzwerk / alles)

37. Bereits jemanden im Kopf oder aktiv suchend?

38. Welche Rolle übernimmst du selbst parallel zu Doctolib?
    (Nur strategisch / auch operativ am Wochenende / beides)

39. Kündigungsfrist bei Doctolib?

40. Erstes Personal: Eine Teilzeitkraft reicht oder 
    brauchst du vom Tag 1 einen erfahrenen Barista?

---

## BLOCK 8 — Vision & Exit

41. Eröffnungsziel: Wann soll das Café spätestens öffnen?

42. Jahr-1-Ziel: Was bedeutet Erfolg für dich nach 12 Monaten?

43. Skalierung: Zweite Location Berlin / andere Städte / 
    Verkauf nach Proof of Concept / Franchise?

44. Wäre eine Marken-Lizenzierung denkbar 
    (andere betreiben das Konzept unter deiner Brand)?

45. Persönliche Exit-Vorstellung: Vollständiger Verkauf oder 
    Anteile behalten und Dividenden langfristig?

---

Sobald du alle Blöcke beantwortet hast baue ich auf:

- Vollständiger Projektplan mit Phasen, Meilensteinen, Deadlines
- Notar-Briefing Satzungsänderung
- Kapitalbedarf-Kalkulation und Break-even-Analyse
- Standort-Kriterien-Profil Berlin
- Interior-Moodboard-Brief für Designer/Architekt
- Brand-Strategie und Naming-Vorschläge
- Co-Founder-Profil und Beteiligungsstruktur-Entwurf
- Online-Shop Architektur
- Lizenz- und Behörden-Checkliste Berlin
- Exit-Szenarien mit steuerlicher Optimierung

Einmalig ausgefüllt — alles andere läuft von selbst.
```

---

**Das ist der vollständige Kickoff-Prompt.** 45 Fragen, 8 Blöcke, kein Bereich ausgelassen — von der GmbH bis zum Vinyl an der Wand.

Ins Projekt einfügen, als erste Nachricht schicken, einmal komplett beantworten — dann haben wir die Basis für alles.

---

