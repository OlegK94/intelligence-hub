---
date: 2026-05-14
tags: [claude]
---

# Fotos von Google Fotos zu iCloud übertragen

**Du:**

Meine Mutter nutzt noch Google Fotos und ich möchte alle Fotos zu I Cloud übertragen und dann das Google One Abo beenden

Wie kann ich die Fotos sicher und alle übertragen

---

**Claude:**

```
This block is not supported on your current device yet.
```

Hier ist eine klare, schrittweise Anleitung für den sichersten Transfer — ohne Datenverlust und ohne doppelte Abos.
```
This block is not supported on your current device yet.
```

**Was du für deine Mutter konkret tun solltest:**

**Vor dem Start:** iCloud-Speicher checken — Google Fotos-Bibliothek ist oft 10–50 GB. Wenn der iCloud-Speicher zu klein ist, vorher auf iCloud+ upgraden (0,99 €/Monat für 50 GB, 2,99 € für 200 GB).

**Bestes Vorgehen für Nicht-Techniker:** Das Google-eigene Migrationstool unter `accounts.google.com/info/photos-transfer` ist die einfachste Route — Google überträgt direkt zu iCloud, ohne dass Dateien manuell heruntergeladen werden müssen. Verfügbarkeit in Deutschland: ja, seit 2021.

**Wenn Takeout nötig ist** (z. B. weil das Tool nicht funktioniert): Die ZIPs kommen ohne Metadaten-Probleme, sofern man die `.json`-Begleitdateien nicht braucht. Für normale Familienfotos ist das kein Problem.

**Kritischer Punkt:** Google One erst kündigen, wenn die Fotos mindestens eine Woche lang sicher in iCloud liegen und stichprobenartig geprüft wurden. Google behält Daten nach Kündigung noch 30 Tage — das ist die Sicherheitsnetz-Frist.

**Nächster Schritt:** Prüfe den aktuellen Google-Speicherverbrauch (unter `one.google.com`) und den iCloud-Speicher deiner Mutter — dann weißt du, ob ein Plan-Upgrade nötig ist, bevor der Transfer beginnt.

---

**Du:**

Wie kann ich Mails von den letzten 10 Tagen aus Proton wieder zu i. Cloud Mail mit der selben Domail umziehen?

---

**Claude:**

Kurze Rückfrage, damit ich dir die richtige Lösung gebe:

Was genau möchtest du erreichen?
```
This block is not supported on your current device yet.
```

---

**Du:**

F: Was ist das Ziel des Umzugs?
A: Ich möchte dauerhaft von Proton zu iCloud Mail wechseln

F: Welches Gerät nutzt deine Mutter hauptsächlich?
A: Beides

---

**Claude:**

Kurze Klärung noch — geht es um **deine Mutter** (wie beim Fotos-Thema), oder um **dich selbst** und deine `ok-holding.com`-Domain auf Proton?

Das ändert die Komplexität erheblich: Bei einer eigenen Domain mit DNS-Konfiguration (MX, SPF, DKIM, DMARC) ist der Umzug aufwendiger als bei einer Standard-Adresse.
```
This block is not supported on your current device yet.
```

---

**Du:**

F: Um wessen Proton-Account geht es?
A: Mein eigener Account (ok-holding.com oder ähnlich)

---

**Claude:**

Wichtiger Hinweis vorab: Du hast Proton als Privacy-First-Infrastruktur bewusst gewählt und alles sauber konfiguriert (MX, SPF, DKIM, DMARC via GoDaddy). Ein Wechsel zu iCloud Mail mit custom Domain ist technisch möglich, aber du gibst dabei einiges auf — das solltest du einkalkulieren.

---

**Was du verlierst beim Wechsel zu iCloud Mail:**

- Ende-zu-Ende-Verschlüsselung (Proton) → iCloud verschlüsselt, aber Apple hat Zugriff
- Zero-Knowledge-Architektur
- Proton Pass, Bridge, alle integrierten Tools verlieren ihre Mail-Basis

**Was iCloud Mail mit custom Domain kann:** Seit 2021 unterstützt iCloud Mail eigene Domains — aber nur mit `@me.com`, `@icloud.com` oder custom domain über Apple-ID. Für `ok-holding.com` wäre das möglich.

---

**Der konkrete Umzugsplan:**

**Phase 1 — Mails exportieren (aus Proton)**

Proton unterstützt keinen direkten IMAP-Export. Weg: Proton Mail Bridge installieren (Desktop-App) → macht Proton per IMAP lokal erreichbar → dann mit einem Mail-Client (Apple Mail auf Mac) verbinden und alle Mails lokal speichern oder als `.mbox`/`.eml` exportieren.

Schritt für Schritt:
1. Proton Mail Bridge herunterladen: `proton.me/mail/bridge`
2. Auf Mac installieren, einloggen
3. Apple Mail öffnen → Account hinzufügen → IMAP → Bridge-Zugangsdaten eingeben
4. Alle Ordner synchronisieren lassen (kann bei 10 Tagen schnell gehen)
5. Mails in Apple Mail markieren → in lokalen Ordner ziehen (als Backup)

**Phase 2 — iCloud Mail mit ok-holding.com einrichten**

1. `icloud.com/mail` → Einstellungen → Custom Email Domain
2. Domain `ok-holding.com` hinzufügen
3. Apple gibt dir neue DNS-Einträge → in GoDaddy eintragen (MX, SPF, DKIM ersetzen die Proton-Einträge)
4. Verifizierung abwarten (~15–30 Min.)

**Phase 3 — Mails von Proton nach iCloud übertragen**

Sobald iCloud Mail mit der Domain läuft:
1. In Apple Mail: iCloud-Account ebenfalls einrichten
2. Lokale Mails (aus Phase 1) per Drag & Drop in iCloud-Postfach ziehen
3. Oder: beide Accounts gleichzeitig in Apple Mail offen → direkt zwischen Ordnern verschieben

**Phase 4 — DNS-Umstellung in GoDaddy**

Das ist der kritische Schnitt — ab diesem Moment landen neue Mails bei iCloud, nicht mehr bei Proton:
- Alte MX-Einträge (Proton) löschen
- Neue MX-Einträge (Apple) setzen
- SPF, DKIM, DMARC auf Apple-Werte aktualisieren
- TTL vorher auf 300 Sekunden reduzieren (schnellere Propagation)

**Phase 5 — Proton-Abo kündigen**

Erst nach 48–72 Stunden, wenn die DNS-Propagation bestätigt ist und neue Mails sauber bei iCloud ankommen.

---

**Zeitaufwand:** Ca. 2–3 Stunden für die technische Umsetzung, plus 24–48h DNS-Wartezeit.

**Nächster Schritt:** Entscheid, ob du den Privacy-Trade-off bewusst eingehen willst — oder ob der eigentliche Wunsch eher eine bessere Apple Mail Integration bei gleichzeitig aktivem Proton ist (das geht über Proton Bridge ohne DNS-Wechsel).

---

