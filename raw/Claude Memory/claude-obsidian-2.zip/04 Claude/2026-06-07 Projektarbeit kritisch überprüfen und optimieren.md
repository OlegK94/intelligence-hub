---
date: 2026-06-07
tags: [claude]
---

# Projektarbeit kritisch überprüfen und optimieren

**Du:**

Durchsuche alle bisherigen Gespräche in diesem Projekt. 
Identifiziere die wichtigsten Ergebnisse, Entscheidungen 
und Outputs die wir erarbeitet haben.
Bewerte diese jetzt kritisch nach deinen aktuellen 
Anweisungen als Experte in diesem Projekt:
— Was ist noch valide und hält dem Standard stand?
— Was war suboptimal und würdest du heute anders liefern?
— Was fehlt komplett das nach neuen Anweisungen dazugehört?
Liefere danach die wichtigsten Punkte neu — optimiert, 
direkt verwendbar, auf aktuellem Niveau.

---

**Claude:**

The user wants me to search through all previous conversations in this project, identify key results, decisions, and outputs, then critically evaluate them against the current instructions as a "World-Class Analyst" expert role. Let me search the conversations first.
```
This block is not supported on your current device yet.
```

Now I have a good overview of the conversations in this project. Let me also search for a few more specific topics to make sure I have everything.
```
This block is not supported on your current device yet.
```

Now I have a comprehensive picture of all the conversations in this project. Let me also check if there are any more recent conversations I might have missed by looking at the most recent chats more carefully. The first chat I found is from 2026-06-07 (today) about the universal prompt and project migration. Let me also check for the café revival with "Hai" which is mentioned in the userMemories.

Based on the search results and userMemories, I can now do the comprehensive audit. Let me organize the main areas:

1. **Health & Performance** (Huberman/Patrick protocol, 3D scan, supplement stack, Hyrox)
2. **Business/Strategy** (Café initially rejected, now being revived with Hai; GmbH activation; Cyprus relocation)
3. **Digital Infrastructure** (Proton setup, then iCloud migration planned)
4. **DoktorLib** (Discovery automation pipeline)
5. **Claude Setup** (Project architecture, instructions)
6. **Insurance** (Allianz consolidation)
7. **Mattress** (TEMPUR decision)
8. **Minor topics** (tomatoes, dog grass-eating, running distance, photo cleanup, iPad accessories, washing clothes)

Now I'm starting the critical audit to see what's still valid and what needs updating.

The core health stack with Momentous supplements, the 2,800 kcal and 220g protein targets, and meal timing are all solid. The Hyrox 5-day plan structure is good but the 10-week progression never got finished. The DoktorLib automation architecture mapping Tally through Make to Salesforce/Notion and Dust KEB is still sound, just never executed. Cyprus economics hold up—€4,100/month budget with €30-35k starting capital. TEMPUR SmartCool is the right call. Allianz consolidation with three policies to add is still on track.

But the recent updates show the Fashion Brand is discontinued, while the Café is back on with Hai as a partner and planning kicks off Saturday June 14, 2026.

Now I'm seeing what actually needs to shift: the original Café analysis was thorough but led to rejection, so redoing it with Hai as a co-founder changes everything—I need to figure out the equity split, capital allocation, and who handles what. The DoktorLib automation stopped at the architecture stage and never moved to implementation. The Hyrox plan is incomplete. The business direction that recommended freelance sales consulting, performance coaching, and the fashion brand as three parallel tracks is now completely different with the fashion brand gone and the Café revived. I also need to confirm whether the iCloud DNS cutover actually happened. The biggest gap is a concrete Café business plan with Hai that covers roles, equity, capital split, and timeline, plus a revised strategic priority ranking given these changes.Ich habe alle 17 Conversations durchgesehen. Hier ist die ehrliche Bilanz.

---

## Audit: Was steht, was fällt, was fehlt

### ✅ Noch vollständig valide

**Health-Stack** — Die Kernentscheidungen halten: 2.800 kcal / 220g Protein, Momentous Complete Expert Stack + Sulforaphane Sunday Natural als Gap-Filler, D3/K2 2×/Woche hochdosiert, Meal-Timing um 05:00-Weckzeit herum. Die 3D-Scan-Daten (97 kg, 20,3% BF, 77,1 kg lean mass, 97,2 cm Waist) sind der richtige Baseline-Anker — solange kein neuer Scan vorliegt.

**Cyprus-Analyse** — Kernthese bleibt korrekt: 50%-Exemption gilt für Vertriebsrollen, Portugal IFICI nicht. Budget ~€4.100/Monat für zwei Personen + Hund ist realistisch, €30-35k Startkapital ausreichend. Zwei offene Items blockieren die Entscheidung weiter: EOR-Klärung bei beiden Arbeitgebern, Steuerberater mit DE/CY-Expertise wegen Exit-Besteuerung.

**TEMPUR-Entscheidung** — SmartCool 2× 90×200 (Medium Firm + Medium) bleibt die richtige Wahl. Keine Neuanalyse nötig.

**Allianz-Konsolidierung** — Logik stimmt: Haftpflicht, Hausrat, Rechtsschutz hinzufügen → 5-Policen-Schwelle → 20% Rabatt. Risikoversicherung bleibt unangetastet.

**DoktorLib-Automation** — Architektur (Tally → Make → SF + Notion → Dust KEB) ist solide. Problem: Sie wurde nie gebaut. Steht noch offen.

---

### ⚠️ Suboptimal — würde ich heute anders liefern

**Strategische Prioritätskarte** — Im Mai wurde "Freelance Sales Consulting + Performance Coaching + Fashion Brand" als Dreiklang empfohlen. Dieser Rahmen ist jetzt obsolet. Fashion Brand eingestellt, Café revived. Das war nie eine kohärente Synthese — es war eine Aufzählung von Optionen ohne echte Priorisierung nach Opportunity Cost. Was heute fehlt: eine klare strategische Position: Was ist der primäre Einkommenshebel? Was ist die Cyprus-kompatible Option? Was ist das parallele Projekt?

**Hyrox-Plan** — Der 5-Tage-Wochenplan war gut. Aber die 10-Wochen-Progression wurde angeboten und nie geliefert. Das ist ein halbfertiges Deliverable — nutzlos in der aktuellen Form, weil ohne Phasierung keine Fortschrittskontrolle möglich ist.

**Café-Erstanalyse (Mai 2026)** — Die Analyse war handwerklich korrekt, hat dich aber zur Ablehnung geführt — jetzt kommt das Projekt trotzdem zurück, mit Partner Hai. Das bedeutet: Die ursprüngliche Analyse hat den falschen Rahmen gehabt (Solo-Betrieb, kein Co-Founder, kein geteiltes Kapital). Das gesamte Profitabilitätsmodell muss unter den neuen Parametern neu berechnet werden.

**Proton→iCloud Migration** — Status unbestätigt. Entweder hast du den DNS-Cutover gemacht oder nicht — beides hat Konsequenzen. Das ist ein offenes operatives Risiko (falsche Zustellung, DNS-Split-Brain) das nicht in der Luft hängen sollte.

---

### ❌ Fehlt komplett

**Café mit Hai: Business-Frame** — Wer ist Hai, was bringt er mit (Kapital, Gastro-Erfahrung, Netzwerk, Zeit), welche Rolle nimmst du ein, wie ist die Gesellschaftsstruktur geplant, welches Vehikel (GmbH? Neue Gesellschaft? Stiller Betrieb?). Das ist die kritische Grundlage bevor die Planung am 14. Juni startet — ohne diesen Frame verhandelst du im Nebel.

**Strategische Neubewertung 2026** — Der aktuelle Zustand in einem Satz: Du hast einen Vollzeitjob, planst ein Café mit Partner, willst nach Cyprus, baust ein Health-System aus und hast zwei schlafende Gesellschaften. Das ist zuviel parallel ohne klare Hierarchie. Was ist primär, was ist Option, was ist Aufwand der kein Return liefert?

---

## Die wichtigsten Punkte — neu und direkt verwendbar

---

### 1. Strategische Prioritätshierarchie 2026 (Annahme [*])

[*] Annahme: Hauptziel bleibt Kapitalaufbau + Cyprus-Vorbereitung in 2–3 Jahren. Café mit Hai ist ein ernstgemeintes Projekt, kein Hobby.

**Primär / Einkommensschutz:**
DoktorLib-Job — läuft, zahlt, sichert. Keine strategische Energie außer der Automation die du ohnehin schon buildest.

**Aktives Aufbauprojekt mit Partner:**
Café mit Hai — hier liegt jetzt die meiste Energie. Einziger realistischer Weg zu einem zweiten signifikanten Einkommensstrom in Berlin, *wenn* die Partnerschaft die Risiken richtig verteilt. Muss vor dem 14. Juni strukturiert sein.

**Langfristig / optionserweiternd:**
Cyprus — kein Aktionismus, aber die zwei blockierenden Items (EOR + Steuerberater) endlich abarbeiten. Das dauert zusammen 2-3 Stunden echter Arbeit.

**Abgeschlossen / nicht weiter priorisieren:**
Fashion Brand. GmbH als consulting-Vehikel — erst relevant wenn der Job endet oder Cyprus konkreter wird.

---

### 2. Café mit Hai — was vor dem 14. Juni geklärt sein muss

Das sind keine netten Vorbereitungspunkte. Das sind Dealbreaker-Fragen die ihr vor dem ersten gemeinsamen Planungstag beantwortet haben solltet:

**Kapitalstruktur:** Wer bringt wie viel ein? Gleichmäßig oder asymmetrisch? Was ist die Untergrenze die ihr gemeinsam für ein realistisches Konzept braucht — meine Einschätzung aus der alten Analyse: mindestens €40-50k für einen kleinen Berlin-Betrieb mit Vorlaufkosten (Kaution 3 Monate, Umbau, Ausstattung, Anlaufverluste Monat 1-3).

**Rollenverteilung:** Wer führt operativ (steht im Laden), wer übernimmt kaufmännische Verantwortung? Mit deinem Vollzeitjob kannst du nicht Hauptoperator sein. Das muss Hai sein — oder ihr braucht von Tag 1 eine bezahlte Kraft.

**Gesellschaftsform:** Bestehende GmbH reaktivieren oder neue Gesellschaft mit Hai? Wichtig: Wenn Hai Mitgesellschafter wird, braucht ihr einen Gesellschaftervertrag mit klaren Exit-Regelungen bevor ihr einen Euro ausgegeben habt. Das ist nicht optional — Gastro-Partnerschaften scheitern häufiger am fehlenden Exit-Rahmen als an schlechter Performance.

**Konzept und Standort:** Friedrichshain oder Prenzlauer Berg war die alte Annahme. Stimmt das noch? Hat Hai bestehende Kontakte zu Vermietern oder Standorten?

---

### 3. Hyrox 10-Wochen-Progression — Struktur (fehlende Lieferung)

Da das der offenste unfertige Output ist: Hier die Phasierung als direkte Ergänzung zum bereits existierenden 5-Tage-Plan.

**Woche 1-3 — Aerobe Basis:** Zone 2 dominiert. Laufvolumen aufbauen von ~25 km/Woche auf ~35 km/Woche. Stationsgewichte moderat (80% Competition). Kein Tempo.

**Woche 4-6 — Schwelle entwickeln:** Erste Tempo-Einheiten. 3-5 km unter 5:30/km 2×/Woche. Hyrox-Simulation mit vollem Competition-Gewicht (Sled 102 kg). Brick-Training einführen: Direkt nach Sled in 400m-Run ohne Pause.

**Woche 7-9 — Race-Pace-Vorbereitung:** Eine vollständige Hyrox-Simulation pro Woche (alle 8 Stationen + 8×1 km). Ziel: unter 1:45h. Identifiziere deine schwächste Station — mit hoher Wahrscheinlichkeit Wall Balls oder Ski Erg aerob.

**Woche 10 — Taper:** Volumen -40%. Intensität erhalten. Letzte volle Simulation nicht später als 10 Tage vor Wettkampf.

Engpass bleibt aerobe Kapazität. Wenn du jetzt bei ~6:00/km bist, sind 5:30/km Race-Pace in Woche 7-8 realistisch — das bringt dich in den 1:35h-Korridor.

---

### 4. Cyprus — zwei offene Items, konkret

**EOR-Klärung:** Frag deinen Arbeitgeber direkt: "Unterstützt ihr Employer of Record Arrangements für Remote-Arbeit aus der EU?" Viele deutsche SaaS-Unternehmen haben das inzwischen über Deel, Remote.com oder ähnliche. Die Frage per se ist kein Risiko — sie zeigt nur dass du langfristig planst.

**Steuerberater:** Suchst du einen mit expliziter DE→CY-Erfahrung? Empfohlene Anlaufstellen: German Business Network Cyprus (Nicosia), KPMG Zypern hat ein deutschsprachiges Team. Wegen Exit-Besteuerung (§6 AStG) willst du jemanden der beide Seiten kennt — ein deutscher Steuberater ohne Cyprus-Erfahrung reicht hier nicht.

---

**Nächster Schritt:** Beantworte vor dem 14. Juni die fünf Café-Fragen (Kapital, Rollen, Gesellschaft, Standort, Konzept) — am besten schriftlich, damit ihr am Samstag auf Basis von Fakten plant statt von Enthusiasm. Ich kann dir dafür ein einseitiges Partner-Briefing bauen das ihr beide ausfüllt.

---

**Du:**

Wir haben dafür separate Projecte erstellt ist es trotzdem notwendig hier das zu optimieren?

---

**Claude:**

The user is asking whether it's necessary to optimize everything here in this project (🔍 RESEARCH), given that they have separate projects for each topic (Health, Café, Cyprus, etc.).

They have a point. This is the 🔍 RESEARCH project - its purpose is "Tiefenanalyse und Entscheidungsintelligenz zu jedem Thema." The health optimization belongs in 🧠 ME or ⚡ OPS, the Café belongs in its own project, Cyprus in another, etc.

So my answer should be: No, not fully necessary here. The migration prompt was designed to be run in each project individually. 

For this RESEARCH project specifically, I should focus on auditing and optimizing the analytical frameworks and research methodologies that live here—the topic-specific content like health protocols or the Café plan should be handled within their own dedicated projects where they'll actually be implemented.Nein. Der Migrations-Prompt war für Projekte gedacht die persistent inhaltliche Outputs haben — also wo die History das lebende Dokument ist.

Hier ist das Gegenteil der Fall: Dieses Projekt ist ein Analyse-Werkzeug, kein Wissensspeicher. Was hier entsteht wird anderswo genutzt — im Café-Projekt, im Health-Projekt, in Cyprus, etc.

Das einzige was hier optimiert werden müsste wäre die Anweisungslogik selbst — und die hast du heute schon mit den neuen Instructions überschrieben.

**Konsequenz:** Lauf den Migrations-Prompt in den Projekten wo die History tatsächlich weiterlebt. Café und Health zuerst — da sind die meisten persistenten Entscheidungen offen.

---

**Du:**

optimiere alles

---

**Claude:**

The user wants me to optimize everything in this RESEARCH project. But I just told them this is an analysis tool, not a knowledge store. The "optimize everything" request is vague - what exactly should I optimize here?

I think they want me to optimize the project instructions/setup for this RESEARCH project specifically. Let me think about what that means:

1. The current system prompt/instructions for this project define it as a "World-Class Analyst" role
2. The user preferences are already set
3. There's no persistent content to migrate here

But "optimiere alles" - they might mean:
1. Optimize the project instructions
2. Optimize the research methodology
3. Deliver all the optimized outputs I identified in my audit

Looking back at our conversation, I did a full audit and identified several optimization opportunities. The user then asked if it's necessary to optimize this project since they have separate projects for each topic, and I said no, this is just an analysis tool. But then they said "optimize everything" anyway - so they want me to go ahead and provide comprehensive optimizations across all the key areas I flagged, not just the ones I already mentioned.

They might be frustrated with my hesitation and just want all the optimized content delivered without the meta-discussion about where it belongs. The "alles" likely means they want the full treatment: the complete 10-week Hyrox progression plan, the full Café partner framework with Hai, concrete Cyprus action items, DoktorLib automation roadmap, and the strategic priority map - all the items I identified as needing optimization but didn't fully flesh out yet. I'm realizing the user wants a comprehensive master optimization document covering all active projects in one place—strategy, the café partnership framework, health protocols, Hyrox training, and the other initiatives—delivered efficiently without redundancy or meta-discussion.Alles auf einmal, kein Kommentar dazu wo es hingehört.

---

## Strategische Gesamtlage — Juni 2026

**Aktuelle Realität:** Vollzeitjob (Primäreinkommen, sicher), Café-Projekt mit Hai (aktiv ab 14.6.), Cyprus (geplant, 2 Blocker), Health/Hyrox (laufend), 2 schlafende Gesellschaften, Fashion Brand eingestellt.

**Prioritätshierarchie nach Opportunity Cost:**

1. DoktorLib — schützen, nicht optimieren außer der Automation
2. Café mit Hai — einziger realistischer zweiter Einkommensstrom in Berlin-Zeitrahmen
3. Cyprus — 2 konkrete Blocker abarbeiten, dann Entscheidung
4. Health/Hyrox — läuft, braucht nur Fertigstellung des Plans
5. GmbH — erst relevant wenn Job endet oder Cyprus konkret wird

---

## Café mit Hai — Vollständiger Pre-Planning Frame

**Fünf Fragen die vor dem 14. Juni schriftlich beantwortet sein müssen:**

Kapitaleinlage: Wer bringt was? Realistisches Mindestkapital für einen kleinen Berliner Betrieb mit 3 Monaten Anlaufpuffer: **€45.000–60.000** (Kaution 3 Monate ~€9k, Umbau €10-15k, Ausstattung €8-12k, Behörden/Lizenzen €2k, Anlaufverluste Monate 1–3 ~€10-15k). Wenn einer von euch signifikant mehr einbringt als der andere, braucht ihr eine asymmetrische Gewinnverteilung — das jetzt festlegen, nicht später.

Rollenverteilung: Du hast einen Vollzeitjob. Du kannst nicht operativer Hauptverantwortlicher sein. Das bedeutet: Hai führt den Laden, du übernimmst Finanzen/Steuer/Strategie. Wenn Hai das nicht will oder nicht kann, ist die Partnerschaft falsch strukturiert.

Gesellschaftsform: Deine bestehende GmbH als Betriebsgesellschaft reaktivieren ist die einfachste Option — aber nur wenn Hai als Mitgesellschafter eingetragen wird. Alternativ neue UG/GmbH gemeinsam gründen. Entscheidend: **Gesellschaftervertrag mit Exit-Klauseln** bevor der erste Euro ausgegeben wird. Standardregelung: Vorkaufsrecht der anderen Seite, Bewertungsformel (3× EBITDA oder Ertragswert), Abberufungsregeln bei Streit.

Standort: Hat Hai Kontakte oder konkrete Objekte? Friedrichshain vs. Prenzlauer Berg hat sehr unterschiedliche Mietkostendynamik — FXhain €18-25/m², PB €22-32/m². Für 40-50m² Laden: €900-1.600/Monat kalt. Das ist der größte Fixkostenhebel.

Konzept-Klarheit: Café-Bar (Kaffee + Abend-Alkohol) oder reines Café? Alkohol bedeutet Konzession (Gaststättenerlaubnis, nicht nur Gewerbeanmeldung), höheres Haftungsrisiko, aber 40-60% bessere Abendmarge. Entscheidung muss vor der Standortsuche fallen, weil sie die Flächenanforderungen bestimmt.

**Profitabilitätsrahmen (aktualisiert für Zwei-Personen-Betrieb):**

| Szenario | Umsatz/Monat | Wareneinsatz 28% | Miete | Personal | Fixkosten | GF-Gehalt je | Überschuss |
|---|---|---|---|---|---|---|---|
| Konservativ | €18.000 | €5.040 | €1.400 | €3.500 | €2.500 | €1.500 | €4.060 |
| Realistisch | €24.000 | €6.720 | €1.400 | €4.200 | €2.500 | €2.500 | €6.680 |
| Optimistisch | €32.000 | €8.960 | €1.400 | €5.500 | €2.500 | €3.500 | €10.140 |

[*Annahme: 40m², Friedrichshain, 1 Vollzeitkraft + Minijobber, keine Fremdfinanzierung]

Realistisches Szenario bedeutet: ~80 Deckungen/Tag bei €10 Durchschnittsbon oder ~55 bei €15. Das ist machbar in einem etablierten Kiez ab Monat 6.

---

## Health & Performance — Aktueller Optimierter Stand

**Unveränderter Kern:**
- 2.800 kcal / 220g Protein / 270g Carbs / 70g Fett
- Meal Timing: Shake 07:40 / Breakfast 09:00 / Lunch 13:00 / Dinner 19:00–19:30
- 14-Stunden-Nüchternfenster (19:30–09:00)

**Supplement Stack (final, keine Änderungen nötig):**
Momentous Complete Expert Stack + Whey Isolate + Multivitamin, D3 20.000 IU + K2 2×/Woche, Sunday Natural Sulforaphane. Stack ist vollständig — kein weiterer Bedarf.

**Einzige offene Frage:** Nächster 3D-Scan. Empfehlung: 12 Wochen nach dem letzten (29. Mai) = ca. Ende August. Vorher kein Adjustieren der Kalorien auf Basis von Gefühl.

---

## Hyrox — Vollständige 10-Wochen-Progression

Ausgangsbasis: 5 km bei ~6:00/km, Sled-Stärke überdurchschnittlich, aerobe Kapazität ist der Engpass.

**Woche 1–2 | Fundament**
- Mo: Kraft + Sled (80% Wettkampfgewicht), 60 min
- Di: Easy Run mit Hund 35 min (Zone 2, max. 6:30/km)
- Do: Hyrox Circuit 4 Stationen (Ski Erg, Sled Push, Burpee Broad Jump, Wall Balls), je 1 Runde + 400m Run zwischen Stationen
- Sa: Kraft + Rowing/Ski Erg, 55 min
- So: Zone 2 Lauf 40 min

**Woche 3–4 | Aerobe Basis aufbauen**
- Laufvolumen: +20% (Di und So je 5 min länger)
- Do: 6 Stationen Hyrox Circuit (volle Wettkampfgewichte einführen)
- Erstes Brick Training: Sled Pull → direkt 400m Run ohne Pause

**Woche 5–6 | Schwelle entwickeln**
- Di: 3×1 km bei 5:30/km Zieltempo, 90s Pause
- Do: Vollständige Hyrox Simulation 8 Stationen + je 1 km Run (Wettkampfgewichte)
- Zielzeit Week 6 Simulation: unter 1:50h
- Sa: Kraft-Focus Upper Body (Chest, Trizeps — deine Priorität)

**Woche 7–8 | Race-Pace-Spezifik**
- Di: 5 km Tempolauf Ziel 5:20/km
- Do: Hyrox Simulation mit Zeitnahme — Ziel unter 1:45h
- Schwächste Station identifizieren (erfahrungsgemäß Ski Erg oder Wall Balls aerob) → Extravolumen Samstag
- Brick Training 2× pro Woche

**Woche 9 | Peak**
- Letzte vollständige Simulation (nicht später als 10 Tage vor Wettkampf)
- Zielzeit: 1:35–1:40h
- Kein neues Volumen, keine neuen Übungen

**Woche 10 | Taper**
- Volumen –40%, Intensität gleich
- Kein Sled die letzten 5 Tage vor Wettkampf (Beinermüdung)
- Schlaf, Hydration, Carb-Loading Tag davor (+50g Carbs)

**Wettkampfstrategie:** Erste 2 km konservativ (6:10/km) — wer zu schnell startet, bricht in Woche 7–8 ein. Sled mit voller Intensität (Stärke ist dein Vorteil). Wall Balls rhythmisch, nicht maximal.

---

## Cyprus — Execution Roadmap

Zwei Blocker. Konkret.

**Blocker 1 — EOR-Klärung (diese Woche, 30 Minuten):**
E-Mail oder Slack an HR/deinen Manager: *"Ich denke langfristig über Remote-Arbeit aus dem EU-Ausland nach. Unterstützt DoktorLib EOR-Arrangements, z.B. über Deel oder Remote.com?"* Das ist keine Kündigung, kein Alarm. Es ist eine Frage die viele stellen. Antwort gibt dir die Planungsgrundlage.

**Blocker 2 — Steuerberater (diese Woche, 1 Stunde):**
Kontakt aufnehmen mit einem der folgenden: KPMG Limassol (deutschsprachiges Team vorhanden), PKF Cyprus, oder über die Deutsch-Zyprische Handelskammer. Konkrete Fragen: Exit-Besteuerung §6 AStG bei Wohnsitzaufgabe Deutschland, Behandlung GmbH-Beteiligungen nach Wegzug, optimaler Zeitpunkt der Ummeldung.

Sobald beide Fragen beantwortet sind, ist Cyprus keine Planung mehr sondern eine Entscheidung mit Datum.

---

## DoktorLib Automation — Execution Roadmap

Architektur steht seit Mai. Nie gebaut. Priorisierung jetzt nach Aufwand/Impact:

**Schritt 1 (1 Tag):** Tally-Formular bauen — Praxisstruktur, bestehende Software, IT-Infrastruktur, Labor-Partner, Geräteparks. Pflichtfelder definieren. DSGVO-konforme Datenverarbeitung aktivieren (Tally EU-Hosting, DPA vorhanden).

**Schritt 2 (2–3 Stunden):** Make-Automation: Tally-Submission → Salesforce (strukturierte Felder) + Notion (Datenbank-Eintrag parallel).

**Schritt 3 (1–2 Tage):** Dust-Agent für KEB-Generierung: System Prompt mit KEB-Struktur, SF-Daten als Input, Output = fertig formatiertes KEB-Dokument. Manuelle Excel-Übergabe entfällt.

Gesamtaufwand: ~1 Arbeitswoche. ROI: Jede Discovery spart 30–45 min manuelle Arbeit. Bei 20 Leads/Monat sind das 10–15 Stunden.

Wenn du willst bauen wir Schritt 1 jetzt — der Tally-Fragebogen braucht nur deine Bestätigung welche Felder Pflicht sind.

---

**Nächster Schritt:** Café-Partner-Briefing für den 14. Juni — ich baue dir ein einseitiges Dokument das ihr beide vor dem Meeting ausfüllt. Bringt euch in 20 Minuten auf denselben Informationsstand und verhindert dass ihr strategische Fragen auf der Gefühlsebene klärt.

---

