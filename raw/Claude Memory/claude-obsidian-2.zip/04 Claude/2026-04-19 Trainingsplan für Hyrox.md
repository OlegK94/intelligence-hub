---
date: 2026-04-19
tags: [claude]
---

# Trainingsplan für Hyrox

**Du:**

Trainingsplatz hyrox für mich

---

**Claude:**

```
This block is not supported on your current device yet.
```

Drei kurze Fragen, damit der Plan wirklich zu dir passt:

---

**Du:**

F: Was ist dein aktuelles Fitnesslevel?
A: Noch keine hyrox Erfahrung aber kraftsport 

F: Wie viele Tage pro Woche kannst du trainieren?
A: 4 Tage

F: Was ist dein Ziel?
A: Ersten Hyrox finishen

---

**Claude:**

Gutes Ausgangsprofil — Kraftbasis vorhanden, Ausdauer wird der Engpass sein. Hier ist dein Plan:

---

## HYROX TRAININGSPLAN — 4 Tage/Woche
**Horizont: 10–12 Wochen bis Wettkampf**

---

### STRUKTUR DER WOCHE

| Tag | Fokus |
|-----|-------|
| **Mo** | Kraft + Functional Strength |
| **Mi** | Lauf-Ausdauer |
| **Fr** | Hyrox-Simulation (Stationen) |
| **Sa** | Zone 2 Cardio + Mobility |

---

### TAG 1 — KRAFT + FUNCTIONAL (Mo)
*Ziel: Stationsübungen unter Last stabilisieren*

- Farmers Carry 3×30m (progressiv schwerer)
- Sandbag Squat 4×8
- Sled Push 4×20m (schwer)
- Wall Balls 3×15
- Burpee Broad Jumps 3×8
- Romanian Deadlift 3×10

**Dauer:** ~55 Min

---

### TAG 2 — LAUF-AUSDAUER (Mi)
*Ziel: 8 km laufen können, während du müde bist*

**Wochen 1–4:**
- 5 km Dauerlauf, moderates Tempo (Gespräch noch möglich)

**Wochen 5–8:**
- 2×3 km mit 2 Min Pause — etwas flottes Tempo

**Wochen 9–12:**
- 6–8 km Tempolauf + 400m-Intervalle (4–6×)

**Dauer:** ~40–50 Min

---

### TAG 3 — HYROX-SIMULATION (Fr)
*Ziel: Stationen kennen, Übergänge trainieren*

Führe 2–3 Stationen als Block aus, 1000m Lauf zwischen je Block:

**Block A:** SkiErg 500m → Sled Push 25m → Sled Pull 25m
**Block B:** Burpees Broad Jump 20m → Rowing 500m → Farmers Carry 2×24 kg / 50m
**Block C:** Wall Balls 20 Wdh → Sandbag Lunges 25m

*Keine Maschine? Ersetze SkiErg durch Battle Rope 45 Sek, Rowing durch Box Step-ups.*

**Dauer:** ~60 Min

---

### TAG 4 — ZONE 2 + MOBILITY (Sa)
*Ziel: aktive Erholung, aerobe Basis aufbauen*

- 30–45 Min lockeres Cardio (Fahrrad, Rudern, Joggen — Puls max. 135)
- 15 Min Mobility: Hüftöffner, Thorax-Rotation, Wadenrollen

---

### PROGRESSIVE BELASTUNG
| Wochen | Fokus |
|--------|-------|
| 1–3 | Technik & Basis aufbauen |
| 4–7 | Volumen erhöhen |
| 8–10 | Intensität + Wettkampftempo |
| 11–12 | Tapering, komplette Race-Simulation |

---

### DIE 3 WICHTIGSTEN HYROX-PRINZIPIEN FÜR DICH

1. **Nie im Sprint aus dem Lauf in die Station** — Puls kontrollieren, sonst brichst du bei Wall Balls ein
2. **Atemrhythmus bei Stationen** — besonders Sandbag Lunges und Burpees fressen Anfänger
3. **Sled Push ist das Kernproblem** — trainiere ihn wöchentlich, deine Kraftbasis hilft hier

---

**Nächster Schritt:** Hast du einen Wettkampftermin? Dann passe ich die Wochen-Periodisierung exakt darauf an.

---

**Du:**

Wie oft muss ich Schlitten schieben und ziehen mit wieviel kg

---

**Claude:**

## Sled Push & Pull — Hyrox-Spezifikationen

---

### IM WETTKAMPF

| | Push | Pull |
|--|------|------|
| **Distanz** | 25m × 2 = **50m gesamt** | 25m × 2 = **50m gesamt** |
| **Gewicht Männer** | 102 kg (Schlitten ~72 kg + 30 kg) | 102 kg |
| **Gewicht Frauen** | 72 kg | 72 kg |
| **Position im Rennen** | Station 2 | Station 3 |

> Das Gewicht = Schlitten + Gewichtsscheiben. Je nach Wettkampfstätte variiert das Schlittengewicht leicht — das Gesamtgewicht ist aber standardisiert.

---

### IM TRAINING

**Faustregel:** Lieber öfter mit weniger Gewicht als selten mit Maximalgewicht.

| Phase | Gewicht | Sets × Distanz |
|-------|---------|----------------|
| Wochen 1–3 | 60–70 kg | 4 × 20m |
| Wochen 4–7 | 80–90 kg | 4 × 25m |
| Wochen 8–10 | 100–110 kg | 3 × 25m + 1 Wettkampfsimulation |
| Wochen 11–12 | Wettkampfgewicht | 2 × 50m am Stück |

---

### WICHTIG FÜR DICH ALS KRAFTSPORTLER

Deine Beinbasis hilft — aber **Sled Push ist ein anderes Bewegungsmuster** als Squat oder Deadlift. Typische Fehler:

- Zu aufrecht → Kraft verpufft, Nacken überlastet → **Oberkörper 45° nach vorne**
- Zu breiter Griff → instabil → **Hände schulterbreit, Arme gestreckt**
- Schritt zu groß → verlierst Druck → **kurze, explosive Schritte**

Beim **Sled Pull** (Seil): Hand über Hand, Kern angespannt, nicht mit dem Rücken ziehen.

---

**Nächster Schritt:** Falls du kein Gym mit Schlitten hast — ich zeige dir die besten Ersatzübungen, die dasselbe Muster trainieren.

---

**Du:**

Ich hab 125kg schieben und ziehen geschafft 6-8 nach 100 wallballs mit 7 kg

---

**Claude:**

Das ist eine starke Leistung — deutlich über Wettkampfgewicht, nach Vorermüdung. Du bist konditionell besser aufgestellt als du dachst.

---

## Was das über dich aussagt

**Positiv:**
- Kraft ist kein limitierender Faktor beim Sled
- 7 kg Wall Ball ist Wettkampfgewicht (Männer = 6 kg, Frauen = 4 kg) — du trainierst schwerer
- Vorermüdung durch 100 Wall Balls und trotzdem 6–8 Runden → gute muskuläre Ausdauer

**Dein echter Engpass wird sein:**
- **Laufleistung** zwischen den Stationen
- **Kumulative Erschöpfung** über alle 8 Stationen + 8 km Lauf

---

## Plananpassung für dich

Da deine Kraftausdauer solide ist, verschiebe ich die Prioritäten:

| Fokus | Gewichtung |
|-------|------------|
| Laufaufbau | ↑↑ Hauptpriority |
| Zone 2 Cardio | ↑ mehr Volumen |
| Sled Training | ↓ Erhaltung reicht |
| Stationskraft | ↓ Basis ist da |

**Konkret:** Ersetze auf Tag 1 zwei Kraftübungen durch einen zusätzlichen 2–3 km Lauf direkt nach dem Training — simuliert Laufen auf müden Beinen.

---

## Deine realistische Zielzeit

Mit deinem Profil — Kraftbasis stark, Ausdauer noch im Aufbau — bei konsequentem 10-Wochen-Training:

**1:30h – 1:45h** ist realistisch und solide für den ersten Hyrox.

---

**Nächster Schritt:** Wie ist dein aktueller Laufstand? 5 km — welche Zeit ungefähr?

---

**Du:**

Wieviel muss ich laufen

---

**Claude:**

## Laufanteil beim Hyrox

---

### Im Wettkampf

**8 × 1 km Laufrunden** — je zwischen den Stationen.
**= 8 km Laufen gesamt**, verteilt über das gesamte Rennen.

Kein durchgehender Lauf — aber du startest jede Runde mit bereits müden Beinen.

---

### Was das in der Praxis bedeutet

Bei einer Zielzeit von **1:30–1:45h** musst du die 1 km Runden in roughly **5:30–7:00 Min/km** laufen können — **im ermüdeten Zustand.**

---

### Dein Lauftraining im Plan

| Tag | Einheit | Warum |
|-----|---------|-------|
| **Mi** | Dauerlauf 5–8 km | aerobe Basis aufbauen |
| **Mo** | 2–3 km nach Kraft | Laufen auf müden Beinen simulieren |
| **Sa** | 30–45 Min Zone 2 | Fettverbrennung, Erholung |

**Gesamtlaufvolumen pro Woche:** ~10–14 km

---

### Progression über 10 Wochen

| Wochen | Einheit Mittwoch |
|--------|-----------------|
| 1–3 | 4 km locker |
| 4–6 | 6 km moderat |
| 7–9 | 8 km + 1 km Intervalle |
| 10–12 | Race-Pace 8 km + Stationen danach |

---

### Die eine Einheit die den Unterschied macht

**Brick Training** — direkt aus der Station in den Lauf:

> 20 Wall Balls → sofort 1 km laufen → 25m Sled Push → sofort 1 km laufen → wiederholen

Das trainiert genau das, was Anfänger im Wettkampf killt: der Übergang.

---

**Nächster Schritt:** Sag mir deine aktuelle 5 km Zeit — dann kalkuliere ich dein genaues Lauftempo pro Zone.

---

**Du:**

5 km vermutlich 30 min

---

**Claude:**

Solider Ausgangspunkt. 6 Min/km ist eine ehrliche Basis — damit kannst du arbeiten.

---

## Was das für deinen Hyrox bedeutet

Bei 6 Min/km über 8 × 1 km = **~48 Min reine Laufzeit**
Stationen + Übergänge = ~45–55 Min
**Gesamtprognose: ~1:35–1:45h** ✅ Solides Ergebnis für den ersten Start

---

## Deine Zieltempo-Zonen

| Zone | Tempo | Wann |
|------|-------|------|
| **Wettkampftempo** | 6:00–6:30 Min/km | Hyrox-Runden anpeilen |
| **Dauerlauf (Mi)** | 6:30–7:00 Min/km | locker, Nase atmen möglich |
| **Zone 2 (Sa)** | 7:00–7:30 Min/km | Unterhaltungstempo |
| **Intervalle (ab Wo. 7)** | 5:00–5:30 Min/km | kurze 400–800m Einheiten |

---

## Laufplan konkret — 10 Wochen

| Wochen | Mittwoch | Montag (nach Kraft) |
|--------|----------|---------------------|
| 1–2 | 4 km @ 7:00 | 2 km auslaufen |
| 3–4 | 5 km @ 6:45 | 2 km @ 6:30 |
| 5–6 | 6 km @ 6:30 | 3 km @ 6:15 |
| 7–8 | 3×1 km @ 5:30 + 2 km locker | 3 km @ 6:00 |
| 9–10 | 8 km @ 6:15 | Brick Training |

---

## Dein realistisches Entwicklungspotenzial

10 Wochen konsequent → **5 km unter 27 Min** ist machbar.
Das bringt dich im Wettkampf auf **~5:30 Min/km** — spürbar bessere Endzeit.

---

**Nächster Schritt:** Willst du den kompletten 10-Wochen-Plan als fertiges Dokument — alle 4 Tage, alle Wochen, direkt verwendbar?

---

**Du:**

Schreib mir einen Tag Plan für hyrox mit kraftsport nimm soviel Tage wie es realistisch wäre neben einem Job und Hund

---

**Claude:**

Realistisch mit Job + Hund = **5 Tage, davon 1 Tag sehr kurz.** Kein Perfektionsplan — ein Plan der hält.

---

## WOCHENPLAN HYROX + KRAFT

| Tag | Inhalt | Dauer |
|-----|--------|-------|
| **Mo** | Kraft + Sled | 60 Min |
| **Di** | Lauf (mit Hund 🐕) | 35 Min |
| **Mi** | frei / aktive Erholung | — |
| **Do** | Hyrox-Simulation | 60 Min |
| **Fr** | frei | — |
| **Sa** | Kraft + Kondition | 55 Min |
| **So** | Zone 2 Lauf (mit Hund 🐕) | 40 Min |

---

## MONTAG — Kraft + Sled
*Gym | 60 Min*

- Sled Push 4×25m (progressiv bis Wettkampfgewicht)
- Sled Pull 4×25m
- Romanian Deadlift 4×8
- Farmers Carry 3×40m
- Wall Balls 3×15
- Core: Plank 3×45 Sek

---

## DIENSTAG — Lauf mit Hund
*Draußen | 35 Min*

- 5 km @ 6:45–7:00 Min/km
- Locker, Gespräch möglich
- Hund läuft mit → kein Ausrede-Tag

---

## DONNERSTAG — Hyrox Simulation
*Gym | 60 Min*

Ablauf als Circuit, 1 Min Pause zwischen Blöcken:

**Runde 1:**
→ 1 km Lauf @ 6:15 Min/km
→ SkiErg 500m (oder Battle Rope 45 Sek)
→ 1 km Lauf

**Runde 2:**
→ Sled Push 25m + Sled Pull 25m
→ 1 km Lauf

**Runde 3:**
→ Burpee Broad Jump 20m
→ Wall Balls 20 Wdh
→ 1 km Lauf

*Gesamtlauf: ~4 km, Stationen kombiniert*

---

## SAMSTAG — Kraft + Kondition
*Gym | 55 Min*

- Back Squat 4×6 (schwer)
- Sandbag Lunges 3×20m
- Seated Row / Rudern 3×12
- Box Step-ups mit Gewicht 3×12
- Finisher: 10 Wall Balls + 200m Lauf × 4 Runden

---

## SONNTAG — Zone 2 mit Hund
*Draußen | 40 Min*

- 5–6 km @ 7:00–7:30 Min/km
- Puls unter 135 — bewusst langsam
- Aktive Erholung, nicht Leistung

---

## WOCHENVOLUMEN

| Kategorie | Umfang |
|-----------|--------|
| Laufen | ~14–15 km |
| Krafteinheiten | 2× |
| Hyrox-spezifisch | 2× |
| Freie Tage | 2 (Mi + Fr) |

---

**Nächster Schritt:** Willst du das als 10-Wochen-Progressionsplan — also konkret was sich jede Woche steigert?

---

